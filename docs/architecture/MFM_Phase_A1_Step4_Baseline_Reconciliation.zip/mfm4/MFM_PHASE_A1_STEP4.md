# MFM Phase A.1 — Step 4
## Baseline Reconciliation & MainWindow Navigation Contract

Status: COMPLETE — audit/reconciliation only. No application logic changed.

## Purpose

Validate whether the unresolved MainWindow navigation handlers identified in
Step 3 exist elsewhere in the supplied v1.49 baseline before introducing any
new GUI navigation architecture.

## Findings

The current MainWindow `_build()` contains 15 command references for which no
`show_*` method exists in `MainWindow` and no corresponding implementation was
found elsewhere under `src/`:

- show_account_ledger
- show_accounting_audit
- show_accounting_entry
- show_accounting_reports
- show_ai
- show_assistant
- show_audit
- show_bank
- show_bank_import_matching
- show_export
- show_forecast
- show_system
- show_users
- show_voucher_documents
- show_year_end_closing

These are therefore unresolved GUI navigation references in the supplied
codebase.

## Important conclusion

No stub methods, placeholder screens, or speculative implementations are
being added in Step 4.

Doing so would hide a baseline inconsistency and would violate the Phase A.1
principle of preserving existing functionality before changing navigation.

The corresponding service capabilities do exist in several cases, including
accounting, bank, forecast, AI, assistant, export, audit, system and user
services. However, the presence of a service does NOT prove that a missing GUI
handler should be created automatically.

## Navigation contract for the next phase

The current 51 referenced `show_*` navigation targets are not yet treated as
the final product navigation.

The future Phase A navigation will consolidate these capabilities behind the
seven product areas:

Home
Work
Projects
Members
Finance
Reports
Administration

Therefore Step 4 deliberately stops at reconciliation.

## Safety decision

DO NOT:

- create 15 dummy handlers;
- delete the 15 buttons yet;
- modify services to satisfy GUI references;
- introduce a second navigation architecture;
- implement the seven-area navigation before MainWindow structure is stable.

## Next step

Phase A.1 Step 5 should establish the MainWindow command registry as a single,
explicit, testable structure. That registry should make every navigation target
visible and should become the controlled seam used later by Phase A's product
navigation consolidation.
