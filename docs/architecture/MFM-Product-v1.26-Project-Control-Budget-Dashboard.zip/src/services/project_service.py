class ProjectService:
    def __init__(self, repo):
        self.repo = repo

    def create(self, name, description="", status="Planned", budget=0):
        name = str(name).strip()
        if not name:
            raise ValueError("Project name is required.")
        budget = float(budget or 0)
        if budget < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.create(name, str(description).strip(), status, budget)

    def list(self):
        return self.repo.list()

    def count(self):
        return self.repo.count()

    def set_budget(self, project_id, amount):
        amount = float(amount)
        if amount < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.set_budget(project_id, amount)

    def budget(self, project_id):
        return self.repo.project_budget(project_id)

    def create_activity(self, project_id, name, description="", activity_date=None,
                        status="Planned", budget=0):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")
        name=str(name).strip()
        if not name: raise ValueError("Activity name is required.")
        budget=float(budget or 0)
        if budget < 0: raise ValueError("Activity budget cannot be negative.")
        return self.repo.create_activity(project_id,name,str(description).strip(),
                                          activity_date,status,budget)

    def activities(self, project_id):
        return self.repo.list_activities(project_id)

    def update_activity(self, activity_id, **fields):
        if "budget" in fields and float(fields["budget"]) < 0:
            raise ValueError("Activity budget cannot be negative.")
        return self.repo.update_activity(activity_id,**fields)

    def activity_summary(self, project_id):
        return dict(self.repo.project_activity_summary(project_id))

    def financial_tracking(self, project_id):
        return self.repo.project_financial_tracking(project_id)

    def expense_lines(self, project_id):
        return self.repo.project_expense_lines(project_id)

    def activity_financials(self, project_id):
        return self.repo.activity_actuals(project_id)

    def activity_financial_detail(self, project_id):
        rows=self.repo.activity_financial_detail(project_id)
        result=[]
        for r in rows:
            budget=float(r["budget"] or 0)
            actual=round(float(r["actual"] or 0),2)
            result.append({
                "id":r["id"],"name":r["name"],"status":r["status"],
                "budget":budget,"actual":actual,
                "variance":round(budget-actual,2),
                "utilization":round(actual/budget*100,2) if budget else 0.0
            })
        return result

    def project_control_dashboard(self, project_id):
        data=self.repo.project_control_dashboard(project_id)
        data["activities"]=[
            {
                **dict(a),
                "budget":float(a["budget"] or 0),
                "actual":round(float(a["actual"] or 0),2),
                "variance":round(float(a["budget"] or 0)-float(a["actual"] or 0),2),
                "utilization":round(float(a["actual"] or 0)/float(a["budget"])*100,2)
                    if float(a["budget"] or 0) else 0.0
            }
            for a in data["activities"]
        ]
        return data
