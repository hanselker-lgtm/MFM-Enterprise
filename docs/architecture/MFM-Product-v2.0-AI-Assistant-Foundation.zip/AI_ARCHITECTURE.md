# MFM AI Architecture — v2.0 Foundation

## Principle

The AI layer is a consumer of MFM's operational data. It is not a governance
document generator and it does not replace the accounting, project, membership,
banking or permission systems.

## Current v2.0 boundary

The current assistant is read-only. It can:
- collect structured operational context;
- identify simple data-driven conditions;
- present prioritized insights.

It cannot:
- post accounting entries;
- edit members or projects;
- delete records;
- approve payments;
- change permissions;
- make autonomous business decisions.

## Future LLM adapter

A future LLM integration should receive structured context from `AIService`
and return explanations, summaries, questions and recommendations. Any
write operation should remain behind explicit application services and
permission checks.
