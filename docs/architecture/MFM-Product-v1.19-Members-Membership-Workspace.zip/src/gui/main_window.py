import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import date

class MainWindow:
    def __init__(self, context):
        self.ctx = context
        self.root = tk.Tk()
        self.root.title("MFM — MaritimForeningsManager")
        self.root.geometry("1100x700")
        self.current_user = None
        self._login()

    def _login(self):
        win = tk.Toplevel(self.root)
        win.title("MFM Login")
        win.geometry("360x220")
        win.transient(self.root)
        win.grab_set()

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="MFM Login", font=("Segoe UI", 16, "bold")).pack(pady=(0,12))
        ttk.Label(frame, text="Username").pack(anchor="w")
        username = ttk.Entry(frame)
        username.pack(fill="x", pady=(0,8))
        ttk.Label(frame, text="Password").pack(anchor="w")
        password = ttk.Entry(frame, show="*")
        password.pack(fill="x")

        def do_login():
            user = self.ctx.users.authenticate(username.get(), password.get())
            if not user:
                messagebox.showerror("MFM Login", "Invalid username or password.")
                return
            self.current_user = user
            win.destroy()
            self._build()

        ttk.Button(frame, text="Login", command=do_login).pack(pady=14)
        win.protocol("WM_DELETE_WINDOW", self.root.destroy)
        username.focus_set()
        self.root.withdraw()

        def on_close():
            if win.winfo_exists():
                win.destroy()
            self.root.destroy()
        win.protocol("WM_DELETE_WINDOW", on_close)
        self.root.wait_window(win)
        if self.current_user:
            self.root.deiconify()

    def _build(self):
        top = ttk.Frame(self.root, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text="MFM — Management & Intelligence", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Button(top, text="Refresh", command=self.refresh).pack(side="right")
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(top, textvariable=self.search_var, width=35)
        search_entry.pack(side="right", padx=8)
        ttk.Button(top, text="Search", command=self.run_search).pack(side="right")
        search_entry.bind("<Return>", lambda event: self.run_search())

        nav = ttk.Frame(self.root, padding=(12,0))
        nav.pack(fill="x")
        for text, command in [
            ("Dashboard", self.show_dashboard),
            ("Projects", self.show_projects),
            ("Tasks", self.show_tasks),
            ("Risks", self.show_risks),
            ("Decisions", self.show_decisions),
            ("Accounting", self.show_accounting),
            ("Members", self.show_members),
            ("Bank", self.show_bank),
            ("Users", self.show_users),
            ("System", self.show_system),
            ("Export", self.show_export),
            ("Audit", self.show_audit),
            ("AI Assistant", self.show_ai),
            ("MFM Assistant", self.show_assistant),
            ("Bank Import & Matching", self.show_bank_import_matching),
            ("Year-End & Closing", self.show_year_end_closing),
            ("Financial Dashboard", self.show_financial_dashboard),
            ("Accounting Audit", self.show_accounting_audit),
            ("Voucher Documents", self.show_voucher_documents),
            ("Account Ledger", self.show_account_ledger),
            ("Journals & Vouchers", self.show_journals),
            ("Accounting Entry", self.show_accounting_entry),
            ("Accounting & Reports", self.show_accounting_reports),
            ("Forecast", self.show_forecast),
        ]:
            ttk.Button(nav, text=text, command=command).pack(side="left", padx=(0,6))

        self.body = ttk.Frame(self.root, padding=12)
        self.body.pack(fill="both", expand=True)
        self.show_dashboard()

def allowed(self, code):
    return self.ctx.permissions.can(self.current_user, code)

def denied(self):
    messagebox.showwarning("MFM Access", "You do not have permission for this function.")

    def clear(self):
        for child in self.body.winfo_children():
            child.destroy()

    def card(self, parent, title, value, row, col):
        f = ttk.LabelFrame(parent, text=title, padding=18)
        f.grid(row=row, column=col, sticky="nsew", padx=6, pady=6)
        ttk.Label(f, text=str(value), font=("Segoe UI", 22, "bold")).pack()
        return f

def show_dashboard(self):
    self.clear()
    ttk.Label(self.body, text="Management Dashboard", font=("Segoe UI", 18, "bold")).pack(anchor="w")

    snapshot = self.ctx.management.snapshot()
    grid = ttk.Frame(self.body)
    grid.pack(fill="x", pady=12)
    for c in range(4):
        grid.columnconfigure(c, weight=1)

    cards = [
        ("Projects", snapshot["projects"]),
        ("Open Tasks", snapshot["open_tasks"]),
        ("Open Risks", snapshot["open_risks"]),
        ("Pending Decisions", snapshot["pending_decisions"]),
        ("Members", snapshot["members"]),
        ("Open Invoices", snapshot["open_invoices"]),
        ("Unmatched Bank", snapshot["unmatched_bank"]),
        ("Result", f"{snapshot['result']:,.2f}"),
    ]
    for i, (title, value) in enumerate(cards):
        self.card(grid, title, value, i // 4, i % 4)

    ttk.Label(self.body, text="Attention Required", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(12, 6))
    attention = self.ctx.management.attention_items()
    tree = ttk.Treeview(self.body, columns=("priority","item"), show="headings", height=6)
    tree.heading("priority", text="Priority")
    tree.heading("item", text="Item")
    tree.column("priority", width=110)
    tree.column("item", width=700)
    for priority, item in attention:
        tree.insert("", "end", values=(priority, item))
    tree.pack(fill="x")

    ttk.Separator(self.body).pack(fill="x", pady=14)
    ttk.Label(
        self.body,
        text=f"Income {snapshot['income']:,.2f}  |  Expenses {snapshot['expenses']:,.2f}  |  Result {snapshot['result']:,.2f}",
        font=("Segoe UI", 11, "bold")
    ).pack(anchor="w")

    def table(self, columns, rows):
        tree = ttk.Treeview(self.body, columns=columns, show="headings")
        for c in columns:
            tree.heading(c, text=c.replace("_"," ").title())
            tree.column(c, width=180)
        for row in rows:
            tree.insert("", "end", values=[row[c] for c in columns])
        tree.pack(fill="both", expand=True, pady=10)
        return tree

    def show_projects(self):
        if not self.allowed("projects.view"):
            self.denied()
            return
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Projects", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="Project Finance", command=self.show_project_finance).pack(side="right", padx=(0,6))
        ttk.Button(head, text="New Project", command=self.new_project).pack(side="right")
        self.table(["id","name","status","budget"], self.ctx.projects.list())


def show_project_finance(self):
    self.clear()
    ttk.Label(self.body, text="Project Finance", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    projects = self.ctx.projects.list()
    if not projects:
        ttk.Label(self.body, text="Create a project first.").pack(anchor="w", pady=10)
        return
    project_names = {str(p["id"]): p["name"] for p in projects}
    selected = tk.StringVar(value=str(projects[0]["id"]))
    row = ttk.Frame(self.body); row.pack(fill="x", pady=10)
    ttk.Label(row, text="Project:").pack(side="left")
    combo = ttk.Combobox(row, textvariable=selected, values=list(project_names.keys()), state="readonly", width=10)
    combo.pack(side="left", padx=6)

    output = ttk.LabelFrame(self.body, text="Budget vs Actual", padding=12)
    output.pack(fill="x", pady=10)

    def refresh():
        for w in output.winfo_children(): w.destroy()
        pid = int(selected.get())
        result = self.ctx.accounting.project_budget_vs_actual(pid)
        ttk.Label(output, text=f"Budget: {result['budget']:,.2f}").pack(anchor="w")
        ttk.Label(output, text=f"Actual: {result['actual']:,.2f}").pack(anchor="w")
        ttk.Label(output, text=f"Variance: {result['variance']:,.2f}").pack(anchor="w")
        ttk.Label(output, text=f"Utilization: {result['utilization']:.1f}%").pack(anchor="w")

    ttk.Button(row, text="Refresh", command=refresh).pack(side="left")
    refresh()

    def new_project(self):
        if not self.allowed("projects.edit"):
            self.denied()
            return
        name = simpledialog.askstring("New Project", "Project name:")
        if not name: return
        try:
            self.ctx.projects.create(name)
            self.show_projects()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_tasks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Tasks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Task", command=self.new_task).pack(side="right")
        self.table(["id","title","status","due_date","owner"], self.ctx.tasks.list())

    def new_task(self):
        title = simpledialog.askstring("New Task", "Task title:")
        if not title: return
        try:
            self.ctx.tasks.create(title)
            self.show_tasks()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_risks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Risks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Risk", command=self.new_risk).pack(side="right")
        self.table(["id","title","severity","status","owner"], self.ctx.risks.list())

    def new_risk(self):
        title = simpledialog.askstring("New Risk", "Risk title:")
        if not title: return
        try:
            self.ctx.risks.create(title)
            self.show_risks()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_decisions(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Decisions", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Decision", command=self.new_decision).pack(side="right")
        self.table(["id","title","status","owner"], self.ctx.decisions.list())

    def new_decision(self):
        title = simpledialog.askstring("New Decision", "Decision title:")
        if not title: return
        try:
            self.ctx.decisions.create(title)
            self.show_decisions()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))


def show_accounting(self):
    self.clear()
    ttk.Label(self.body, text="Accounting", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    buttons = ttk.Frame(self.body)
    buttons.pack(fill="x", pady=8)
    ttk.Button(buttons, text="Chart of Accounts", command=self.show_accounts).pack(side="left", padx=(0,6))
    ttk.Button(buttons, text="Journals", command=self.show_journals).pack(side="left", padx=(0,6))
    ttk.Button(buttons, text="Trial Balance", command=self.show_trial_balance).pack(side="left")
    ttk.Label(self.body, text="Accounting Core v0.1: balanced double-entry journals and trial balance.").pack(anchor="w", pady=10)

def show_accounts(self):
    self.clear()
    head = ttk.Frame(self.body); head.pack(fill="x")
    ttk.Label(head, text="Chart of Accounts", font=("Segoe UI", 16, "bold")).pack(side="left")
    ttk.Button(head, text="New Account", command=self.new_account).pack(side="right")
    self.table(["number","name","account_type"], self.ctx.accounting.accounts())

def new_account(self):
    number = simpledialog.askstring("New Account", "Account number:")
    if not number: return
    name = simpledialog.askstring("New Account", "Account name:")
    if not name: return
    account_type = simpledialog.askstring(
        "New Account", "Type (Asset, Liability, Income, Expense):",
        initialvalue="Expense")
    try:
        self.ctx.accounting.create_account(number, name, account_type)
        self.show_accounts()
    except Exception as e:
        messagebox.showerror("MFM Accounting", str(e))

def show_journals(self):
    self.clear()
    head = ttk.Frame(self.body); head.pack(fill="x")
    ttk.Label(head, text="Posted Journals", font=("Segoe UI", 16, "bold")).pack(side="left")
    ttk.Label(self.body, text="Journal entry creation UI is the next accounting increment.").pack(anchor="w", pady=8)
    self.table(["journal_no","journal_date","description","status"], self.ctx.accounting.journals())

def show_trial_balance(self):
    self.clear()
    ttk.Label(self.body, text="Trial Balance", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    self.table(["number","name","debit","credit"], self.ctx.accounting.trial_balance())

    def refresh(self):
        self.show_dashboard()

    def run(self):
        self.root.mainloop()


    def show_financial_dashboard(self):
        self.clear()
        ttk.Label(
            self.body, text="Financial Reporting & Management Dashboard",
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w")
        ttk.Label(
            self.body,
            text="Overblik over indtægter, omkostninger, resultat og balance."
        ).pack(anchor="w", pady=(2, 10))

        controls = ttk.Frame(self.body)
        controls.pack(fill="x", pady=6)

        ttk.Label(controls, text="Fra:").pack(side="left")
        start = ttk.Entry(controls, width=12)
        start.pack(side="left", padx=4)
        ttk.Label(controls, text="Til:").pack(side="left")
        end = ttk.Entry(controls, width=12)
        end.pack(side="left", padx=4)

        cards = ttk.Frame(self.body)
        cards.pack(fill="x", pady=10)

        values = {}
        for key, title in [
            ("revenue","Indtægter"),
            ("expenses","Omkostninger"),
            ("net_result","Årets resultat"),
            ("assets","Aktiver"),
            ("liabilities","Forpligtelser"),
            ("equity","Egenkapital")
        ]:
            frame = ttk.LabelFrame(cards, text=title)
            frame.pack(side="left", fill="x", expand=True, padx=3)
            label = ttk.Label(frame, text="0,00", font=("Segoe UI", 14, "bold"))
            label.pack(padx=8, pady=10)
            values[key] = label

        tree = ttk.Treeview(
            self.body,
            columns=("number","name","amount"),
            show="headings"
        )
        for col, title, width in [
            ("number","Konto",100),
            ("name","Navn",300),
            ("amount","Beløb",150)
        ]:
            tree.heading(col, text=title)
            tree.column(col, width=width)
        tree.pack(fill="both", expand=True, pady=8)

        def refresh():
            r = self.ctx.accounting.financial_dashboard(
                start.get().strip() or None,
                end.get().strip() or None
            )
            for k, label in values.items():
                label.config(text=f'{r[k]:,.2f}')
            for item in tree.get_children():
                tree.delete(item)
            for row in r["income_accounts"]:
                tree.insert("", "end", values=(
                    row["number"], row["name"], f'{row["amount"]:,.2f}'
                ))
            for row in r["expense_accounts"]:
                tree.insert("", "end", values=(
                    row["number"], row["name"], f'-{row["amount"]:,.2f}'
                ))

        ttk.Button(controls, text="Opdater", command=refresh).pack(side="left", padx=6)
        refresh()


def _mfm_member_clear(self):
    for child in self.body.winfo_children():
        child.destroy()

def _mfm_show_members(self):
    self._mfm_member_clear()
    self.ctx.members.refresh_invoice_statuses()

    ttk.Label(self.body, text="Members & Memberships",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,
              text="Medlemmer, medlemskaber, kontingenter, fakturaer og betalinger."
              ).pack(anchor="w",pady=(2,10))

    summary=self.ctx.members.summary()
    cards=ttk.Frame(self.body); cards.pack(fill="x",pady=6)
    for title,key in [
        ("Medlemmer","members"),("Aktive","active_members"),
        ("Aktive medlemskaber","active_memberships"),
        ("Åbne fakturaer","open_invoices"),
        ("Udestående","outstanding")
    ]:
        f=ttk.LabelFrame(cards,text=title)
        f.pack(side="left",fill="x",expand=True,padx=3)
        value=summary[key]
        txt=f"{float(value):,.2f}" if key=="outstanding" else str(value)
        ttk.Label(f,text=txt,font=("Segoe UI",13,"bold")).pack(padx=8,pady=8)

    toolbar=ttk.Frame(self.body); toolbar.pack(fill="x",pady=6)
    search=tk.StringVar()
    ttk.Label(toolbar,text="Søg:").pack(side="left")
    ttk.Entry(toolbar,textvariable=search,width=30).pack(side="left",padx=5)

    tree=ttk.Treeview(self.body,
        columns=("no","name","email","phone","status","joined"),
        show="headings")
    for c,t,w in [
        ("no","Medlemsnr.",100),("name","Navn",240),("email","E-mail",220),
        ("phone","Telefon",130),("status","Status",100),("joined","Indmeldt",110)
    ]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=6)

    selected_id={"value":None}

    def load():
        for x in tree.get_children(): tree.delete(x)
        rows=self.ctx.members.search(search.get()) if search.get().strip() else self.ctx.members.members()
        for r in rows:
            tree.insert("", "end", iid=str(r["id"]), values=(
                r["member_no"],f'{r["first_name"]} {r["last_name"]}',
                r["email"],r["phone"],r["status"],r["joined_date"] or ""
            ))

    def new_member():
        win=tk.Toplevel(self.root); win.title("Nyt medlem"); win.geometry("420x430")
        fields={}
        for label,key in [
            ("Medlemsnr.","member_no"),("Fornavn","first_name"),("Efternavn","last_name"),
            ("E-mail","email"),("Telefon","phone"),("Adresse","address"),
            ("Postnr.","postal_code"),("By","city"),("Indmeldelsesdato","joined_date")
        ]:
            ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
            e=ttk.Entry(win); e.pack(fill="x",padx=15); fields[key]=e
        fields["joined_date"].insert(0,date.today().isoformat())
        def save():
            try:
                self.ctx.members.create_member(
                    fields["member_no"].get(),fields["first_name"].get(),fields["last_name"].get(),
                    **{k:v.get() for k,v in fields.items() if k not in ("member_no","first_name","last_name")}
                )
                win.destroy(); load()
            except Exception as exc:
                messagebox.showerror("Medlem",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=14)

    def membership():
        sel=tree.selection()
        if not sel: return
        member_id=int(sel[0])
        types=self.ctx.members.membership_types()
        if not types:
            messagebox.showwarning("Medlemskab","Opret først en medlemskabstype.")
            return
        win=tk.Toplevel(self.root); win.title("Tilknyt medlemskab"); win.geometry("400x220")
        mapping={f'{x["name"]} — {float(x["annual_fee"]):,.2f}':x for x in types}
        var=tk.StringVar(value=list(mapping)[0])
        ttk.Label(win,text="Medlemskabstype").pack(anchor="w",padx=15,pady=8)
        ttk.Combobox(win,textvariable=var,values=list(mapping),state="readonly").pack(fill="x",padx=15)
        ttk.Label(win,text="Startdato").pack(anchor="w",padx=15,pady=(8,2))
        start=tk.Entry(win); start.pack(fill="x",padx=15); start.insert(0,date.today().isoformat())
        def save():
            try:
                self.ctx.members.add_membership(member_id,mapping[var.get()]["id"],start.get())
                win.destroy(); load()
            except Exception as exc: messagebox.showerror("Medlemskab",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=12)

    def invoice():
        sel=tree.selection()
        if not sel: return
        memberships=[m for m in self.ctx.members.memberships() if m["id"] and m["member_no"]==tree.item(sel[0])["values"][0]]
        if not memberships:
            messagebox.showwarning("Faktura","Medlemmet har intet aktivt medlemskab.")
            return
        m=memberships[0]
        self.ctx.members.invoice_membership(m["id"],m["id"] if False else
            next(x["id"] for x in self.ctx.members.repo.list_memberships() if x["member_no"]==m["member_no"] and x["membership_type"]==m["membership_type"]),
            float(m["annual_fee"]))
        load()

    def open_member():
        sel=tree.selection()
        if not sel: return
        member_id=int(sel[0])
        member=self.ctx.members.member(member_id)
        invoices=self.ctx.members.member_invoices(member_id)
        win=tk.Toplevel(self.root); win.title("Medlemsdetaljer"); win.geometry("850x500")
        ttk.Label(win,text=f'{member["member_no"]} — {member["first_name"]} {member["last_name"]}',
                  font=("Segoe UI",14,"bold")).pack(anchor="w",padx=12,pady=10)
        ttk.Label(win,text=f'{member["email"]} | {member["phone"]} | {member["address"]}, {member["postal_code"]} {member["city"]}').pack(anchor="w",padx=12)
        inv=ttk.Treeview(win,columns=("no","date","due","amount","paid","status"),show="headings")
        for c,t,w in [("no","Faktura",80),("date","Dato",100),("due","Forfald",100),("amount","Beløb",100),("paid","Betalt",100),("status","Status",130)]:
            inv.heading(c,text=t); inv.column(c,width=w)
        inv.pack(fill="both",expand=True,padx=12,pady=12)
        for r in invoices:
            status=self.ctx.members.invoice_status(r)
            inv.insert("", "end", values=(r["invoice_no"],r["invoice_date"],r["due_date"],
                f'{float(r["amount"]):,.2f}',f'{float(r["paid_amount"]):,.2f}',status))

    ttk.Button(toolbar,text="Nyt medlem",command=new_member).pack(side="left",padx=4)
    ttk.Button(toolbar,text="Tilknyt medlemskab",command=membership).pack(side="left",padx=4)
    ttk.Button(toolbar,text="Opret kontingentfaktura",command=invoice).pack(side="left",padx=4)
        ttk.Button(toolbar,text="Vis detaljer",command=open_member).pack(side="left",padx=4)
    ttk.Button(toolbar,text="Opdater",command=load).pack(side="left",padx=4)
    search.bind("<KeyRelease>",lambda e:load())
    tree.bind("<Double-1>",lambda e:open_member())
    load()

MainWindow._mfm_member_clear=_mfm_member_clear
MainWindow.show_members=_mfm_show_members
