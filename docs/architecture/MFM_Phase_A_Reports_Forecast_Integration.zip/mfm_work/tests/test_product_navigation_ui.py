import ast
from pathlib import Path

from src.gui.main_window import MainWindow

MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def _main_window():
    tree = ast.parse(MAIN_WINDOW.read_text(encoding="utf-8"))
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")


def test_build_uses_product_navigation_not_flat_command_registry():
    cls = _main_window()
    build = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_build")
    source = ast.unparse(build)
    assert "product_navigation_contract" in source
    assert "show_product_area" in source
    assert "command_registry" not in source


def test_product_area_handler_exists():
    cls = _main_window()
    methods = {n.name for n in cls.body if isinstance(n, ast.FunctionDef)}
    assert "show_product_area" in methods


def test_product_navigation_contains_seven_top_level_areas():
    ns = {}
    exec(compile(ast.parse(MAIN_WINDOW.read_text(encoding="utf-8")), str(MAIN_WINDOW), "exec"), ns)
    areas = [area for area, _ in ns["MainWindow"].product_navigation_contract()]
    assert areas == ["Home", "Work", "Projects", "Members", "Finance", "Reports", "Administration"]


def test_product_navigation_tracks_active_area_in_top_level_buttons():
    tree = ast.parse(MAIN_WINDOW.read_text(encoding="utf-8"))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")
    build = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_build")
    build_source = ast.unparse(build)
    assert "product_nav_buttons" in build_source

    handler = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "show_product_area")
    handler_source = ast.unparse(handler)
    assert "current_product_area" in handler_source
    assert "product_nav_buttons" in handler_source
    assert "✓" in handler_source


def test_forecast_is_registered_in_reports():
    registry = dict(MainWindow.command_registry())
    assert registry["Forecast"] == "show_forecast"
    assert "show_forecast" in dict(MainWindow.product_navigation_contract())["Reports"]


def test_forecast_workspace_uses_existing_forecast_service():
    source = MAIN_WINDOW.read_text(encoding="utf-8")
    assert "self.ctx.forecast.forecast" in source
    assert "Financial Forecast" in source
