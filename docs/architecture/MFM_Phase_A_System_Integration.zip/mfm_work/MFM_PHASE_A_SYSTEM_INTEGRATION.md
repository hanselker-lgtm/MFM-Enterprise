# MFM Phase A — System Integration

## Purpose
Expose the existing `SystemService` settings capability through the Administration area.

## Change
Added `MainWindow.show_system()` using the existing `ctx.system.get_setting()` and `ctx.system.set_setting()` APIs.

The screen currently exposes the existing `company_name` setting and requires the already-defined `system.settings` permission.

No new database table, service, repository, permission model, or business rule was introduced.

## Navigation
Administration now contains:
- Export
- System

## Validation
Targeted GUI/navigation/export/workflow tests: **30 passed**.

A broader run including the core suite was started but exceeded the execution-time limit after 39 tests had reported success; therefore the full 71-test baseline is not claimed here.
