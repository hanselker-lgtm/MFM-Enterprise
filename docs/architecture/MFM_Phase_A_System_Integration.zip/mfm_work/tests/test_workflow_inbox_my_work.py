import tempfile
from pathlib import Path

from src.application.context import ApplicationContext
from src.database.db import Database
from src.database.schema import initialize_schema


def _context():
    tmp = tempfile.TemporaryDirectory()
    db = Database(Path(tmp.name) / "test.db")
    initialize_schema(db)
    return tmp, db, ApplicationContext(db)


def test_inbox_is_open_and_unassigned_only():
    tmp, db, ctx = _context()
    try:
        ctx.projects.create("Test Project")
        ctx.projects.create_project_task(1, "Inbox task", assigned_to="", status="Open")
        ctx.projects.create_project_task(1, "Assigned task", assigned_to="test-user", status="Open")
        ctx.projects.create_project_task(1, "Closed task", assigned_to="", status="Closed")
        rows = ctx.projects.work_intake_inbox()["items"]
        assert [r["title"] for r in rows] == ["Inbox task"]
    finally:
        tmp.cleanup()


def test_assignment_moves_task_from_inbox_to_my_work():
    tmp, db, ctx = _context()
    try:
        ctx.projects.create("Test Project")
        task_id = ctx.projects.create_project_task(1, "Inbox task", assigned_to="", status="Open")
        assert any(r["id"] == task_id for r in ctx.projects.work_intake_inbox()["items"])

        ctx.projects.triage_work_item(task_id, "test-user", None, None)

        assert all(r["id"] != task_id for r in ctx.projects.work_intake_inbox()["items"])
        assert any(r["id"] == task_id for r in ctx.projects.personal_work_queue("test-user")["tasks"])
    finally:
        tmp.cleanup()
