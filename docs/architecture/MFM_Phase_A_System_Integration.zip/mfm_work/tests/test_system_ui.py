from src.gui.main_window import MainWindow


def test_system_is_registered_in_administration():
    registry = dict(MainWindow.command_registry())
    assert registry["System"] == "show_system"
    assert "show_system" in dict(MainWindow.product_navigation_contract())["Administration"]


def test_system_navigation_requires_existing_permission():
    item = next(item for item in MainWindow.navigation_model() if item.command == "show_system")
    assert item.permission_code == "system.settings"
