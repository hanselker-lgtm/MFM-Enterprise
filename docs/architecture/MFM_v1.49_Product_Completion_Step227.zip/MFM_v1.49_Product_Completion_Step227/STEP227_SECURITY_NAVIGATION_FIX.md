# MFM v1.49 Product Completion — Step 227

## Finding
The product-navigation contract assigned `dashboard.view` to both `show_dashboard` and `show_financial_dashboard`, but the two entry-point methods did not enforce that permission themselves.

Because the canonical Home and Reports product-area buttons call those methods directly, the GUI navigation boundary could bypass the declared permission mapping.

## Root Cause
The permission was present in the navigation model, but the canonical workspace methods did not independently enforce the same existing permission boundary.

## Remediation
Added the minimum existing-pattern guard to both methods:

- `show_dashboard()` → `allowed('dashboard.view')`
- `show_financial_dashboard()` → `allowed('dashboard.view')`

On denial, the existing `denied()` handler is used and the workspace is not opened.

No new permission, service, repository, navigation layer, or business rule was introduced.

## Regression
Added one structural regression test covering both dashboard entry points.

Focused GUI/navigation tests:

- 31 passed

Compilation:

- `python -m compileall -q src tests` → PASS

Full suite:

- Existing unrelated failure remains in `test_project_financial_tracking` because the test creates a new activity directly with `status="Active"`, while the established service contract requires new activities to start as `Planned`.
- Before any change, this same failure was already present in the baseline.

## Scope Decision
This step does not change the activity lifecycle contract. That would be unrelated to the discovered navigation authorization defect.
