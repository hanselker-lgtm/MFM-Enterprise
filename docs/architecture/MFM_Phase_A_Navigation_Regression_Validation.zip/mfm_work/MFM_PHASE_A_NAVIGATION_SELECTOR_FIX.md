# MFM Phase A — Product Navigation Selector Fix

## Finding

The compact product navigation introduced a real GUI lifecycle bug: `show_product_area()` destroyed every child of `workspace_nav`, including the persistent Workspace label and `ttk.Combobox`, and then attempted to reuse the destroyed combobox.

## Fix

Removed the child-destruction loop from `show_product_area()`.

The Workspace selector is now created once in `_build()` and reused when the active product area changes.

## Scope

- GUI only
- No database changes
- No repository changes
- No service changes
- No business-rule changes
- No new feature

## Validation

Targeted tests: 16 passed.

`compileall`: PASS.
