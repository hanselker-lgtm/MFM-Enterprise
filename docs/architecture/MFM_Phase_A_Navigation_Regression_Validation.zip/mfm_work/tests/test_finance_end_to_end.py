import tempfile
from pathlib import Path

from src.application.context import ApplicationContext
from src.database.db import Database
from src.database.schema import initialize_schema


def test_finance_end_to_end_entry_bank_reconciliation_close_reports():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.accounting.create_accounting_year(2026, "2026-01-01", "2026-12-31")
        accounts = {row["number"]: row for row in ctx.accounting.accounts()}

        journal_id = ctx.accounting.post_journal(
            None,
            "Member payment",
            [
                {"account_id": accounts["1000"]["id"], "debit": 1000, "credit": 0},
                {"account_id": accounts["3000"]["id"], "debit": 0, "credit": 1000},
            ],
            "2026-08-19",
        )
        assert ctx.accounting.journal(journal_id)["journal"]["status"] == "Posted"

        bank = ctx.accounting.list_bank_accounts()
        if not bank:
            bank_id = ctx.bank.create_account("Operating Account", "TEST-001")
        else:
            bank_id = bank[0]["id"]

        created = ctx.accounting.import_bank_transactions(
            bank_id,
            [{
                "transaction_date": "2026-08-19",
                "amount": 1000,
                "description": "Member payment",
                "external_reference": "TEST-001",
            }],
        )
        tx_id = created[0]
        assert ctx.accounting.bank_reconciliation_summary(bank_id)["unmatched_count"] == 1

        suggestions = ctx.accounting.suggest_bank_matches(bank_id)
        suggestion = next(x for x in suggestions if x["transaction_id"] == tx_id)
        ctx.accounting.match_bank_transaction(tx_id, suggestion["suggestion"]["journal_id"])
        assert ctx.accounting.bank_reconciliation_summary(bank_id)["reconciled"] is True

        check = ctx.accounting.year_end_control_check(2026)
        assert check["unbalanced_journals"] == 0
        assert check["unmatched_bank_transactions"] == 0
        assert check["trial_balance_balanced"] is True
        assert check["ready_to_close"] is True

        report = ctx.accounting.financial_dashboard("2026-01-01", "2026-12-31")
        assert report["revenue"] == 1000
        assert report["net_result"] == 1000

        ctx.accounting.close_year(2026, actor="test")
        assert ctx.accounting.repo.get_accounting_year(2026)["status"] == "Closed"
