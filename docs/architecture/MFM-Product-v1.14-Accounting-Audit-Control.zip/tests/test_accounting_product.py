import tempfile
from pathlib import Path
import pytest
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def setup():
    d = tempfile.TemporaryDirectory()
    db = Database(Path(d.name) / "test.db")
    initialize_schema(db)
    return d, db, ApplicationContext(db)

def test_balance_sheet_balances():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 1000},
        ])
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": a["5000"]["id"], "debit": 250, "credit": 0},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 250},
        ])
        bs = ctx.accounting.balance_sheet("2026-12-31")
        assert bs["total_assets"] == 750
        assert bs["current_result"] == 750
        assert bs["balanced"] is True
        assert bs["total_assets"] == bs["liabilities_and_equity"]
    finally:
        d.cleanup()

def test_general_ledger_and_account_movements():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 1000},
        ], "2026-03-15")
        ledger = ctx.accounting.general_ledger("2026-03-01", "2026-03-31")
        assert len(ledger) == 2
        movements = ctx.accounting.account_movements(a["1000"]["id"], "2026-03-01", "2026-03-31")
        assert len(movements) == 1
        assert movements[0]["debit"] == 1000
    finally:
        d.cleanup()

def test_closed_period_rejects_posting():
    d, db, ctx = setup()
    try:
        ctx.accounting.create_fiscal_year(2026)
        period = ctx.accounting.periods(2026)[0]
        ctx.accounting.close_period(period["id"])
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        with pytest.raises(ValueError, match="closed"):
            ctx.accounting.post_journal(None, "Blocked", [
                {"account_id": a["1000"]["id"], "debit": 100, "credit": 0},
                {"account_id": a["3000"]["id"], "debit": 0, "credit": 100},
            ], "2026-01-15")
    finally:
        d.cleanup()

def test_invalid_line_does_not_create_partial_journal():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        with pytest.raises(ValueError):
            ctx.accounting.post_journal(None, "Invalid", [
                {"account_id": a["1000"]["id"], "debit": 100, "credit": 0},
                {"account_id": 999999, "debit": 0, "credit": 100},
            ])
        assert db.fetch_one("SELECT COUNT(*) c FROM journals")["c"] == 0
    finally:
        d.cleanup()

def test_income_statement_date_range():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "January income", [
            {"account_id": a["1000"]["id"], "debit": 500, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 500},
        ], "2026-01-10")
        ctx.accounting.post_journal(None, "February income", [
            {"account_id": a["1000"]["id"], "debit": 700, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 700},
        ], "2026-02-10")
        report = ctx.accounting.income_statement("2026-02-01", "2026-02-28")
        assert report["total_income"] == 700
    finally:
        d.cleanup()


def test_reports_cover_core_accounting_outputs():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 2000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 2000},
        ], "2026-03-01")
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": a["5000"]["id"], "debit": 800, "credit": 0},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 800},
        ], "2026-03-02")

        income = ctx.accounting.income_statement("2026-03-01", "2026-03-31")
        assert income["total_income"] == 2000
        assert income["total_expenses"] == 800
        assert income["result"] == 1200

        balance = ctx.accounting.balance_sheet("2026-03-31")
        assert balance["balanced"] is True

        trial = ctx.accounting.trial_balance("2026-03-01", "2026-03-31")
        assert round(sum(float(x["debit"]) for x in trial), 2) == 2800
        assert round(sum(float(x["credit"]) for x in trial), 2) == 2800

        ledger = ctx.accounting.general_ledger("2026-03-01", "2026-03-31")
        assert len(ledger) == 4
    finally:
        d.cleanup()


def test_entry_workspace_service_contract():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Workspace entry", [
                {"account_id": accounts["1000"]["id"], "debit": 1250, "credit": 0},
                {"account_id": accounts["3000"]["id"], "debit": 0, "credit": 1250},
            ], "2026-04-10"
        )
        assert journal_id
        journal = ctx.accounting.journal(journal_id)
        assert journal["journal"]["status"] == "Posted"
        assert len(journal["lines"]) == 2
    finally:
        d.cleanup()


def test_journal_voucher_details():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Voucher detail test", [
                {"account_id": accounts["5100"]["id"], "debit": 375, "credit": 0,
                 "description": "Materials"},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 375,
                 "description": "Bank payment"},
            ], "2026-05-12"
        )
        voucher = ctx.accounting.journal(journal_id)
        assert voucher["journal"]["journal_no"] is not None
        assert voucher["journal"]["status"] == "Posted"
        assert len(voucher["lines"]) == 2
        assert sum(float(x["debit"]) for x in voucher["lines"]) == 375
        assert sum(float(x["credit"]) for x in voucher["lines"]) == 375
        assert voucher["lines"][0]["number"] == "5100"
        assert voucher["lines"][0]["name"] == "Project Expenses"
    finally:
        d.cleanup()


def test_account_ledger_drilldown():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Ledger drill-down", [
                {"account_id": accounts["5100"]["id"], "debit": 900, "credit": 0,
                 "description": "Project materials"},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 900,
                 "description": "Paid from bank"},
            ], "2026-06-03"
        )
        movements = ctx.accounting.account_movements(
            accounts["5100"]["id"], "2026-06-01", "2026-06-30"
        )
        assert len(movements) == 1
        assert movements[0]["journal_no"] is not None
        voucher = ctx.accounting.journal_by_number(movements[0]["journal_no"])
        assert voucher["id"] == journal_id
        details = ctx.accounting.journal(voucher["id"])
        assert len(details["lines"]) == 2
    finally:
        d.cleanup()


def test_voucher_document_attachment_lifecycle(tmp_path):
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Attachment test", [
                {"account_id": accounts["5100"]["id"], "debit": 125, "credit": 0},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 125},
            ], "2026-07-01"
        )
        source = tmp_path / "invoice.txt"
        source.write_text("Invoice 123\nAmount 125.00", encoding="utf-8")

        doc_id = ctx.accounting.attach_voucher_document(
            journal_id, source, "Test invoice", tmp_path / "storage"
        )
        doc = ctx.accounting.voucher_document(doc_id)
        assert doc["file_name"] == "invoice.txt"
        assert doc["description"] == "Test invoice"
        assert doc["file_size"] > 0
        assert len(doc["sha256"]) == 64
        assert Path(doc["stored_name"]).exists()

        docs = ctx.accounting.voucher_documents(journal_id)
        assert len(docs) == 1

        ctx.accounting.remove_voucher_document(doc_id)
        assert ctx.accounting.voucher_document(doc_id) is None
        assert not Path(doc["stored_name"]).exists()
    finally:
        d.cleanup()


def test_accounting_audit_and_control():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Audit control test", [
                {"account_id": accounts["5100"]["id"], "debit": 250, "credit": 0},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 250},
            ], "2026-08-01"
        )
        events = ctx.accounting.audit_events(
            entity_type="journal", entity_id=journal_id
        )
        assert any(e["event_type"] == "JOURNAL_POSTED" for e in events)

        report = ctx.accounting.accounting_control_check(
            "2026-08-01", "2026-08-31"
        )
        assert report["trial_balance_balanced"] is True
        assert report["balance_sheet_balanced"] is True
        assert report["overall_ok"] is True
        assert report["posted_journals"] >= 1
        assert report["audit_events"] >= 1
    finally:
        d.cleanup()
