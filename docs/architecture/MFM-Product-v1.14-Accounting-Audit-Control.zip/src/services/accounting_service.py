from calendar import monthrange
from datetime import date, datetime

class AccountingService:
    ACCOUNT_TYPES = {"Asset", "Liability", "Equity", "Income", "Expense"}

    def __init__(self, repo):
        self.repo = repo

    def seed_standard_accounts(self):
        defaults = [
            ("1000", "Bank", "Asset"),
            ("1100", "Cash", "Asset"),
            ("1200", "Receivables", "Asset"),
            ("2000", "Payables", "Liability"),
            ("3000", "Membership Income", "Income"),
            ("4000", "Grants and Donations", "Income"),
            ("5000", "Operating Expenses", "Expense"),
            ("5100", "Project Expenses", "Expense"),
            ("8000", "Accumulated Funds", "Equity"),
        ]
        existing = {a["number"] for a in self.repo.list_accounts(include_inactive=True)}
        for item in defaults:
            if item[0] not in existing:
                self.repo.create_account(*item)

    def accounts(self, include_inactive=False):
        return self.repo.list_accounts(include_inactive=include_inactive)

    def create_account(self, number, name, account_type):
        number = str(number).strip()
        name = str(name).strip()
        account_type = str(account_type).strip()
        if not number or not name:
            raise ValueError("Account number and name are required.")
        if account_type not in self.ACCOUNT_TYPES:
            raise ValueError(f"Invalid account type: {account_type}")
        return self.repo.create_account(number, name, account_type)

    def create_fiscal_year(self, year):
        year = int(year)
        if year < 1900 or year > 2200:
            raise ValueError("Fiscal year is outside the supported range.")
        if self.repo.get_fiscal_year(year):
            raise ValueError("Fiscal year already exists.")

        year_id = self.repo.create_fiscal_year(year)
        for month in range(1, 13):
            start = f"{year:04d}-{month:02d}-01"
            end = f"{year:04d}-{month:02d}-{monthrange(year, month)[1]:02d}"
            self.repo.create_period(year_id, month, start, end)
        return year_id

    def fiscal_years(self):
        return self.repo.list_fiscal_years()

    def periods(self, year):
        fy = self.repo.get_fiscal_year(int(year))
        return self.repo.list_periods(fy["id"]) if fy else []

    def _period_for_date(self, journal_date):
        return self.repo.period_for_date(journal_date)

    def close_period(self, period_id):
        row = self.repo.get_period(period_id)
        if not row:
            raise ValueError("Period not found.")
        if row["status"] == "Closed":
            return
        self.repo.set_period_status(period_id, "Closed")

    def reopen_period(self, period_id):
        row = self.repo.get_period(period_id)
        if not row:
            raise ValueError("Period not found.")
        self.repo.set_period_status(period_id, "Open")

    def _validate_journal_date(self, journal_date):
        try:
            datetime.strptime(journal_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Journal date must use YYYY-MM-DD.")

        period = self._period_for_date(journal_date)
        if period and period["status"] == "Closed":
            raise ValueError("The accounting period is closed.")

    def post_journal(self, journal_no, description, lines, journal_date=None):
        journal_date = journal_date or date.today().isoformat()
        description = str(description).strip()
        if not description:
            raise ValueError("Journal description is required.")
        self._validate_journal_date(journal_date)

        if not lines or len(lines) < 2:
            raise ValueError("A journal needs at least two lines.")

        normalized = []
        debit_total = 0.0
        credit_total = 0.0

        for line in lines:
            debit = round(float(line.get("debit", 0) or 0), 2)
            credit = round(float(line.get("credit", 0) or 0), 2)
            if debit < 0 or credit < 0:
                raise ValueError("Debit and credit cannot be negative.")
            if debit > 0 and credit > 0:
                raise ValueError("Each line must contain either debit or credit.")
            if debit == 0 and credit == 0:
                raise ValueError("Each journal line must contain an amount.")
            account = self.repo.get_account(int(line["account_id"]))
            if not account or not account["active"]:
                raise ValueError("Journal contains an invalid or inactive account.")
            normalized.append((
                int(line["account_id"]),
                str(line.get("description", "")),
                debit,
                credit,
                line.get("project_id")
            ))
            debit_total += debit
            credit_total += credit

        debit_total = round(debit_total, 2)
        credit_total = round(credit_total, 2)
        if debit_total <= 0 or credit_total <= 0 or debit_total != credit_total:
            raise ValueError("Journal must balance: total debit must equal total credit.")

        if journal_no is None:
            journal_no = self.repo.next_journal_number("FIN")

        journal_id = self.repo.create_posted_journal(
            journal_no, journal_date, description, normalized
        )
        self.audit_event("JOURNAL_POSTED", "journal", journal_id,
                         f"Journal {journal_id} posted.")
        return journal_id

    def journals(self):
        return self.repo.list_journals()

    def journal_by_number(self, journal_no):
        return self.repo.journal_by_number(journal_no)

    def journal(self, journal_id):
        return self.repo.get_journal(journal_id)

    def trial_balance(self, start_date=None, end_date=None):
        return self.repo.trial_balance(start_date, end_date)

    def account_movements(self, account_id, start_date=None, end_date=None):
        return self.repo.account_movements(account_id, start_date, end_date)

    def _account_totals(self, start_date=None, end_date=None):
        rows = self.repo.trial_balance(start_date, end_date)
        return [{
            "id": r["id"],
            "number": r["number"],
            "name": r["name"],
            "account_type": r["account_type"],
            "debit": float(r["debit"] or 0),
            "credit": float(r["credit"] or 0),
            "balance": round(float(r["debit"] or 0) - float(r["credit"] or 0), 2),
        } for r in rows]

    def income_statement(self, start_date=None, end_date=None):
        rows = self._account_totals(start_date, end_date)
        income = [r for r in rows if r["account_type"] == "Income"]
        expenses = [r for r in rows if r["account_type"] == "Expense"]
        total_income = round(sum(-r["balance"] for r in income), 2)
        total_expenses = round(sum(r["balance"] for r in expenses), 2)
        return {
            "income": income,
            "expenses": expenses,
            "total_income": total_income,
            "total_expenses": total_expenses,
            "result": round(total_income - total_expenses, 2),
            "start_date": start_date,
            "end_date": end_date,
        }

    def balance_sheet(self, as_of_date=None):
        rows = self._account_totals(None, as_of_date)
        assets = [r for r in rows if r["account_type"] == "Asset"]
        liabilities = [r for r in rows if r["account_type"] == "Liability"]
        equity_accounts = [r for r in rows if r["account_type"] == "Equity"]

        total_assets = round(sum(r["balance"] for r in assets), 2)
        total_liabilities = round(sum(-r["balance"] for r in liabilities), 2)
        posted_income = self.income_statement(None, as_of_date)
        current_result = posted_income["result"]
        retained_equity = round(sum(-r["balance"] for r in equity_accounts), 2)
        total_equity = round(retained_equity + current_result, 2)
        liabilities_and_equity = round(total_liabilities + total_equity, 2)

        return {
            "assets": assets,
            "liabilities": liabilities,
            "equity": equity_accounts,
            "current_result": current_result,
            "retained_equity": retained_equity,
            "total_assets": total_assets,
            "total_liabilities": total_liabilities,
            "total_equity": total_equity,
            "liabilities_and_equity": liabilities_and_equity,
            "balanced": round(total_assets - liabilities_and_equity, 2) == 0,
            "as_of_date": as_of_date,
        }

    def general_ledger(self, start_date=None, end_date=None):
        return self.repo.general_ledger(start_date, end_date)

    def project_financials(self, project_id):
        return self.repo.project_financials(project_id)

    def project_budget_vs_actual(self, project_id):
        budget = self.repo.db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",
            (project_id,)
        )
        actual = self.repo.project_actuals(project_id)
        budget_amount = float(budget["budget_amount"]) if budget else 0.0
        actual_amount = round(float(actual["debit"] or 0) - float(actual["credit"] or 0), 2)
        return {
            "budget": budget_amount,
            "actual": actual_amount,
            "variance": round(budget_amount - actual_amount, 2),
            "utilization": (actual_amount / budget_amount * 100) if budget_amount else 0.0,
        }


    def attach_voucher_document(self, journal_id, source_path, description="",
                                storage_dir=None):
        from pathlib import Path
        from datetime import datetime

        source = Path(source_path)
        if not source.is_file():
            raise ValueError("Attachment file not found.")
        journal = self.repo.get_journal(journal_id)
        if not journal:
            raise ValueError("Voucher not found.")

        storage = Path(storage_dir) if storage_dir else Path("data") / "attachments"
        storage.mkdir(parents=True, exist_ok=True)

        digest = __import__("hashlib").sha256(source.read_bytes()).hexdigest()
        safe_name = f"{journal['journal']['journal_no']}_{digest[:12]}_{source.name}"
        target = storage / safe_name

        if not target.exists():
            target.write_bytes(source.read_bytes())

        mime = __import__("mimetypes").guess_type(source.name)[0] or "application/octet-stream"
        uploaded_at = datetime.now().isoformat(timespec="seconds")

        return self.repo.add_voucher_document(
            journal_id,
            source.name,
            str(target),
            mime,
            target.stat().st_size,
            digest,
            description,
            uploaded_at
        )

    def voucher_documents(self, journal_id):
        return self.repo.list_voucher_documents(journal_id)

    def voucher_document(self, document_id):
        return self.repo.get_voucher_document(document_id)

    def remove_voucher_document(self, document_id):
        doc = self.repo.get_voucher_document(document_id)
        if not doc:
            raise ValueError("Attachment not found.")
        from pathlib import Path
        path = Path(doc["stored_name"])
        self.repo.delete_voucher_document(document_id)
        if path.exists():
            path.unlink()
        return True


    def audit_event(self, event_type, entity_type, entity_id, description,
                    actor=None, metadata=None):
        import json
        from datetime import datetime
        return self.repo.add_audit_event(
            datetime.now().isoformat(timespec="seconds"),
            event_type, entity_type, entity_id, description,
            actor, json.dumps(metadata, ensure_ascii=False) if metadata else None
        )

    def audit_events(self, entity_type=None, entity_id=None,
                     start_date=None, end_date=None):
        return self.repo.list_audit_events(
            entity_type, entity_id, start_date, end_date
        )

    def accounting_control_check(self, start_date=None, end_date=None):
        trial = self.trial_balance(start_date, end_date)
        debit = round(sum(float(r["debit"] or 0) for r in trial), 2)
        credit = round(sum(float(r["credit"] or 0) for r in trial), 2)
        balance = self.balance_sheet(end_date)
        posted = [j for j in self.journals() if j["status"] == "Posted"]
        return {
            "trial_balance_balanced": debit == credit,
            "trial_debit": debit,
            "trial_credit": credit,
            "balance_sheet_balanced": bool(balance["balanced"]),
            "posted_journals": len(posted),
            "audit_events": len(self.audit_events(
                start_date=start_date, end_date=end_date
            )),
            "overall_ok": debit == credit and bool(balance["balanced"])
        }
