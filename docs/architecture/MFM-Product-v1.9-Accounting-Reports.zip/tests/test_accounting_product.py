import tempfile
from pathlib import Path
import pytest
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def setup():
    d = tempfile.TemporaryDirectory()
    db = Database(Path(d.name) / "test.db")
    initialize_schema(db)
    return d, db, ApplicationContext(db)

def test_balance_sheet_balances():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 1000},
        ])
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": a["5000"]["id"], "debit": 250, "credit": 0},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 250},
        ])
        bs = ctx.accounting.balance_sheet("2026-12-31")
        assert bs["total_assets"] == 750
        assert bs["current_result"] == 750
        assert bs["balanced"] is True
        assert bs["total_assets"] == bs["liabilities_and_equity"]
    finally:
        d.cleanup()

def test_general_ledger_and_account_movements():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 1000},
        ], "2026-03-15")
        ledger = ctx.accounting.general_ledger("2026-03-01", "2026-03-31")
        assert len(ledger) == 2
        movements = ctx.accounting.account_movements(a["1000"]["id"], "2026-03-01", "2026-03-31")
        assert len(movements) == 1
        assert movements[0]["debit"] == 1000
    finally:
        d.cleanup()

def test_closed_period_rejects_posting():
    d, db, ctx = setup()
    try:
        ctx.accounting.create_fiscal_year(2026)
        period = ctx.accounting.periods(2026)[0]
        ctx.accounting.close_period(period["id"])
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        with pytest.raises(ValueError, match="closed"):
            ctx.accounting.post_journal(None, "Blocked", [
                {"account_id": a["1000"]["id"], "debit": 100, "credit": 0},
                {"account_id": a["3000"]["id"], "debit": 0, "credit": 100},
            ], "2026-01-15")
    finally:
        d.cleanup()

def test_invalid_line_does_not_create_partial_journal():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        with pytest.raises(ValueError):
            ctx.accounting.post_journal(None, "Invalid", [
                {"account_id": a["1000"]["id"], "debit": 100, "credit": 0},
                {"account_id": 999999, "debit": 0, "credit": 100},
            ])
        assert db.fetch_one("SELECT COUNT(*) c FROM journals")["c"] == 0
    finally:
        d.cleanup()

def test_income_statement_date_range():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "January income", [
            {"account_id": a["1000"]["id"], "debit": 500, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 500},
        ], "2026-01-10")
        ctx.accounting.post_journal(None, "February income", [
            {"account_id": a["1000"]["id"], "debit": 700, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 700},
        ], "2026-02-10")
        report = ctx.accounting.income_statement("2026-02-01", "2026-02-28")
        assert report["total_income"] == 700
    finally:
        d.cleanup()


def test_reports_cover_core_accounting_outputs():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 2000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 2000},
        ], "2026-03-01")
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": a["5000"]["id"], "debit": 800, "credit": 0},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 800},
        ], "2026-03-02")

        income = ctx.accounting.income_statement("2026-03-01", "2026-03-31")
        assert income["total_income"] == 2000
        assert income["total_expenses"] == 800
        assert income["result"] == 1200

        balance = ctx.accounting.balance_sheet("2026-03-31")
        assert balance["balanced"] is True

        trial = ctx.accounting.trial_balance("2026-03-01", "2026-03-31")
        assert round(sum(float(x["debit"]) for x in trial), 2) == 2800
        assert round(sum(float(x["credit"]) for x in trial), 2) == 2800

        ledger = ctx.accounting.general_ledger("2026-03-01", "2026-03-31")
        assert len(ledger) == 4
    finally:
        d.cleanup()
