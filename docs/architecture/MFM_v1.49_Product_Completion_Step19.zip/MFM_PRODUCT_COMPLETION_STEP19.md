# MFM Product Completion – Step 19

## Project Activity Actuals Consistency

### Concrete gap
`ProjectService.activity_financials()` delegated to `ProjectRepository.activity_actuals()`, but `activity_actuals()` returned `0.0` for every activity actual and used the full activity budget as variance. This contradicted the existing `activity_financial_detail()` implementation, which already calculated posted expense journal lines allocated by `activity_id`.

### Change
`activity_actuals()` now derives actual cost from posted expense journal lines linked to the activity and calculates `variance = budget - actual`.

No schema, service API, accounting authority, or project model changes were introduced.

### Validation
- `python -m compileall -q src tests`: PASS
- Focused project/finance regression tests: 4 passed, 43 deselected
- Added regression test proving allocated posted activity expenses appear in `activity_financials()`.

### Product impact
Project → Activity → Cost → Accounting → Budget/Actual reporting is now internally consistent for activity-level actuals.
