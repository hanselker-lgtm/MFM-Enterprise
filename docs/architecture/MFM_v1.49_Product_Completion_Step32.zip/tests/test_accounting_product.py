import tempfile
from pathlib import Path
import pytest
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def setup():
    d = tempfile.TemporaryDirectory()
    db = Database(Path(d.name) / "test.db")
    initialize_schema(db)
    return d, db, ApplicationContext(db)

def test_balance_sheet_balances():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 1000},
        ])
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": a["5000"]["id"], "debit": 250, "credit": 0},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 250},
        ])
        bs = ctx.accounting.balance_sheet("2026-12-31")
        assert bs["total_assets"] == 750
        assert bs["current_result"] == 750
        assert bs["balanced"] is True
        assert bs["total_assets"] == bs["liabilities_and_equity"]
    finally:
        d.cleanup()

def test_general_ledger_and_account_movements():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 1000},
        ], "2026-03-15")
        ledger = ctx.accounting.general_ledger("2026-03-01", "2026-03-31")
        assert len(ledger) == 2
        movements = ctx.accounting.account_movements(a["1000"]["id"], "2026-03-01", "2026-03-31")
        assert len(movements) == 1
        assert movements[0]["debit"] == 1000
    finally:
        d.cleanup()

def test_closed_period_rejects_posting():
    d, db, ctx = setup()
    try:
        ctx.accounting.create_fiscal_year(2026)
        period = ctx.accounting.periods(2026)[0]
        ctx.accounting.close_period(period["id"])
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        with pytest.raises(ValueError, match="closed"):
            ctx.accounting.post_journal(None, "Blocked", [
                {"account_id": a["1000"]["id"], "debit": 100, "credit": 0},
                {"account_id": a["3000"]["id"], "debit": 0, "credit": 100},
            ], "2026-01-15")
    finally:
        d.cleanup()

def test_invalid_line_does_not_create_partial_journal():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        with pytest.raises(ValueError):
            ctx.accounting.post_journal(None, "Invalid", [
                {"account_id": a["1000"]["id"], "debit": 100, "credit": 0},
                {"account_id": 999999, "debit": 0, "credit": 100},
            ])
        assert db.fetch_one("SELECT COUNT(*) c FROM journals")["c"] == 0
    finally:
        d.cleanup()

def test_income_statement_date_range():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "January income", [
            {"account_id": a["1000"]["id"], "debit": 500, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 500},
        ], "2026-01-10")
        ctx.accounting.post_journal(None, "February income", [
            {"account_id": a["1000"]["id"], "debit": 700, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 700},
        ], "2026-02-10")
        report = ctx.accounting.income_statement("2026-02-01", "2026-02-28")
        assert report["total_income"] == 700
    finally:
        d.cleanup()


def test_reports_cover_core_accounting_outputs():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": a["1000"]["id"], "debit": 2000, "credit": 0},
            {"account_id": a["3000"]["id"], "debit": 0, "credit": 2000},
        ], "2026-03-01")
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": a["5000"]["id"], "debit": 800, "credit": 0},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 800},
        ], "2026-03-02")

        income = ctx.accounting.income_statement("2026-03-01", "2026-03-31")
        assert income["total_income"] == 2000
        assert income["total_expenses"] == 800
        assert income["result"] == 1200

        balance = ctx.accounting.balance_sheet("2026-03-31")
        assert balance["balanced"] is True

        trial = ctx.accounting.trial_balance("2026-03-01", "2026-03-31")
        assert round(sum(float(x["debit"]) for x in trial), 2) == 2800
        assert round(sum(float(x["credit"]) for x in trial), 2) == 2800

        ledger = ctx.accounting.general_ledger("2026-03-01", "2026-03-31")
        assert len(ledger) == 4
    finally:
        d.cleanup()


def test_entry_workspace_service_contract():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Workspace entry", [
                {"account_id": accounts["1000"]["id"], "debit": 1250, "credit": 0},
                {"account_id": accounts["3000"]["id"], "debit": 0, "credit": 1250},
            ], "2026-04-10"
        )
        assert journal_id
        journal = ctx.accounting.journal(journal_id)
        assert journal["journal"]["status"] == "Posted"
        assert len(journal["lines"]) == 2
    finally:
        d.cleanup()


def test_journal_voucher_details():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Voucher detail test", [
                {"account_id": accounts["5100"]["id"], "debit": 375, "credit": 0,
                 "description": "Materials"},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 375,
                 "description": "Bank payment"},
            ], "2026-05-12"
        )
        voucher = ctx.accounting.journal(journal_id)
        assert voucher["journal"]["journal_no"] is not None
        assert voucher["journal"]["status"] == "Posted"
        assert len(voucher["lines"]) == 2
        assert sum(float(x["debit"]) for x in voucher["lines"]) == 375
        assert sum(float(x["credit"]) for x in voucher["lines"]) == 375
        assert voucher["lines"][0]["number"] == "5100"
        assert voucher["lines"][0]["name"] == "Project Expenses"
    finally:
        d.cleanup()


def test_account_ledger_drilldown():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Ledger drill-down", [
                {"account_id": accounts["5100"]["id"], "debit": 900, "credit": 0,
                 "description": "Project materials"},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 900,
                 "description": "Paid from bank"},
            ], "2026-06-03"
        )
        movements = ctx.accounting.account_movements(
            accounts["5100"]["id"], "2026-06-01", "2026-06-30"
        )
        assert len(movements) == 1
        assert movements[0]["journal_no"] is not None
        voucher = ctx.accounting.journal_by_number(movements[0]["journal_no"])
        assert voucher["id"] == journal_id
        details = ctx.accounting.journal(voucher["id"])
        assert len(details["lines"]) == 2
    finally:
        d.cleanup()


def test_voucher_document_attachment_lifecycle(tmp_path):
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Attachment test", [
                {"account_id": accounts["5100"]["id"], "debit": 125, "credit": 0},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 125},
            ], "2026-07-01"
        )
        source = tmp_path / "invoice.txt"
        source.write_text("Invoice 123\nAmount 125.00", encoding="utf-8")

        doc_id = ctx.accounting.attach_voucher_document(
            journal_id, source, "Test invoice", tmp_path / "storage"
        )
        doc = ctx.accounting.voucher_document(doc_id)
        assert doc["file_name"] == "invoice.txt"
        assert doc["description"] == "Test invoice"
        assert doc["file_size"] > 0
        assert len(doc["sha256"]) == 64
        assert Path(doc["stored_name"]).exists()

        docs = ctx.accounting.voucher_documents(journal_id)
        assert len(docs) == 1

        ctx.accounting.remove_voucher_document(doc_id)
        assert ctx.accounting.voucher_document(doc_id) is None
        assert not Path(doc["stored_name"]).exists()
    finally:
        d.cleanup()


def test_accounting_audit_and_control():
    d, db, ctx = setup()
    try:
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Audit control test", [
                {"account_id": accounts["5100"]["id"], "debit": 250, "credit": 0},
                {"account_id": accounts["1000"]["id"], "debit": 0, "credit": 250},
            ], "2026-08-01"
        )
        events = ctx.accounting.audit_events(
            entity_type="journal", entity_id=journal_id
        )
        assert any(e["event_type"] == "JOURNAL_POSTED" for e in events)

        report = ctx.accounting.accounting_control_check(
            "2026-08-01", "2026-08-31"
        )
        assert report["trial_balance_balanced"] is True
        assert report["balance_sheet_balanced"] is True
        assert report["overall_ok"] is True
        assert report["posted_journals"] >= 1
        assert report["audit_events"] >= 1
    finally:
        d.cleanup()


def test_bank_reconciliation_workspace():
    d, db, ctx = setup()
    try:
        bank = db.execute(
            "INSERT INTO bank_accounts(name, account_number) VALUES (?,?)",
            ("Test Bank", "TEST-001")
        )
        bank_id = getattr(bank, "lastrowid", None) or db.fetch_one(
            "SELECT id FROM bank_accounts WHERE account_number=?",
            ("TEST-001",)
        )["id"]
        rows = ctx.accounting.import_bank_transactions(bank_id, [
            {"transaction_date":"2026-08-01","amount":250,
             "description":"Test payment","external_reference":"REF-1"}
        ])
        assert len(rows) == 1
        tx_id = getattr(rows[0], "lastrowid", None) or db.fetch_one(
            "SELECT id FROM bank_transactions WHERE external_reference=?",
            ("REF-1",)
        )["id"]
        accounts = {x["number"]: x for x in ctx.accounting.accounts()}
        journal_id = ctx.accounting.post_journal(
            None, "Bank match", [
                {"account_id":accounts["5100"]["id"],"debit":250,"credit":0},
                {"account_id":accounts["1000"]["id"],"debit":0,"credit":250}
            ], "2026-08-01"
        )
        ctx.accounting.match_bank_transaction(tx_id, journal_id)
        summary = ctx.accounting.bank_reconciliation_summary(bank_id)
        assert summary["matched_count"] == 1
        assert summary["unmatched_count"] == 0
        assert summary["reconciled"] is True
        ctx.accounting.unmatch_bank_transaction(tx_id)
        summary = ctx.accounting.bank_reconciliation_summary(bank_id)
        assert summary["unmatched_count"] == 1
        assert summary["reconciled"] is False
    finally:
        d.cleanup()


def test_bank_csv_import_and_match_suggestions(tmp_path):
    d, db, ctx = setup()
    try:
        result = db.execute(
            "INSERT INTO bank_accounts(name, account_number) VALUES (?,?)",
            ("Import Bank", "CSV-001")
        )
        bank_id = getattr(result, "lastrowid", None) or db.fetch_one(
            "SELECT id FROM bank_accounts WHERE account_number=?",
            ("CSV-001",)
        )["id"]
        csv_path = tmp_path / "bank.csv"
        csv_path.write_text(
            "Date,Amount,Text,Ref\n2026-08-10,250.00,Payment,ABC123\n"
            "2026-08-11,-50.00,Fee,ABC124\n",
            encoding="utf-8"
        )
        mapping={"date":"Date","amount":"Amount",
                 "description":"Text","reference":"Ref"}
        preview=ctx.accounting.preview_bank_csv(csv_path,mapping)
        assert len(preview["rows"]) == 2
        imported=ctx.accounting.import_bank_csv(bank_id,csv_path,mapping)
        assert imported["created"] == 2
        assert imported["skipped_duplicates"] == 0
        imported2=ctx.accounting.import_bank_csv(bank_id,csv_path,mapping)
        assert imported2["created"] == 0
        assert imported2["skipped_duplicates"] == 2

        accounts={x["number"]:x for x in ctx.accounting.accounts()}
        journal_id=ctx.accounting.post_journal(
            None,"Matching candidate",[
                {"account_id":accounts["5100"]["id"],"debit":250,"credit":0},
                {"account_id":accounts["1000"]["id"],"debit":0,"credit":250}
            ],"2026-08-10"
        )
        suggestions=ctx.accounting.suggest_bank_matches(bank_id)
        first=next(x for x in suggestions if x["amount"]==250)
        assert first["suggestion"]["journal_id"]==journal_id
        assert first["suggestion"]["score"]==100
    finally:
        d.cleanup()


def test_accounting_year_end_control_and_close():
    d, db, ctx = setup()
    try:
        db.execute(
            "INSERT INTO accounting_years(year,period_start,period_end,status) VALUES(?,?,?,'Open')",
            (2026,"2026-01-01","2026-12-31")
        )
        db.execute(
            "INSERT INTO accounting_periods(period_start,period_end,name,status) VALUES(?,?,?,'Open')",
            ("2026-01-01","2026-12-31","2026")
        )
        check=ctx.accounting.year_end_control_check(2026)
        assert check["trial_balance_balanced"] is True
        assert check["unbalanced_journals"] == 0
        assert check["ready_to_close"] is True
        ctx.accounting.close_year(2026, actor="test")
        year=ctx.accounting.list_accounting_years()[0]
        assert year["status"] == "Closed"
        events=ctx.accounting.audit_events("accounting_year",2026)
        assert any(e["event_type"]=="YEAR_CLOSED" for e in events)
    finally:
        d.cleanup()


def test_financial_dashboard():
    d, db, ctx = setup()
    try:
        a={x["number"]:x for x in ctx.accounting.accounts()}
        ctx.accounting.post_journal(
            None,"Income",[
                {"account_id":a["1000"]["id"],"debit":1000,"credit":0},
                {"account_id":a["3000"]["id"],"debit":0,"credit":1000}
            ],"2026-08-01"
        )
        ctx.accounting.post_journal(
            None,"Expense",[
                {"account_id":a["5100"]["id"],"debit":250,"credit":0},
                {"account_id":a["1000"]["id"],"debit":0,"credit":250}
            ],"2026-08-02"
        )
        r=ctx.accounting.financial_dashboard("2026-08-01","2026-08-31")
        assert r["revenue"] == 1000
        assert r["expenses"] == 250
        assert r["net_result"] == 750
    finally:
        d.cleanup()


def test_membership_workspace_core():
    d, db, ctx = setup()
    try:
        ctx.members.create_member("M-001","Hans","Test",email="hans@example.dk")
        member=ctx.members.members()[0]
        ctx.members.create_membership_type("Standard",300)
        mt=ctx.members.membership_types()[0]
        ctx.members.add_membership(member["id"],mt["id"],"2026-01-01")
        membership=ctx.members.memberships()[0]
        invoice_id=ctx.members.invoice_membership(
            membership["id"],member["id"],300,"2026-01-02","2026-01-16"
        )
        inv=ctx.members.member_invoices(member["id"])[0]
        assert inv["invoice_no"] >= 1
        assert ctx.members.invoice_status(inv) == "Overdue"
        payment_id=ctx.members.register_payment(invoice_id,300,"2026-01-10")
        assert payment_id is not None
        inv=ctx.members.member_invoices(member["id"])[0]
        assert ctx.members.invoice_status(inv) == "Paid"
        summary=ctx.members.summary()
        assert summary["members"] == 1
        assert summary["active_members"] == 1
        assert summary["outstanding"] == 0
    finally:
        d.cleanup()


def test_membership_billing_batch():
    d, db, ctx = setup()
    try:
        ctx.members.create_member("M-101","A","One")
        ctx.members.create_member("M-102","B","Two")
        mtid=ctx.members.create_membership_type("Annual",400)
        members=ctx.members.members()
        for m in members:
            ctx.members.add_membership(m["id"],mtid,"2026-01-01")
        preview=ctx.members.billing_preview(2026,"2026-01-05","2026-01-19")
        assert len(preview)==2
        assert all(x["already_invoiced"] is False for x in preview)
        result=ctx.members.bill_memberships(2026,"2026-01-05","2026-01-19")
        assert result["created_count"]==2
        assert result["skipped_count"]==0
        result2=ctx.members.bill_memberships(2026,"2026-01-05","2026-01-19")
        assert result2["created_count"]==0
        assert result2["skipped_count"]==2
        summary=ctx.members.payment_status_summary(2026)
        assert summary["invoices"]==2
        assert summary["outstanding"]==800
        outstanding=ctx.members.outstanding_invoices(2026)
        assert len(outstanding)==2
    finally:
        d.cleanup()


def test_member_dunning_and_communication_history():
    d, db, ctx = setup()
    try:
        ctx.members.create_member("M-201","C","Three",email="c@example.dk")
        m=ctx.members.members()[0]
        mt=ctx.members.create_membership_type("Dunning",500)
        ctx.members.add_membership(m["id"],mt,"2026-01-01")
        ms=ctx.members.memberships()[0]
        iid=ctx.members.invoice_membership(ms["id"],m["id"],500,
                                           "2026-01-01","2026-01-15")
        rows=ctx.members.dunning_preview("2026-02-15")
        assert len(rows)==1
        assert rows[0]["outstanding"]==500
        assert rows[0]["days_overdue"]==31
        cid=ctx.members.record_dunning(rows[0],2)
        assert cid is not None
        history=ctx.members.communication_history(m["id"],iid)
        assert len(history)==1
        assert history[0]["communication_type"]=="Dunning-2"
        assert "Rykker" in history[0]["subject"]
    finally:
        d.cleanup()


def test_member_administration_and_member_card():
    d, db, ctx = setup()
    try:
        ctx.members.create_member("M-301","D","Four",email="d@example.dk",
                                  phone="12345678",joined_date="2026-01-05")
        m=ctx.members.members()[0]
        assert ctx.members.administration_overview()["active"]==1
        ctx.members.update_member_contact(m["id"],phone="87654321",city="Odense")
        updated=ctx.members.member(m["id"])
        assert updated["phone"]=="87654321"
        assert updated["city"]=="Odense"
        ctx.members.change_member_status(m["id"],"Suspended",
                                         event_date="2026-02-01",reason="Midlertidigt sat i bero")
        assert ctx.members.member(m["id"])["status"]=="Suspended"
        ctx.members.register_join(m["id"],"2026-03-01")
        assert ctx.members.member(m["id"])["status"]=="Active"
        mt=ctx.members.create_membership_type("Admin",250)
        ctx.members.add_membership(m["id"],mt,"2026-03-01")
        ctx.members.register_leave(m["id"],"2026-06-30","Udmeldt efter eget ønske")
        assert ctx.members.member(m["id"])["status"]=="Resigned"
        ms=ctx.members.memberships()[0]
        assert ms["status"]=="Ended"
        assert ms["end_date"]=="2026-06-30"
        events=ctx.members.member_events(m["id"])
        assert len(events)>=4
        card=ctx.members.member_card(m["id"])
        assert card["member"]["member_no"]=="M-301"
        assert len(card["memberships"])==1
    finally:
        d.cleanup()


def test_association_activities_and_project_budget():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Álvur Restoration","Restoration project","Planned",100000)
        aid=ctx.projects.create_activity(pid,"Skrog","Replace planks","2026-08-19",
                                         "Planned",25000)
        assert aid is not None
        rows=ctx.projects.activities(pid)
        assert len(rows)==1
        assert rows[0]["name"]=="Skrog"
        summary=ctx.projects.activity_summary(pid)
        assert summary["activity_count"]==1
        assert summary["activity_budget"]==25000
        ctx.projects.update_activity(aid,status="Active",budget=30000)
        row=ctx.projects.activities(pid)[0]
        assert row["status"]=="Active"
        assert row["budget"]==30000
        ctx.projects.set_budget(pid,100000)
        assert ctx.projects.budget(pid)["budget_amount"]==100000
    finally:
        d.cleanup()


def test_project_financial_tracking():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Project Financial","Tracking","Planned",10000)
        ctx.projects.set_budget(pid,10000)
        ctx.projects.create_activity(pid,"Activity A","", "2026-08-01","Active",6000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(
            None,"Project expense",[
                {"account_id":accounts["5100"],"debit":2500,"credit":0,
                 "project_id":pid,"description":"Materials"},
                {"account_id":accounts["1000"],"debit":0,"credit":2500,
                 "project_id":pid,"description":"Bank payment"}
            ],"2026-08-19")
        data=ctx.projects.financial_tracking(pid)
        assert data["budget"]==10000
        assert data["actual"]==2500
        assert data["variance"]==7500
        assert data["utilization"]==25.0
        lines=ctx.projects.expense_lines(pid)
        assert len(lines)==1
        assert lines[0]["account_number"]=="5100"
        acts=ctx.projects.activity_financials(pid)
        assert len(acts)==1
        assert acts[0]["budget"]==6000
        assert acts[0]["actual"]==0
    finally:
        d.cleanup()


def test_activity_financials_reflect_allocated_posted_expenses():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Activity Actuals","Allocation","Active",10000)
        aid=ctx.projects.create_activity(pid,"Skrog","", "2026-08-01","Active",6000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Allocated activity cost",[
            {"account_id":accounts["5100"],"debit":2500,"credit":0,
             "project_id":pid,"activity_id":aid,"description":"Materials"},
            {"account_id":accounts["1000"],"debit":0,"credit":2500,
             "project_id":pid,"activity_id":aid,"description":"Bank"}
        ],"2026-08-19")
        rows=ctx.projects.activity_financials(pid)
        assert len(rows)==1
        assert rows[0]["actual"]==2500
        assert rows[0]["variance"]==3500
    finally:
        d.cleanup()


def test_project_activity_cost_allocation():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Activity Allocation","Costs","Planned",20000)
        ctx.projects.set_budget(pid,20000)
        aid=ctx.projects.create_activity(pid,"Skrog","", "2026-08-01","Active",12000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Skrog cost",[
            {"account_id":accounts["5100"],"debit":4500,"credit":0,
             "project_id":pid,"activity_id":aid,"description":"Wood"},
            {"account_id":accounts["1000"],"debit":0,"credit":4500,
             "project_id":pid,"activity_id":aid,"description":"Bank"}
        ],"2026-08-19")
        rows=ctx.projects.activity_financial_detail(pid)
        assert len(rows)==1
        assert rows[0]["actual"]==4500
        assert rows[0]["variance"]==7500
        assert rows[0]["utilization"]==37.5
        try:
            ctx.accounting.post_journal(None,"Invalid allocation",[
                {"account_id":accounts["5100"],"debit":100,"credit":0,
                 "project_id":pid,"activity_id":99999},
                {"account_id":accounts["1000"],"debit":0,"credit":100,
                 "project_id":pid}
            ],"2026-08-19")
            assert False, "Expected invalid activity rejection"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_project_control_dashboard():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Control Dashboard","Project","Active",20000)
        ctx.projects.set_budget(pid,20000)
        a1=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",12000)
        a2=ctx.projects.create_activity(pid,"Maskin","","2026-08-02","Planned",5000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Allocated",[
            {"account_id":accounts["5100"],"debit":4500,"credit":0,
             "project_id":pid,"activity_id":a1,"description":"Wood"},
            {"account_id":accounts["1000"],"debit":0,"credit":4500,
             "project_id":pid,"activity_id":a1,"description":"Bank"}
        ],"2026-08-19")
        ctx.accounting.post_journal(None,"Unallocated",[
            {"account_id":accounts["5100"],"debit":1000,"credit":0,
             "project_id":pid,"description":"Other project cost"},
            {"account_id":accounts["1000"],"debit":0,"credit":1000,
             "project_id":pid,"description":"Bank"}
        ],"2026-08-19")
        dash=ctx.projects.project_control_dashboard(pid)
        assert dash["budget"]==20000
        assert dash["actual"]==5500
        assert dash["variance"]==14500
        assert dash["utilization"]==27.5
        assert dash["activity_budget"]==17000
        assert dash["activity_actual"]==4500
        assert dash["unallocated_actual"]==1000
        assert dash["activities"][0]["actual"]==4500
        assert dash["activities"][0]["variance"]==7500
        assert dash["activities"][1]["actual"]==0
    finally:
        d.cleanup()


def test_project_work_and_task_management():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Work Project","Tasks","Active",10000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",5000)
        tid=ctx.projects.create_project_task(pid,"Bestil eg","Order oak",aid,
                                             "Hans","High","2026-09-01","Open")
        assert tid is not None
        tasks=ctx.projects.project_tasks(pid)
        assert len(tasks)==1
        assert tasks[0]["activity_name"]=="Skrog"
        assert tasks[0]["assigned_to"]=="Hans"
        assert tasks[0]["priority"]=="High"
        assert tasks[0]["status"]=="Open"
        ctx.projects.update_project_task(tid,status="In Progress",priority="Critical")
        task=ctx.projects.project_tasks(pid)[0]
        assert task["status"]=="In Progress"
        assert task["priority"]=="Critical"
        try:
            ctx.projects.create_project_task(pid,"Bad","",99999,"Hans")
            assert False,"Expected invalid activity rejection"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_operational_workboard():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Board Project","Operations","Active",10000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",5000)
        ctx.projects.create_project_task(pid,"Critical task","",aid,"Hans","Critical","2026-08-01","Open")
        ctx.projects.create_project_task(pid,"High task","",aid,"Hans","High","2026-08-20","Open")
        ctx.projects.create_project_task(pid,"Completed task","",aid,"Hans","Normal","2026-08-10","Completed")
        data=ctx.projects.operational_workboard()
        assert data["metrics"]["open_tasks"]==2
        assert data["metrics"]["critical_tasks"]==1
        assert data["metrics"]["high_tasks"]==1
        assert data["metrics"]["overdue_tasks"]==1
        assert data["metrics"]["next_7_days"]==2
        assert data["metrics"]["active_projects"]==1
        assert len(data["tasks"])==2
        assert data["tasks"][0]["priority"]=="Critical"
        assert data["projects"][0]["name"]=="Board Project"
    finally:
        d.cleanup()


def test_operational_actions_workflow():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Workflow Project","Actions","Active",5000)
        tid=ctx.projects.create_project_task(pid,"Do work","",None,"Hans","High","2026-09-01","Open")
        task=ctx.projects.task_detail(tid)
        assert task["status"]=="Open"
        ctx.projects.transition_project_task(tid,"In Progress")
        assert ctx.projects.task_detail(tid)["status"]=="In Progress"
        ctx.projects.transition_project_task(tid,"Blocked")
        assert ctx.projects.task_detail(tid)["status"]=="Blocked"
        ctx.projects.transition_project_task(tid,"In Progress")
        ctx.projects.transition_project_task(tid,"Completed")
        assert ctx.projects.task_detail(tid)["status"]=="Completed"
        ctx.projects.transition_project_task(tid,"Closed")
        assert ctx.projects.task_detail(tid)["status"]=="Closed"
        try:
            ctx.projects.transition_project_task(tid,"Open")
            assert False,"Closed task should not reopen"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_notifications_deadlines_followup():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Alert Project","Operations","Active",100)
        ctx.projects.create_project_task(pid,"Overdue","",None,"","High","2026-08-01","Open")
        ctx.projects.create_project_task(pid,"Due Soon","",None,"Hans","High","2026-08-22","Open")
        ctx.projects.create_project_task(pid,"Blocked","",None,"Hans","Normal","2026-08-22","Blocked")
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Overrun",[
            {"account_id":accounts["5100"],"debit":150,"credit":0,"project_id":pid},
            {"account_id":accounts["1000"],"debit":0,"credit":150,"project_id":pid}
        ],"2026-08-19")
        data=ctx.projects.operational_alerts("2026-08-19")
        types=[a["type"] for a in data["alerts"]]
        assert "overdue_task" in types
        assert "deadline_soon" in types
        assert "blocked_task" in types
        assert "missing_owner" in types
        assert "budget_overrun" in types
        assert data["counts"]["critical"] >= 2
        assert data["counts"]["high"] >= 3
    finally:
        d.cleanup()


def test_personal_work_queue_and_my_day():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Personal Project","Work","Active",1000)
        ctx.projects.create_project_task(pid,"Overdue","",None,"Hans","High","2026-08-01","Open")
        ctx.projects.create_project_task(pid,"Today","",None,"Hans","Critical","2026-08-19","In Progress")
        ctx.projects.create_project_task(pid,"Blocked","",None,"Hans","Normal","2026-08-21","Blocked")
        ctx.projects.create_project_task(pid,"Other","",None,"Else","High","2026-08-19","Open")
        data=ctx.projects.personal_work_queue("Hans","2026-08-19")
        assert data["metrics"]["open"]==3
        assert data["metrics"]["overdue"]==1
        assert data["metrics"]["today"]==1
        assert data["metrics"]["next_7_days"]==2
        assert data["metrics"]["critical"]==1
        assert data["metrics"]["blocked"]==1
        assert len(ctx.projects.my_day("Hans","2026-08-19")["today_tasks"])==1
    finally:
        d.cleanup()


def test_quick_actions_and_daily_execution():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Daily Project","Work","Active",1000)
        tid=ctx.projects.create_project_task(pid,"Daily task","",None,"Hans",
                                             "Normal","2026-08-25","Open")
        ctx.projects.quick_action(tid,"start")
        assert ctx.projects.task_detail(tid)["status"]=="In Progress"
        ctx.projects.quick_action(tid,"block")
        assert ctx.projects.task_detail(tid)["status"]=="Blocked"
        ctx.projects.quick_action(tid,"start")
        ctx.projects.quick_action(tid,"priority","Critical")
        ctx.projects.quick_action(tid,"deadline","2026-08-20")
        ctx.projects.quick_action(tid,"assign","Hans")
        task=ctx.projects.task_detail(tid)
        assert task["status"]=="In Progress"
        assert task["priority"]=="Critical"
        assert task["due_date"]=="2026-08-20"
        assert task["assigned_to"]=="Hans"
        ctx.projects.quick_action(tid,"complete")
        assert ctx.projects.task_detail(tid)["status"]=="Completed"
        try:
            ctx.projects.quick_action(tid,"block")
            assert False,"Completed task should not block directly"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_activity_and_project_execution_view():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Execution Project","Work","Active",20000)
        ctx.projects.set_budget(pid,20000)
        a1=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",12000)
        a2=ctx.projects.create_activity(pid,"Maskin","","2026-08-02","Active",5000)
        ctx.projects.create_project_task(pid,"Done task","",a1,"Hans","Normal","2026-08-10","Completed")
        ctx.projects.create_project_task(pid,"Open task","",a1,"Hans","High","2026-08-25","In Progress")
        ctx.projects.create_project_task(pid,"Machine task","",a2,"Else","Normal","2026-09-01","Open")
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Skrog cost",[
            {"account_id":accounts["5100"],"debit":4500,"credit":0,"project_id":pid,"activity_id":a1},
            {"account_id":accounts["1000"],"debit":0,"credit":4500,"project_id":pid,"activity_id":a1}
        ],"2026-08-19")
        dta=ctx.projects.project_execution_view(pid)
        assert dta["budget"]==20000
        assert dta["actual"]==4500
        assert dta["variance"]==15500
        assert dta["task_progress"]==33.33
        assert dta["activities"][0]["progress"]==50.0
        assert dta["activities"][0]["actual"]==4500
        assert len(dta["tasks"])==3
    finally:
        d.cleanup()


def test_project_execution_actions():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Action Project","Work","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",3000)
        tid=ctx.projects.create_project_task(pid,"Fit plank","",aid,"Hans","High","2026-08-25","Open")
        view=ctx.projects.activity_execution_view(pid,aid)
        assert view["activity"]["name"]=="Skrog"
        assert len(view["tasks"])==1
        assert view["progress"]==0.0
        ctx.projects.execution_action(pid,tid,"start")
        assert ctx.projects.task_detail(tid)["status"]=="In Progress"
        ctx.projects.execution_action(pid,tid,"complete")
        view=ctx.projects.activity_execution_view(pid,aid)
        assert view["progress"]==100.0
        try:
            ctx.projects.execution_action(pid,99999,"start")
            assert False,"Foreign/missing task should be rejected"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_project_progress_financial_control():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Control Project","Work","Active",10000)
        ctx.projects.set_budget(pid,10000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",6000)
        ctx.projects.create_project_task(pid,"Done","",aid,"Hans","Normal","2026-08-10","Completed")
        ctx.projects.create_project_task(pid,"Open","",aid,"Hans","High","2026-08-25","In Progress")
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Cost",[
            {"account_id":accounts["5100"],"debit":6500,"credit":0,"project_id":pid,"activity_id":aid},
            {"account_id":accounts["1000"],"debit":0,"credit":6500,"project_id":pid,"activity_id":aid}
        ],"2026-08-19")
        dta=ctx.projects.project_progress_control(pid)
        assert dta["task_progress"]==50.0
        assert dta["financial_status"]=="On budget"
        assert dta["execution_status"]=="In progress"
        assert dta["budget"]==10000
        assert dta["actual"]==6500
        assert dta["variance"]==3500
        assert dta["utilization"]==65.0
        assert dta["activities"][0]["progress"]==50.0
        assert dta["activities"][0]["control_status"]=="Over budget"
    finally:
        d.cleanup()


def test_project_control_actions_exception_management():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Exception Project","Work","Active",1000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",500)
        ctx.projects.create_project_task(pid,"Overdue","",aid,"","High","2026-08-01","Open")
        ctx.projects.create_project_task(pid,"Blocked","",aid,"Hans","High","2026-08-25","Blocked")
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Overrun",[
            {"account_id":accounts["5100"],"debit":600,"credit":0,"project_id":pid,"activity_id":aid},
            {"account_id":accounts["1000"],"debit":0,"credit":600,"project_id":pid,"activity_id":aid}
        ],"2026-08-19")
        data=ctx.projects.project_control_exceptions(pid)
        types={x["type"] for x in data["exceptions"]}
        assert "activity_over_budget" in types
        assert "overdue_task" in types
        assert "blocked_task" in types
        assert "missing_owner" in types
        e=next(x for x in data["exceptions"] if x["type"]=="activity_over_budget")
        tid=ctx.projects.create_exception_followup(pid,e,"Hans")
        assert ctx.projects.task_detail(tid)["title"].startswith("Opfølgning:")
        assert ctx.projects.task_detail(tid)["assigned_to"]=="Hans"
    finally:
        d.cleanup()


def test_project_control_cockpit_integration():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Cockpit Project","Work","Active",10000)
        ctx.projects.set_budget(pid,10000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",6000)
        ctx.projects.create_project_task(pid,"Done","",aid,"Hans","Normal","2026-08-10","Completed")
        ctx.projects.create_project_task(pid,"Open","",aid,"Hans","High","2026-08-20","In Progress")
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Cost",[
            {"account_id":accounts["5100"],"debit":6500,"credit":0,"project_id":pid,"activity_id":aid},
            {"account_id":accounts["1000"],"debit":0,"credit":6500,"project_id":pid,"activity_id":aid}
        ],"2026-08-19")
        dta=ctx.projects.project_control_cockpit(pid)
        assert dta["control"]["task_progress"]==50.0
        assert dta["control"]["budget"]==10000
        assert dta["control"]["actual"]==6500
        assert dta["control"]["variance"]==3500
        assert dta["open_tasks"]==1
        assert dta["exception_counts"]["total"]==1
        assert dta["activities"][0]["control_status"]=="Over budget"
        assert len(dta["tasks"])==2
    finally:
        d.cleanup()


def test_integrated_operations_dashboard():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Operations Project","Work","Active",10000)
        ctx.projects.set_budget(pid,10000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",6000)
        ctx.projects.create_project_task(pid,"Open","",aid,"Hans","High","2026-08-25","In Progress")
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        ctx.accounting.post_journal(None,"Cost",[
            {"account_id":accounts["5100"],"debit":6500,"credit":0,"project_id":pid,"activity_id":aid},
            {"account_id":accounts["1000"],"debit":0,"credit":6500,"project_id":pid,"activity_id":aid}
        ],"2026-08-19")
        data=ctx.projects.integrated_operations_dashboard()
        assert data["project_summary"]["active"]==1
        assert data["project_summary"]["open_tasks"]==1
        assert data["project_summary"]["exceptions"]>=1
        assert data["project_summary"]["over_budget"]==0
        assert data["projects"][0]["actual"]==6500
        assert data["projects"][0]["progress"]==0.0
        assert "member_summary" in data
    finally:
        d.cleanup()


def test_integrated_operations_actions():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Actions Project","Work","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        tid=ctx.projects.create_project_task(pid,"Open task","",aid,"Hans","High","2026-08-25","Open")
        tasks=ctx.projects.integrated_operations_action("open_tasks",project_id=pid)
        assert len(tasks["tasks"])==1
        ctx.projects.integrated_operations_action("start",project_id=pid,task_id=tid)
        assert ctx.projects.task_detail(tid)["status"]=="In Progress"
        cockpit=ctx.projects.integrated_operations_action("open_project",project_id=pid)
        assert cockpit["project"]["id"]==pid
        exc=ctx.projects.integrated_operations_action("open_exceptions",project_id=pid)
        assert "exceptions" in exc
        d2=ctx.projects.integrated_operations_action("create_exception_followup",
            project_id=pid,exception_index=0) if exc["exceptions"] else None
        if d2:
            assert "exception" in d2
    finally:
        d.cleanup()


def test_navigation_workspace_integration():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Workspace Project","Work","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        tid=ctx.projects.create_project_task(pid,"Task","",aid,"Hans","Normal","2026-08-25","Open")
        project_ctx=ctx.projects.workspace_context("project",pid)
        task_ctx=ctx.projects.workspace_context("task",tid)
        activity_ctx=ctx.projects.workspace_context("activity",aid)
        assert project_ctx["type"]=="project"
        assert project_ctx["data"]["project"]["id"]==pid
        assert task_ctx["data"]["id"]==tid
        assert activity_ctx["data"]["id"]==aid
        try:
            ctx.projects.workspace_context("task",99999)
            assert False,"Missing task should be rejected"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_global_search_contextual_navigation():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Álvur Restaurering","Historisk projekt","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrogarbejde","Udskiftning","","Active",2000)
        tid=ctx.projects.create_project_task(pid,"Udskift spant","Spant 17",aid,"Hans","High","2026-08-25","Open")
        results=ctx.projects.global_search("spant")
        assert any(r["type"]=="Opgave" and r["id"]==tid for r in results)
        results=ctx.projects.global_search("Álvur")
        assert any(r["type"]=="Projekt" and r["id"]==pid for r in results)
        results=ctx.projects.global_search("Skrog")
        assert any(r["type"]=="Aktivitet" and r["id"]==aid for r in results)
        assert ctx.projects.global_search("")==[]
    finally:
        d.cleanup()


def test_unified_record_view():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Unified Project","Detail","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        tid=ctx.projects.create_project_task(pid,"Udskift spant","Spant 17",aid,"Hans","High","2026-08-25","Open")
        pview=ctx.projects.unified_record_view("project",pid)
        assert pview["record"]["id"]==pid
        assert any(t["id"]==tid for t in pview["related"]["tasks"])
        aview=ctx.projects.unified_record_view("activity",aid)
        assert aview["record"]["id"]==aid
        assert any(t["id"]==tid for t in aview["related"]["tasks"])
        tview=ctx.projects.unified_record_view("task",tid)
        assert tview["record"]["id"]==tid
        assert "complete" in tview["actions"]
    finally:
        d.cleanup()


def test_contextual_actions_and_related_records():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Context Action Project","Detail","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        tid=ctx.projects.create_project_task(pid,"Udskift spant","Spant 17",aid,"Hans","High","2026-08-25","Open")
        ctx.projects.contextual_action("task",tid,"start")
        assert ctx.projects.task_detail(tid)["status"]=="In Progress"
        related=ctx.projects.contextual_action("project",pid,"open_related",
            {"type":"activity","id":aid})
        assert related["record"]["id"]==aid
        follow=ctx.projects.contextual_action("activity",aid,"create_followup","Hans")
        assert ctx.projects.task_detail(follow["task_id"])["activity_id"]==aid
        try:
            ctx.projects.contextual_action("project",pid,"complete")
            assert False,"Non-task workflow action should be rejected"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_personal_workspace_my_work():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("My Work Project","Detail","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        tid1=ctx.projects.create_project_task(pid,"Open","",aid,"Hans","High","2099-08-25","Open")
        tid2=ctx.projects.create_project_task(pid,"Blocked","",aid,"Hans","High","2099-08-26","Blocked")
        ctx.projects.create_project_task(pid,"Other","",aid,"Else","Normal","2099-08-27","Open")
        data=ctx.projects.personal_workspace("Hans")
        assert data["summary"]["open"]==2
        assert data["summary"]["blocked"]==1
        assert len(data["tasks"])==2
        assert {t["id"] for t in data["tasks"]}=={tid1,tid2}
    finally:
        d.cleanup()


def test_personal_work_actions_daily_execution():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Daily Work Project","Detail","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        tid=ctx.projects.create_project_task(pid,"Daily task","",aid,"Hans","High","2099-08-25","Open")
        result=ctx.projects.personal_work_action("Hans",tid,"start")
        assert result["task"]["status"]=="In Progress"
        data=ctx.projects.personal_workspace("Hans")
        assert data["summary"]["open"]==1
        ctx.projects.personal_work_action("Hans",tid,"complete")
        data=ctx.projects.personal_workspace("Hans")
        assert data["summary"]["open"]==0
        try:
            ctx.projects.personal_work_action("Else",tid,"start")
            assert False,"Unassigned user must be rejected"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_daily_work_prioritization_today_view():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Today Project","Detail","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        overdue=ctx.projects.create_project_task(pid,"Overdue","",aid,"Hans","Normal","2020-01-01","Open")
        today=ctx.projects.create_project_task(pid,"Today","",aid,"Hans","Normal","2026-08-19","Open")
        high=ctx.projects.create_project_task(pid,"High","",aid,"Hans","High","2099-08-30","Open")
        blocked=ctx.projects.create_project_task(pid,"Blocked","",aid,"Hans","Normal","2099-08-31","Blocked")
        data=ctx.projects.today_view("Hans","2026-08-19")
        assert data["summary"]["total"]==4
        assert overdue in [t["id"] for t in data["buckets"]["overdue"]]
        assert today in [t["id"] for t in data["buckets"]["due_today"]]
        assert high in [t["id"] for t in data["buckets"]["high_priority"]]
        assert blocked in [t["id"] for t in data["buckets"]["blocked"]]
    finally:
        d.cleanup()


def test_quick_capture_work_intake():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Quick Project","Detail","Active",5000)
        aid=ctx.projects.create_activity(pid,"Skrog","","2026-08-01","Active",2000)
        task=ctx.projects.quick_capture("Udskift pakning",pid,aid,"Hans","High","2026-08-25","Motor")
        assert task["title"]=="Udskift pakning"
        assert task["project_id"]==pid
        assert task["activity_id"]==aid
        assert task["assigned_to"]=="Hans"
        assert task["priority"]=="High"
        try:
            ctx.projects.quick_capture("",pid)
            assert False,"Empty title must be rejected"
        except ValueError:
            pass
        try:
            ctx.projects.quick_capture("Bad activity",pid,99999)
            assert False,"Invalid activity must be rejected"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_work_intake_triage_assignment():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Triage Project","Detail","Active",5000)
        tid=ctx.projects.quick_capture("Ny arbejdsopgave",pid)
        updated=ctx.projects.triage_work_item(tid,"Hans","High","2026-08-25")
        assert updated["assigned_to"]=="Hans"
        assert updated["priority"]=="High"
        assert updated["due_date"]=="2026-08-25"
        assert updated["status"]=="Open"
        updated=ctx.projects.triage_work_item(tid,"Else","Normal",None,"In Progress")
        assert updated["assigned_to"]=="Else"
        assert updated["status"]=="In Progress"
        try:
            ctx.projects.triage_work_item(tid,"Hans","Impossible")
            assert False,"Invalid priority must be rejected"
        except ValueError:
            pass
    finally:
        d.cleanup()


def test_work_intake_inbox_only_contains_unassigned_open_work():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Inbox Project","Detail","Active",5000)
        unassigned=ctx.projects.quick_capture("Needs triage",pid)
        assigned=ctx.projects.quick_capture("Already assigned",pid,assigned_to="Hans")
        blocked=ctx.projects.quick_capture("Blocked",pid)
        ctx.projects.triage_work_item(blocked,None,"High",None,"Blocked")
        inbox=ctx.projects.work_intake_inbox()
        ids={x["id"] for x in inbox["items"]}
        assert unassigned["id"] in ids
        assert assigned["id"] not in ids
        assert blocked["id"] not in ids
        assert inbox["count"]==1
        assert inbox["rule"]=="Open + unassigned"
    finally:
        d.cleanup()

def test_project_financial_report_uses_project_accounting_actuals_and_traceability():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        pid = ctx.projects.create("Report Project")
        ctx.projects.set_budget(pid, 1000)
        ctx.accounting.post_journal(None, "Project expense", [
            {"account_id": a["5000"]["id"], "debit": 250, "credit": 0, "project_id": pid},
            {"account_id": a["1000"]["id"], "debit": 0, "credit": 250, "project_id": pid},
        ], "2026-03-15")
        report = ctx.projects.financial_report(pid, 3)
        assert report["budget"] == 1000.0
        assert report["actual"] == 250.0
        assert report["revenue"] == 0.0
        assert report["funding"] == 0.0
        assert report["variance"] == 750.0
        assert report["read_only"] is True
        assert report["accounting_lines"][0]["journal_no"]
        assert report["accounting_lines"][0]["journal_id"]
        assert report["accounting_lines"][0]["line_id"]
        assert report["monthly_actuals"] == [{"month": "2026-03", "actual": 250.0}]
    finally:
        d.cleanup()


def test_project_financial_report_includes_authoritative_project_revenue():
    d, db, ctx = setup()
    try:
        a = {x["number"]: x for x in ctx.accounting.accounts()}
        pid = ctx.projects.create("Funded Project")
        ctx.accounting.post_journal(None, "Project funding", [
            {"account_id": a["1000"]["id"], "debit": 1000, "credit": 0, "project_id": pid},
            {"account_id": a["4000"]["id"], "debit": 0, "credit": 1000, "project_id": pid},
        ], "2026-04-15")
        report = ctx.projects.financial_report(pid, 3)
        assert report["revenue"] == 1000.0
        assert report["funding"] == 1000.0
        assert len(report["income_lines"]) == 1
        assert report["income_lines"][0]["journal_id"]
        assert report["income_lines"][0]["line_id"]
    finally:
        d.cleanup()


def test_project_financial_report_api_exists():
    from src.services.project_service import ProjectService
    assert hasattr(ProjectService, "financial_report")


def test_project_financial_forecast_respects_calendar_months():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Forecast Calendar","Trend","Active",10000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        for day, amount in [("2026-01-15",1000),("2026-03-15",3000)]:
            ctx.accounting.post_journal(None,"Forecast cost",[
                {"account_id":accounts["5100"],"debit":amount,"credit":0,
                 "project_id":pid},
                {"account_id":accounts["1000"],"debit":0,"credit":amount,
                 "project_id":pid}
            ],day)
        report=ctx.projects.financial_forecast(pid,2)
        assert report["available"] is True
        assert [x["month"] for x in report["history"]]==["2026-01","2026-03"]
        assert [x["month"] for x in report["forecasts"]]==["2026-04","2026-05"]
        assert report["forecasts"][0]["value"]==4000.0
    finally:
        d.cleanup()


def test_project_financial_forecast_reports_calendar_gaps():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Forecast Gap","Trend","Active",10000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        for day, amount in [("2026-01-15",1000),("2026-03-15",3000)]:
            ctx.accounting.post_journal(None,"Forecast gap",[
                {"account_id":accounts["5100"],"debit":amount,"credit":0,"project_id":pid},
                {"account_id":accounts["1000"],"debit":0,"credit":amount,"project_id":pid}
            ],day)
        report=ctx.projects.financial_forecast(pid,2)
        assert report["data_points"] == 2
        assert report["expected_months"] == 3
        assert report["missing_months"] == ["2026-02"]
        assert report["history_complete"] is False
        assert report["forecasts"][0]["month"] == "2026-04"
    finally:
        d.cleanup()


def test_project_financial_forecast_insufficient_history_contract():
    d, db, ctx = setup()
    try:
        pid=ctx.projects.create("Forecast Single Month","Trend","Active",10000)
        accounts={a["number"]:a["id"] for a in ctx.accounting.accounts()}
        amount=1250
        ctx.accounting.post_journal(None,"Single month forecast",[
            {"account_id":accounts["5100"],"debit":amount,"credit":0,"project_id":pid},
            {"account_id":accounts["1000"],"debit":0,"credit":amount,"project_id":pid}
        ],"2026-06-15")
        report=ctx.projects.financial_forecast(pid,2)
        assert report["available"] is False
        assert report["data_points"] == 1
        assert report["forecasts"] == []
        assert report["history_complete"] is True
        assert report["missing_months"] == []
        assert report["slope"] == 0.0
        assert report["intercept"] == 0.0
    finally:
        d.cleanup()
