import csv
from pathlib import Path

class ExportService:
    def __init__(self, context):
        self.ctx = context

    def _write_csv(self, path, headers, rows):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            raise FileExistsError(f"Export destination already exists: {path}")
        with path.open("x", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)
        return path

    def _export(self, label, path, headers, rows):
        try:
            result = self._write_csv(path, headers, rows)
            self.ctx.audit.success(
                self.ctx.current_user,
                "EXPORT",
                label,
                message=f"Exported {label} to {result.name}",
            )
            return result
        except Exception as exc:
            self.ctx.audit.failure(
                self.ctx.current_user,
                "EXPORT",
                label,
                message=str(exc),
            )
            raise

    def export_members(self, path):
        rows = self.ctx.members.members()
        headers = ["member_no","first_name","last_name","email","phone","status","joined_date"]
        return self._export("members", path, headers, [[r[h] for h in headers] for r in rows])

    def export_projects(self, path):
        rows = self.ctx.projects.list()
        headers = ["id","name","status","budget","start_date","end_date"]
        return self._export("projects", path, headers, [[r[h] for h in headers] for r in rows])

    def export_journals(self, path):
        rows = self.ctx.accounting.journals()
        headers = ["journal_no","journal_date","description","status"]
        return self._export("journals", path, headers, [[r[h] for h in headers] for r in rows])

    def export_invoices(self, path):
        rows = self.ctx.members.invoices()
        headers = ["invoice_no","member_no","first_name","last_name","invoice_date","due_date","amount","status"]
        return self._export("invoices", path, headers, [[r[h] for h in headers] for r in rows])

    def export_bank_transactions(self, path):
        rows = self.ctx.bank.transactions()
        headers = ["id","transaction_date","amount","description","external_reference","status"]
        return self._export("bank_transactions", path, headers, [[r[h] for h in headers] for r in rows])

    def export_trial_balance(self, path):
        rows = self.ctx.accounting.trial_balance()
        headers = ["number","name","debit","credit"]
        return self._export("trial_balance", path, headers, [[r[h] for h in headers] for r in rows])
