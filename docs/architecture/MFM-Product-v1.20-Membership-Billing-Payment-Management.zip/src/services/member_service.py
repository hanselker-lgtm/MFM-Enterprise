from datetime import date, timedelta

class MemberService:
    def __init__(self, repo, accounting=None):
        self.repo = repo
        self.accounting = accounting

    def create_member(self, member_no, first_name, last_name, **kwargs):
        if not str(member_no).strip():
            raise ValueError("Member number is required.")
        if not str(first_name).strip() or not str(last_name).strip():
            raise ValueError("First name and last name are required.")
        return self.repo.create_member(
            str(member_no).strip(), str(first_name).strip(), str(last_name).strip(),
            str(kwargs.get("email", "")).strip(), str(kwargs.get("phone", "")).strip(),
            str(kwargs.get("address", "")).strip(), str(kwargs.get("postal_code", "")).strip(),
            str(kwargs.get("city", "")).strip(), kwargs.get("joined_date")
        )

    def members(self):
        return self.repo.list_members()

    def create_membership_type(self, name, annual_fee):
        name = str(name).strip()
        annual_fee = float(annual_fee)
        if not name:
            raise ValueError("Membership type name is required.")
        if annual_fee < 0:
            raise ValueError("Membership fee cannot be negative.")
        return self.repo.create_membership_type(name, annual_fee)

    def membership_types(self):
        return self.repo.list_membership_types()

    def add_membership(self, member_id, membership_type_id, start_date=None):
        return self.repo.create_membership(
            member_id, membership_type_id, start_date or date.today().isoformat()
        )

    def memberships(self):
        return self.repo.list_memberships()

    def invoice_membership(self, membership_id, member_id, amount, invoice_date=None, due_date=None):
        amount = float(amount)
        if amount <= 0:
            raise ValueError("Invoice amount must be greater than zero.")
        invoice_date = invoice_date or date.today().isoformat()
        due_date = due_date or (date.today() + timedelta(days=14)).isoformat()
        invoice_no = self.repo.next_invoice_number()

        # Invoice: debit receivable / credit membership income.
        journal_id = None
        if self.accounting:
            accounts = {a["number"]: a for a in self.accounting.accounts()}
            if accounts.get("1200") and accounts.get("3000"):
                journal_id = self.accounting.post_journal(
                    None, f"Membership invoice {invoice_no}", [
                        {"account_id": accounts["1200"]["id"], "debit": amount, "credit": 0},
                        {"account_id": accounts["3000"]["id"], "debit": 0, "credit": amount},
                    ], invoice_date
                )

        return self.repo.create_invoice(
            member_id, membership_id, invoice_no, invoice_date, due_date, amount, journal_id
        )

    def invoices(self):
        return self.repo.list_invoices()

    def register_payment(self, invoice_id, amount, payment_date=None):
        payment_date = payment_date or date.today().isoformat()
        invoice = self.repo.get_invoice(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found.")

        amount = round(float(amount), 2)
        if amount <= 0:
            raise ValueError("Payment must be greater than zero.")

        paid_before = self.repo.invoice_paid_amount(invoice_id)
        remaining = round(float(invoice["amount"]) - paid_before, 2)
        if amount > remaining:
            raise ValueError("Payment exceeds outstanding invoice amount.")

        journal_id = None
        if self.accounting:
            accounts = {a["number"]: a for a in self.accounting.accounts()}
            if accounts.get("1000") and accounts.get("1200"):
                journal_id = self.accounting.post_journal(
                    None, f"Payment invoice {invoice['invoice_no']}", [
                        {"account_id": accounts["1000"]["id"], "debit": amount, "credit": 0},
                        {"account_id": accounts["1200"]["id"], "debit": 0, "credit": amount},
                    ], payment_date
                )

        payment_id = self.repo.register_payment(
            invoice_id, payment_date, amount, journal_id
        )
        paid_after = round(paid_before + amount, 2)
        self.repo.update_invoice_status(
            invoice_id,
            "Paid" if paid_after >= float(invoice["amount"]) else "Partially Paid"
        )
        return payment_id

    def payments(self):
        return self.repo.list_payments()


    def summary(self):
        return dict(self.repo.member_summary())

    def search(self, text):
        return self.repo.search_members(text)

    def member(self, member_id):
        return self.repo.get_member(member_id)

    def member_invoices(self, member_id):
        return self.repo.list_member_invoices(member_id)

    def invoice_status(self, invoice):
        paid=float(invoice["paid_amount"] if "paid_amount" in invoice.keys() else 0) if hasattr(invoice, "keys") else 0
        amount=float(invoice["amount"])
        if paid >= amount:
            return "Paid"
        if paid > 0:
            return "Partially Paid"
        from datetime import date
        if invoice["due_date"] < date.today().isoformat():
            return "Overdue"
        return "Open"

    def refresh_invoice_statuses(self):
        for invoice in self.repo.list_invoices():
            paid=self.repo.invoice_paid_amount(invoice["id"])
            invoice_for_status=dict(invoice)
            invoice_for_status["paid_amount"]=paid
            status=self.invoice_status(invoice_for_status)
            if status != invoice["status"]:
                self.repo.update_invoice_status(invoice["id"], status)

    def invoice_active_membership(self, member_id):
        member=self.repo.get_member(member_id)
        if not member:
            raise ValueError("Member not found.")
        rows=[m for m in self.repo.list_memberships()
              if m["member_no"]==member["member_no"] and m["status"]=="Active"]
        if not rows:
            raise ValueError("Member has no active membership.")
        m=rows[0]
        return self.invoice_membership(m["id"], member_id, float(m["annual_fee"]))

    def billing_preview(self, billing_year, invoice_date=None, due_date=None):
        invoice_date = invoice_date or f"{billing_year}-01-01"
        due_date = due_date or invoice_date
        rows=[]
        for m in self.repo.billing_candidates(int(billing_year)):
            existing=self.repo.existing_invoice_for_membership_year(
                m["membership_id"], int(billing_year)
            )
            rows.append({
                "membership_id":m["membership_id"],
                "member_id":m["member_id"],
                "member_no":m["member_no"],
                "name":f'{m["first_name"]} {m["last_name"]}',
                "membership_type":m["membership_type"],
                "amount":float(m["annual_fee"]),
                "already_invoiced":bool(existing),
                "existing_invoice_no":existing["invoice_no"] if existing else None,
                "invoice_date":invoice_date,
                "due_date":due_date
            })
        return rows

    def bill_memberships(self, billing_year, invoice_date=None, due_date=None):
        rows=self.billing_preview(billing_year, invoice_date, due_date)
        created=[]
        skipped=[]
        for row in rows:
            if row["already_invoiced"]:
                skipped.append(row)
                continue
            invoice_id=self.invoice_membership(
                row["membership_id"], row["member_id"], row["amount"],
                row["invoice_date"], row["due_date"]
            )
            created.append({
                **row,
                "invoice_id":invoice_id
            })
        return {
            "billing_year":int(billing_year),
            "created":created,
            "skipped":skipped,
            "created_count":len(created),
            "skipped_count":len(skipped)
        }

    def payment_status_summary(self, billing_year=None):
        invoices=self.repo.list_invoices()
        if billing_year:
            invoices=[i for i in invoices
                      if f"{billing_year}-01-01" <= i["invoice_date"] <= f"{billing_year}-12-31"]
        summary={"invoices":0,"paid":0,"partially_paid":0,"open":0,"overdue":0,
                 "invoiced":0.0,"paid_amount":0.0,"outstanding":0.0}
        for inv in invoices:
            paid=self.repo.invoice_paid_amount(inv["id"])
            amount=float(inv["amount"])
            status=self.invoice_status({**dict(inv),"paid_amount":paid})
            summary["invoices"]+=1
            summary["invoiced"]+=amount
            summary["paid_amount"]+=paid
            summary["outstanding"]+=max(0.0,amount-paid)
            key={"Paid":"paid","Partially Paid":"partially_paid",
                 "Overdue":"overdue","Open":"open"}[status]
            summary[key]+=1
        for k in ("invoiced","paid_amount","outstanding"):
            summary[k]=round(summary[k],2)
        return summary

    def outstanding_invoices(self, billing_year=None):
        invoices=self.repo.list_invoices()
        result=[]
        for inv in invoices:
            if billing_year and not (f"{billing_year}-01-01" <= inv["invoice_date"] <= f"{billing_year}-12-31"):
                continue
            paid=self.repo.invoice_paid_amount(inv["id"])
            row=dict(inv)
            row["paid_amount"]=paid
            row["outstanding"]=round(float(inv["amount"])-paid,2)
            row["status"]=self.invoice_status(row)
            if row["outstanding"] > 0:
                result.append(row)
        return result
