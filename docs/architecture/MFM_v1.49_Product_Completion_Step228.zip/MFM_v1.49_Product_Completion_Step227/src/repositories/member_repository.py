class MemberRepository:
    def __init__(self, db):
        self.db = db

    def list_members(self):
        return self.db.fetch_all("SELECT * FROM members ORDER BY last_name, first_name")

    def create_member(self, member_no, first_name, last_name, email="", phone="",
                      address="", postal_code="", city="", joined_date=None):
        return self.db.execute(
            """INSERT INTO members
               (member_no,first_name,last_name,email,phone,address,postal_code,city,joined_date)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (member_no, first_name, last_name, email, phone, address,
             postal_code, city, joined_date)
        )

    def list_membership_types(self):
        return self.db.fetch_all(
            "SELECT * FROM membership_types WHERE active=1 ORDER BY name"
        )

    def create_membership_type(self, name, annual_fee):
        return self.db.execute(
            "INSERT INTO membership_types(name,annual_fee) VALUES(?,?)",
            (name, annual_fee)
        )

    def create_membership(self, member_id, membership_type_id, start_date, end_date=None):
        return self.db.execute(
            """INSERT INTO memberships(member_id,membership_type_id,start_date,end_date)
               VALUES(?,?,?,?)""",
            (member_id, membership_type_id, start_date, end_date)
        )

    def list_memberships(self):
        return self.db.fetch_all(
            """SELECT ms.member_id, ms.id, m.member_no, m.first_name, m.last_name,
                      mt.name membership_type, mt.annual_fee,
                      ms.start_date, ms.end_date, ms.status
               FROM memberships ms
               JOIN members m ON m.id=ms.member_id
               JOIN membership_types mt ON mt.id=ms.membership_type_id
               ORDER BY m.last_name, m.first_name"""
        )

    def next_invoice_number(self):
        row = self.db.fetch_one(
            "SELECT COALESCE(MAX(invoice_no),0)+1 n FROM membership_invoices"
        )
        return row["n"]

    def create_invoice_with_journal(self, member_id, membership_id,
                                     invoice_no, invoice_date, due_date,
                                     amount, journal_id=None):
        """Create invoice and its journal reference in one transaction."""
        with self.db.connect() as conn:
            try:
                cur = conn.execute(
                    """INSERT INTO membership_invoices
                       (member_id,membership_id,invoice_no,invoice_date,due_date,amount,journal_id)
                       VALUES(?,?,?,?,?,?,?)""",
                    (member_id, membership_id, invoice_no, invoice_date,
                     due_date, amount, journal_id),
                )
                conn.commit()
                return cur.lastrowid
            except Exception:
                conn.rollback()
                raise

    def register_payment_with_status(self, invoice_id, payment_date, amount,
                                      journal_id, status, conn=None):
        """Create payment and update invoice status atomically."""
        owns_transaction = conn is None
        connection = conn or self.db.connect()
        try:
            cur = connection.execute(
                """INSERT INTO membership_payments
                   (invoice_id,payment_date,amount,journal_id)
                   VALUES(?,?,?,?)""",
                (invoice_id, payment_date, amount, journal_id),
            )
            connection.execute(
                "UPDATE membership_invoices SET status=? WHERE id=?",
                (status, invoice_id),
            )
            if owns_transaction:
                connection.commit()
            return cur.lastrowid
        except Exception:
            if owns_transaction:
                connection.rollback()
            raise
        finally:
            if owns_transaction:
                connection.close()

    def create_invoice(self, member_id, membership_id, invoice_no,
                       invoice_date, due_date, amount, journal_id=None):
        return self.db.execute(
            """INSERT INTO membership_invoices
               (member_id,membership_id,invoice_no,invoice_date,due_date,amount,journal_id)
               VALUES(?,?,?,?,?,?,?)""",
            (member_id, membership_id, invoice_no, invoice_date, due_date, amount, journal_id)
        )

    def list_invoices(self):
        return self.db.fetch_all(
            """SELECT i.*, m.member_no, m.first_name, m.last_name
               FROM membership_invoices i
               JOIN members m ON m.id=i.member_id
               ORDER BY i.invoice_date DESC, i.invoice_no DESC"""
        )

    def get_invoice(self, invoice_id):
        return self.db.fetch_one(
            "SELECT * FROM membership_invoices WHERE id=?", (invoice_id,)
        )

    def register_payment(self, invoice_id, payment_date, amount, journal_id=None):
        return self.db.execute(
            """INSERT INTO membership_payments
               (invoice_id,payment_date,amount,journal_id)
               VALUES(?,?,?,?)""",
            (invoice_id, payment_date, amount, journal_id)
        )

    def invoice_paid_amount(self, invoice_id):
        row = self.db.fetch_one(
            """SELECT COALESCE(SUM(amount),0) amount
               FROM membership_payments WHERE invoice_id=?""",
            (invoice_id,)
        )
        return float(row["amount"] or 0)

    def update_invoice_status(self, invoice_id, status):
        self.db.execute(
            "UPDATE membership_invoices SET status=? WHERE id=?",
            (status, invoice_id)
        )

    def list_payments(self):
        return self.db.fetch_all(
            """SELECT p.*, i.invoice_no, m.member_no, m.first_name, m.last_name
               FROM membership_payments p
               JOIN membership_invoices i ON i.id=p.invoice_id
               JOIN members m ON m.id=i.member_id
               ORDER BY p.payment_date DESC, p.id DESC"""
        )


    def member_summary(self):
        return self.db.fetch_one(
            """SELECT
                 (SELECT COUNT(*) FROM members) members,
                 (SELECT COUNT(*) FROM members WHERE status='Active') active_members,
                 (SELECT COUNT(*) FROM memberships WHERE status='Active') active_memberships,
                 (SELECT COUNT(*) FROM membership_invoices
                    WHERE status IN ('Open','Partially Paid')) open_invoices,
                 (SELECT COALESCE(SUM(amount),0) FROM membership_invoices
                    WHERE status IN ('Open','Partially Paid')) invoiced,
                 (SELECT COALESCE(SUM(
                    i.amount - COALESCE((SELECT SUM(p.amount)
                      FROM membership_payments p WHERE p.invoice_id=i.id),0)
                  ),0)
                  FROM membership_invoices i
                  WHERE i.status IN ('Open','Partially Paid')) outstanding
            """
        )

    def search_members(self, text):
        q=f"%{str(text).strip()}%"
        return self.db.fetch_all(
            """SELECT * FROM members
               WHERE member_no LIKE ? OR first_name LIKE ?
                  OR last_name LIKE ? OR email LIKE ?
               ORDER BY last_name, first_name""",
            (q,q,q,q)
        )

    def get_member(self, member_id):
        return self.db.fetch_one("SELECT * FROM members WHERE id=?", (member_id,))

    def list_member_invoices(self, member_id):
        return self.db.fetch_all(
            """SELECT i.*, m.member_no, m.first_name, m.last_name,
                      COALESCE((SELECT SUM(p.amount)
                                FROM membership_payments p
                                WHERE p.invoice_id=i.id),0) paid_amount
               FROM membership_invoices i
               JOIN members m ON m.id=i.member_id
               WHERE i.member_id=?
               ORDER BY i.invoice_date DESC, i.invoice_no DESC""",
            (member_id,)
        )

    def billing_candidates(self, billing_year):
        return self.db.fetch_all(
            """SELECT ms.id membership_id, ms.member_id, ms.membership_type_id,
                      m.member_no, m.first_name, m.last_name,
                      mt.name membership_type, mt.annual_fee
               FROM memberships ms
               JOIN members m ON m.id=ms.member_id
               JOIN membership_types mt ON mt.id=ms.membership_type_id
               WHERE ms.status='Active'
                 AND m.status='Active'
                 AND ms.start_date<=?
                 AND (ms.end_date IS NULL OR ms.end_date>=?)
               ORDER BY m.last_name,m.first_name""",
            (f"{billing_year}-12-31", f"{billing_year}-01-01")
        )

    def existing_invoice_for_membership_year(self, membership_id, billing_year):
        return self.db.fetch_one(
            """SELECT * FROM membership_invoices
               WHERE membership_id=?
                 AND invoice_date>=? AND invoice_date<=?
               ORDER BY id DESC LIMIT 1""",
            (membership_id, f"{billing_year}-01-01", f"{billing_year}-12-31")
        )

    def invoice_payment_status(self, invoice_id):
        return self.db.fetch_one(
            """SELECT i.amount,
                      COALESCE(SUM(p.amount),0) paid_amount
               FROM membership_invoices i
               LEFT JOIN membership_payments p ON p.invoice_id=i.id
               WHERE i.id=?
               GROUP BY i.id""",
            (invoice_id,)
        )

    def add_communication(self, member_id, invoice_id, channel, communication_type,
                          subject, body, sent_at, status="Sent"):
        return self.db.execute(
            """INSERT INTO member_communications
               (member_id,invoice_id,channel,communication_type,subject,body,
                sent_at,status)
               VALUES(?,?,?,?,?,?,?,?)""",
            (member_id,invoice_id,channel,communication_type,subject,body,
             sent_at,status)
        )

    def dunning_candidates(self, as_of_date):
        return self.db.fetch_all(
            """SELECT i.*, m.member_no, m.first_name, m.last_name, m.email,
                      m.phone, m.status member_status,
                      COALESCE((SELECT SUM(p.amount)
                                FROM membership_payments p
                                WHERE p.invoice_id=i.id),0) paid_amount
               FROM membership_invoices i
               JOIN members m ON m.id=i.member_id
               WHERE i.due_date < ? AND m.status='Active'
               ORDER BY i.due_date, m.last_name, m.first_name""",
            (as_of_date,)
        )

    def list_communication_log(self, member_id=None, invoice_id=None):
        sql="SELECT * FROM member_communications WHERE 1=1"
        params=[]
        if member_id is not None:
            sql+=" AND member_id=?"; params.append(member_id)
        if invoice_id is not None:
            sql+=" AND invoice_id=?"; params.append(invoice_id)
        sql+=" ORDER BY sent_at DESC, id DESC"
        return self.db.fetch_all(sql,tuple(params))

    def update_member(self, member_id, **fields):
        allowed={"first_name","last_name","email","phone","address",
                 "postal_code","city","joined_date","status"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates:
            return self.get_member(member_id)
        sql="UPDATE members SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql, tuple(updates.values())+(member_id,))
        return self.get_member(member_id)

    def update_membership(self, membership_id, **fields):
        allowed={"membership_type_id","start_date","end_date","status"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates:
            return self.db.fetch_one("SELECT * FROM memberships WHERE id=?", (membership_id,))
        sql="UPDATE memberships SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql, tuple(updates.values())+(membership_id,))
        return self.db.fetch_one("SELECT * FROM memberships WHERE id=?", (membership_id,))

    def member_events(self, member_id):
        return self.db.fetch_all(
            """SELECT * FROM member_events
               WHERE member_id=?
               ORDER BY event_date DESC, id DESC""",
            (member_id,)
        )

    def add_member_event(self, member_id, event_type, event_date, description,
                         old_status=None, new_status=None, metadata=None):
        return self.db.execute(
            """INSERT INTO member_events
               (member_id,event_type,event_date,description,old_status,new_status,metadata)
               VALUES(?,?,?,?,?,?,?)""",
            (member_id,event_type,event_date,description,old_status,new_status,metadata)
        )

    def member_card(self, member_id):
        member=self.get_member(member_id)
        if not member:
            return None
        memberships=self.db.fetch_all(
            """SELECT ms.*, mt.name membership_type, mt.annual_fee
               FROM memberships ms
               JOIN membership_types mt ON mt.id=ms.membership_type_id
               WHERE ms.member_id=?
               ORDER BY ms.start_date DESC, ms.id DESC""",
            (member_id,)
        )
        invoices=self.db.fetch_all(
            """SELECT i.*, COALESCE((SELECT SUM(p.amount)
                    FROM membership_payments p WHERE p.invoice_id=i.id),0) paid_amount
               FROM membership_invoices i
               WHERE i.member_id=?
               ORDER BY i.invoice_date DESC, i.id DESC""",
            (member_id,)
        )
        return {"member":member,"memberships":memberships,
                "invoices":invoices,"events":self.member_events(member_id)}
