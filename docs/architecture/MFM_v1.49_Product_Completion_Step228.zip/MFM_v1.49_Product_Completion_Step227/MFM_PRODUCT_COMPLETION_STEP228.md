# MFM v1.49 — Product Completion Step 228
## Payment Transaction Integrity

### Scope
Correct the cross-domain transaction boundary for membership payments so the Accounting journal and Membership payment/invoice state commit or roll back together.

### Defect
Before Step 228, `MemberService.register_payment()` called `AccountingService.post_journal()` using AccountingRepository's independent database connection and only afterwards persisted the membership payment and invoice status using a second connection. A failure during membership persistence could therefore leave a posted accounting journal without a corresponding membership payment.

### Correction
- `AccountingRepository.create_posted_journal()` now accepts an optional caller-owned SQLite connection.
- `AccountingService.post_journal()` now accepts an optional connection and optional audit flag.
- `MemberRepository.register_payment_with_status()` now accepts an optional caller-owned connection.
- `MemberService.register_payment()` now owns one transaction covering the payment journal, membership payment row, and invoice status update.
- Accounting audit emission is performed after the shared transaction commits.
- Existing standalone Accounting and Membership repository behavior remains unchanged when no connection is supplied.

### Regression coverage
Added `test_membership_payment_rolls_back_accounting_when_membership_persistence_fails`.
The test deliberately writes the membership payment and then raises before commit. The expected result is:
- no payment row;
- no payment journal;
- invoice remains `Open`;
- the pre-existing invoice journal remains intact.

### Verification
Targeted payment/accounting regression set:
- 31 passed

Compile check:
- `python -m compileall -q src tests` — passed

Broader baseline suite still contains pre-existing unrelated failures, including project activity/task expectations. These were not modified by Step 228.

### Non-goals
- No new payment engine.
- No new accounting ledger.
- No idempotency schema added in this step.
- No unrelated Project/Work changes.
