class ProjectService:
    def __init__(self, repo):
        self.repo = repo

    def create(self, name, description="", status="Planned", budget=0):
        name = str(name).strip()
        if not name:
            raise ValueError("Project name is required.")
        status = str(status or "").strip()
        allowed_statuses = {"Planned", "Active", "Completed", "Closed", "On Hold"}
        if status not in allowed_statuses:
            raise ValueError("Invalid project status.")
        import math
        budget = float(budget or 0)
        if not math.isfinite(budget):
            raise ValueError("Budget must be a finite number.")
        if budget < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.create(name, str(description).strip(), status, budget)

    def list(self):
        return self.repo.list()

    def count(self):
        return self.repo.count()

    def set_budget(self, project_id, amount):
        import math
        existing = self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,))
        if not existing:
            raise ValueError("Project not found.")
        amount = float(amount)
        if not math.isfinite(amount):
            raise ValueError("Budget must be a finite number.")
        if amount < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.set_budget(project_id, amount)

    def budget(self, project_id):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")
        return self.repo.project_budget(project_id)

    def create_activity(self, project_id, name, description="", activity_date=None,
                        status="Planned", budget=0):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")
        name=str(name).strip()
        if not name: raise ValueError("Activity name is required.")
        allowed_statuses = {"Planned", "Active", "On Hold", "Completed", "Cancelled"}
        if status not in allowed_statuses:
            raise ValueError("Invalid activity status.")
        if status != "Planned":
            raise ValueError("New activities must start in Planned status.")
        try:
            budget = float(budget or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid activity budget.") from exc
        import math
        if not math.isfinite(budget):
            raise ValueError("Activity budget must be a finite number.")
        if budget < 0:
            raise ValueError("Activity budget cannot be negative.")
        budget = round(budget, 2)
        if activity_date in (None, ""):
            activity_date = None
        else:
            from datetime import date
            try:
                activity_date = date.fromisoformat(str(activity_date)).isoformat()
            except ValueError as exc:
                raise ValueError("Invalid activity date.") from exc
        description = str(description or "").strip()
        return self.repo.create_activity(project_id,name,description,
                                          activity_date,status,budget)

    def activities(self, project_id):
        self._require_project(project_id)
        rows = self.repo.list_activities(project_id)
        result = []
        allowed_statuses = {"Planned", "Active", "On Hold", "Completed", "Cancelled"}
        for row in rows:
            item = dict(row)
            try:
                budget = float(item.get("budget") or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid stored activity budget.") from exc
            import math
            if not math.isfinite(budget) or budget < 0:
                raise ValueError("Invalid stored activity budget.")
            item["budget"] = round(budget, 2)
            if item.get("status") not in allowed_statuses:
                raise ValueError("Invalid stored activity status.")
            if item.get("activity_date") not in (None, ""):
                from datetime import date
                try:
                    item["activity_date"] = date.fromisoformat(str(item["activity_date"])).isoformat()
                except ValueError as exc:
                    raise ValueError("Invalid stored activity date.") from exc
            else:
                item["activity_date"] = None
            result.append(item)
        return result

    def update_activity(self, activity_id, **fields):
        existing = self.repo.db.fetch_one("SELECT id FROM activities WHERE id=?", (activity_id,))
        if not existing:
            raise ValueError("Activity not found.")
        self._require_project(
            self.repo.db.fetch_one(
                "SELECT project_id FROM activities WHERE id=?", (activity_id,)
            )["project_id"]
        )
        allowed_fields = {"name", "description", "activity_date", "status", "budget", "project_id"}
        unsupported = set(fields) - allowed_fields
        if unsupported:
            names = ", ".join(sorted(unsupported))
            raise ValueError(f"Unsupported activity fields: {names}")
        if not fields:
            raise ValueError("No activity fields supplied for update.")
        if "project_id" in fields:
            current = self.repo.db.fetch_one(
                "SELECT project_id FROM activities WHERE id=?", (activity_id,)
            )
            try:
                target_project_id = int(fields["project_id"])
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid activity project id.") from exc
            if target_project_id != int(current["project_id"]):
                raise ValueError("Activity project cannot be changed.")
            fields.pop("project_id", None)
            if not fields:
                raise ValueError("Project ID is validation-only and no other activity fields were supplied.")
        if "status" in fields:
            allowed_statuses = {"Planned", "Active", "On Hold", "Completed", "Cancelled"}
            if fields["status"] not in allowed_statuses:
                raise ValueError("Invalid activity status.")
            current_status = self.repo.db.fetch_one(
                "SELECT status FROM activities WHERE id=?", (activity_id,)
            )["status"]
            transitions = {
                "Planned": {"Active", "On Hold", "Cancelled"},
                "Active": {"On Hold", "Completed", "Cancelled"},
                "On Hold": {"Active", "Cancelled"},
                "Completed": set(),
                "Cancelled": set(),
            }
            if fields["status"] != current_status and fields["status"] not in transitions.get(current_status, set()):
                raise ValueError(
                    f"Invalid activity workflow transition: {current_status} -> {fields['status']}"
                )
        if "budget" in fields:
            try:
                budget = float(fields["budget"])
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid activity budget.") from exc
            import math
            if not math.isfinite(budget):
                raise ValueError("Activity budget must be a finite number.")
            if budget < 0:
                raise ValueError("Activity budget cannot be negative.")
            fields["budget"] = round(budget, 2)
        if "name" in fields:
            fields["name"] = str(fields["name"]).strip()
            if not fields["name"]:
                raise ValueError("Activity name is required.")
        if "description" in fields:
            fields["description"] = str(fields["description"] or "").strip()
        if "activity_date" in fields:
            if fields["activity_date"] in (None, ""):
                fields["activity_date"] = None
            else:
                from datetime import date
                try:
                    fields["activity_date"] = date.fromisoformat(str(fields["activity_date"])).isoformat()
                except ValueError as exc:
                    raise ValueError("Invalid activity date.") from exc
        return self.repo.update_activity(activity_id,**fields)

    def _require_project(self, project_id):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")

    def activity_summary(self, project_id):
        self._require_project(project_id)
        return dict(self.repo.project_activity_summary(project_id))

    def financial_tracking(self, project_id):
        self._require_project(project_id)
        data = self.repo.project_financial_tracking(project_id)
        import math
        try:
            budget = float(data.get("budget") or 0)
            activity_budget = float(data.get("activity_budget") or 0)
            actual = float(data.get("actual") or 0)
            variance = float(data.get("variance") or 0)
            utilization = float(data.get("utilization") or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid stored project financial tracking data.") from exc
        if any(not math.isfinite(v) for v in
               (budget, activity_budget, actual, variance, utilization)):
            raise ValueError("Invalid stored project financial tracking data.")
        if any(v < 0 for v in (budget, activity_budget, actual)):
            raise ValueError("Invalid stored project financial tracking data.")
        return {
            "project": dict(data["project"]),
            "budget": round(budget, 2),
            "activity_budget": round(activity_budget, 2),
            "activity_count": int(data.get("activity_count") or 0),
            "actual": round(actual, 2),
            "variance": round(variance, 2),
            "utilization": round(utilization, 2),
        }

    def financial_report(self, project_id, periods=3):
        self._require_project(project_id)
        data = self.repo.project_financial_report(project_id, periods)
        import math
        try:
            budget = float(data.get("budget") or 0)
            actual = float(data.get("actual") or 0)
            revenue = float(data.get("revenue") or 0)
            funding = float(data.get("funding") or 0)
            result = float(data.get("project_result") or 0)
            variance = float(data.get("variance") or 0)
            utilization = float(data.get("utilization") or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid stored project financial report data.") from exc
        if any(not math.isfinite(v) for v in
               (budget, actual, revenue, funding, result, variance, utilization)):
            raise ValueError("Invalid stored project financial report data.")
        if any(v < 0 for v in (budget, actual, revenue, funding)):
            raise ValueError("Invalid stored project financial report data.")
        return {
            **data,
            "project": dict(data["project"]),
            "budget": round(budget, 2),
            "actual": round(actual, 2),
            "revenue": round(revenue, 2),
            "funding": round(funding, 2),
            "project_result": round(result, 2),
            "variance": round(variance, 2),
            "utilization": round(utilization, 2),
            "read_only": True,
        }

    def financial_forecast(self, project_id, periods=3):
        self._require_project(project_id)
        data = self.repo.project_financial_forecast(project_id, periods)
        import math
        try:
            data_points = int(data.get("data_points") or 0)
            expected_months = int(data.get("expected_months") or 0)
            slope = float(data.get("slope") or 0)
            intercept = float(data.get("intercept") or 0)
            confidence_score = float(data.get("confidence_score") or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid stored project financial forecast data.") from exc
        if data_points < 0 or expected_months < 0:
            raise ValueError("Invalid stored project financial forecast data.")
        if any(not math.isfinite(v) for v in (slope, intercept, confidence_score)):
            raise ValueError("Invalid stored project financial forecast data.")
        if not 0 <= confidence_score <= 1:
            raise ValueError("Invalid stored project financial forecast data.")

        history = []
        for row in data.get("history", []):
            try:
                actual = float(row.get("actual") or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid stored project financial forecast data.") from exc
            if not math.isfinite(actual) or actual < 0:
                raise ValueError("Invalid stored project financial forecast data.")
            history.append({**row, "actual": round(actual, 2)})

        forecasts = []
        for row in data.get("forecasts", []):
            try:
                value = float(row.get("value") or 0)
                raw_value = float(row.get("raw_value") or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid stored project financial forecast data.") from exc
            if not math.isfinite(value) or not math.isfinite(raw_value) or value < 0:
                raise ValueError("Invalid stored project financial forecast data.")
            forecasts.append({
                **row,
                "value": round(value, 2),
                "raw_value": round(raw_value, 2),
                "is_clamped": bool(row.get("is_clamped", False)),
            })

        return {
            **data,
            "history": history,
            "forecasts": forecasts,
            "data_points": data_points,
            "expected_months": expected_months,
            "slope": round(slope, 4),
            "intercept": round(intercept, 4),
            "confidence_score": round(confidence_score, 3),
            "read_only": True,
        }

    def expense_lines(self, project_id):
        self._require_project(project_id)
        return self.repo.project_expense_lines(project_id)

    def activity_financials(self, project_id):
        self._require_project(project_id)
        rows = self.repo.activity_actuals(project_id)
        result = []
        for row in rows:
            item = dict(row)
            try:
                actual = float(item.get("actual") or 0)
                variance = float(item.get("variance") or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid stored activity actual.") from exc
            import math
            if not math.isfinite(actual) or actual < 0 or not math.isfinite(variance):
                raise ValueError("Invalid stored activity actual.")
            item["actual"] = round(actual, 2)
            item["variance"] = round(variance, 2)
            result.append(item)
        return result

    def activity_financial_detail(self, project_id):
        self._require_project(project_id)
        rows=self.repo.activity_financial_detail(project_id)
        result=[]
        for r in rows:
            budget=float(r["budget"] or 0)
            actual=round(float(r["actual"] or 0),2)
            result.append({
                "id":r["id"],"name":r["name"],"status":r["status"],
                "budget":budget,"actual":actual,
                "variance":round(budget-actual,2),
                "utilization":round(actual/budget*100,2) if budget else 0.0
            })
        return result

    def project_control_dashboard(self, project_id):
        self._require_project(project_id)
        data = self.repo.project_control_dashboard(project_id)
        import math

        def money(value, error):
            try:
                number = float(value or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError(error) from exc
            if not math.isfinite(number):
                raise ValueError(error)
            return round(number, 2)

        budget = money(data.get("budget"), "Invalid stored project control dashboard data.")
        actual = money(data.get("actual"), "Invalid stored project control dashboard data.")
        variance = money(data.get("variance"), "Invalid stored project control dashboard data.")
        utilization = money(data.get("utilization"), "Invalid stored project control dashboard data.")
        if budget < 0 or actual < 0:
            raise ValueError("Invalid stored project control dashboard data.")

        activities = []
        for activity in data.get("activities", []):
            item = dict(activity)
            activity_budget = money(item.get("budget"), "Invalid stored project control dashboard data.")
            activity_actual = money(item.get("actual"), "Invalid stored project control dashboard data.")
            activity_variance = money(item.get("variance"), "Invalid stored project control dashboard data.")
            activity_utilization = money(item.get("utilization"), "Invalid stored project control dashboard data.")
            if activity_budget < 0 or activity_actual < 0:
                raise ValueError("Invalid stored project control dashboard data.")
            item.update({
                "budget": activity_budget,
                "actual": activity_actual,
                "variance": activity_variance,
                "utilization": activity_utilization,
            })
            activities.append(item)

        result = {
            **data,
            "project": dict(data["project"]),
            "budget": budget,
            "actual": actual,
            "variance": variance,
            "utilization": utilization,
            "activity_budget": money(data.get("activity_budget"), "Invalid stored project control dashboard data."),
            "activity_actual": money(data.get("activity_actual"), "Invalid stored project control dashboard data."),
            "unallocated_actual": money(data.get("unallocated_actual"), "Invalid stored project control dashboard data."),
            "forecast_value": (
                None if data.get("forecast_value") is None
                else money(data.get("forecast_value"), "Invalid stored project control dashboard data.")
            ),
            "forecast_confidence_score": (
                None if data.get("forecast_confidence_score") is None
                else money(data.get("forecast_confidence_score"), "Invalid stored project control dashboard data.")
            ),
            "forecast_data_points": int(data.get("forecast_data_points") or 0),
            "forecast_expected_months": int(data.get("forecast_expected_months") or 0),
            "forecast_missing_months": list(data.get("forecast_missing_months") or []),
            "forecast_clamped": bool(data.get("forecast_clamped", False)),
            "forecast_clamped_months": list(data.get("forecast_clamped_months") or []),
            "activities": activities,
            "read_only": True,
        }
        if result["activity_budget"] < 0 or result["activity_actual"] < 0:
            raise ValueError("Invalid stored project control dashboard data.")
        return result

    def project_tasks(self, project_id):
        self._require_project(project_id)
        return self.repo.project_tasks(project_id)

    def create_project_task(self, project_id, title, description="", activity_id=None,
                            assigned_to="", priority="Normal", due_date=None,
                            status="Open"):
        self._require_project(project_id)
        title=str(title).strip()
        if not title: raise ValueError("Task title is required.")
        if activity_id is not None:
            activity=self.repo.db.fetch_one("SELECT * FROM activities WHERE id=?", (activity_id,))
            if not activity or int(activity["project_id"]) != int(project_id):
                raise ValueError("Task activity must belong to the selected project.")
        if priority not in {"Low","Normal","High","Critical"}:
            raise ValueError("Invalid task priority.")
        assigned_to = str(assigned_to or "").strip()
        if status not in {"Open","In Progress","Blocked","Completed","Closed"}:
            raise ValueError("Invalid task status.")
        if due_date is not None:
            from datetime import date
            due_date = str(due_date).strip() or None
            if due_date:
                try:
                    date.fromisoformat(due_date)
                except ValueError as exc:
                    raise ValueError("Invalid task due date.") from exc
        return self.repo.create_project_task(project_id,title,str(description).strip(),
                                              activity_id,assigned_to,priority,due_date,status)

    def update_project_task(self, task_id, **changes):
        task = self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        self._require_project(task["project_id"])

        allowed = {"title", "description", "assigned_to", "due_date", "priority"}
        unknown = set(changes) - allowed
        if unknown:
            raise ValueError("Unknown task fields.")

        normalized = {}
        if "title" in changes:
            value = str(changes["title"] or "").strip()
            if not value:
                raise ValueError("Task title is required.")
            normalized["title"] = value

        if "description" in changes:
            normalized["description"] = None if changes["description"] is None else str(changes["description"]).strip()

        if "assigned_to" in changes:
            value = str(changes["assigned_to"] or "").strip()
            normalized["assigned_to"] = value or None

        if "due_date" in changes:
            value = None if changes["due_date"] in (None, "") else str(changes["due_date"]).strip()
            if value:
                from datetime import date
                try:
                    date.fromisoformat(value)
                except ValueError as exc:
                    raise ValueError("Invalid task due date.") from exc
            normalized["due_date"] = value

        if "priority" in changes:
            value = str(changes["priority"] or "").strip()
            if value not in {"Low", "Normal", "High", "Critical"}:
                raise ValueError("Invalid priority.")
            normalized["priority"] = value

        if not normalized:
            raise ValueError("No task changes supplied.")

        return self.repo.update_project_task(task_id, **normalized)

    def operational_workboard(self, today=None):
        from datetime import date

        try:
            today = date.fromisoformat(str(today)) if today else date.today()
        except ValueError as exc:
            raise ValueError("Invalid operational workboard date.") from exc

        data = self.repo.operational_workboard(today.isoformat())
        items = [dict(row) for row in data.get("items", [])]

        for item in items:
            item["status"] = str(item.get("status") or "").strip()
            item["priority"] = str(item.get("priority") or "").strip()
            item["title"] = str(item.get("title") or "").strip()
            if item.get("due_date"):
                try:
                    date.fromisoformat(str(item["due_date"]))
                except ValueError as exc:
                    raise ValueError("Invalid operational workboard due date.") from exc

        priority_order = {"Critical": 0, "High": 1, "Normal": 2, "Low": 3}
        items.sort(key=lambda item: (
            priority_order.get(item["priority"], 9),
            item.get("due_date") or "9999-12-31",
            item["title"],
        ))

        return {
            **data,
            "as_of": today.isoformat(),
            "items": items,
            "counts": {
                "total": len(items),
                "open": sum(
                    item["status"] not in {"Completed", "Closed"}
                    for item in items
                ),
                "high_priority": sum(
                    item["priority"] in {"Critical", "High"} for item in items
                ),
            },
            "read_only": True,
        }

    def _validate_task_transition(self, task, new_status):
        transitions={
            "Open":{"In Progress","Blocked","Completed","Closed"},
            "In Progress":{"Blocked","Completed","Open"},
            "Blocked":{"In Progress","Open"},
            "Completed":{"Closed","Open"},
            "Closed":set()
        }
        if new_status not in transitions.get(task["status"],set()):
            raise ValueError(
                f"Invalid workflow transition: {task['status']} -> {new_status}"
            )

    def transition_project_task(self, task_id, new_status):
        allowed = {"Open", "In Progress", "Blocked", "Completed"}
        normalized = str(new_status or "").strip()
        if normalized not in allowed:
            raise ValueError("Invalid task status.")
        task = self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        self._require_project(task["project_id"])
        self._validate_task_transition(task, normalized)
        return self.repo.transition_project_task(task_id, normalized)

    def task_detail(self, task_id):
        task = self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        self._require_project(task["project_id"])

        result = dict(task)
        due = result.get("due_date")
        if due:
            from datetime import date
            try:
                date.fromisoformat(str(due))
            except ValueError as exc:
                raise ValueError("Invalid stored task due date.") from exc

        project = self.repo.db.fetch_one(
            "SELECT * FROM projects WHERE id=?", (task["project_id"],)
        )
        return {
            "task": result,
            "project": dict(project) if project else None,
            "read_only": True,
        }

    def operational_alerts(self, today=None):
        from datetime import date
        import math

        try:
            today = date.fromisoformat(str(today)) if today else date.today()
        except ValueError as exc:
            raise ValueError("Invalid operational alert date.") from exc

        data = self.repo.operational_alerts(today.isoformat())
        alerts = []

        for task in data.get("tasks", []):
            due_raw = task.get("due_date")
            if not due_raw:
                raise ValueError("Invalid stored task due date.")
            try:
                due = date.fromisoformat(str(due_raw))
            except ValueError as exc:
                raise ValueError("Invalid stored task due date.") from exc

            days = (due - today).days
            base = {
                "task_id": task["id"],
                "project": str(task.get("project_name") or ""),
                "due_date": str(due_raw),
                "message": str(task.get("title") or ""),
            }
            if not task.get("assigned_to"):
                alerts.append({**base, "type": "missing_owner",
                               "severity": "High",
                               "title": "Opgave mangler ansvarlig"})
            if days < 0:
                alerts.append({**base, "type": "overdue_task",
                               "severity": "Critical",
                               "title": "Opgave er forfalden"})
            elif days <= 7:
                alerts.append({**base, "type": "deadline_soon",
                               "severity": "High",
                               "title": "Deadline nærmer sig"})
            if task.get("status") == "Blocked":
                alerts.append({**base, "type": "blocked_task",
                               "severity": "High",
                               "title": "Opgave er blokeret"})

        for project in data.get("projects", []):
            try:
                budget = float(project.get("budget") or 0)
                actual = float(project.get("actual") or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid stored operational alert financial data.") from exc
            if not math.isfinite(budget) or not math.isfinite(actual) or budget < 0 or actual < 0:
                raise ValueError("Invalid stored operational alert financial data.")
            if budget and actual > budget:
                alerts.append({
                    "type": "budget_overrun", "severity": "Critical",
                    "project": str(project.get("name") or ""),
                    "message": f"{actual:.2f} > {budget:.2f}",
                    "title": "Projekt overskrider budget"
                })

        order = {"Critical": 0, "High": 1, "Normal": 2}
        alerts.sort(key=lambda x: (
            order.get(x["severity"], 9), x.get("due_date", ""), x["title"]
        ))
        return {
            "as_of": today.isoformat(),
            "alerts": alerts,
            "counts": {
                "critical": sum(a["severity"] == "Critical" for a in alerts),
                "high": sum(a["severity"] == "High" for a in alerts),
                "total": len(alerts),
            },
            "read_only": True,
        }

    def personal_work_queue(self, assigned_to, today=None):
        from datetime import date, timedelta

        person = str(assigned_to or "").strip()
        if not person:
            raise ValueError("A responsible person is required.")
        try:
            day = date.fromisoformat(str(today)) if today else date.today()
        except ValueError as exc:
            raise ValueError("Invalid personal work queue date.") from exc

        horizon = day + timedelta(days=7)
        rows = self.repo.personal_work_queue(person, day.isoformat(), horizon.isoformat())
        tasks = [dict(row) for row in rows]

        for task in tasks:
            due = task.get("due_date")
            if due:
                try:
                    date.fromisoformat(str(due))
                except ValueError as exc:
                    raise ValueError("Invalid stored task due date.") from exc

        overdue = [t for t in tasks if t.get("due_date") and str(t["due_date"]) < day.isoformat()]
        due_today = [t for t in tasks if t.get("due_date") == day.isoformat()]
        next_7 = [t for t in tasks if t.get("due_date")
                  and day.isoformat() <= str(t["due_date"]) <= horizon.isoformat()]
        critical = [t for t in tasks if t.get("priority") == "Critical"]
        blocked = [t for t in tasks if t.get("status") == "Blocked"]

        return {
            "person": person,
            "as_of": day.isoformat(),
            "horizon": horizon.isoformat(),
            "tasks": tasks,
            "metrics": {
                "open": len(tasks),
                "overdue": len(overdue),
                "today": len(due_today),
                "next_7_days": len(next_7),
                "critical": len(critical),
                "blocked": len(blocked),
            },
            "read_only": True,
        }

    def my_day(self, assigned_to, today=None):
        from datetime import date

        person = str(assigned_to or "").strip()
        if not person:
            raise ValueError("A responsible person is required.")
        try:
            day = date.fromisoformat(str(today)) if today else date.today()
        except ValueError as exc:
            raise ValueError("Invalid My Day date.") from exc

        queue = self.personal_work_queue(person, day.isoformat())
        tasks = [dict(task) for task in queue["tasks"]]

        for task in tasks:
            task["status"] = str(task.get("status") or "").strip()
            task["priority"] = str(task.get("priority") or "").strip()
            task["title"] = str(task.get("title") or "").strip()
            due = task.get("due_date")
            if due:
                try:
                    date.fromisoformat(str(due))
                except ValueError as exc:
                    raise ValueError("Invalid stored My Day due date.") from exc

        overdue = [t for t in tasks if t.get("due_date") and str(t["due_date"]) < day.isoformat()]
        today_tasks = [t for t in tasks if t.get("due_date") == day.isoformat()]
        critical = [t for t in tasks if t.get("priority") == "Critical"]
        blocked = [t for t in tasks if t.get("status") == "Blocked"]

        return {
            "person": person,
            "as_of": day.isoformat(),
            "tasks": tasks,
            "sections": {
                "overdue": overdue,
                "today": today_tasks,
                "critical": critical,
                "blocked": blocked,
            },
            "metrics": {
                "total": len(tasks),
                "overdue": len(overdue),
                "today": len(today_tasks),
                "critical": len(critical),
                "blocked": len(blocked),
            },
            "read_only": True,
        }

    def quick_action(self, task_id, action, value=None):
        task = self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        self._require_project(task["project_id"])

        action = str(action or "").strip().lower()
        allowed = {"start", "block", "complete", "reopen",
                   "deadline", "priority", "assign"}
        if action not in allowed:
            raise ValueError("Unknown quick action.")

        if action in {"start", "block", "complete", "reopen"}:
            status = {
                "start": "In Progress",
                "block": "Blocked",
                "complete": "Completed",
                "reopen": "Open",
            }[action]
            return self.transition_project_task(task_id, status)

        if action == "deadline":
            normalized = None if value in (None, "") else str(value).strip()
            if normalized:
                from datetime import date
                try:
                    date.fromisoformat(normalized)
                except ValueError as exc:
                    raise ValueError("Invalid task due date.") from exc
            return self.repo.quick_update_task(task_id, due_date=normalized)

        if action == "priority":
            normalized = str(value or "").strip()
            if normalized not in {"Low", "Normal", "High", "Critical"}:
                raise ValueError("Invalid priority.")
            return self.repo.quick_update_task(task_id, priority=normalized)

        normalized = str(value or "").strip()
        if not normalized:
            raise ValueError("Responsible person is required.")
        return self.repo.quick_update_task(task_id, assigned_to=normalized)

    def project_execution_view(self, project_id):
        self._require_project(project_id)
        data = self.repo.project_execution_view(project_id)
        project = dict(data.get("project") or {})
        tasks = [dict(row) for row in data.get("tasks", [])]

        from datetime import date
        for task in tasks:
            task["status"] = str(task.get("status") or "").strip()
            task["priority"] = str(task.get("priority") or "").strip()
            task["title"] = str(task.get("title") or "").strip()
            due = task.get("due_date")
            if due:
                try:
                    date.fromisoformat(str(due))
                except ValueError as exc:
                    raise ValueError("Invalid stored task due date.") from exc

        return {
            "project": project,
            "tasks": tasks,
            "metrics": {
                "total_tasks": len(tasks),
                "open_tasks": sum(
                    t["status"] not in {"Completed", "Closed"} for t in tasks
                ),
                "completed_tasks": sum(
                    t["status"] in {"Completed", "Closed"} for t in tasks
                ),
                "blocked_tasks": sum(t["status"] == "Blocked" for t in tasks),
                "critical_tasks": sum(
                    t["priority"] == "Critical" for t in tasks
                ),
            },
            "read_only": True,
        }

    def activity_execution_view(self, activity_id):
        activity = self.repo.db.fetch_one(
            "SELECT * FROM activities WHERE id=?", (activity_id,)
        )
        if not activity:
            raise ValueError("Activity not found.")

        project_id = activity["project_id"]
        self._require_project(project_id)

        tasks = [dict(row) for row in self.repo.project_tasks(project_id)]
        from datetime import date

        for task in tasks:
            task["status"] = str(task.get("status") or "").strip()
            task["priority"] = str(task.get("priority") or "").strip()
            task["title"] = str(task.get("title") or "").strip()
            due = task.get("due_date")
            if due:
                try:
                    date.fromisoformat(str(due))
                except ValueError as exc:
                    raise ValueError("Invalid stored activity task due date.") from exc

        return {
            "activity": dict(activity),
            "project_id": project_id,
            "tasks": tasks,
            "metrics": {
                "task_count": len(tasks),
                "open_tasks": sum(
                    task["status"] not in {"Completed", "Closed"} for task in tasks
                ),
                "completed_tasks": sum(
                    task["status"] in {"Completed", "Closed"} for task in tasks
                ),
                "critical_tasks": sum(task["priority"] == "Critical" for task in tasks),
                "blocked_tasks": sum(task["status"] == "Blocked" for task in tasks),
            },
            "read_only": True,
        }

    def execution_action(self, project_id, task_id, action, value=None):
        self._require_project(project_id)
        task=self.repo.task_by_id(task_id)
        if not task or int(task["project_id"]) != int(project_id):
            raise ValueError("Task does not belong to selected project.")
        if action in {"start","block","complete","reopen"}:
            return self.quick_action(task_id,action,value)
        if action in {"deadline","priority","assign"}:
            return self.quick_action(task_id,action,value)
        raise ValueError("Unknown execution action.")

    def project_progress_control(self, project_id):
        self._require_project(project_id)
        data = self.repo.project_progress_control(project_id)

        tasks = [dict(row) for row in data.get("tasks", [])]
        activities = [dict(row) for row in data.get("activities", [])]
        done = sum(t["status"] in {"Completed", "Closed"} for t in tasks)
        total = len(tasks)

        budget = float(data.get("budget") or 0)
        actual = round(float(data.get("actual") or 0), 2)

        data = dict(data)
        data["tasks"] = tasks
        data["activities"] = activities
        data["task_progress"] = round(done / total * 100, 2) if total else 0.0
        data["budget"] = budget
        data["actual"] = actual
        data["variance"] = round(budget - actual, 2)
        data["utilization"] = round(actual / budget * 100, 2) if budget else 0.0
        data["financial_status"] = (
            "Over budget" if budget and actual > budget
            else ("On budget" if budget else "No budget")
        )
        data["execution_status"] = (
            "Complete" if total and done == total
            else ("Not started" if total and done == 0
                  else ("In progress" if total else "No tasks"))
        )

        for activity in activities:
            activity_tasks = [
                task for task in tasks if task["activity_id"] == activity["id"]
            ]
            activity_done = sum(
                task["status"] in {"Completed", "Closed"}
                for task in activity_tasks
            )
            activity["task_count"] = len(activity_tasks)
            activity["completed_tasks"] = activity_done
            activity["progress"] = (
                round(activity_done / len(activity_tasks) * 100, 2)
                if activity_tasks else 0.0
            )
            activity_budget = float(activity.get("budget") or 0)
            activity_actual = round(float(activity.get("actual") or 0), 2)
            activity["budget"] = activity_budget
            activity["actual"] = activity_actual
            activity["variance"] = round(
                activity_budget - activity_actual, 2
            )
            activity["utilization"] = (
                round(activity_actual / activity_budget * 100, 2)
                if activity_budget else 0.0
            )
            activity["control_status"] = (
                "Over budget"
                if activity_budget and activity_actual > activity_budget
                else "OK"
            )

        data["read_only"] = True
        return data

    def project_control_exceptions(self, project_id):
        self._require_project(project_id)
        data = self.repo.project_control_exceptions(project_id)

        exceptions = [dict(row) for row in data.get("exceptions", [])]
        for item in exceptions:
            item["severity"] = str(item.get("severity") or "").strip()
            item["status"] = str(item.get("status") or "").strip()
            item["title"] = str(item.get("title") or "").strip()

        critical = sum(item.get("severity") == "Critical" for item in exceptions)
        high = sum(item.get("severity") == "High" for item in exceptions)
        total = len(exceptions)

        result = dict(data)
        result["exceptions"] = exceptions
        result["counts"] = {
            "critical": critical,
            "high": high,
            "total": total,
        }
        result["exception_count"] = total
        result["open_count"] = sum(
            item.get("status") not in {"Resolved", "Closed"}
            for item in exceptions
        )
        result["critical_count"] = critical
        result["read_only"] = True
        return result

    def create_exception_followup(self, project_id, exception, assigned_to):
        self._require_project(project_id)
        if not isinstance(exception, dict):
            raise ValueError("Exception must be a dictionary.")
        responsible = str(assigned_to or "").strip()
        if not responsible:
            raise ValueError("Responsible person is required.")

        normalized = dict(exception)
        normalized["type"] = str(normalized.get("type") or "").strip()
        normalized["severity"] = str(normalized.get("severity") or "").strip()
        normalized["title"] = str(normalized.get("title") or "").strip()
        if not normalized["type"]:
            raise ValueError("Exception type is required.")
        if not normalized["title"]:
            raise ValueError("Exception title is required.")
        if normalized["severity"] not in {"Critical", "High", "Medium", "Low"}:
            raise ValueError("Invalid exception severity.")

        return self.create_project_task(
            project_id,
            f'Opfølgning: {normalized["title"]}',
            normalized.get("message", ""),
            normalized.get("activity_id"),
            responsible,
            "High",
            normalized.get("due_date"),
            "Open",
        )
    def project_control_cockpit(self, project_id):
        control = self.project_progress_control(project_id)
        exceptions = self.project_control_exceptions(project_id)
        execution = self.project_execution_view(project_id)
        tasks = [dict(t) for t in execution["tasks"]]
        open_tasks = [t for t in tasks if t["status"] not in {"Completed", "Closed"}]
        assigned_open = [t for t in open_tasks if (t.get("assigned_to") or "").strip()]
        activities = [dict(a) for a in control["activities"]]
        return {
            "project": dict(control["project"]),
            "control": {
                "task_progress": float(control["task_progress"]),
                "execution_status": str(control["execution_status"]),
                "financial_status": str(control["financial_status"]),
                "budget": float(control["budget"]),
                "actual": float(control["actual"]),
                "variance": float(control["variance"]),
                "utilization": float(control["utilization"]),
            },
            "activities": activities,
            "tasks": tasks,
            "exceptions": [dict(e) for e in exceptions["exceptions"]],
            "exception_counts": dict(exceptions["counts"]),
            "open_tasks": len(open_tasks),
            "assigned_open_tasks": len(assigned_open),
            "read_only": True,
        }

    def integrated_operations_dashboard(self):
        base = self.repo.integrated_operations_dashboard()
        projects = []
        import math

        for project in base.get("projects", []):
            control = self.project_control_cockpit(project["id"])
            values = {
                "budget": float(control["control"]["budget"]),
                "actual": float(control["control"]["actual"]),
                "variance": float(control["control"]["variance"]),
                "progress": float(control["control"]["task_progress"]),
            }
            if any(not math.isfinite(v) for v in values.values()):
                raise ValueError("Invalid integrated operations project data.")

            counts = dict(control.get("exception_counts") or {})
            exceptions_total = int(counts.get("total", 0))
            open_tasks = int(control.get("open_tasks", 0))
            if exceptions_total < 0 or open_tasks < 0:
                raise ValueError("Invalid integrated operations project data.")

            projects.append({
                "id": project["id"],
                "name": str(project.get("name") or ""),
                "status": str(project.get("status") or ""),
                "budget": round(values["budget"], 2),
                "actual": round(values["actual"], 2),
                "variance": round(values["variance"], 2),
                "progress": round(values["progress"], 2),
                "exceptions": exceptions_total,
                "open_tasks": open_tasks,
            })

        def nonnegative_count(value):
            if value is None:
                return 0
            value = int(value)
            if value < 0:
                raise ValueError("Invalid integrated operations summary data.")
            return value

        task_summary = dict(base.get("task_summary") or {})
        member_summary = dict(base.get("member_summary") or {})
        for summary in (task_summary, member_summary):
            for key, value in list(summary.items()):
                summary[key] = nonnegative_count(value)

        return {
            **base,
            "projects": projects,
            "task_summary": task_summary,
            "member_summary": member_summary,
            "project_summary": {
                "active": len(projects),
                "exceptions": sum(x["exceptions"] for x in projects),
                "open_tasks": sum(x["open_tasks"] for x in projects),
                "over_budget": sum(1 for x in projects if x["variance"] < 0),
            },
            "read_only": True,
        }

    def integrated_operations_action(self, action, project_id=None, exception_index=None, task_id=None):
        action=str(action).strip().lower()
        if action=="open_project":
            if project_id is None: raise ValueError("Project is required.")
            return self.project_control_cockpit(project_id)
        if action=="open_exceptions":
            if project_id is None: raise ValueError("Project is required.")
            return self.project_control_exceptions(project_id)
        if action=="open_tasks":
            if project_id is None: raise ValueError("Project is required.")
            data=self.project_execution_view(project_id)
            return {"tasks":[t for t in data["tasks"] if t["status"] not in {"Completed","Closed"}]}
        if action in {"start","block","complete","reopen"}:
            if project_id is None or task_id is None:
                raise ValueError("Project and task are required.")
            return self.execution_action(project_id,task_id,action)
        if action=="create_exception_followup":
            if project_id is None or exception_index is None:
                raise ValueError("Project and exception are required.")
            data=self.project_control_exceptions(project_id)
            try: exc=data["exceptions"][int(exception_index)]
            except (IndexError,ValueError): raise ValueError("Exception not found.")
            return {"exception":exc}
        raise ValueError("Unknown integrated operations action.")

    def workspace_context(self, context_type, context_id=None):
        context_type=str(context_type).strip().lower()
        if context_type=="project":
            if context_id is None: raise ValueError("Project is required.")
            return {"type":"project","id":context_id,"data":self.project_control_cockpit(context_id)}
        if context_type=="task":
            if context_id is None: raise ValueError("Task is required.")
            task=self.repo.task_by_id(context_id)
            if not task: raise ValueError("Task not found.")
            return {"type":"task","id":context_id,"data":dict(task)}
        if context_type=="activity":
            if context_id is None: raise ValueError("Activity is required.")
            activity=self.repo.db.fetch_one("SELECT * FROM activities WHERE id=?",(context_id,))
            if not activity: raise ValueError("Activity not found.")
            return {"type":"activity","id":context_id,"data":dict(activity)}
        raise ValueError("Unknown workspace context.")

    def global_search(self, query, limit=50):
        results=self.repo.global_search(query,limit)
        for r in results:
            mapping={"Projekt":("project","open_project"),
                     "Aktivitet":("activity","open_activity"),
                     "Opgave":("task","open_task"),
                     "Medlem":("member","open_member")}
            r["context"],r["action"]=mapping.get(r["type"],(None,None))
        return results

    def unified_record_view(self, record_type, record_id):
        record_type=str(record_type).strip().lower()
        data=self.repo.unified_record(record_type,record_id)
        result={"type":record_type,"id":record_id,"record":data,"related":{},"actions":[]}
        if record_type=="project":
            c=self.project_control_cockpit(record_id)
            result["related"]={"activities":c["activities"],"tasks":c["tasks"],
                               "exceptions":c["exceptions"],"control":c["control"]}
            result["actions"]=["open_project","open_tasks","open_exceptions"]
        elif record_type=="activity":
            pid=data.get("project_id")
            if pid:
                c=self.project_control_cockpit(pid)
                result["related"]={"project":c["project"],
                                   "tasks":[t for t in c["tasks"] if t.get("activity_id")==record_id],
                                   "exceptions":[e for e in c["exceptions"] if e.get("activity_id")==record_id]}
            result["actions"]=["open_activity"]
        elif record_type=="task":
            result["related"]={"project_id":data.get("project_id"),
                               "activity_id":data.get("activity_id")}
            result["actions"]=["start","block","complete","reopen"]
        elif record_type=="member":
            result["actions"]=["open_member"]
        return result

    def contextual_action(self, record_type, record_id, action, value=None):
        record_type=str(record_type).strip().lower()
        action=str(action).strip().lower()
        view=self.unified_record_view(record_type,record_id)
        if action in {"start","block","complete","reopen"}:
            if record_type!="task":
                raise ValueError("Task action requires a task record.")
            return self.execution_action(view["record"].get("project_id"),record_id,action,value)
        if action=="open_related":
            related_type=str(value.get("type")).strip().lower() if isinstance(value,dict) else ""
            related_id=value.get("id") if isinstance(value,dict) else None
            if not related_type or related_id is None:
                raise ValueError("Related record type and id are required.")
            return self.unified_record_view(related_type,related_id)
        if action=="create_followup":
            if record_type!="task" and record_type!="activity":
                raise ValueError("Follow-up requires a task or activity record.")
            owner=value if isinstance(value,str) else ""
            if not owner.strip():
                raise ValueError("Responsible person is required.")
            project_id=view["record"].get("project_id")
            if record_type=="activity":
                title=f'Opfølgning: {view["record"].get("name","Aktivitet")}'
                activity_id=record_id
                return {"task_id":self.create_project_task(project_id,title,
                    "Opfølgning oprettet fra kontekstvisning.",activity_id,
                    owner.strip(),"High",None,"Open")}
            return {"task_id":self.create_project_task(project_id,
                f'Opfølgning: {view["record"].get("title","Opgave")}',
                "Opfølgning oprettet fra kontekstvisning.",
                view["record"].get("activity_id"),owner.strip(),"High",None,"Open")}
        raise ValueError("Unknown contextual action.")

    def personal_workspace(self, owner):
        data=self.repo.personal_workspace(owner)
        tasks=data["tasks"]
        overdue=[]; blocked=[]
        from datetime import date
        for t in tasks:
            due=t.get("due_date")
            if due:
                try:
                    if date.fromisoformat(due) < date.today():
                        overdue.append(t)
                except ValueError:
                    pass
            if t.get("status")=="Blocked":
                blocked.append(t)
        data["summary"]={"open":len(tasks),"overdue":len(overdue),"blocked":len(blocked)}
        data["overdue"]=overdue; data["blocked"]=blocked
        return data

    def personal_work_action(self, owner, task_id, action):
        owner=str(owner or "").strip()
        if not owner:
            raise ValueError("Owner is required.")
        task=self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        task_dict=dict(task)
        if (task_dict.get("assigned_to") or "").strip()!=owner:
            raise ValueError("Task is not assigned to this user.")
        action=str(action).strip().lower()
        if action not in {"start","block","complete","reopen"}:
            raise ValueError("Unknown personal work action.")
        result=self.execution_action(task_dict.get("project_id"),task_id,action)
        return {"task":dict(self.repo.task_by_id(task_id)),"result":result}

    def today_view(self, owner, today=None):
        from datetime import date
        today=today or date.today().isoformat()
        data=self.repo.today_work(owner,today)
        buckets={"due_today":[],"overdue":[],"high_priority":[],"blocked":[],"other":[]}
        for t in data["tasks"]:
            due=t.get("due_date") or ""
            if due and due<today: buckets["overdue"].append(t)
            elif due==today: buckets["due_today"].append(t)
            elif t.get("status")=="Blocked": buckets["blocked"].append(t)
            elif t.get("priority")=="High": buckets["high_priority"].append(t)
            else: buckets["other"].append(t)
        data["buckets"]=buckets
        data["summary"]={
            "total":len(data["tasks"]),
            "due_today":len(buckets["due_today"]),
            "overdue":len(buckets["overdue"]),
            "high_priority":len(buckets["high_priority"]),
            "blocked":len(buckets["blocked"])
        }
        return data

    def quick_capture(self, title, project_id=None, activity_id=None,
                      assigned_to="", priority="Normal", due_date=None, description=""):
        title=str(title or "").strip()
        if not title:
            raise ValueError("Task title is required.")
        if priority not in {"Low","Normal","High","Critical"}:
            raise ValueError("Invalid task priority.")
        if project_id is None:
            raise ValueError("Project is required.")
        self._require_project(project_id)
        if activity_id is not None:
            activity=self.repo.db.fetch_one("SELECT * FROM activities WHERE id=?",(activity_id,))
            if not activity or int(activity["project_id"])!=int(project_id):
                raise ValueError("Activity must belong to the selected project.")
        task_id=self.create_project_task(project_id,title,description,activity_id,
                                         assigned_to,priority,due_date,"Open")
        return self.repo.task_by_id(task_id)

    def triage_work_item(self, task_id, assigned_to=None, priority=None,
                         due_date=None, status="Open"):
        if hasattr(task_id, "keys"):
            task_id = task_id["id"]
        task_id = int(task_id)
        task=self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        self._require_project(task["project_id"])
        updates={}
        if assigned_to is not None:
            updates["assigned_to"]=str(assigned_to).strip()
        if priority is not None:
            if priority not in {"Low","Normal","High","Critical"}:
                raise ValueError("Invalid task priority.")
            updates["priority"]=priority
        if due_date is not None:
            from datetime import date
            updates["due_date"]=str(due_date).strip() or None
            if updates["due_date"]:
                try:
                    date.fromisoformat(updates["due_date"])
                except ValueError as exc:
                    raise ValueError("Invalid task due date.") from exc
        if status is not None:
            if status not in {"Open","In Progress","Blocked","Completed","Closed"}:
                raise ValueError("Invalid task status.")
            if status != task["status"]:
                self._require_project(task["project_id"])
                self._validate_task_transition(task, status)
            updates["status"]=status
        if not updates:
            return dict(task)
        sets=[f"{k}=?" for k in updates]
        vals=list(updates.values())+[task_id]
        self.repo.db.execute(f"UPDATE tasks SET {', '.join(sets)} WHERE id=?",tuple(vals))
        return dict(self.repo.task_by_id(task_id))

    def work_intake_inbox(self):
        items=self.repo.work_intake_inbox()
        return {"items":items,"count":len(items),"needs_triage":len(items),
                "rule":"Open + unassigned"}
