import shutil
import logging
from src.services.error_service import ErrorService
import csv
import tempfile
import sqlite3
import pytest
from pathlib import Path
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def test_core_crud():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.projects.create("Test Project")
        ctx.tasks.create("Test Task")
        ctx.risks.create("Test Risk", "High")
        ctx.decisions.create("Test Decision")
        assert ctx.projects.count() == 1
        assert ctx.tasks.count_open() == 1
        assert ctx.risks.count_high() == 1
        assert ctx.decisions.count_pending() == 1


def test_accounting_balanced_posting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        jid = ctx.accounting.post_journal(
            1,
            "Membership payment",
            [
                {"account_id": bank["id"], "debit": 500, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 500},
            ],
        )
        assert jid == 1
        assert db.fetch_one("SELECT status FROM journals WHERE id=?", (jid,))["status"] == "Posted"

def test_accounting_rejects_unbalanced_journal():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        a = accounts[0]
        b = accounts[1]
        try:
            ctx.accounting.post_journal(
                1, "Invalid", [
                    {"account_id": a["id"], "debit": 100, "credit": 0},
                    {"account_id": b["id"], "debit": 0, "credit": 90},
                ])
            assert False, "Expected ValueError"
        except ValueError:
            pass


def test_fiscal_year_creates_12_open_periods():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.accounting.create_fiscal_year(2026)
        periods = ctx.accounting.periods(2026)
        assert len(periods) == 12
        assert all(p["status"] == "Open" for p in periods)
        assert periods[0]["start_date"] == "2026-01-01"
        assert periods[-1]["end_date"] == "2026-12-31"

def test_journal_number_is_automatic():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        ctx.accounting.post_journal(None, "First", [
            {"account_id": bank["id"], "debit": 10, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 10},
        ])
        ctx.accounting.post_journal(None, "Second", [
            {"account_id": bank["id"], "debit": 20, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 20},
        ])
        rows = db.fetch_all("SELECT journal_no FROM journals ORDER BY id")
        assert [r["journal_no"] for r in rows] == [1, 2]


def test_financial_reports():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        expense = next(a for a in accounts if a["number"] == "5000")
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": bank["id"], "debit": 1000, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 1000},
        ])
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": expense["id"], "debit": 300, "credit": 0},
            {"account_id": bank["id"], "debit": 0, "credit": 300},
        ])
        income_report = ctx.accounting.income_statement()
        assert income_report["total_income"] == 1000
        assert income_report["total_expenses"] == 300
        assert income_report["result"] == 700


def test_project_budget_vs_actual():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Restoration")
        ctx.projects.set_budget(project_id, 1000)
        accounts = ctx.accounting.accounts()
        expense = next(a for a in accounts if a["number"] == "5000")
        bank = next(a for a in accounts if a["number"] == "1000")
        ctx.accounting.post_journal(None, "Project expense", [
            {"account_id": expense["id"], "debit": 250, "credit": 0, "project_id": project_id},
            {"account_id": bank["id"], "debit": 0, "credit": 250, "project_id": project_id},
        ])
        r = ctx.accounting.project_budget_vs_actual(project_id)
        assert r["budget"] == 1000
        assert r["actual"] == 250
        assert r["variance"] == 750
        assert r["utilization"] == 25


def test_membership_core():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member("M001", "Hans", "Hansen")
        type_id = ctx.members.create_membership_type("Ordinary", 500)
        membership_id = ctx.members.add_membership(member_id, type_id)
        invoice_id = ctx.members.invoice_membership(membership_id, member_id, 500)
        assert member_id == 1
        assert membership_id == 1
        assert invoice_id == 1
        assert ctx.members.members()[0]["member_no"] == "M001"
        assert ctx.members.invoices()[0]["amount"] == 500


def test_membership_payment_posts_to_accounting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member("M002", "Test", "Member")
        type_id = ctx.members.create_membership_type("Ordinary", 500)
        membership_id = ctx.members.add_membership(member_id, type_id)
        invoice_id = ctx.members.invoice_membership(membership_id, member_id, 500)
        payment_id = ctx.members.register_payment(invoice_id, 500)
        assert payment_id == 1
        invoice = db.fetch_one("SELECT status FROM membership_invoices WHERE id=?", (invoice_id,))
        assert invoice["status"] == "Paid"
        journals = db.fetch_all("SELECT * FROM journals WHERE status='Posted' ORDER BY id")
        # One journal records the invoice and one records the payment.
        assert len(journals) == 2
        invoice_journal = db.fetch_one(
            "SELECT journal_id FROM membership_invoices WHERE id=?", (invoice_id,)
        )
        assert invoice_journal["journal_id"] == journals[0]["id"]
        payment_row = db.fetch_one(
            "SELECT journal_id FROM membership_payments WHERE id=?", (payment_id,)
        )
        assert payment_row["journal_id"] == journals[1]["id"]
        lines = db.fetch_all("SELECT * FROM journal_lines WHERE journal_id=?", (journals[1]["id"],))
        assert sum(x["debit"] for x in lines) == 500
        assert sum(x["credit"] for x in lines) == 500


def test_bank_reconciliation():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main Bank", "123")
        bank = next(a for a in ctx.accounting.accounts() if a["number"] == "1000")
        income = next(a for a in ctx.accounting.accounts() if a["number"] == "3000")
        journal_id = ctx.accounting.post_journal(None, "Bank deposit", [
            {"account_id": bank["id"], "debit": 500, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 500},
        ])
        tx_id = ctx.bank.import_transaction(bank_id, 500, "Bank deposit")
        assert len(ctx.bank.unmatched()) == 1
        candidates = ctx.bank.candidates(500)
        assert any(x["id"] == journal_id for x in candidates)
        ctx.bank.match(tx_id, journal_id)
        assert ctx.bank.summary()["matched"] == 1
        assert ctx.bank.summary()["unmatched"] == 0


def test_management_snapshot_and_attention():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.tasks.create("Overdue task", due_date="2000-01-01")
        ctx.risks.create("High risk", "High")
        ctx.decisions.create("Pending decision")
        snapshot = ctx.management.snapshot()
        assert snapshot["open_tasks"] == 1
        assert snapshot["overdue_tasks"] == 1
        assert snapshot["high_risks"] == 1
        assert snapshot["pending_decisions"] == 1
        priorities = [x[0] for x in ctx.management.attention_items()]
        assert "HIGH" in priorities


def test_user_authentication():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        user = ctx.users.authenticate("admin", "admin")
        assert user is not None
        assert user["role_name"] == "Administrator"
        assert ctx.users.authenticate("admin", "wrong") is None


def test_backup_restore():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.system.set_setting("company_name", "Test Association")
        backup = base / "backup.db"
        ctx.system.backup(backup)
        assert backup.exists()
        ctx.system.set_setting("company_name", "Changed")
        safety = ctx.system.restore(backup)
        assert safety.exists()
        restored = Database(db.path)
        assert restored.fetch_one(
            "SELECT value FROM app_settings WHERE key='company_name'"
        )["value"] == "Test Association"


def test_restore_creates_unique_safety_copies():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        backup = base / "backup.db"
        ctx.system.backup(backup)

        first = ctx.system.restore(backup)
        second = ctx.system.restore(backup)

        assert first != second
        assert first.exists()
        assert second.exists()



def test_restore_rejects_invalid_sqlite_backup_and_preserves_database():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.system.set_setting("company_name", "Protected")

        invalid_backup = base / "invalid.db"
        invalid_backup.write_text("not a sqlite database")

        import pytest
        with pytest.raises(ValueError, match="valid SQLite database"):
            ctx.system.restore(invalid_backup)

        assert db.fetch_one(
            "SELECT value FROM app_settings WHERE key='company_name'"
        )["value"] == "Protected"


def test_global_search():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M100", "Hans", "Search")
        ctx.projects.create("Álvur Restoration", "Historic vessel project")
        ctx.tasks.create("Prepare restoration application")
        results = ctx.search.search("Hans")
        assert any(x["entity"] == "Member" for x in results)
        results = ctx.search.search("Álvur")
        assert any(x["entity"] == "Project" for x in results)
        results = ctx.search.search("restoration")
        assert any(x["entity"] == "Project" for x in results)
        assert any(x["entity"] == "Task" for x in results)


def test_exports():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M300", "Export", "Test")
        ctx.projects.create("Export Project")
        member_file = base / "members.csv"
        project_file = base / "projects.csv"
        ctx.export.export_members(member_file)
        ctx.export.export_projects(project_file)
        assert "Export,Test" in member_file.read_text(encoding="utf-8-sig")
        assert "Export Project" in project_file.read_text(encoding="utf-8-sig")


def test_organization_settings():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.organization.save(
            "Álvur Preservation Association",
            "12345678",
            "Harbour Road 1",
            "5000",
            "Odense",
            "Denmark",
            "info@example.org",
            "+45 12345678",
            "DKK",
            1
        )
        org = ctx.organization.get()
        assert org["name"] == "Álvur Preservation Association"
        assert org["currency"] == "DKK"
        assert org["fiscal_year_start"] == 1


def test_role_permissions():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        assert ctx.permissions.can(admin, "users.manage")
        manager_role = ctx.users.repo.get_role("Manager")
        manager_id = ctx.users.repo.create_user(
            "manager", "Manager User", ctx.users._hash("pw"), manager_role["id"]
        )
        manager = ctx.users.authenticate("manager", "pw")
        assert manager is not None
        assert ctx.permissions.can(manager, "projects.edit")
        assert not ctx.permissions.can(manager, "users.manage")
        user_role = ctx.users.repo.get_role("User")
        ctx.users.repo.create_user(
            "basic", "Basic User", ctx.users._hash("pw"), user_role["id"]
        )
        basic = ctx.users.authenticate("basic", "pw")
        assert ctx.permissions.can(basic, "projects.view")
        assert not ctx.permissions.can(basic, "projects.edit")


def test_audit_and_error_logging():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.audit.success(admin, "TEST_ACTION", "Test", 1, "Completed")
        rows = ctx.audit.list()
        assert rows[0]["action"] == "TEST_ACTION"
        assert rows[0]["status"] == "SUCCESS"
        ctx.audit.failure(admin, "TEST_FAILURE", "Test", 2, "Example failure")
        rows = ctx.audit.list()
        assert rows[0]["status"] == "FAILURE"
        assert rows[0]["message"] == "Example failure"


def test_windows_packaging_assets():
    root = Path(__file__).resolve().parents[1]
    assert (root / "VERSION").read_text(encoding="utf-8").strip() == "1.7.0"
    assert (root / "run_mfm.py").exists()
    assert (root / "build_windows.ps1").exists()
    assert (root / "build_windows.bat").exists()
    assert (root / "DEPLOYMENT.md").exists()


def test_ai_insights_are_read_only():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.organization.save("AI Test Organization")
        before = db.fetch_one("SELECT COUNT(*) c FROM audit_log")["c"]
        insights = ctx.ai.insights()
        after = db.fetch_one("SELECT COUNT(*) c FROM audit_log")["c"]
        assert insights
        assert before == after


def test_natural_language_queries():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M500", "Query", "Member")
        answer = ctx.query.answer("Hvor mange medlemmer har vi?")
        assert "1" in answer
        finance = ctx.query.answer("Hvordan ser økonomien ud?")
        assert "Resultat:" in finance
        bank = ctx.query.answer("Hvordan ser bankafstemningen ud?")
        assert "Ikke-afstemte:" in bank


def test_recommendations():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main")
        ctx.bank.import_transaction(bank_id, 100, "Unmatched")
        recs = ctx.recommendations.analyze()
        assert any(r["area"] == "Bank" for r in recs)
        assert all("reason" in r for r in recs)


def test_unified_assistant():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M900", "Assistant", "Test")
        status = ctx.assistant.respond("Hvordan går det?")
        assert "Resultat:" in status
        members = ctx.assistant.respond("Hvor mange medlemmer har vi?")
        assert "1" in members
        advice = ctx.assistant.respond("Hvad bør jeg gøre?")
        assert advice


def test_explainable_recommendations():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main")
        ctx.bank.import_transaction(bank_id, 100, "Needs matching")
        rows = ctx.explainability.recommendations_with_sources()
        bank_rows = [r for r in rows if r["area"] == "Bank"]
        assert bank_rows
        assert bank_rows[0]["sources"][0]["source"] == "bank_transactions"
        assert "MFM-datakilde" in bank_rows[0]["explanation"]


def test_forecast():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        income = next(a for a in accounts if a["number"] == "3000")
        expense = next(a for a in accounts if a["number"] == "5000")

        bank = next(a for a in accounts if a["number"] == "1000")
        ctx.accounting.post_journal(
            1, "January", [
                {"account_id": bank["id"], "debit": 1000, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 1000},
            ], "2026-01-15"
        )
        ctx.accounting.post_journal(
            2, "January expense", [
                {"account_id": expense["id"], "debit": 600, "credit": 0},
                {"account_id": bank["id"], "debit": 0, "credit": 600},
            ], "2026-01-20"
        )
        ctx.accounting.post_journal(
            3, "February", [
                {"account_id": bank["id"], "debit": 1200, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 1200},
            ], "2026-02-15"
        )
        ctx.accounting.post_journal(
            4, "February expense", [
                {"account_id": expense["id"], "debit": 700, "credit": 0},
                {"account_id": bank["id"], "debit": 0, "credit": 700},
            ], "2026-02-20"
        )
        result = ctx.forecast.forecast(3)
        assert result["available"] is True
        assert len(result["forecasts"]) == 3
        assert result["forecasts"][0]["value"] > 0


def test_project_financial_forecast_requires_history():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project = ctx.projects.create("Forecast Project", budget=1000)
        result = ctx.projects.financial_forecast(project, 1)
        assert result["available"] is False



def test_backup_does_not_overwrite_existing_recovery_point():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        backup = base / "backup.db"
        ctx.system.backup(backup)
        original = backup.read_bytes()
        with pytest.raises(FileExistsError):
            ctx.system.backup(backup)
        assert backup.read_bytes() == original


def test_export_creates_audit_record_and_refuses_overwrite():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.current_user = admin
        ctx.members.create_member("M901", "Audit", "Export")
        path = base / "members.csv"
        ctx.export.export_members(path)
        rows = ctx.audit.list()
        assert any(r["action"] == "EXPORT" and r["entity_type"] == "members"
                   and r["status"] == "SUCCESS" for r in rows)
        original = path.read_bytes()
        with pytest.raises(FileExistsError):
            ctx.export.export_members(path)
        assert path.read_bytes() == original
        rows = ctx.audit.list()
        assert any(r["action"] == "EXPORT" and r["entity_type"] == "members"
                   and r["status"] == "FAILURE" for r in rows)


def test_restore_rejects_valid_sqlite_that_is_not_an_mfm_database():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        source = base / "unrelated.db"
        with sqlite3.connect(source) as conn:
            conn.execute("CREATE TABLE unrelated(id INTEGER PRIMARY KEY)")
            conn.commit()
        before = db.fetch_one("SELECT COUNT(*) AS n FROM users")["n"]
        with pytest.raises(ValueError, match="not a valid MFM database"):
            ctx.system.restore(source)
        after = db.fetch_one("SELECT COUNT(*) AS n FROM users")["n"]
        assert after == before


def test_bank_match_is_atomic_when_status_update_fails():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.current_user = admin
        # Satisfy the journal foreign key with a real journal.
        account = next(
            (a for a in ctx.accounting.repo.list_accounts() if a["number"] == "1000"),
            None,
        )
        if account is None:
            account_id = ctx.accounting.create_account("1000", "Test Account", "Asset")
            account = ctx.accounting.repo.get_account(account_id)
        journal = ctx.accounting.repo.create_posted_journal(
            "ATOMIC-001", "2026-08-20", "Atomic test",
            [(account["id"], "Atomic", 10.0, 0.0, None)]
        )
        bank_id = db.execute(
            "INSERT INTO bank_accounts(name,account_number) VALUES(?,?)",
            ("Test Bank", "123"),
        )
        tx = ctx.accounting.repo.create_bank_transaction(
            bank_id, "2026-08-20", 10.0, "Atomic", "EXT-ATOMIC", "Unmatched"
        )
        with db.connect() as conn:
            conn.execute(
                "CREATE TRIGGER fail_bank_status BEFORE UPDATE OF status ON bank_transactions "
                "BEGIN SELECT RAISE(ABORT, 'forced status failure'); END;"
            )
        with pytest.raises(Exception, match="forced status failure"):
            ctx.accounting.repo.match_bank_transaction_atomic(tx, journal, 10.0)
        assert ctx.accounting.repo.get_bank_match(tx) is None
        current = next(
            r for r in ctx.accounting.repo.list_bank_transactions()
            if r["id"] == tx
        )
        assert current["status"] == "Unmatched"
        assert current["journal_id"] is None


def test_membership_payment_is_atomic_when_invoice_status_update_fails():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member("AT51", "Atomic", "Payment")
        mtype = ctx.members.create_membership_type("Atomic", 500)
        membership_id = ctx.members.add_membership(member_id, mtype)
        invoice_id = ctx.members.invoice_membership(membership_id, member_id, 500)
        with db.connect() as conn:
            conn.execute(
                "CREATE TRIGGER fail_invoice_status BEFORE UPDATE OF status ON membership_invoices "
                "BEGIN SELECT RAISE(ABORT, 'forced invoice status failure'); END;"
            )
        with pytest.raises(Exception, match="forced invoice status failure"):
            ctx.members.register_payment(invoice_id, 500, "2026-08-20")
        assert db.fetch_one(
            "SELECT COUNT(*) AS n FROM membership_payments WHERE invoice_id=?",
            (invoice_id,),
        )["n"] == 0
        assert db.fetch_one(
            "SELECT status FROM membership_invoices WHERE id=?", (invoice_id,)
        )["status"] == "Open"


def test_bank_import_batch_is_atomic_when_one_row_fails():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = db.execute(
            "INSERT INTO bank_accounts(name,account_number) VALUES(?,?)",
            ("Import Test Bank", "B52"),
        )
        with db.connect() as conn:
            conn.execute(
                "CREATE TRIGGER fail_second_import BEFORE INSERT ON bank_transactions "
                "WHEN NEW.external_reference='FAIL-52' "
                "BEGIN SELECT RAISE(ABORT, 'forced import failure'); END;"
            )
        rows = [
            {"transaction_date":"2026-08-20","amount":10.0,
             "description":"First","external_reference":"OK-52"},
            {"transaction_date":"2026-08-20","amount":20.0,
             "description":"Second","external_reference":"FAIL-52"},
        ]
        with pytest.raises(Exception, match="forced import failure"):
            ctx.accounting.import_bank_transactions(bank_id, rows)
        assert db.fetch_one(
            "SELECT COUNT(*) AS n FROM bank_transactions WHERE bank_account_id=?",
            (bank_id,),
        )["n"] == 0


def test_project_budget_update_keeps_legacy_and_normalized_budget_in_sync():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Budget Sync", budget=100)
        ctx.projects.set_budget(project_id, 250)
        project = db.fetch_one("SELECT budget FROM projects WHERE id=?", (project_id,))
        normalized = db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",
            (project_id,),
        )
        assert float(project["budget"]) == 250.0
        assert float(normalized["budget_amount"]) == 250.0


def test_voucher_document_delete_does_not_remove_db_record_when_file_delete_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        account = next(a for a in ctx.accounting.repo.list_accounts() if a["number"] == "1000")
        journal = ctx.accounting.repo.create_posted_journal(
            "DOC-54", "2026-08-20", "Document delete safety",
            [(account["id"], "Document", 10.0, 0.0, None)]
        )
        storage = base / "storage"
        storage.mkdir()
        source = base / "source.txt"
        source.write_text("voucher", encoding="utf-8")
        stored = storage / "voucher-54.txt"
        stored.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
        doc_id = ctx.accounting.repo.add_voucher_document(
            journal,
            source.name,
            str(stored),
            "text/plain",
            stored.stat().st_size,
            "test-sha-54",
            "Test document",
            "2026-08-20T12:00:00",
        )
        doc = ctx.accounting.voucher_document(doc_id)
        target = Path(doc["stored_name"])
        assert target.exists()

        original_unlink = Path.unlink
        def fail_unlink(self, *args, **kwargs):
            if self == target:
                raise OSError("forced storage delete failure")
            return original_unlink(self, *args, **kwargs)
        monkeypatch.setattr(Path, "unlink", fail_unlink)

        with pytest.raises(ValueError, match="could not be removed from storage"):
            ctx.accounting.remove_voucher_document(doc_id)

        assert ctx.accounting.voucher_document(doc_id) is not None
        assert target.exists()


def test_export_cleans_partial_temp_file_when_write_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        target = base / "members.csv"
        class FailingWriter:
            def writerow(self, row):
                pass
            def writerows(self, rows):
                raise OSError("forced export failure")
        def fake_writer(fh):
            return FailingWriter()
        monkeypatch.setattr(csv, "writer", fake_writer)
        with pytest.raises(OSError, match="forced export failure"):
            ctx.export.export_members(target)
        assert not target.exists()
        assert not target.with_name(target.name + ".tmp").exists()


def test_forced_password_change_does_not_store_plaintext_password_in_main_window():
    text = (Path(__file__).resolve().parents[1] / "src" / "gui" / "main_window.py").read_text(
        encoding="utf-8"
    )
    assert "_last_new_password" not in text
    assert "authenticate(username.get(), self._last_new_password)" not in text


def test_error_service_does_not_silently_swallow_audit_failure(caplog):
    class FailingAudit:
        def failure(self, user, action, message):
            raise RuntimeError("forced audit failure")

    service = ErrorService(FailingAudit())
    with caplog.at_level(logging.ERROR):
        result = service.handle(
            RuntimeError("primary operation failure"),
            user="admin",
            action="STEP57_TEST",
        )
    assert result == "primary operation failure"
    assert any("MFM audit failure while handling action STEP57_TEST" in r.message
               for r in caplog.records)


def test_backup_cleans_partial_destination_when_copy_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        destination = base / "failed_backup.db"

        def partial_copy(src, dst, *args, **kwargs):
            Path(dst).write_bytes(b"partial-backup")
            raise OSError("forced backup copy failure")

        monkeypatch.setattr(shutil, "copy2", partial_copy)
        with pytest.raises(OSError, match="forced backup copy failure"):
            ctx.system.backup(destination)
        assert not destination.exists()


def test_restore_rolls_back_when_replacement_copy_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        original_value = db.fetch_one(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users'"
        )["name"]
        backup = base / "backup.db"
        ctx.system.backup(backup)

        original_copy2 = shutil.copy2
        calls = {"n": 0}
        def fail_restore_copy(src, dst, *args, **kwargs):
            if Path(dst) == db.path:
                calls["n"] += 1
                if calls["n"] == 1:
                    Path(dst).write_bytes(b"partial-restore")
                    raise OSError("forced restore replacement failure")
            return original_copy2(src, dst, *args, **kwargs)

        monkeypatch.setattr(shutil, "copy2", fail_restore_copy)
        with pytest.raises(OSError, match="forced restore replacement failure"):
            ctx.system.restore(backup)

        restored = Database(db.path)
        assert restored.fetch_one(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users'"
        )["name"] == original_value
        assert db.path.exists()


def test_restore_rejects_active_database_as_restore_source():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="active MFM database"):
            ctx.system.restore(db.path)


def test_create_project_task_rejects_invalid_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 61")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.create_project_task(
                project_id, "Bad date task", due_date="2026-99-99"
            )


def test_create_project_task_rejects_invalid_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 61")
        with pytest.raises(ValueError, match="Invalid task status"):
            ctx.projects.create_project_task(
                project_id, "Bad status task", status="Bogus"
            )


def test_update_project_task_rejects_invalid_due_date_and_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 62")
        task_id = ctx.projects.create_project_task(project_id, "Update validation")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.update_project_task(task_id, due_date="2026-99-99")
        with pytest.raises(ValueError, match="Invalid task status"):
            ctx.projects.update_project_task(task_id, status="Bogus")


def test_triage_work_item_rejects_invalid_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 63")
        task_id = ctx.projects.create_project_task(project_id, "Triage validation")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.triage_work_item(task_id, due_date="2026-99-99")


def test_quick_action_deadline_rejects_invalid_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 64")
        task_id = ctx.projects.create_project_task(project_id, "Quick action validation")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.quick_action(task_id, "deadline", "2026-99-99")


def test_create_project_task_normalizes_assignee_whitespace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 65")
        task_id = ctx.projects.create_project_task(
            project_id, "Assignment normalization", assigned_to="  Alice  "
        )
        task = ctx.projects.repo.task_by_id(task_id)
        assert task["assigned_to"] == "Alice"


def test_update_project_task_normalizes_assignee_whitespace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 65 update")
        task_id = ctx.projects.create_project_task(project_id, "Assignment update")
        ctx.projects.update_project_task(task_id, assigned_to="  Bob  ")
        task = ctx.projects.repo.task_by_id(task_id)
        assert task["assigned_to"] == "Bob"


def test_update_project_task_rejects_activity_from_another_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 66 A")
        project_b = ctx.projects.create("Step 66 B")
        activity_b = ctx.projects.create_activity(project_b, "Foreign activity")
        task_a = ctx.projects.create_project_task(project_a, "Activity ownership")
        with pytest.raises(ValueError, match="Activity does not belong"):
            ctx.projects.update_project_task(task_a, activity_id=activity_b)


def test_update_project_task_rejects_blank_title():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 67")
        task_id = ctx.projects.create_project_task(project_id, "Original title")
        with pytest.raises(ValueError, match="Task title is required"):
            ctx.projects.update_project_task(task_id, title="   ")
        assert ctx.projects.repo.task_by_id(task_id)["title"] == "Original title"


def test_update_project_task_rejects_unknown_task():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project task not found"):
            ctx.projects.update_project_task(999999, title="Does not exist")


def test_update_activity_rejects_blank_name():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 69")
        activity_id = ctx.projects.create_activity(project_id, "Original activity")
        with pytest.raises(ValueError, match="Activity name is required"):
            ctx.projects.update_activity(activity_id, name="   ")
        assert ctx.projects.repo.db.fetch_one(
            "SELECT name FROM activities WHERE id=?", (activity_id,)
        )["name"] == "Original activity"


def test_update_activity_rejects_unknown_activity():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Activity not found"):
            ctx.projects.update_activity(999999, name="Does not exist")


def test_update_activity_rejects_cross_project_reparenting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 70 A")
        project_b = ctx.projects.create("Step 70 B")
        activity_id = ctx.projects.create_activity(project_a, "Protected activity")
        with pytest.raises(ValueError, match="Activity project cannot be changed"):
            ctx.projects.update_activity(activity_id, project_id=project_b)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id FROM activities WHERE id=?", (activity_id,)
        )
        assert int(row["project_id"]) == int(project_a)


def test_create_activity_rejects_invalid_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 71 create")
        with pytest.raises(ValueError, match="Invalid activity date"):
            ctx.projects.create_activity(project_id, "Date validation", activity_date="2026-99-99")


def test_update_activity_rejects_invalid_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 71 update")
        activity_id = ctx.projects.create_activity(project_id, "Date update", activity_date="2026-08-21")
        with pytest.raises(ValueError, match="Invalid activity date"):
            ctx.projects.update_activity(activity_id, activity_date="2026-99-99")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT activity_date FROM activities WHERE id=?", (activity_id,)
        )
        assert row["activity_date"] == "2026-08-21"


def test_create_project_rejects_invalid_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Invalid project status"):
            ctx.projects.create("Step 73 invalid", status="Bogus")


def test_create_project_normalizes_status_whitespace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 73 normalize", status=" Active ")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT status FROM projects WHERE id=?", (project_id,)
        )
        assert row["status"] == "Active"


def test_project_budget_rejects_non_finite_values():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.create("Step 74 finite project", budget=value)
        project_id = ctx.projects.create("Step 74 budget target")
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.set_budget(project_id, value)


def test_activity_budget_rejects_non_finite_values():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 74 activity budget")
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.create_activity(project_id, "Finite budget", budget=value)
        activity_id = ctx.projects.create_activity(project_id, "Budget update", budget=100)
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.update_activity(activity_id, budget=value)


def test_set_budget_rejects_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.set_budget(999999, 1000)


def test_project_budget_read_rejects_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.budget(999999)


def test_project_financial_reads_reject_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        methods = [
            ctx.projects.activity_summary,
            ctx.projects.financial_tracking,
            ctx.projects.financial_report,
            ctx.projects.financial_forecast,
            ctx.projects.expense_lines,
            ctx.projects.activity_financials,
            ctx.projects.activity_financial_detail,
            ctx.projects.project_control_dashboard,
            ctx.projects.project_tasks,
        ]
        for method in methods:
            with pytest.raises(ValueError, match="Project not found"):
                method(999999)


def test_update_project_task_rejects_cross_project_reparenting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 78 A")
        project_b = ctx.projects.create("Step 78 B")
        task_id = ctx.projects.create_project_task(project_a, "Protected task")
        with pytest.raises(ValueError, match="Task project cannot be changed"):
            ctx.projects.update_project_task(task_id, project_id=project_b)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id FROM tasks WHERE id=?", (task_id,)
        )
        assert int(row["project_id"]) == int(project_a)
