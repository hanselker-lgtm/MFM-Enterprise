# MFM Product v0.1

A first working product baseline for MaritimForeningsManager.

## What is implemented

- SQLite database with migrations
- Dashboard
- Projects
- Tasks
- Risks
- Decisions
- Accounting core: chart of accounts, balanced journals, posting, trial balance, fiscal years, periods, automatic journal numbering, income statement, balance sheet, project budgets and budget-vs-actual
- Application/service/repository separation
- No external dependency for the first GUI baseline (Tkinter)

## Start

From the project root:

```text
python run.py
```

The database is created automatically in `data/mfm.db`.

## First product principle

This release is deliberately small. It implements working business functions rather than additional governance documents.

Next implementation target:
- accounting core
- members
- documents
- reporting
- backup/restore
- AI assistant
