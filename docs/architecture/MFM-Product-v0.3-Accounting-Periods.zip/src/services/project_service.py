class ProjectService:
    def __init__(self, repo): self.repo = repo
    def create(self, name, description="", status="Planned", budget=0):
        name = name.strip()
        if not name: raise ValueError("Project name is required.")
        return self.repo.create(name, description.strip(), status, float(budget or 0))
    def list(self): return self.repo.list()
    def count(self): return self.repo.count()
