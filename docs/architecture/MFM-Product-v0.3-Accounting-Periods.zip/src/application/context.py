from src.repositories.project_repository import ProjectRepository
from src.repositories.task_repository import TaskRepository
from src.repositories.risk_repository import RiskRepository
from src.repositories.decision_repository import DecisionRepository
from src.services.project_service import ProjectService
from src.services.task_service import TaskService
from src.services.risk_service import RiskService
from src.services.decision_service import DecisionService
from src.repositories.accounting_repository import AccountingRepository
from src.services.accounting_service import AccountingService

class ApplicationContext:
    def __init__(self, db):
        self.db = db
        self.projects = ProjectService(ProjectRepository(db))
        self.tasks = TaskService(TaskRepository(db))
        self.risks = RiskService(RiskRepository(db))
        self.decisions = DecisionService(DecisionRepository(db))
        self.accounting = AccountingService(AccountingRepository(db))
        self.accounting.seed_standard_accounts()
