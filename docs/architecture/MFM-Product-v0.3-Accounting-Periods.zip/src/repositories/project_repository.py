class ProjectRepository:
    def __init__(self, db): self.db = db
    def list(self): return self.db.fetch_all("SELECT * FROM projects ORDER BY id DESC")
    def create(self, name, description, status, budget):
        return self.db.execute(
            "INSERT INTO projects(name,description,status,budget) VALUES(?,?,?,?)",
            (name, description, status, budget))
    def count(self): return self.db.fetch_one("SELECT COUNT(*) c FROM projects")["c"]
