from datetime import date, timedelta

class MemberService:
    def __init__(self, repo):
        self.repo = repo

    def create_member(self, member_no, first_name, last_name, **kwargs):
        if not member_no.strip():
            raise ValueError("Member number is required.")
        if not first_name.strip() or not last_name.strip():
            raise ValueError("First name and last name are required.")
        return self.repo.create_member(
            member_no.strip(), first_name.strip(), last_name.strip(),
            kwargs.get("email","").strip(), kwargs.get("phone","").strip(),
            kwargs.get("address","").strip(), kwargs.get("postal_code","").strip(),
            kwargs.get("city","").strip(), kwargs.get("joined_date")
        )

    def members(self):
        return self.repo.list_members()

    def create_membership_type(self, name, annual_fee):
        name = name.strip()
        annual_fee = float(annual_fee)
        if not name:
            raise ValueError("Membership type name is required.")
        if annual_fee < 0:
            raise ValueError("Membership fee cannot be negative.")
        return self.repo.create_membership_type(name, annual_fee)

    def membership_types(self):
        return self.repo.list_membership_types()

    def add_membership(self, member_id, membership_type_id, start_date=None):
        start_date = start_date or date.today().isoformat()
        return self.repo.create_membership(member_id, membership_type_id, start_date)

    def memberships(self):
        return self.repo.list_memberships()

    def invoice_membership(self, membership_id, member_id, amount, invoice_date=None, due_date=None):
        invoice_date = invoice_date or date.today().isoformat()
        due_date = due_date or (date.today() + timedelta(days=14)).isoformat()
        invoice_no = self.repo.next_invoice_number()
        return self.repo.create_invoice(
            member_id, membership_id, invoice_no, invoice_date, due_date, float(amount)
        )

    def invoices(self):
        return self.repo.list_invoices()
