from datetime import date, timedelta

class MemberService:
    def __init__(self, repo, accounting=None):
        self.repo = repo
        self.accounting = accounting

    def create_member(self, member_no, first_name, last_name, **kwargs):
        if not str(member_no).strip():
            raise ValueError("Member number is required.")
        if not str(first_name).strip() or not str(last_name).strip():
            raise ValueError("First name and last name are required.")
        return self.repo.create_member(
            str(member_no).strip(), str(first_name).strip(), str(last_name).strip(),
            str(kwargs.get("email", "")).strip(), str(kwargs.get("phone", "")).strip(),
            str(kwargs.get("address", "")).strip(), str(kwargs.get("postal_code", "")).strip(),
            str(kwargs.get("city", "")).strip(), kwargs.get("joined_date")
        )

    def members(self):
        return self.repo.list_members()

    def create_membership_type(self, name, annual_fee):
        name = str(name).strip()
        annual_fee = float(annual_fee)
        if not name:
            raise ValueError("Membership type name is required.")
        if annual_fee < 0:
            raise ValueError("Membership fee cannot be negative.")
        return self.repo.create_membership_type(name, annual_fee)

    def membership_types(self):
        return self.repo.list_membership_types()

    def add_membership(self, member_id, membership_type_id, start_date=None):
        return self.repo.create_membership(
            member_id, membership_type_id, start_date or date.today().isoformat()
        )

    def memberships(self):
        return self.repo.list_memberships()

    def invoice_membership(self, membership_id, member_id, amount, invoice_date=None, due_date=None):
        amount = float(amount)
        if amount <= 0:
            raise ValueError("Invoice amount must be greater than zero.")
        invoice_date = invoice_date or date.today().isoformat()
        due_date = due_date or (date.today() + timedelta(days=14)).isoformat()
        invoice_no = self.repo.next_invoice_number()

        # Invoice: debit receivable / credit membership income.
        journal_id = None
        if self.accounting:
            accounts = {a["number"]: a for a in self.accounting.accounts()}
            if accounts.get("1200") and accounts.get("3000"):
                journal_id = self.accounting.post_journal(
                    None, f"Membership invoice {invoice_no}", [
                        {"account_id": accounts["1200"]["id"], "debit": amount, "credit": 0},
                        {"account_id": accounts["3000"]["id"], "debit": 0, "credit": amount},
                    ], invoice_date
                )

        return self.repo.create_invoice(
            member_id, membership_id, invoice_no, invoice_date, due_date, amount, journal_id
        )

    def invoices(self):
        return self.repo.list_invoices()

    def register_payment(self, invoice_id, amount, payment_date=None):
        payment_date = payment_date or date.today().isoformat()
        invoice = self.repo.get_invoice(invoice_id)
        if not invoice:
            raise ValueError("Invoice not found.")

        amount = round(float(amount), 2)
        if amount <= 0:
            raise ValueError("Payment must be greater than zero.")

        paid_before = self.repo.invoice_paid_amount(invoice_id)
        remaining = round(float(invoice["amount"]) - paid_before, 2)
        if amount > remaining:
            raise ValueError("Payment exceeds outstanding invoice amount.")

        journal_id = None
        if self.accounting:
            accounts = {a["number"]: a for a in self.accounting.accounts()}
            if accounts.get("1000") and accounts.get("1200"):
                journal_id = self.accounting.post_journal(
                    None, f"Payment invoice {invoice['invoice_no']}", [
                        {"account_id": accounts["1000"]["id"], "debit": amount, "credit": 0},
                        {"account_id": accounts["1200"]["id"], "debit": 0, "credit": amount},
                    ], payment_date
                )

        payment_id = self.repo.register_payment(
            invoice_id, payment_date, amount, journal_id
        )
        paid_after = round(paid_before + amount, 2)
        self.repo.update_invoice_status(
            invoice_id,
            "Paid" if paid_after >= float(invoice["amount"]) else "Partially Paid"
        )
        return payment_id

    def payments(self):
        return self.repo.list_payments()
