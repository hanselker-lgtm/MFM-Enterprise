import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import date

class MainWindow:
    def __init__(self, context):
        self.ctx = context
        self.root = tk.Tk()
        self.root.title("MFM — MaritimForeningsManager")
        self.root.geometry("1100x700")
        self._build()

    def _build(self):
        top = ttk.Frame(self.root, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text="MFM — Management & Intelligence", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Button(top, text="Refresh", command=self.refresh).pack(side="right")

        nav = ttk.Frame(self.root, padding=(12,0))
        nav.pack(fill="x")
        for text, command in [
            ("Dashboard", self.show_dashboard),
            ("Projects", self.show_projects),
            ("Tasks", self.show_tasks),
            ("Risks", self.show_risks),
            ("Decisions", self.show_decisions),
        ]:
            ttk.Button(nav, text=text, command=command).pack(side="left", padx=(0,6))

        self.body = ttk.Frame(self.root, padding=12)
        self.body.pack(fill="both", expand=True)
        self.show_dashboard()

    def clear(self):
        for child in self.body.winfo_children():
            child.destroy()

    def card(self, parent, title, value, row, col):
        f = ttk.LabelFrame(parent, text=title, padding=18)
        f.grid(row=row, column=col, sticky="nsew", padx=6, pady=6)
        ttk.Label(f, text=str(value), font=("Segoe UI", 22, "bold")).pack()
        return f

    def show_dashboard(self):
        self.clear()
        ttk.Label(self.body, text="Management Dashboard", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        grid = ttk.Frame(self.body)
        grid.pack(fill="x", pady=12)
        for c in range(4): grid.columnconfigure(c, weight=1)
        today = date.today().isoformat()
        self.card(grid, "Projects", self.ctx.projects.count(), 0, 0)
        self.card(grid, "Open Tasks", self.ctx.tasks.count_open(), 0, 1)
        self.card(grid, "Open Risks", self.ctx.risks.count_open(), 0, 2)
        self.card(grid, "Pending Decisions", self.ctx.decisions.count_pending(), 0, 3)
        ttk.Label(self.body, text=f"Overdue tasks: {self.ctx.tasks.count_overdue(today)}").pack(anchor="w")
        ttk.Label(self.body, text=f"High risks: {self.ctx.risks.count_high()}").pack(anchor="w", pady=(4,0))
        ttk.Separator(self.body).pack(fill="x", pady=16)
        ttk.Label(self.body, text="Product direction", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Label(self.body, text="MFM is now being built around real business data, decisions, actions, risks and results — not document production.").pack(anchor="w", pady=4)

    def table(self, columns, rows):
        tree = ttk.Treeview(self.body, columns=columns, show="headings")
        for c in columns:
            tree.heading(c, text=c.replace("_"," ").title())
            tree.column(c, width=180)
        for row in rows:
            tree.insert("", "end", values=[row[c] for c in columns])
        tree.pack(fill="both", expand=True, pady=10)
        return tree

    def show_projects(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Projects", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Project", command=self.new_project).pack(side="right")
        self.table(["id","name","status","budget"], self.ctx.projects.list())

    def new_project(self):
        name = simpledialog.askstring("New Project", "Project name:")
        if not name: return
        try:
            self.ctx.projects.create(name)
            self.show_projects()
        except Exception as e:
            messagebox.showerror("MFM", str(e))

    def show_tasks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Tasks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Task", command=self.new_task).pack(side="right")
        self.table(["id","title","status","due_date","owner"], self.ctx.tasks.list())

    def new_task(self):
        title = simpledialog.askstring("New Task", "Task title:")
        if not title: return
        try:
            self.ctx.tasks.create(title)
            self.show_tasks()
        except Exception as e:
            messagebox.showerror("MFM", str(e))

    def show_risks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Risks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Risk", command=self.new_risk).pack(side="right")
        self.table(["id","title","severity","status","owner"], self.ctx.risks.list())

    def new_risk(self):
        title = simpledialog.askstring("New Risk", "Risk title:")
        if not title: return
        try:
            self.ctx.risks.create(title)
            self.show_risks()
        except Exception as e:
            messagebox.showerror("MFM", str(e))

    def show_decisions(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Decisions", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Decision", command=self.new_decision).pack(side="right")
        self.table(["id","title","status","owner"], self.ctx.decisions.list())

    def new_decision(self):
        title = simpledialog.askstring("New Decision", "Decision title:")
        if not title: return
        try:
            self.ctx.decisions.create(title)
            self.show_decisions()
        except Exception as e:
            messagebox.showerror("MFM", str(e))

    def refresh(self):
        self.show_dashboard()

    def run(self):
        self.root.mainloop()
