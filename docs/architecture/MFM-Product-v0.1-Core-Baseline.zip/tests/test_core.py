import tempfile
from pathlib import Path
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def test_core_crud():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.projects.create("Test Project")
        ctx.tasks.create("Test Task")
        ctx.risks.create("Test Risk", "High")
        ctx.decisions.create("Test Decision")
        assert ctx.projects.count() == 1
        assert ctx.tasks.count_open() == 1
        assert ctx.risks.count_high() == 1
        assert ctx.decisions.count_pending() == 1
