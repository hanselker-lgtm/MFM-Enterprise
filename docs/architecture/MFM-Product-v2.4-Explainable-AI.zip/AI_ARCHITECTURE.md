# MFM AI Architecture — v2.4

## Explainability

AI recommendations must remain traceable to current MFM data.

Each supported recommendation exposes:
- priority;
- area;
- recommendation;
- reason;
- one or more MFM source references.

Example source references identify the module, metric, observed value and
logical source table/service.

The explainability layer remains read-only. It does not grant the AI any
authority to change, approve, post or delete data.
