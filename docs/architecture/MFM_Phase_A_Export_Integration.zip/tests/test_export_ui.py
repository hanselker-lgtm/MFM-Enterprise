from pathlib import Path
import tempfile
from src.gui.main_window import MainWindow
from src.application.context import ApplicationContext
from src.database.db import Database
from src.database.schema import initialize_schema

def test_export_is_registered_under_administration():
    assert dict(MainWindow.command_registry())["Export"] == "show_export"

def test_export_navigation_contract_contains_existing_export():
    assert dict(MainWindow.product_navigation_contract())["Administration"] == ("show_export",)

def test_all_existing_exports_create_csv_files():
    with tempfile.TemporaryDirectory() as d:
        base=Path(d)
        db=Database(base/"test.db")
        initialize_schema(db)
        ctx=ApplicationContext(db)
        ctx.members.create_member("M900","Export","Coverage")
        ctx.projects.create("Export Coverage Project")
        exports={
            "members":ctx.export.export_members,
            "projects":ctx.export.export_projects,
            "journals":ctx.export.export_journals,
            "invoices":ctx.export.export_invoices,
            "bank":ctx.export.export_bank_transactions,
            "trial_balance":ctx.export.export_trial_balance,
        }
        for name, fn in exports.items():
            target=base/f"{name}.csv"
            fn(target)
            assert target.exists()
            assert target.read_text(encoding="utf-8-sig").splitlines()[0]
