import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

class SystemService:
    def __init__(self, db):
        self.db = db

    def get_setting(self, key, default=""):
        row = self.db.fetch_one("SELECT value FROM app_settings WHERE key=?", (key,))
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.db.execute(
            """INSERT INTO app_settings(key,value) VALUES(?,?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value""",
            (key, str(value))
        )

    def _verify_sqlite(self, path):
        """Verify that a SQLite file passes the built-in integrity check."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Database file not found: {path}")
        try:
            with sqlite3.connect(path) as conn:
                result = conn.execute("PRAGMA integrity_check").fetchone()
        except sqlite3.DatabaseError as exc:
            raise ValueError("Database file is not a valid SQLite database.") from exc
        if not result or result[0] != "ok":
            raise ValueError("Database integrity check failed.")

    def backup(self, destination):
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Ensure pending WAL content is checkpointed before copying.
        with self.db.connect() as conn:
            conn.execute("PRAGMA wal_checkpoint(FULL)")
        # Never silently overwrite an existing recovery point.
        if destination.exists():
            raise FileExistsError(f"Backup destination already exists: {destination}")
        shutil.copy2(self.db.path, destination)
        try:
            self._verify_sqlite(destination)
        except Exception:
            destination.unlink(missing_ok=True)
            raise
        return destination

    def restore(self, source):
        source = Path(source)
        if not source.exists():
            raise FileNotFoundError("Backup file not found.")

        # Never replace the live database with an unverified backup.
        self._verify_sqlite(source)

        # Keep the existing database file as a safety copy.
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        safety = self.db.path.with_name(
            self.db.path.stem + "_before_restore_" +
            timestamp + self.db.path.suffix
        )
        # Never overwrite an earlier recovery point, even if multiple restores
        # are initiated during the same timestamp window.
        counter = 1
        while safety.exists():
            safety = self.db.path.with_name(
                self.db.path.stem + "_before_restore_" +
                timestamp + f"_{counter}" + self.db.path.suffix
            )
            counter += 1
        if self.db.path.exists():
            shutil.copy2(self.db.path, safety)
        shutil.copy2(source, self.db.path)
        try:
            self._verify_sqlite(self.db.path)
        except Exception:
            # Restore the safety copy if the replacement itself is invalid.
            if safety.exists():
                shutil.copy2(safety, self.db.path)
            raise
        return safety
