# MFM v1.49 — Product Completion Step 38

## Project Control — forecast display clarity

Step 37 hardened the no-history contract. Step 38 improves the existing Project
Control forecast display so the user can distinguish:
- forecast amount
- forecast month
- confidence classification
- insufficient historical data

When a forecast is available, the card now displays the value together with the
forecast month and confidence. When history is insufficient, the UI explicitly
states that there is too little history instead of using a generic unavailable
message.

No calculation, database/schema, or accounting-source change.
