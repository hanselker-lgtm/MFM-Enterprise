# MFM v1.49 — Product Completion Step 31

## Forecast transparency and data-quality diagnostics

Step 30 corrected the forecast time axis to use real calendar months.

Step 31 adds explicit diagnostics to the forecast result so the user can distinguish
a complete monthly history from a history containing months with no posted project
expense.

Added fields:
- `data_points`
- `expected_months`
- `missing_months`
- `history_complete`
- `slope`
- `intercept`

A missing month is **not** interpreted as zero expense. The forecast remains advisory
and read-only.

No database/schema change and no new accounting source.
