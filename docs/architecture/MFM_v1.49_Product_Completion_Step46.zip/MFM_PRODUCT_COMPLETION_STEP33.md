# MFM v1.49 — Product Completion Step 33

## Forecast confidence transparency

Step 32 stabilized the forecast contract when historical data is insufficient.
Step 33 adds transparent diagnostics for the quality of an available linear trend.

Added:
- `r_squared`
- `coverage`
- `confidence`
- `confidence_score`

The score is a bounded diagnostic derived from trend fit (`R²`) and calendar coverage.
It does not alter the forecast value and is not presented as a statistical guarantee.

For insufficient history, confidence is explicitly `insufficient_history` with score `0.0`.

No database/schema change and no new accounting source.
