# MFM v1.49 — Product Completion Step 30

## Project Financial Forecast — calendar-aware trend correction

### Concrete gap
The existing advisory forecast used the sequence of observed transaction months
as x-values. If a calendar month had no posted project expense, that month was
silently removed and the trend treated the next observed month as adjacent.

That can distort a time-series forecast.

### Correction
The trend now uses the actual calendar month index (`YYYY-MM`) as the time axis
and returns the forecast month for each predicted value.

Example:
- history: 2026-01, 2026-03
- forecast: 2026-04, 2026-05

No database/schema change and no new financial source were introduced.
The forecast remains advisory and read-only.
