# MFM v1.49 — Product Completion Step 35

## Project Control — single forecast snapshot

Step 34 exposed forecast confidence in the Project Control UI, but the UI obtained
the dashboard data and forecast through two separate service calls.

Step 35 consolidates the forecast into `project_control_dashboard()` itself.

The dashboard now returns a single forecast snapshot containing:
- forecast value/month
- confidence diagnostics
- history diagnostics

The GUI consumes `data["forecast"]` instead of issuing a second forecast query.

This reduces duplicate reads and ensures the Project Control view presents one
consistent dashboard snapshot.

No database/schema change and no new accounting source.
