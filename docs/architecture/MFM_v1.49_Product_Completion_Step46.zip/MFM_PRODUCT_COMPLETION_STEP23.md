# MFM Product Completion – Step 23

## Project Financial Report UI Traceability Fix

### Concrete gap
The Project Financial Report populated `line_id` and `journal_id` values in its accounting-reference rows, but the Treeview's declared column list did not include those two columns. This made the UI definition inconsistent with the data it attempted to display.

### Change
Added `line_id` and `journal_id` to the Treeview column definition. No data model, repository, service, accounting, or database changes were made.

### Validation
- Python compileall: PASS
- Project financial report regression: 1 passed, 47 deselected
- Full suite: not claimed green
