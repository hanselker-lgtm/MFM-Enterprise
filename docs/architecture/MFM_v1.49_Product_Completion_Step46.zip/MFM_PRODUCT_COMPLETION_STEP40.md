# MFM v1.49 — Product Completion Step 40

## Project Control — incomplete-history visibility

Step 39 exposed forecast data-quality diagnostics through the Project Control
dashboard contract.

Step 40 uses that existing information in the GUI when a forecast is not
available because the historical calendar contains missing months.

The display now distinguishes:
- insufficient history
- incomplete historical calendar
- other unavailable forecast states

For an incomplete calendar, the missing months are shown directly in the
Forecast card.

No new calculation was introduced.

No database/schema change and no new accounting source.
