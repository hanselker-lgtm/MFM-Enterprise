# MFM v1.49 — Product Completion Step 37

## Project Control — no-history forecast contract

Step 36 introduced the flat forecast summary fields on the Project Control
dashboard.

Step 37 verifies the opposite edge case: when a project does not yet have enough
historical months for a forecast, all flat summary fields remain explicit and
safe for GUI consumers.

Expected contract:
- `forecast_value` = `None`
- `forecast_month` = `None`
- `forecast_confidence` = `insufficient_history`
- `forecast_confidence_score` = `0.0`

No placeholder numeric forecast is generated.

No database/schema change and no new accounting source.
