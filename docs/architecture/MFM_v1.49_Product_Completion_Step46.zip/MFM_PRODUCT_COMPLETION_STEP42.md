# MFM v1.49 — Product Completion Step 42

## Project Control — forecast clamping summary

Step 41 made negative-trend clamping transparent at the individual forecast-point
level through `raw_value` and `is_clamped`.

Step 42 surfaces the same information at the Project Control dashboard level.

Added:
- `forecast_clamped`
- `forecast_clamped_months`

This gives dashboard/reporting consumers a simple way to determine whether any
forecast period was forced to the zero floor, without inspecting every forecast
point.

The detailed forecast object remains unchanged and available.

No new calculation, database/schema change, or accounting source.
