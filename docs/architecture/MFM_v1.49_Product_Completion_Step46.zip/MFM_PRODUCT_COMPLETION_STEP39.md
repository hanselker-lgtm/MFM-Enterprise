# MFM v1.49 — Product Completion Step 39

## Project Control — forecast data-quality summary

Step 38 improved forecast presentation. Step 39 exposes the forecast's existing
data-quality diagnostics directly at the Project Control dashboard level.

Added:
- `forecast_warning`
- `forecast_data_points`
- `forecast_expected_months`
- `forecast_missing_months`
- `forecast_history_complete`

This allows future UI/reporting consumers to explain *why* a forecast has lower
confidence without reaching into the nested forecast object.

No new calculation was introduced. The existing diagnostics from Step 31–33 are
simply surfaced through the dashboard contract.

No database/schema change and no new accounting source.
