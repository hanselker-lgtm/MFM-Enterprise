# MFM Product Completion Step 25

## Project Revenue / Funding Integration

Step 24 contained project budget, actual, forecast, variance and accounting traceability, but the Project Financial Report did not expose authoritative project revenue/funding.

Step 25 adds read-only project revenue/funding derived from posted accounting journal lines linked by `project_id` to Income/Revenue accounts.

### Architecture

- Accounting remains authoritative for posted financial transactions.
- No parallel ledger or funding ledger was introduced.
- `ProjectRepository.project_income_lines()` exposes traceable income lines.
- `ProjectService.financial_report()` exposes `revenue`, `funding`, and `income_lines`.
- The Project Financial Report GUI displays Revenue / Funding.

### Safe boundary

Only posted journal lines with the project reference and an Income/Revenue account are included. No operational funding commitment is created or modified by this reporting feature.

### Validation

- `python -m compileall -q src` — PASS
- Project Financial Report regression subset — 2 passed, 47 deselected
