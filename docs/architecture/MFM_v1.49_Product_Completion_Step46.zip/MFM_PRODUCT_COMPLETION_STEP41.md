# MFM v1.49 — Product Completion Step 41

## Forecast — negative-trend clamping transparency

The forecast deliberately prevents negative expense values by applying a zero
floor. Step 41 makes that transformation explicit in each forecast point.

Each forecast point now contains:
- `value`: the non-negative value presented to consumers
- `raw_value`: the underlying linear-trend result before the zero floor
- `is_clamped`: whether the raw result was below zero and therefore clipped

This prevents a consumer from mistaking a zero forecast for a naturally
zero-valued trend.

The regression covers both the boundary point where the raw trend reaches
exactly zero and the following point where the raw trend becomes negative.

No change to the accounting source, database/schema, or trend calculation.
