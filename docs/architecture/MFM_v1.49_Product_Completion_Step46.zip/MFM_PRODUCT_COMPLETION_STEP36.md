# MFM v1.49 — Product Completion Step 36

## Project Control — flat forecast summary contract

Step 35 consolidated the forecast into the Project Control dashboard snapshot.

Step 36 makes the most important forecast values directly accessible at the
dashboard level, without requiring GUI consumers to understand the nested
forecast structure.

Added:
- `forecast_value`
- `forecast_month`
- `forecast_confidence`
- `forecast_confidence_score`

The original full `forecast` object remains available.

No database/schema change and no new accounting source.
