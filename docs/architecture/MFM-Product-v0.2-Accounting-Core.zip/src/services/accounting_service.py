from datetime import date

class AccountingService:
    def __init__(self, repo):
        self.repo = repo

    def seed_standard_accounts(self):
        existing = self.repo.list_accounts()
        if existing:
            return
        defaults = [
            ("1000", "Bank", "Asset"),
            ("1100", "Cash", "Asset"),
            ("1200", "Receivables", "Asset"),
            ("2000", "Payables", "Liability"),
            ("3000", "Membership Income", "Income"),
            ("4000", "Grants and Donations", "Income"),
            ("5000", "Operating Expenses", "Expense"),
            ("5100", "Project Expenses", "Expense"),
        ]
        for item in defaults:
            self.repo.create_account(*item)

    def accounts(self):
        return self.repo.list_accounts()

    def create_account(self, number, name, account_type):
        number = number.strip()
        name = name.strip()
        if not number or not name:
            raise ValueError("Account number and name are required.")
        return self.repo.create_account(number, name, account_type)

    def post_journal(self, journal_no, description, lines, journal_date=None):
        journal_date = journal_date or date.today().isoformat()
        if not lines or len(lines) < 2:
            raise ValueError("A journal needs at least two lines.")

        debit = round(sum(float(x["debit"]) for x in lines), 2)
        credit = round(sum(float(x["credit"]) for x in lines), 2)
        if debit <= 0 or credit <= 0 or debit != credit:
            raise ValueError("Journal must balance: total debit must equal total credit.")

        journal_id = self.repo.create_journal(journal_no, journal_date, description.strip())
        for line in lines:
            d = float(line["debit"])
            c = float(line["credit"])
            if d < 0 or c < 0 or (d > 0 and c > 0):
                raise ValueError("Each line must contain either debit or credit.")
            self.repo.add_line(
                journal_id,
                int(line["account_id"]),
                line.get("description", ""),
                d, c,
                line.get("project_id"),
            )
        self.repo.set_journal_status(journal_id, "Posted")
        return journal_id

    def journals(self):
        return self.repo.list_journals()

    def trial_balance(self):
        return self.repo.trial_balance()
