class AccountingRepository:
    def __init__(self, db):
        self.db = db

    def list_accounts(self):
        return self.db.fetch_all(
            "SELECT * FROM accounts WHERE active=1 ORDER BY number"
        )

    def create_account(self, number, name, account_type):
        return self.db.execute(
            "INSERT INTO accounts(number,name,account_type) VALUES(?,?,?)",
            (number, name, account_type),
        )

    def get_account(self, account_id):
        return self.db.fetch_one("SELECT * FROM accounts WHERE id=?", (account_id,))

    def create_journal(self, journal_no, journal_date, description):
        return self.db.execute(
            "INSERT INTO journals(journal_no,journal_date,description) VALUES(?,?,?)",
            (journal_no, journal_date, description),
        )

    def add_line(self, journal_id, account_id, description, debit, credit, project_id=None):
        return self.db.execute(
            """INSERT INTO journal_lines
               (journal_id,account_id,description,debit,credit,project_id)
               VALUES(?,?,?,?,?,?)""",
            (journal_id, account_id, description, debit, credit, project_id),
        )

    def get_journal_lines(self, journal_id):
        return self.db.fetch_all(
            """SELECT jl.*, a.number, a.name
               FROM journal_lines jl
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.journal_id=? ORDER BY jl.id""",
            (journal_id,),
        )

    def set_journal_status(self, journal_id, status):
        self.db.execute("UPDATE journals SET status=? WHERE id=?", (status, journal_id))

    def list_journals(self):
        return self.db.fetch_all(
            "SELECT * FROM journals ORDER BY journal_date DESC, journal_no DESC"
        )

    def trial_balance(self):
        return self.db.fetch_all(
            """SELECT a.number, a.name,
                      COALESCE(SUM(jl.debit),0) debit,
                      COALESCE(SUM(jl.credit),0) credit
               FROM accounts a
               LEFT JOIN journal_lines jl ON jl.account_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id AND j.status='Posted'
               WHERE a.active=1
               GROUP BY a.id
               ORDER BY a.number"""
        )
