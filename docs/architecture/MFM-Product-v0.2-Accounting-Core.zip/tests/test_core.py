import tempfile
from pathlib import Path
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def test_core_crud():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.projects.create("Test Project")
        ctx.tasks.create("Test Task")
        ctx.risks.create("Test Risk", "High")
        ctx.decisions.create("Test Decision")
        assert ctx.projects.count() == 1
        assert ctx.tasks.count_open() == 1
        assert ctx.risks.count_high() == 1
        assert ctx.decisions.count_pending() == 1


def test_accounting_balanced_posting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        jid = ctx.accounting.post_journal(
            1,
            "Membership payment",
            [
                {"account_id": bank["id"], "debit": 500, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 500},
            ],
        )
        assert jid == 1
        assert db.fetch_one("SELECT status FROM journals WHERE id=?", (jid,))["status"] == "Posted"

def test_accounting_rejects_unbalanced_journal():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        a = accounts[0]
        b = accounts[1]
        try:
            ctx.accounting.post_journal(
                1, "Invalid", [
                    {"account_id": a["id"], "debit": 100, "credit": 0},
                    {"account_id": b["id"], "debit": 0, "credit": 90},
                ])
            assert False, "Expected ValueError"
        except ValueError:
            pass
