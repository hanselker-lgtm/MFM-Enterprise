# MFM v1.22 — Member & Association Administration

v1.22 adds the day-to-day administrative member lifecycle:
- member status management;
- join and resignation events;
- contact/detail updates;
- automatic closure of active memberships on resignation;
- member event history;
- member card combining member data, memberships, invoices and administration events;
- association membership status overview.
