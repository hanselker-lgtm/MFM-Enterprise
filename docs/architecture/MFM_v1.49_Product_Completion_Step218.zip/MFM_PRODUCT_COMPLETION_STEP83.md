# MFM v1.49 — Product Completion Step 83

## P1 — Task creation and auxiliary mutation parent-project integrity

Step 83 closes the remaining parent-project integrity gaps in the task
mutation surface.

Step 82 established workflow enforcement for task status changes. The review
after Step 82 identified three adjacent paths that could still operate on a
task without first proving that its parent project exists.

### Protected paths

1. `create_project_task()`
   - now requires the target project to exist before task creation.

2. `triage_work_item()`
   - now verifies the task's parent project before any update, including
     non-status updates such as assignment or priority.

3. `quick_action()`
   - now verifies the task's parent project before executing deadline,
     priority, assignment or transition actions.

All three use the existing project integrity contract:
`ValueError("Project not found.")`

This closes the distinction between status mutations and other task mutations:
a stale/orphaned task cannot be modified through an auxiliary service path.

Three regression tests cover unknown project creation and orphaned-task
mutation through triage and quick action.
