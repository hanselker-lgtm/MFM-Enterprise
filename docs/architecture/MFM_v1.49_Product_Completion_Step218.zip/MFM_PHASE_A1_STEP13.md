# MFM Phase A.1 — Step 13
## Backup / Restore Integrity Safety

### Objective
Close a concrete operational-safety gap identified after v1.49 without introducing a new backup system.

### Concrete gap
The existing `SystemService` already supported backup and restore, but restore accepted any existing file and replaced the live database before verifying that the replacement was a valid, internally consistent SQLite database.

### Change
- Added a SQLite `PRAGMA integrity_check` verification helper.
- Backups are verified immediately after creation.
- Restore sources are verified before replacing the live database.
- The restored database is verified after replacement.
- If post-restore verification fails, the pre-restore safety copy is restored.
- Existing backup and restore APIs remain unchanged.

### Validation
- `python -m compileall -q src tests` — passed.
- Targeted core validation: **2 passed, 24 deselected**.
- No database schema changes.
- No repository/service API redesign.
- No GUI changes.
- No changes to business rules.

### Scope protection
This increment addresses only operational safety of the existing backup/restore capability. It does not add scheduled backups, cloud storage, encryption, retention policies, or a new recovery subsystem.

### Result
MFM will not knowingly replace the live database with an invalid SQLite backup, and a failed post-restore integrity check automatically falls back to the pre-restore safety copy.

### Next step
Do not add another backup feature merely to extend this increment. The next change must come from a separately identified concrete product or operational gap.
