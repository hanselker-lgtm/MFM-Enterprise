# MFM v1.48 — Work Intake Triage & Assignment

v1.48 adds a lightweight triage surface for open tasks. Existing tasks can be
assigned, prioritized, dated and moved to an existing task status.

No separate intake queue or workflow engine is introduced.
