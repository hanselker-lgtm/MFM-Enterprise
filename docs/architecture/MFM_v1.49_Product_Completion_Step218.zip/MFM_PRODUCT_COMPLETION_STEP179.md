# MFM v1.49 — Product Completion — Step 179

## Billing Preview Boundary

### Boundary

`MemberService.billing_preview(billing_year, invoice_date=None, due_date=None)`

### Purpose

Provides a read-only billing plan for eligible memberships before invoices are created.

### Existing flow

```text
billing_preview()
    ↓
repository.billing_candidates(year)
    ↓
repository.existing_invoice_for_membership_year()
    ↓
normalized preview rows
```

The boundary reuses the existing membership and invoice repositories. It does not create invoices and does not introduce a parallel billing source.

### Contract verified

- eligible memberships are returned for the selected billing year
- existing invoices are detected per membership/year
- invoice number is exposed when an existing invoice is present
- amount and billing dates are included in the preview
- the operation is read-only
- the preview does not mutate invoice state

### Product code

**NO PRODUCT CODE CHANGE.**

The existing implementation already satisfies the intended boundary contract. Existing batch billing continues to consume this preview through `bill_memberships()`.

### Regression

A focused regression was added to `tests/test_core.py` to protect the read-only preview contract and the existing-invoice detection behaviour.

### Step status

**STEP 179 — COMPLETE**
