# MFM v1.49 — Product Completion — Step 197

## P1 — Journal Posting Boundary

Step 197 verifies the existing `AccountingService.post_journal()` mutation
boundary.

## Existing implementation

```text
post_journal()
        ↓
journal date / accounting period validation
        ↓
line validation
        ↓
account + activity/project validation
        ↓
debit/credit balancing
        ↓
repository.create_posted_journal()
        ↓
JOURNAL_POSTED audit event
```

The service performs the business validation before calling the existing
repository posting path. The repository remains the authoritative persistence
boundary for journals and journal lines.

## Verified contract

The focused regression verifies that a valid journal:

- is persisted as `Posted`;
- preserves the journal description;
- creates the expected two journal lines;
- preserves equal debit and credit totals;
- produces the existing `JOURNAL_POSTED` audit event.

The existing validation contract remains protected elsewhere in the product
suite, including closed-period rejection, invalid accounts, invalid activity /
project relationships, negative amounts and unbalanced journals.

## Architecture decision

**NO PRODUCT CODE CHANGE.**

No new posting engine, journal store, accounting model or parallel mutation
path was introduced. The existing service/repository split is already the
correct boundary.

## Regression

Focused Step 197 regression: **1 passed**.

Compileall: **PASS**.

Step 197 is complete.
