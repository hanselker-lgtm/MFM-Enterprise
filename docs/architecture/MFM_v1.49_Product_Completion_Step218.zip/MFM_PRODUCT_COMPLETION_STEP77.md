# MFM v1.49 — Product Completion Step 77

## P1 — Project-scoped read target integrity

Step 77 extends the project-existence contract established by Steps 75 and 76
to the remaining project-scoped read APIs in the project service.

The review found that several reporting/control methods still delegated an
unknown project ID directly to the repository:
- activity summary;
- financial tracking;
- financial report;
- financial forecast;
- expense lines;
- activity financials;
- activity financial detail;
- project control dashboard;
- project tasks.

The service now uses one `_require_project()` guard for these APIs. An unknown
project ID consistently produces `ValueError("Project not found.")` before
repository access.

This avoids inconsistent empty/partial responses for stale project references
and establishes a single service-level target contract for project-scoped
reads.

One regression test exercises all nine APIs against an unknown project.
