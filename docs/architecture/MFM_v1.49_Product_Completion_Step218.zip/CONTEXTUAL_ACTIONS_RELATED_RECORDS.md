# MFM v1.43 — Contextual Actions & Related Records

v1.43 makes the Unified Record View actionable. Users can execute existing
task workflow actions, open related records, and create a normal project-task
follow-up from a task or activity context.

No parallel action or issue model is introduced.
