# MFM v1.49 — Product Completion Step 90

## P1 — Activity date mutation consistency

Step 90 closes a small but real mutation-contract gap in the activity date
field.

`create_activity()` already accepts an optional activity date, and
`update_activity()` validated non-empty dates. However, an update using
`activity_date=None` previously skipped normalization and could not express
the intentional action of clearing an existing date through the service
contract.

The update path now treats:
- `None` or empty string as an explicit clear operation;
- non-empty values as ISO dates requiring validation;
- invalid dates as a domain error.

The existing date remains unchanged when invalid input is supplied.

Two regression tests verify both explicit clearing and rejection of invalid
dates.
