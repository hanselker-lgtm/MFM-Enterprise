# MFM v1.36 — Project Control Actions & Exception Management

v1.36 turns project-control findings into actionable exceptions. It detects
activity budget overruns, overdue tasks, blocked tasks and missing owners,
and lets the user create a concrete follow-up task from an exception.

Exceptions are derived from existing project, task and accounting data.
Follow-up is implemented as a normal project task, avoiding a parallel
issue-management or governance system.
