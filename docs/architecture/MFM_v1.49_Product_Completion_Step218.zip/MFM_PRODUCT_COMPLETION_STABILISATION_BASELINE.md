# MFM Product Completion & Stabilisation — Baseline

## Phase objective

Stop feature accumulation and make the existing MFM capabilities coherent,
safe and usable as one application.

## Phase A — Core Navigation & Workspace Consolidation

Principles:

1. User-facing navigation must describe user jobs, not development history.
2. Existing services and data models are reused.
3. No new task, inbox, workflow or dashboard model is introduced.
4. Duplicate workspace entry points should converge on a canonical workspace.
5. Every consolidation change must preserve existing automated tests.

## Baseline

The current application is tested before changes. The first implementation
step is navigation consolidation, not a new feature.

## Target top-level areas

- Home
- Work
- Projects
- Members
- Finance
- Reports
- Administration

Detailed capabilities should be reached contextually from these areas.

## Canonical work surfaces

- Work → My Work / Today / Inbox / Quick Capture
- Projects → Project / Activities / Financial Control / Execution
- Members → Member Administration / Membership / Billing / Dunning
- Finance → Accounting / Banking / Reconciliation / Closing
- Reports → Financial and operational reporting
- Administration → Users / Permissions / Audit / Backup / Export

Legacy capabilities remain available internally until their canonical surface
is verified; they should not be duplicated in the primary navigation.
