# MFM v1.31 — Personal Work Queue & My Day

v1.31 adds a personal operational view over the existing assigned-task
model. It provides counts for overdue, due today, next seven days, critical
and blocked work, plus the user's active task queue.

It is intentionally a personal filter over existing work rather than another
task database or approval workflow.
