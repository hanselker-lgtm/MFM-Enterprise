# MFM v1.18 — Financial Reporting & Management Dashboard

This version turns the accounting data into a practical management view.

The dashboard provides:
- revenue;
- expenses;
- net result;
- assets;
- liabilities;
- equity;
- account-level income and expense movements;
- date filtering.

The report layer reads posted journal data and does not create additional
accounting entries. Management values are derived from the existing chart of
accounts and journal lines.
