# MFM v1.49 Product Completion — Step 169

## Boundary
Operational Alerts

## Existing implementation
The existing `ProjectService.operational_alerts(today=None)` is a read-only orchestration boundary.

Flow:

    operational_alerts()
        ↓
    date validation / normalization
        ↓
    repository.operational_alerts(today)
        ↓
    existing task/project data
        ↓
    service-level alert derivation and validation
        ↓
    severity ordering and counts
        ↓
    read-only result

## Repository contract
`ProjectRepository.operational_alerts()` is the authoritative data source. It returns:
- active task records with project/activity context and due dates
- active project records with budget and posted expense actuals

The service does not introduce another persistence path or parallel alert data source.

## Verified behaviours
- optional as-of date validation
- overdue task alerts
- deadline-soon alerts within seven days
- missing-owner alerts
- blocked-task alerts
- project budget-overrun alerts
- Critical/High severity ordering
- alert counts
- invalid stored task due dates are rejected
- invalid stored financial values are rejected
- read-only result

## Product code
**NO PRODUCT CODE CHANGE.**

The existing boundary is architecturally correct and follows the established MFM Product Completion pattern.

## Regression
Added focused regression tests for:
1. task alert composition and counts
2. budget-overrun detection through the existing accounting data path
3. invalid as-of/stored task dates
4. invalid stored financial data

## Status
STEP 169 — COMPLETE

Product code: NO CHANGE
Regression tests: ADDED
Documentation: ADDED
