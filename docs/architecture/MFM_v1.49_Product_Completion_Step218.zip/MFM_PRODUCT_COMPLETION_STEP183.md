# MFM v1.49 — Product Completion — Step 183

## Dunning Preview Boundary

### Boundary

`dunning_preview(as_of_date=None)`

### Purpose

This is a real operational read boundary for collections follow-up. It converts the repository's existing dunning candidates into a stable preview model without sending communication or mutating invoice/member data.

### Existing flow

```text
dunning_preview()
    ↓
repository.dunning_candidates(as_of_date)
    ↓
existing invoice/payment/member data
    ↓
outstanding + days overdue calculation
    ↓
read-only dunning rows
```

### Contract verified

- only invoices due before the as-of date are candidates
- only active members are candidates
- fully paid invoices are excluded
- zero/negative outstanding balances are excluded
- partial payments are reflected in `paid_amount` and `outstanding`
- `days_overdue` is calculated from the supplied as-of date
- member contact context is included for the preview
- no communication is recorded and no invoice/member state is mutated

### Architectural decision

No product-code change was required. The service correctly reuses the repository's authoritative `dunning_candidates()` query and performs only presentation-level calculations needed by the preview boundary.

No separate dunning engine or parallel payment source is introduced.

### Regression

Added a focused regression covering overdue, partially paid, fully paid, inactive-member, and not-yet-due cases, plus the read-only contract.

### Status

**STEP 183 — COMPLETE**

Product code: **NO CHANGE**

Regression: **ADDED**
