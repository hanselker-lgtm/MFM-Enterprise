# MFM v1.49 — Product Completion Step 115

## P1 — Project Task Update Mutation Boundary

Following Step 114, the next task-level mutation boundary is
`update_project_task()`.

Step 115 establishes a controlled update boundary around the existing task
edit operation:

- task existence and project context are validated;
- only supported editable fields are accepted;
- text fields are normalized;
- task title cannot be empty;
- assigned-to values are normalized;
- due dates are ISO-date validated;
- priority values are normalized and validated;
- an empty update is rejected;
- the existing repository update operation is used.

Task status is intentionally excluded from this boundary and remains governed
by Step 114's workflow transition service.
No new task field or business rule is introduced.
