# MFM v1.49 — Product Completion Step 96

## P1 — Activity budget read-model normalization

Step 96 extends the service read-model boundary established in Step 95.

Step 95 converted raw database rows into application dictionaries, but the
`budget` field still reflected the database representation directly. This
could expose legacy/imported precision or inconsistent numeric types to
callers.

The activity read model now normalizes `budget` to a Python float rounded to
two decimal places.

The contract is:

- missing/null/zero-like budget becomes `0.0`;
- numeric budget is exposed as a float;
- budget precision is limited to two decimal places;
- persistence data is not modified by read-model normalization.

This keeps the read boundary consistent with the budget rules established in
Steps 88 and 89 without mutating stored data.
