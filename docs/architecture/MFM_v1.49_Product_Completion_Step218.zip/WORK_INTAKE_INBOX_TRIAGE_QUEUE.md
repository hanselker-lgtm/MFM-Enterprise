# MFM v1.49 — Work Intake Inbox & Triage Queue

## Product decision

The Inbox is deliberately **not** a new data model. It is a focused view of
existing project tasks that are still Open and have no assigned owner.

This prevents v1.49 from duplicating the task system already built in v1.47-v1.48.

## Purpose

Answer one concrete question:

> Which newly captured work still needs a person to take responsibility?

Once assigned, the item leaves the Inbox automatically and appears in the
assignee's My Work / Today View.
