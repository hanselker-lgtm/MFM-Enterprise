# MFM v1.49 Product Completion — Step 211

## Task Detail Boundary

### Boundary

```python
task_detail(task_id)
```

### Purpose

`task_detail()` is the existing read-only service boundary for opening a single task in its project context.

### Existing flow

```text
task_detail(task_id)
        ↓
repository.task_by_id()
        ↓
project authorization / scope validation
        ↓
stored due-date validation
        ↓
project lookup
        ↓
read-only task + project result
```

### Contract verified

- unknown task is rejected with the existing `Task not found.` contract
- the task is returned as a detached dictionary
- the parent project is returned as a detached dictionary
- the stored due date is validated when present
- malformed stored due dates are rejected
- the result explicitly declares `read_only == True`
- the boundary does not mutate task or project state

### Architecture decision

No product code change was required.

The boundary already uses the existing repository and authorization path. No new task-detail engine, data source, or persistence path was introduced.

### Regression

Added focused regression:

```text
test_step211_task_detail_boundary
```

The test verifies the actual existing implementation contract rather than imposing a new model.

### Result

```text
Product code change: NO
Regression added: YES
Focused regression: 1 passed
Compile: PASS
Compile: PASS
```
