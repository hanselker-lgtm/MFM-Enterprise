# MFM v1.34 — Project Execution Actions

v1.34 makes the Project Execution View actionable at project and activity
level. Users can filter tasks by activity and perform the existing quick
actions without leaving the project execution context.

Execution actions are delegated to the existing task workflow; no duplicate
workflow engine is introduced.
