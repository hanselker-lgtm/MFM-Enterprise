# MFM v1.49 — Product Completion Step 55

## P1 — Atomic CSV export file creation

Step 55 addresses a concrete export-integrity gap.

The previous CSV exporter opened the final destination directly and wrote the
header and rows into it. If the export failed after the file was created, a
partial CSV could remain at the user's requested destination.

The exporter now writes to a temporary sibling file first, flushes the data
and performs an fsync, then atomically replaces the final destination.

If writing fails:
- the final destination is not created;
- the temporary file is cleaned up;
- the existing audit failure event remains in place.

If the final destination already exists, it is still protected from
overwriting.

No CSV schema or exported fields were changed.

A regression test deliberately fails during row writing and verifies that
neither the final nor temporary export file remains.

This is a genuine product-completion change because an export is a user-facing
data boundary and must not leave misleading partial files.
