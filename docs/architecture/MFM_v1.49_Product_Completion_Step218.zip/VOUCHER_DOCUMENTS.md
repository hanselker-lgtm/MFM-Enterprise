# MFM v1.13 — Voucher Documents & Attachments

A posted voucher can now have source documents attached to it.

Stored metadata:
- original file name;
- MIME type;
- file size;
- SHA-256 hash;
- description;
- upload timestamp;
- application storage path.

The storage name is generated from the voucher number and content hash to
reduce collisions. The document record is linked to the journal/voucher.

The next hardening step should be permissions, audit events for attachment
changes, configurable storage location, and explicit document retention
policy. Those are product controls, not additional architecture layers.
