# MFM v1.35 — Project Progress & Financial Control

v1.35 combines execution progress and posted financial actuals into a
project-control cockpit.

Progress is derived from completed/closed tasks. Financial actuals are
derived only from posted expense journal lines. Project and activity control
status are shown separately so an activity can be over budget while the
overall project remains within budget.
