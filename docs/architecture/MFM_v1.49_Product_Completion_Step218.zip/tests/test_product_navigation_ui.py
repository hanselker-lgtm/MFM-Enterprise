import ast
from pathlib import Path

MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def _main_window():
    tree = ast.parse(MAIN_WINDOW.read_text(encoding="utf-8"))
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")


def test_build_uses_product_navigation_not_flat_command_registry():
    cls = _main_window()
    build = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_build")
    source = ast.unparse(build)
    assert "product_navigation_contract" in source
    assert "show_product_area" in source
    assert "command_registry" not in source


def test_product_area_handler_exists():
    cls = _main_window()
    methods = {n.name for n in cls.body if isinstance(n, ast.FunctionDef)}
    assert "show_product_area" in methods


def test_product_navigation_contains_seven_top_level_areas():
    ns = {}
    exec(compile(ast.parse(MAIN_WINDOW.read_text(encoding="utf-8")), str(MAIN_WINDOW), "exec"), ns)
    areas = [area for area, _ in ns["MainWindow"].product_navigation_contract()]
    assert areas == ["Home", "Work", "Projects", "Members", "Finance", "Reports", "Administration"]


def test_product_area_entry_points_are_canonical():
    cls = _main_window()
    method = next(
        n for n in cls.body
        if isinstance(n, ast.FunctionDef) and n.name == "show_product_area"
    )
    source = ast.unparse(method)
    for expected in (
        "'Home': self.show_dashboard",
        "'Work': self.show_my_day",
        "'Projects': self.show_projects",
        "'Members': self.show_members",
        "'Finance': self.show_accounting",
        "'Reports': self.show_financial_dashboard",
        "'Administration': self.show_administration",
    ):
        assert expected in source


def test_canonical_entry_points_are_not_duplicated_in_secondary_row():
    cls = _main_window()
    method = next(
        n for n in cls.body
        if isinstance(n, ast.FunctionDef) and n.name == "show_product_area"
    )
    source = ast.unparse(method)
    assert "canonical_entry" in source
    assert "item.command == canonical_entry" in source
    assert "continue" in source
