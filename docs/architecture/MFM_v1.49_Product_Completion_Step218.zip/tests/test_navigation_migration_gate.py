from pathlib import Path

MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def test_visible_product_navigation_is_activated():
    source = MAIN_WINDOW.read_text(encoding="utf-8")
    assert "product_nav" in source.split("def _build", 1)[1].split("def show_product_area", 1)[0]
    assert 'show_product_area("Home")' in source.split("def _build", 1)[1].split("def show_product_area", 1)[0]


def test_product_areas_are_defined_before_visible_migration():
    source = MAIN_WINDOW.read_text(encoding="utf-8")
    expected = ["Home", "Work", "Projects", "Members", "Finance", "Reports", "Administration"]
    for area in expected:
        assert f'("{area}",' in source
