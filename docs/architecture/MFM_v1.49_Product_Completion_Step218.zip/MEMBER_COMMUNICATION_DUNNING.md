# MFM v1.21 — Member Communication & Dunning

The membership module now provides a practical overdue-payment workflow:
- overdue invoice detection;
- outstanding balance calculation;
- days overdue;
- reminder/collection message templates;
- communication logging per member and invoice;
- history for later review.

v1.21 deliberately prepares and logs communications rather than sending email
automatically. This keeps the first implementation safe and testable while
preserving the full communication history.
