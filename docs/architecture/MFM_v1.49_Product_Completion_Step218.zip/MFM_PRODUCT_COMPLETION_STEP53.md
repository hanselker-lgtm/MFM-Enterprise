# MFM v1.49 — Product Completion Step 53

## P1 — Project budget source-of-truth consistency

Step 53 addresses a concrete consistency gap in the project budget model.

The database contains both:
- `projects.budget` (legacy/project-level budget field); and
- `project_budgets.budget_amount` (normalized budget record).

The existing `set_budget()` method updated only `project_budgets`. This meant
the two representations could silently diverge after a budget change.

The product now updates both representations in one database transaction.
If the normalized budget insert/update fails, the project-level budget update
is rolled back as well.

No reporting semantics were changed. The change ensures that existing and
newer consumers see the same project budget.

A regression test verifies that changing a project budget updates both stored
representations to the same value.

This is a genuine product-completion change because duplicate financial
representations must not drift apart.
