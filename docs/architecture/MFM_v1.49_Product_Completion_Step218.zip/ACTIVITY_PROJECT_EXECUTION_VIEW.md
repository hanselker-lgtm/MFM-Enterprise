# MFM v1.33 — Activity & Project Execution View

v1.33 provides a consolidated execution view for a project. It combines
project budget/actuals, activity-level financials, activity task progress,
and the project's operational tasks.

Task progress is calculated from Completed/Closed tasks. Financial actuals
continue to come only from posted expense journal lines; no financial
amounts are inferred from task progress.
