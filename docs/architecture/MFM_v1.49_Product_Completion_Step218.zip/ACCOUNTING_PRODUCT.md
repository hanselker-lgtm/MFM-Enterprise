# MFM Accounting Product Baseline

The accounting core now covers:

- chart of accounts with typed accounts;
- fiscal years and 12 monthly periods;
- open/closed period control;
- balanced double-entry journal posting;
- atomic journal creation (no partial journal on validation failure);
- automatic journal numbering;
- trial balance with date filtering;
- general ledger;
- account movements;
- income statement;
- balance sheet with current result and balance validation;
- project actuals and budget-vs-actual;
- membership invoice/payment integration.

Accounting principle used by the product:
- assets: debit balance;
- liabilities/equity/income: credit balance;
- expenses: debit balance.

The balance sheet explicitly checks:
    assets == liabilities + equity + current result

The next accounting work should be UI/report presentation, vouchers/attachments,
VAT handling if required by the target organization, year-end closing/opening
balances, and stronger integration tests. These are product decisions rather
than additional architecture documents.
