# MFM Phase A.1 — Step 9
## Controlled MainWindow Integration Preview

### Objective
Exercise the complete Phase A.1 navigation chain in an isolated preview without replacing the known v1.49 visible navigation.

### Changes
- Added `MainWindow.preview_product_navigation(parent)`.
- The preview creates a clearly labelled, caller-supplied container.
- The preview consumes the existing `build_product_navigation()` adapter.
- The adapter therefore exercises the full chain:
  `Product Area → NavigationItem → Command → MainWindow handler`.
- The preview returns the created frame and button map for controlled testing.
- `_build()` remains unchanged and continues to use the existing command registry navigation.

### Scope protection
No database, repository, service, workflow, business-rule, permission-definition, or workspace implementation was changed.

### Validation
- `python -m compileall -q src`: PASS
- `pytest -q tests/test_gui_structure.py`: expected 17 tests; run below.
- The full 71-test baseline is not declared revalidated unless the complete suite finishes successfully.

### Migration gate
The visible product navigation must not replace the current navigation until the preview path and complete regression suite are validated.
