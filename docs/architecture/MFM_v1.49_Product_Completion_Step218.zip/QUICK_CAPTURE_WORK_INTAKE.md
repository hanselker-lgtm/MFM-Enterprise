# MFM v1.47 — Quick Capture & Work Intake

v1.47 provides a fast intake surface for creating a normal MFM project task.
Only the project and title are essential; activity, owner, priority, deadline
and description can be supplied when known.

The feature writes directly to the existing task model.
