# MFM v1.49 — Product Completion — Step 180

## Batch Billing Execution Boundary

### Boundary

`MemberService.bill_memberships(billing_year, invoice_date=None, due_date=None)`

### Purpose

Executes the existing membership billing plan produced by `billing_preview()`.
It is a real mutation boundary because it converts eligible preview rows into
membership invoices while explicitly skipping memberships that are already
invoiced for the selected billing year.

### Existing flow

```text
bill_memberships()
    ↓
billing_preview()
    ↓
existing invoice detection
    ↓
for each eligible row
    ├── already invoiced → skip
    └── not invoiced → invoice_membership()
                           ↓
                    existing accounting/repository path
```

The boundary therefore does not introduce a second billing engine. It reuses
the existing preview contract and the existing `invoice_membership()` mutation
path.

### Contract verified

- billing is scoped to the selected billing year
- eligible memberships are processed through the existing preview
- new invoices are created through `invoice_membership()`
- already-invoiced memberships are skipped
- created/skipped collections and counts are returned
- a repeated billing run does not create duplicate invoices
- the existing invoice/accounting persistence path remains authoritative

### Product code

**NO PRODUCT CODE CHANGE.**

The existing implementation already satisfies the intended execution
contract. No refactoring or new billing engine was justified.

### Regression

A focused regression was added to `tests/test_core.py` covering both the
initial batch creation and a repeated run that must skip the existing invoice.

### Step status

**STEP 180 — COMPLETE**
