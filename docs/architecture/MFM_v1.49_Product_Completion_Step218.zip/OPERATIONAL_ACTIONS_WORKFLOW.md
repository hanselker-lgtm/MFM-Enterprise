# MFM v1.29 — Operational Actions & Workflow

v1.29 makes the operational workboard actionable. Users can inspect a task
and transition its status directly from the operational workspace.

Workflow transitions are explicitly controlled:
Open -> In Progress / Blocked / Completed / Closed
In Progress -> Blocked / Completed / Open
Blocked -> In Progress / Open
Completed -> Closed / Open
Closed -> no further transition

This is intentionally a small workflow model, not a new bureaucratic
approval engine.
