# MFM v1.49 — Product Completion Step 66

## P0/P1 — Project task activity ownership on update

Step 66 closes a cross-project data-integrity gap in project task updates.

Task creation already verified that an optional activity belonged to the same
project as the task. The normal update path did not perform that relationship
check.

Without the check, an existing task in Project A could potentially be changed
to reference an activity belonging to Project B. That would corrupt project
hierarchy and could make execution, progress and control views associate work
with the wrong project.

The product now validates `activity_id` updates at the service boundary:
- the target task must exist;
- the selected activity must exist;
- the selected activity must belong to the task's project;
- otherwise the update is rejected before repository mutation.

Existing valid same-project activity assignments remain unchanged.

A regression test creates two projects and verifies that assigning an activity
from Project B to a task in Project A is rejected.

This is a genuine product-completion change because project/activity ownership
is a structural integrity rule, not merely a UI preference.
