# MFM v1.49 — Product Completion Step 189

## Boundary

**Bank Match Suggestions**

Existing service boundary:

```python
suggest_bank_matches(bank_account_id)
```

## Architectural verification

The boundary is a read-only suggestion layer over the existing bank reconciliation model.

Flow:

```text
suggest_bank_matches()
        ↓
repo.list_bank_transactions(..., "Unmatched")
        ↓
repo.list_candidate_journals()
        ↓
existing amount/date comparison
        ↓
deterministic suggestion + score
```

It does not create a match, change transaction status, post a journal, or introduce a second matching engine.

The suggestion is deliberately advisory. The existing explicit approval path remains:

```text
suggestion
    ↓
user review
    ↓
match_bank_transaction()
```

## Validation

Verified behaviour:

- only unmatched transactions are considered;
- candidate journals are existing posted journals;
- amount equality is required;
- date proximity affects the score;
- the best candidate is selected deterministically;
- the reason explains amount/date matching;
- no mutation occurs while generating suggestions.

## Product code change

**NO PRODUCT CODE CHANGE**

The existing implementation already satisfies the intended boundary contract.

## Regression

Added focused regression covering:

- exact amount/date match;
- deterministic journal suggestion;
- score and reason;
- transaction remains unmatched;
- journal match is not created during suggestion.

Result:

```text
1 passed
```

## Compile

```text
python -m compileall -q src tests
PASS
```

## Step status

```text
STEP 189 — COMPLETE

Boundary:
Bank Match Suggestions

Product code:
NO CHANGE

Regression:
ADDED

Compile:
PASS

Documentation:
ADDED
```
