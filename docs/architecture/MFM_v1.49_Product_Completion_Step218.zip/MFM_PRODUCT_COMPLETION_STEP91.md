# MFM v1.49 — Product Completion Step 91

## P1 — Activity update field contract

Step 91 closes a mutation-contract gap in `update_activity()`.

The repository already had an allow-list for activity columns, but the
service accepted arbitrary keyword fields and the repository silently ignored
unsupported names. A caller could therefore believe an update had succeeded
when no supported field was actually changed.

The service now defines the complete activity update contract:

- name
- description
- activity_date
- status
- budget
- project_id (only for integrity validation; the project cannot be changed)

Unsupported fields fail explicitly with:
`ValueError("Unsupported activity fields: ...")`

An update with no fields also fails explicitly with:
`ValueError("No activity fields supplied for update.")`

This makes the service contract deterministic and prevents silent no-op
mutations.

Two regression tests verify unsupported-field rejection and empty-update
rejection.
