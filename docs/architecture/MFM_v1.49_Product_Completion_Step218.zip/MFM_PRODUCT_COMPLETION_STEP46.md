# MFM v1.49 — Product Completion Step 46

## P0 — Backup recovery-point safety

Step 46 addresses a concrete operational risk found in the existing backup
implementation.

MFM already performed SQLite integrity checking and preserved the live database
before a restore. However, `backup(destination)` silently overwrote an
existing backup file. That could destroy an earlier recovery point without an
explicit user decision.

The product now:
- refuses to overwrite an existing backup destination;
- raises a clear `FileExistsError`;
- removes a newly-created destination if post-copy integrity verification
  fails, avoiding a misleading partial backup artifact;
- preserves existing recovery points.

No new backup format, database model, or restore mechanism was introduced.

This is a genuine product-completion/release-readiness change because backup
and recovery are only useful if previously-created recovery points cannot be
silently destroyed.
