# MFM v1.49 — Product Completion — Step 209

## Project Budget vs Actual Boundary

### Existing boundary

```python
AccountingService.project_budget_vs_actual(project_id)
```

This is a real cross-module financial read boundary. It combines the existing
project budget with the authoritative accounting actuals for the selected
project.

### Existing flow

```text
project_budget_vs_actual(project_id)
        ↓
project_budgets
        +
AccountingRepository.project_actuals(project_id)
        ↓
budget / actual / variance / utilization
```

The accounting actual is deliberately obtained from `project_actuals()`, which
uses posted journal lines restricted to Expense accounts. The bank/funding line
of a project journal therefore does not incorrectly cancel the project expense.

### Contract verified

- project budget is returned as the planning amount
- actual is derived from posted project expense lines
- variance is `budget - actual`
- utilization is actual as a percentage of budget
- zero budget produces zero utilization
- the boundary is read-only
- no parallel financial ledger is created

### Regression

The Step 209 regression verifies the complete boundary and explicitly checks
that reading the budget-vs-actual result does not mutate the stored project
budget.

### Product code

```text
NO PRODUCT CODE CHANGE
```

The existing implementation is architecturally correct and is retained.

### Status

```text
STEP 209 — COMPLETE
```
