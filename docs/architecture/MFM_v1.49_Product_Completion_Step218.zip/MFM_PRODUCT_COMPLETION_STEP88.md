# MFM v1.49 — Product Completion Step 88

## P1 — Activity financial value integrity

Step 88 continues the activity service-boundary hardening with the financial
budget field.

The repository accepts the activity `budget` value as a generic field, but
the service previously did not explicitly reject negative or non-numeric
values during update.

The service now enforces:

- budget must be numeric;
- budget cannot be negative;
- stored update value is normalized to two decimal places.

Invalid input fails with either:
`ValueError("Invalid activity budget.")`
or
`ValueError("Activity budget cannot be negative.")`

The existing activity remains unchanged when validation fails.

Two regression tests cover negative and non-numeric budget updates.
