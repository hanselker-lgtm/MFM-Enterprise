param(
    [string]$Python = "python"
)

$ErrorActionPreference = "Stop"

Write-Host "MFM Windows build starting..."

& $Python -m pip install --upgrade pyinstaller
if ($LASTEXITCODE -ne 0) { throw "Could not install PyInstaller." }

& $Python -m PyInstaller `
    --noconfirm `
    --clean `
    --windowed `
    --name "MFM" `
    --add-data "src;src" `
    run_mfm.py

if ($LASTEXITCODE -ne 0) { throw "PyInstaller build failed." }

Write-Host "Build complete: dist\MFM"
