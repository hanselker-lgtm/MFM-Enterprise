# MFM v1.49 — Product Completion Step 68

## P1 — Project task existence guard on update

Step 68 closes a mutation-contract gap in project task updates.

The repository update operation naturally returned no row when a task ID did
not exist, but the service layer did not distinguish that condition from a
normal update result.

This could allow callers to treat an update against a stale/deleted task as a
successful operation even though no task was changed.

The product now verifies task existence at the service boundary before any
field validation or repository mutation:
- existing task -> continue with normal validation/update;
- unknown task ID -> ValueError("Project task not found.").

This gives the UI and calling services a deterministic product-level outcome
for stale task references.

A regression test verifies that an unknown task ID is rejected.

This is a genuine product-completion change because mutation APIs must
explicitly report when their target record no longer exists.
