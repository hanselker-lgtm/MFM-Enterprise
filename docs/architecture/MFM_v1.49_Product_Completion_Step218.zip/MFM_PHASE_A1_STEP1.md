# MFM Product Completion & Stabilisation — Phase A.1

## Step 1 — MainWindow structural consolidation

### Purpose

Restore the core MainWindow methods to one coherent `MainWindow` class without
changing database, repositories, services, business rules, permissions or
existing workflows.

### Changes

- Restored core GUI methods that had been structurally displaced from the
  `MainWindow` class.
- Restored `clear`, `card`, `table`, project workspaces and accounting methods
  as class methods.
- Restored `refresh`, `run` and `show_financial_dashboard` as class methods.
- Preserved local GUI callbacks such as login and financial-dashboard refresh.
- Corrected the isolated extra indentation in the member toolbar.
- Did not implement the new seven-area product navigation yet.
- Did not introduce any new database, task, inbox, workflow or dashboard model.

### Validation

- `src/gui/main_window.py` compiles successfully with Python 3.13.
- Added GUI structure tests covering the consolidated class structure.
- Targeted validation: **27 passed, 1 deselected**.
- The project suite contains **71 existing tests**. A complete suite run in the
  current execution environment did not finish within the available runtime;
  therefore this increment is not marked as full-suite validated yet.

### Important boundary

This is a structural stabilization increment only. The legacy `_mfm_*` extension
functions and their dynamic `MainWindow.*` assignments remain untouched. They
will be handled in a later Phase A.1 increment after their dependencies and
behavior have been mapped.
