# MFM v1.49 — Product Completion Step 52

## P0 — Atomic bank transaction import

Step 52 extends the financial transaction-integrity work to bank statement
imports.

The existing import loop inserted each bank transaction individually. Because
the database helper commits each insert, an error part-way through a file or
batch could leave earlier rows imported while later rows were rejected.

That creates a partial bank statement import and makes reconciliation harder
to trust.

The product now inserts the complete import batch inside one database
transaction:
- all rows succeed -> COMMIT;
- any row fails -> ROLLBACK of the complete batch.

The existing `BANK_IMPORT` audit event remains emitted only after the batch has
successfully committed.

No import mapping or accounting semantics were changed.

A regression test deliberately fails the second row and verifies that zero
rows from the batch remain in the database.

This is a genuine product-completion change because bank imports are a
financial data boundary and partial imports are an operationally dangerous
state.
