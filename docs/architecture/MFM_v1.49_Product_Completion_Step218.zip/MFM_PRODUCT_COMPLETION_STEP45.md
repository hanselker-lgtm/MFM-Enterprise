# MFM v1.49 — Product Completion Step 45

## P0 — First-run credential safety

Step 45 addresses a concrete release-readiness problem: fresh MFM databases
previously created an Administrator account with the known bootstrap
credential `admin/admin` and allowed normal use immediately.

The product now treats that credential as a bootstrap credential only.

Changes:
- Added `users.must_change_password`.
- Schema version advanced to 2 with a non-destructive migration for existing
  databases.
- Fresh installations flag the bootstrap Administrator for a mandatory
  password change.
- Existing installations using the known `admin/admin` credential are also
  flagged automatically.
- Password change requires confirmation and a minimum length of 12 characters.
- Successful password change clears the mandatory-change flag.
- The GUI blocks entry to the main application until the required change is
  completed.
- Existing users who already use a non-bootstrap password are not forced
  through the change flow.

This is a genuine product-completion/security change, not a cosmetic
refactoring: it closes a known first-run credential exposure before release.
No existing business data model or accounting logic was changed.
