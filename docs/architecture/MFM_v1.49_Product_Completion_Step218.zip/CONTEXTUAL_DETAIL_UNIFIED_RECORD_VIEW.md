# MFM v1.42 — Contextual Detail & Unified Record View

v1.42 introduces a unified detail surface for projects, activities, tasks and
members. It resolves an existing record and exposes its relevant operational
context and available actions without creating a duplicate data model.
