# Accounting UI — v1.9

The accounting core is now surfaced through a single Accounting & Reports
workspace with three live views:

1. Resultatopgørelse
2. Balance
3. Saldobalance

Reports can be filtered by start/end date and are generated directly from
posted accounting data. The UI deliberately remains a thin presentation
layer over the accounting service; accounting rules stay in the service
and repository layers.
