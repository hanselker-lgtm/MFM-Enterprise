# MFM v1.16 — Bank Import & Matching Workspace

The bank reconciliation process now has a practical import and matching workspace.

Workflow:
1. choose bank account;
2. choose CSV;
3. map date/amount/description/reference columns;
4. preview imported rows;
5. import while skipping duplicate external references;
6. generate deterministic journal-match suggestions;
7. review the suggestion and approve the match.

Matching currently uses exact amount and date proximity. The score is a
suggestion aid, not an automatic posting decision. The user explicitly approves
the match.
