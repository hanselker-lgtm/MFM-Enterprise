# MFM Product Completion & Stabilisation — Phase A.1

## Step 2 — Legacy MainWindow extension consolidation

### Purpose

Continue the safe MainWindow structural consolidation without changing the
application's database, repositories, services, business rules, permissions or
workflows.

### Changes

- Moved all 29 legacy `_mfm_*` GUI extension functions into the `MainWindow`
  class as real class methods.
- Replaced the previous dynamic `MainWindow.* = _mfm_*` assignments with static
  class aliases inside `MainWindow`.
- Preserved the existing public method names such as `show_members`,
  `show_project_work`, `show_global_search`, `show_quick_capture` and
  `show_work_intake_triage`.
- Preserved nested GUI callbacks inside the affected methods.
- Did not change database/repository/service interfaces.
- Did not implement the seven-area product navigation yet.
- Did not introduce a new Inbox, task system, workflow engine or dashboard.

### Validation

- `src/gui/main_window.py` compiles successfully.
- GUI structure tests: **4 passed**.
- Core tests: **25 passed**.
- A full suite run remains incomplete in the current execution environment
  because the available runtime expires while the accounting tests continue.
- Therefore this increment is not marked as full 71-test validation.

### Architectural result

The MainWindow no longer depends on top-level legacy function definitions or
runtime `MainWindow.method = function` assignments. The GUI surface is now
structurally represented inside one `MainWindow` class while retaining the
existing method names and behavior boundaries.

### Next Phase A.1 step

Perform a dependency and callback audit of the consolidated MainWindow methods,
then isolate duplicated GUI construction patterns and unsafe cross-method
coupling before introducing the new product navigation.
