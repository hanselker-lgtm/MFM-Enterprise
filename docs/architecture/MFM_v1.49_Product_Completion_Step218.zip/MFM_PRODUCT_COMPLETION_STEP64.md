# MFM v1.49 — Product Completion Step 64

## P1 — Quick deadline action error normalization

Step 64 closes the final task deadline mutation path where invalid date input
could escape with an inconsistent low-level exception.

The quick deadline action already attempted ISO-date parsing, but exposed the
raw `ValueError` raised by `date.fromisoformat()`. The normal task create,
update, and triage paths now use the product-level "Invalid task due date."
validation error.

Step 64 aligns the quick-action path with that same product-level contract:
- invalid deadline -> ValueError("Invalid task due date.");
- valid deadline -> unchanged behavior;
- empty/None deadline -> clears the deadline as before.

A regression test verifies the normalized error contract for an invalid
quick-action deadline.

This is a genuine product-completion change because all task mutation paths
should present consistent validation semantics to the UI and calling code.
