# MFM v1.44 — Personal Workspace & My Work Integration

v1.44 connects existing project tasks to a personal work surface. A user can
see their open tasks, overdue work and blocked work in one place.

The feature uses the existing assigned_to and task workflow model; no new
personal task database is introduced.
