# MFM Product Completion – Step 22

## Project Financial Reporting Traceability

### Gap
The Project Financial Report displayed accounting references using journal number, date, account and description, but did not expose the authoritative database identifiers for the journal and journal line.

### Change
Project expense-line retrieval now includes:
- `line_id`
- `journal_id`
- existing journal number/date and account information

The Project Financial Report displays the line and journal IDs alongside the existing accounting reference information.

### Boundary
No database schema changes were made. Accounting remains authoritative for posted transactions. This is read-only reporting/traceability.

### Validation
- Python compileall: PASS
- Focused project financial report regression: 1 passed, 47 deselected
