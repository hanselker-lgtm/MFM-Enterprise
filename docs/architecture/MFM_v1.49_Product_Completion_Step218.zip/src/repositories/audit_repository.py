class AuditRepository:
    def __init__(self, db):
        self.db = db

    def log(self, user_id, action, entity_type="", entity_id=None,
            status="SUCCESS", message=""):
        return self.db.execute(
            """INSERT INTO audit_log
               (user_id,action,entity_type,entity_id,status,message)
               VALUES(?,?,?,?,?,?)""",
            (user_id, action, entity_type, entity_id, status, message)
        )

    def list(self, limit=200):
        return self.db.fetch_all(
            """SELECT a.*, u.username, u.display_name
               FROM audit_log a
               LEFT JOIN users u ON u.id=a.user_id
               ORDER BY a.id DESC LIMIT ?""",
            (limit,)
        )
