class TaskRepository:
    def __init__(self, db): self.db = db
    def list(self): return self.db.fetch_all("SELECT * FROM tasks ORDER BY id DESC")
    def create(self, title, owner="", due_date=None):
        return self.db.execute(
            "INSERT INTO tasks(title,owner,due_date) VALUES(?,?,?)",
            (title, owner, due_date))
    def count_open(self): return self.db.fetch_one(
        "SELECT COUNT(*) c FROM tasks WHERE status='Open'")["c"]
    def count_overdue(self, today):
        return self.db.fetch_one(
            "SELECT COUNT(*) c FROM tasks WHERE status='Open' AND due_date IS NOT NULL AND due_date < ?",
            (today,))["c"]

    def project_tasks(self, project_id):
        return self.db.fetch_all(
            """SELECT t.*, a.name activity_name
               FROM tasks t
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.project_id=?
               ORDER BY CASE t.status WHEN 'Open' THEN 1 WHEN 'In Progress' THEN 2
                                      WHEN 'Blocked' THEN 3 ELSE 4 END,
                        t.due_date, t.id""",(project_id,)
        )

    def create_project_task(self, project_id, title, description="", activity_id=None,
                            assigned_to="", priority="Normal", due_date=None,
                            status="Open"):
        return self.db.execute(
            """INSERT INTO tasks
               (project_id,activity_id,title,description,assigned_to,priority,due_date,status)
               VALUES(?,?,?,?,?,?,?,?)""",
            (project_id,activity_id,title,description,assigned_to,priority,due_date,status)
        )

    def update_project_task(self, task_id, **fields):
        allowed={"title","description","activity_id","assigned_to","priority","due_date","status"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates: return None
        sql="UPDATE tasks SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql,tuple(updates.values())+(task_id,))
        return self.db.fetch_one("SELECT * FROM tasks WHERE id=?", (task_id,))
