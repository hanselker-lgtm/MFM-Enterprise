import re

class QueryService:
    """
    Converts a small, explicit set of natural-language questions into
    deterministic MFM service calls. No database writes are performed.
    """

    def __init__(self, context):
        self.ctx = context

    def answer(self, question):
        q = question.strip().lower()
        if not q:
            return "Please enter a question."

        if any(x in q for x in ["hvad kræver min opmærksomhed", "what needs my attention", "attention"]):
            items = self.ctx.management.attention_items()
            if not items:
                return "Der er ingen registrerede opmærksomhedspunkter."
            return "\n".join(f"{p}: {m}" for p, m in items)

        if any(x in q for x in ["økonom", "financial", "finance", "resultat", "result"]):
            s = self.ctx.management.snapshot()
            return (
                f"Indtægter: {s['income']:,.2f}\n"
                f"Udgifter: {s['expenses']:,.2f}\n"
                f"Resultat: {s['result']:,.2f}"
            )

        if any(x in q for x in ["faktura", "invoice", "kontingent", "betaling"]):
            invoices = self.ctx.members.invoices()
            open_count = sum(1 for x in invoices if x["status"] != "Paid")
            open_amount = sum(float(x["amount"]) for x in invoices if x["status"] != "Paid")
            return (
                f"Åbne medlemsfakturaer: {open_count}\n"
                f"Åbent fakturabeløb: {open_amount:,.2f}"
            )

        if any(x in q for x in ["bank", "afstem", "reconcil"]):
            s = self.ctx.bank.summary()
            return (
                f"Banktransaktioner: {s['total'] or 0}\n"
                f"Afstemte: {s['matched'] or 0}\n"
                f"Ikke-afstemte: {s['unmatched'] or 0}"
            )

        if any(x in q for x in ["projekt", "project", "budget"]):
            projects = self.ctx.projects.list()
            return f"Registrerede projekter: {len(projects)}"

        if any(x in q for x in ["medlem", "member"]):
            return f"Registrerede medlemmer: {len(self.ctx.members.members())}"

        return (
            "Jeg kan foreløbig svare på spørgsmål om økonomi, projekter, "
            "medlemmer, fakturaer, bankafstemning og opmærksomhedspunkter."
        )
