import logging
from pathlib import Path

class ErrorService:
    def __init__(self, audit=None):
        self.audit = audit
        log_dir = Path(__file__).resolve().parents[2] / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            filename=log_dir / "mfm.log",
            level=logging.ERROR,
            format="%(asctime)s %(levelname)s %(message)s"
        )

    def handle(self, error, user=None, action=""):
        logging.exception("MFM operation failed: %s", error)
        if self.audit:
            try:
                self.audit.failure(user, action, message=str(error))
            except Exception as audit_error:
                logging.error(
                    "MFM audit failure while handling action %s: %s",
                    action,
                    audit_error,
                )
        return str(error)
