class RecommendationService:
    """
    Read-only rule-based recommendations.
    Every recommendation is derived from current MFM data and includes a reason.
    """

    def __init__(self, context):
        self.ctx = context

    def analyze(self):
        s = self.ctx.management.snapshot()
        recommendations = []

        if s["unmatched_bank"] > 0:
            recommendations.append({
                "priority": "HIGH",
                "area": "Bank",
                "recommendation": "Afstem de ikke-afstemte banktransaktioner.",
                "reason": f"{s['unmatched_bank']} banktransaktion(er) er ikke afstemt."
            })

        if s["open_invoices"] > 0:
            recommendations.append({
                "priority": "MEDIUM",
                "area": "Membership",
                "recommendation": "Gennemgå åbne medlemsfakturaer.",
                "reason": f"{s['open_invoices']} faktura(er) er ikke fuldt betalt."
            })

        if s["overdue_tasks"] > 0:
            recommendations.append({
                "priority": "HIGH",
                "area": "Operations",
                "recommendation": "Gennemgå og omplanlæg forfaldne opgaver.",
                "reason": f"{s['overdue_tasks']} opgave(r) er forfaldne."
            })

        if s["high_risks"] > 0:
            recommendations.append({
                "priority": "HIGH",
                "area": "Risk",
                "recommendation": "Gennemgå åbne højrisikoforhold.",
                "reason": f"{s['high_risks']} højrisiko-forhold er åbne."
            })

        if s["pending_decisions"] > 0:
            recommendations.append({
                "priority": "MEDIUM",
                "area": "Management",
                "recommendation": "Gennemgå ventende beslutninger.",
                "reason": f"{s['pending_decisions']} beslutning(er) afventer."
            })

        if s["result"] < 0:
            recommendations.append({
                "priority": "HIGH",
                "area": "Finance",
                "recommendation": "Undersøg årsagerne til det negative resultat.",
                "reason": f"Resultatet er {s['result']:,.2f}."
            })

        if not recommendations:
            recommendations.append({
                "priority": "INFO",
                "area": "System",
                "recommendation": "Fortsæt normal drift.",
                "reason": "Ingen af de definerede kritiske forhold er identificeret."
            })

        return recommendations
