from datetime import date
from math import sqrt

class ForecastService:
    """
    Lightweight, transparent time-series forecasting for MFM.
    Uses monthly historical income/expense totals and a linear trend.
    Forecasts are advisory and read-only.
    """

    def __init__(self, context):
        self.ctx = context

    def monthly_financial_series(self):
        rows = self.ctx.db.fetch_all("""
            SELECT substr(j.journal_date,1,7) month,
                   SUM(CASE
                       WHEN a.number LIKE '3%' OR a.number LIKE '4%'
                       THEN jl.credit - jl.debit ELSE 0 END) income,
                   SUM(CASE
                       WHEN a.number LIKE '5%'
                       THEN jl.debit - jl.credit ELSE 0 END) expenses
            FROM journals j
            JOIN journal_lines jl ON jl.journal_id=j.id
            JOIN accounts a ON a.id=jl.account_id
            WHERE j.status='Posted'
            GROUP BY substr(j.journal_date,1,7)
            ORDER BY month
        """)
        result = []
        for r in rows:
            income = float(r["income"] or 0)
            expenses = float(r["expenses"] or 0)
            result.append({
                "month": r["month"],
                "income": income,
                "expenses": expenses,
                "result": income - expenses
            })
        return result

    @staticmethod
    def _linear_forecast(values, periods):
        n = len(values)
        if n == 0:
            return []
        if n == 1:
            return [values[0]] * periods

        xs = list(range(n))
        xbar = sum(xs) / n
        ybar = sum(values) / n
        denom = sum((x - xbar) ** 2 for x in xs)
        slope = sum((x - xbar) * (y - ybar) for x, y in zip(xs, values)) / denom if denom else 0
        intercept = ybar - slope * xbar

        fitted = [intercept + slope * x for x in xs]
        residuals = [y - f for y, f in zip(values, fitted)]
        if n > 2:
            std = sqrt(sum(r*r for r in residuals) / (n - 2))
        else:
            std = 0.0

        forecasts = []
        for step in range(1, periods + 1):
            x = n - 1 + step
            value = intercept + slope * x
            # Simple ±1 standard-error band; intentionally transparent.
            forecasts.append({
                "value": value,
                "lower": value - std,
                "upper": value + std
            })
        return forecasts

    def forecast(self, periods=3):
        periods = max(1, min(int(periods), 12))
        history = self.monthly_financial_series()
        if len(history) < 2:
            return {
                "available": False,
                "reason": "Der kræves mindst to historiske måneder med bogførte data.",
                "history": history,
                "forecasts": []
            }

        result_values = [x["result"] for x in history]
        forecasts = self._linear_forecast(result_values, periods)

        return {
            "available": True,
            "method": "Linear trend on monthly accounting result",
            "history": history,
            "forecasts": forecasts,
            "warning": "Forecast is indicative. Structural changes and external factors are not modeled."
        }

    def explain(self, periods=3):
        f = self.forecast(periods)
        if not f["available"]:
            return f["reason"]
        return (
            f"Forecasten bruger {len(f['history'])} historiske måneder og en "
            f"transparent lineær trend. Den modellerer ikke eksterne faktorer."
        )
