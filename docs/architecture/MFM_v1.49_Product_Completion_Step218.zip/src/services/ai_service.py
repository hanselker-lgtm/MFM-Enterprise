class AIService:
    """
    Local, deterministic intelligence foundation.
    This layer summarizes real MFM data without changing records.
    A future LLM adapter can consume this structured context.
    """

    def __init__(self, context):
        self.ctx = context

    def build_context(self):
        snapshot = self.ctx.management.snapshot()
        attention = self.ctx.management.attention_items()

        return {
            "organization": self.ctx.organization.get(),
            "snapshot": snapshot,
            "attention": [
                {"priority": p, "message": m} for p, m in attention
            ],
            "projects": self.ctx.projects.list(),
            "members": self.ctx.members.members(),
            "invoices": self.ctx.members.invoices(),
            "bank_summary": self.ctx.bank.summary(),
        }

    def insights(self):
        data = self.build_context()
        insights = []

        s = data["snapshot"]

        if s["result"] < 0:
            insights.append({
                "priority": "HIGH",
                "area": "Finance",
                "message": "The current result is negative."
            })
        elif s["result"] > 0:
            insights.append({
                "priority": "INFO",
                "area": "Finance",
                "message": "The current result is positive."
            })

        if s["unmatched_bank"] > 0:
            insights.append({
                "priority": "MEDIUM",
                "area": "Bank",
                "message": f"{s['unmatched_bank']} bank transaction(s) require reconciliation."
            })

        if s["open_invoices"] > 0:
            insights.append({
                "priority": "MEDIUM",
                "area": "Membership",
                "message": f"{s['open_invoices']} membership invoice(s) remain open."
            })

        for priority, message in data["attention"]:
            insights.append({
                "priority": priority,
                "area": "Operations",
                "message": message
            })

        if not insights:
            insights.append({
                "priority": "INFO",
                "area": "System",
                "message": "No immediate data-driven insight was identified."
            })

        return insights
