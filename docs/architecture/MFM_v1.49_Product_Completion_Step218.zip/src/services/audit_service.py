class AuditService:
    def __init__(self, repo):
        self.repo = repo

    def success(self, user, action, entity_type="", entity_id=None, message=""):
        user_id = user["id"] if user else None
        return self.repo.log(user_id, action, entity_type, entity_id, "SUCCESS", message)

    def failure(self, user, action, entity_type="", entity_id=None, message=""):
        user_id = user["id"] if user else None
        return self.repo.log(user_id, action, entity_type, entity_id, "FAILURE", message)

    def list(self, limit=200):
        return self.repo.list(limit)
