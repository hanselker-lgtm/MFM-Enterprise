class AssistantService:
    """
    Unified conversational layer.
    It routes user questions to deterministic MFM query/analysis services.
    It does not modify MFM data.
    """

    def __init__(self, context):
        self.ctx = context

    def respond(self, message):
        text = message.strip()
        if not text:
            return "Skriv et spørgsmål eller en kommando."

        q = text.lower()

        if any(x in q for x in [
            "hvad bør jeg gøre", "hvad skal jeg gøre",
            "what should i do", "what should we do"
        ]):
            recommendations = self.ctx.recommendations.analyze()
            top = [r for r in recommendations if r["priority"] == "HIGH"]
            if not top:
                top = recommendations[:3]
            return "\n".join(
                f"{r['priority']} — {r['area']}: {r['recommendation']}\n"
                f"Årsag: {r['reason']}"
                for r in top[:3]
            )

        if any(x in q for x in ["hvordan går det", "status", "status quo", "how are we doing"]):
            s = self.ctx.management.snapshot()
            return (
                f"Samlet status:\n"
                f"- Resultat: {s['result']:,.2f}\n"
                f"- Projekter: {s['projects']}\n"
                f"- Medlemmer: {s['members']}\n"
                f"- Åbne fakturaer: {s['open_invoices']}\n"
                f"- Ikke-afstemte bankposter: {s['unmatched_bank']}\n"
                f"- Åbne risici: {s['open_risks']}\n"
                f"- Ventende beslutninger: {s['pending_decisions']}"
            )

        # Preserve the deterministic query layer as the primary factual responder.
        return self.ctx.query.answer(text)
