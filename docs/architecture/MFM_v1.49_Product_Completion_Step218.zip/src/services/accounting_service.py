from calendar import monthrange
from datetime import date, datetime

class AccountingService:
    ACCOUNT_TYPES = {"Asset", "Liability", "Equity", "Income", "Expense"}

    def __init__(self, repo):
        self.repo = repo

    def seed_standard_accounts(self):
        defaults = [
            ("1000", "Bank", "Asset"),
            ("1100", "Cash", "Asset"),
            ("1200", "Receivables", "Asset"),
            ("2000", "Payables", "Liability"),
            ("3000", "Membership Income", "Income"),
            ("4000", "Grants and Donations", "Income"),
            ("5000", "Operating Expenses", "Expense"),
            ("5100", "Project Expenses", "Expense"),
            ("8000", "Accumulated Funds", "Equity"),
        ]
        existing = {a["number"] for a in self.repo.list_accounts(include_inactive=True)}
        for item in defaults:
            if item[0] not in existing:
                self.repo.create_account(*item)

    def accounts(self, include_inactive=False):
        return self.repo.list_accounts(include_inactive=include_inactive)

    def create_account(self, number, name, account_type):
        number = str(number).strip()
        name = str(name).strip()
        account_type = str(account_type).strip()
        if not number or not name:
            raise ValueError("Account number and name are required.")
        if account_type not in self.ACCOUNT_TYPES:
            raise ValueError(f"Invalid account type: {account_type}")
        return self.repo.create_account(number, name, account_type)

    def create_fiscal_year(self, year):
        year = int(year)
        if year < 1900 or year > 2200:
            raise ValueError("Fiscal year is outside the supported range.")
        if self.repo.get_fiscal_year(year):
            raise ValueError("Fiscal year already exists.")

        year_id = self.repo.create_fiscal_year(year)
        for month in range(1, 13):
            start = f"{year:04d}-{month:02d}-01"
            end = f"{year:04d}-{month:02d}-{monthrange(year, month)[1]:02d}"
            self.repo.create_period(year_id, month, start, end)
        return year_id

    def fiscal_years(self):
        return self.repo.list_fiscal_years()

    def periods(self, year):
        fy = self.repo.get_fiscal_year(int(year))
        return self.repo.list_periods(fy["id"]) if fy else []

    def _period_for_date(self, journal_date):
        return self.repo.period_for_date(journal_date)

    def close_period(self, period_id):
        row = self.repo.get_period(period_id)
        if not row:
            raise ValueError("Period not found.")
        if row["status"] == "Closed":
            return
        self.repo.set_period_status(period_id, "Closed")

    def reopen_period(self, period_id):
        row = self.repo.get_period(period_id)
        if not row:
            raise ValueError("Period not found.")
        self.repo.set_period_status(period_id, "Open")

    def _validate_journal_date(self, journal_date):
        try:
            datetime.strptime(journal_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Journal date must use YYYY-MM-DD.")

        period = self._period_for_date(journal_date)
        if period and period["status"] == "Closed":
            raise ValueError("The accounting period is closed.")

    def post_journal(self, journal_no, description, lines, journal_date=None):
        journal_date = journal_date or date.today().isoformat()
        description = str(description).strip()
        if not description:
            raise ValueError("Journal description is required.")
        self._validate_journal_date(journal_date)

        if not lines or len(lines) < 2:
            raise ValueError("A journal needs at least two lines.")

        normalized = []
        debit_total = 0.0
        credit_total = 0.0

        for line in lines:
            debit = round(float(line.get("debit", 0) or 0), 2)
            credit = round(float(line.get("credit", 0) or 0), 2)
            if debit < 0 or credit < 0:
                raise ValueError("Debit and credit cannot be negative.")
            if debit > 0 and credit > 0:
                raise ValueError("Each line must contain either debit or credit.")
            if debit == 0 and credit == 0:
                raise ValueError("Each journal line must contain an amount.")
            account = self.repo.get_account(int(line["account_id"]))
            if not account or not account["active"]:
                raise ValueError("Journal contains an invalid or inactive account.")
            project_id = line.get("project_id")
            activity_id = line.get("activity_id")
            if activity_id is not None:
                activity = self.repo.get_activity(int(activity_id))
                if not activity:
                    raise ValueError("Journal line contains an invalid activity.")
                if project_id is None or int(project_id) != int(activity["project_id"]):
                    raise ValueError("Activity must belong to the journal line's project.")
            normalized.append((
                int(line["account_id"]),
                str(line.get("description", "")),
                debit,
                credit,
                project_id,
                activity_id
            ))
            debit_total += debit
            credit_total += credit

        debit_total = round(debit_total, 2)
        credit_total = round(credit_total, 2)
        if debit_total <= 0 or credit_total <= 0 or debit_total != credit_total:
            raise ValueError("Journal must balance: total debit must equal total credit.")

        if journal_no is None:
            journal_no = self.repo.next_journal_number("FIN")

        journal_id = self.repo.create_posted_journal(
            journal_no, journal_date, description, normalized
        )
        self.audit_event("JOURNAL_POSTED", "journal", journal_id,
                         f"Journal {journal_id} posted.")
        return journal_id

    def journals(self):
        return self.repo.list_journals()

    def journal_by_number(self, journal_no):
        return self.repo.journal_by_number(journal_no)

    def journal(self, journal_id):
        return self.repo.get_journal(journal_id)

    def trial_balance(self, start_date=None, end_date=None):
        return self.repo.trial_balance(start_date, end_date)

    def account_movements(self, account_id, start_date=None, end_date=None):
        return self.repo.account_movements(account_id, start_date, end_date)

    def _account_totals(self, start_date=None, end_date=None):
        rows = self.repo.trial_balance(start_date, end_date)
        return [{
            "id": r["id"],
            "number": r["number"],
            "name": r["name"],
            "account_type": r["account_type"],
            "debit": float(r["debit"] or 0),
            "credit": float(r["credit"] or 0),
            "balance": round(float(r["debit"] or 0) - float(r["credit"] or 0), 2),
        } for r in rows]

    def income_statement(self, start_date=None, end_date=None):
        rows = self._account_totals(start_date, end_date)
        income = [r for r in rows if r["account_type"] == "Income"]
        expenses = [r for r in rows if r["account_type"] == "Expense"]
        total_income = round(sum(-r["balance"] for r in income), 2)
        total_expenses = round(sum(r["balance"] for r in expenses), 2)
        return {
            "income": income,
            "expenses": expenses,
            "total_income": total_income,
            "total_expenses": total_expenses,
            "result": round(total_income - total_expenses, 2),
            "start_date": start_date,
            "end_date": end_date,
        }

    def balance_sheet(self, as_of_date=None):
        rows = self._account_totals(None, as_of_date)
        assets = [r for r in rows if r["account_type"] == "Asset"]
        liabilities = [r for r in rows if r["account_type"] == "Liability"]
        equity_accounts = [r for r in rows if r["account_type"] == "Equity"]

        total_assets = round(sum(r["balance"] for r in assets), 2)
        total_liabilities = round(sum(-r["balance"] for r in liabilities), 2)
        posted_income = self.income_statement(None, as_of_date)
        current_result = posted_income["result"]
        retained_equity = round(sum(-r["balance"] for r in equity_accounts), 2)
        total_equity = round(retained_equity + current_result, 2)
        liabilities_and_equity = round(total_liabilities + total_equity, 2)

        return {
            "assets": assets,
            "liabilities": liabilities,
            "equity": equity_accounts,
            "current_result": current_result,
            "retained_equity": retained_equity,
            "total_assets": total_assets,
            "total_liabilities": total_liabilities,
            "total_equity": total_equity,
            "liabilities_and_equity": liabilities_and_equity,
            "balanced": round(total_assets - liabilities_and_equity, 2) == 0,
            "as_of_date": as_of_date,
        }

    def general_ledger(self, start_date=None, end_date=None):
        return self.repo.general_ledger(start_date, end_date)

    def project_financials(self, project_id):
        return self.repo.project_financials(project_id)

    def project_budget_vs_actual(self, project_id):
        budget = self.repo.db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",
            (project_id,)
        )
        actual = self.repo.project_actuals(project_id)
        budget_amount = float(budget["budget_amount"]) if budget else 0.0
        actual_amount = round(float(actual["debit"] or 0) - float(actual["credit"] or 0), 2)
        return {
            "budget": budget_amount,
            "actual": actual_amount,
            "variance": round(budget_amount - actual_amount, 2),
            "utilization": (actual_amount / budget_amount * 100) if budget_amount else 0.0,
        }


    def attach_voucher_document(self, journal_id, source_path, description="",
                                storage_dir=None):
        from pathlib import Path
        from datetime import datetime

        source = Path(source_path)
        if not source.is_file():
            raise ValueError("Attachment file not found.")
        journal = self.repo.get_journal(journal_id)
        if not journal:
            raise ValueError("Voucher not found.")

        storage = Path(storage_dir) if storage_dir else Path("data") / "attachments"
        storage.mkdir(parents=True, exist_ok=True)

        digest = __import__("hashlib").sha256(source.read_bytes()).hexdigest()
        safe_name = f"{journal['journal']['journal_no']}_{digest[:12]}_{source.name}"
        target = storage / safe_name

        if not target.exists():
            target.write_bytes(source.read_bytes())

        mime = __import__("mimetypes").guess_type(source.name)[0] or "application/octet-stream"
        uploaded_at = datetime.now().isoformat(timespec="seconds")

        return self.repo.add_voucher_document(
            journal_id,
            source.name,
            str(target),
            mime,
            target.stat().st_size,
            digest,
            description,
            uploaded_at
        )

    def voucher_documents(self, journal_id):
        return self.repo.list_voucher_documents(journal_id)

    def voucher_document(self, document_id):
        return self.repo.get_voucher_document(document_id)

    def remove_voucher_document(self, document_id):
        doc = self.repo.get_voucher_document(document_id)
        if not doc:
            raise ValueError("Attachment not found.")
        from pathlib import Path
        path = Path(doc["stored_name"])
        if path.exists():
            try:
                path.unlink()
            except OSError as exc:
                raise ValueError(
                    "The voucher document could not be removed from storage; "
                    "the database record was not changed."
                ) from exc
        self.repo.delete_voucher_document(document_id)
        return True


    def audit_event(self, event_type, entity_type, entity_id, description,
                    actor=None, metadata=None):
        import json
        from datetime import datetime
        return self.repo.add_audit_event(
            datetime.now().isoformat(timespec="seconds"),
            event_type, entity_type, entity_id, description,
            actor, json.dumps(metadata, ensure_ascii=False) if metadata else None
        )

    def audit_events(self, entity_type=None, entity_id=None,
                     start_date=None, end_date=None):
        return self.repo.list_audit_events(
            entity_type, entity_id, start_date, end_date
        )

    def accounting_control_check(self, start_date=None, end_date=None):
        trial = self.trial_balance(start_date, end_date)
        debit = round(sum(float(r["debit"] or 0) for r in trial), 2)
        credit = round(sum(float(r["credit"] or 0) for r in trial), 2)
        balance = self.balance_sheet(end_date)
        posted = [j for j in self.journals() if j["status"] == "Posted"]
        return {
            "trial_balance_balanced": debit == credit,
            "trial_debit": debit,
            "trial_credit": credit,
            "balance_sheet_balanced": bool(balance["balanced"]),
            "posted_journals": len(posted),
            "audit_events": len(self.audit_events(
                start_date=start_date, end_date=end_date
            )),
            "overall_ok": debit == credit and bool(balance["balanced"])
        }


    def bank_reconciliation(self, bank_account_id=None, status=None):
        return self.repo.list_bank_transactions(bank_account_id, status)

    def import_bank_transactions(self, bank_account_id, rows):
        created = self.repo.create_bank_transactions_atomic(
            bank_account_id, rows
        )
        self.audit_event(
            "BANK_IMPORT", "bank_account", bank_account_id,
            f"Imported {len(created)} bank transaction(s)."
        )
        return created

    def match_bank_transaction(self, transaction_id, journal_id,
                               matched_amount=None):
        tx = self.repo.get_bank_match(transaction_id)
        if tx:
            raise ValueError("Bank transaction is already matched.")
        if matched_amount is None:
            rows = self.repo.list_bank_transactions()
            selected = next((r for r in rows if r["id"] == transaction_id), None)
            if selected is None:
                raise ValueError("Bank transaction not found.")
            matched_amount = selected["amount"]
        self.repo.match_bank_transaction_atomic(
            transaction_id, journal_id, matched_amount
        )
        self.audit_event(
            "BANK_MATCHED", "bank_transaction", transaction_id,
            f"Bank transaction matched to journal {journal_id}."
        )
        return transaction_id

    def unmatch_bank_transaction(self, transaction_id):
        self.repo.unmatch_bank_transaction_atomic(transaction_id)
        self.audit_event(
            "BANK_UNMATCHED", "bank_transaction", transaction_id,
            "Bank transaction unmatched."
        )

    def bank_reconciliation_summary(self, bank_account_id):
        rows = self.repo.list_bank_transactions(bank_account_id)
        total = round(sum(float(r["amount"]) for r in rows), 2)
        matched = [r for r in rows if r["status"] == "Matched"]
        unmatched = [r for r in rows if r["status"] != "Matched"]
        matched_total = round(sum(float(r["amount"]) for r in matched), 2)
        unmatched_total = round(sum(float(r["amount"]) for r in unmatched), 2)
        return {
            "transaction_count": len(rows),
            "matched_count": len(matched),
            "unmatched_count": len(unmatched),
            "total": total,
            "matched_total": matched_total,
            "unmatched_total": unmatched_total,
            "reconciled": len(unmatched) == 0
        }


    def list_bank_accounts(self):
        return self.repo.list_bank_accounts()

    def preview_bank_csv(self, source_path, mapping):
        import csv
        from pathlib import Path
        path = Path(source_path)
        if not path.is_file():
            raise ValueError("CSV file not found.")
        with path.open("r", encoding="utf-8-sig", newline="") as fh:
            sample = fh.read(4096)
            fh.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample)
            except csv.Error:
                dialect = csv.excel
            reader = csv.DictReader(fh, dialect=dialect)
            headers = reader.fieldnames or []
            required = ["date", "amount"]
            for key in required:
                if mapping.get(key) not in headers:
                    raise ValueError(f"Missing mapped column: {key}")
            rows = []
            for raw in reader:
                amount_text = str(raw.get(mapping["amount"], "")).strip()
                amount_text = amount_text.replace(".", "").replace(",", ".") \
                    if amount_text.count(",") == 1 else amount_text.replace(",", "")
                try:
                    amount = float(amount_text)
                except ValueError:
                    continue
                rows.append({
                    "transaction_date": str(raw.get(mapping["date"], "")).strip(),
                    "amount": amount,
                    "description": str(raw.get(mapping.get("description", ""), "") or "").strip()
                        if mapping.get("description") else "",
                    "external_reference": str(raw.get(mapping.get("reference", ""), "") or "").strip()
                        if mapping.get("reference") else ""
                })
            return {"headers": headers, "rows": rows}

    def import_bank_csv(self, bank_account_id, source_path, mapping):
        preview = self.preview_bank_csv(source_path, mapping)
        existing = {
            r["external_reference"]
            for r in self.repo.existing_bank_external_references(bank_account_id)
        }
        new_rows = [
            r for r in preview["rows"]
            if not r["external_reference"] or r["external_reference"] not in existing
        ]
        created = self.import_bank_transactions(bank_account_id, new_rows)
        return {
            "headers": preview["headers"],
            "read": len(preview["rows"]),
            "created": len(created),
            "skipped_duplicates": len(preview["rows"]) - len(new_rows)
        }

    def suggest_bank_matches(self, bank_account_id):
        transactions = self.repo.list_bank_transactions(
            bank_account_id, "Unmatched"
        )
        suggestions = []
        journals = self.repo.list_candidate_journals()
        from datetime import date

        for tx in transactions:
            amount = float(tx["amount"])
            best = None
            for journal in journals:
                # A journal is a candidate when either total debit or total
                # credit equals the bank transaction amount. We deliberately
                # do not compare the journal net, because balanced journals
                # normally have net zero.
                if not (
                    round(abs(float(journal["debit"])), 2) == round(abs(amount), 2)
                    or round(abs(float(journal["credit"])), 2) == round(abs(amount), 2)
                ):
                    continue
                date_delta = abs(
                    date.fromisoformat(tx["transaction_date"])
                    - date.fromisoformat(journal["journal_date"])
                ).days
                score = max(0, 100 - min(date_delta, 30) * 3)
                if best is None or score > best["score"]:
                    best = {
                        "journal_id": journal["id"],
                        "journal_no": journal["journal_no"],
                        "journal_date": journal["journal_date"],
                        "description": journal["description"],
                        "score": score,
                        "reason": "Amount match" if date_delta == 0
                                  else f"Amount match; {date_delta} day(s) date difference"
                    }
            suggestions.append({
                "transaction_id": tx["id"],
                "transaction_date": tx["transaction_date"],
                "amount": amount,
                "description": tx["description"],
                "suggestion": best
            })
        return suggestions


    def list_accounting_periods(self):
        return self.repo.list_accounting_periods()

    def create_accounting_period(self, period_start, period_end, name):
        return self.repo.create_accounting_period(period_start, period_end, name)

    def list_accounting_years(self):
        return self.repo.list_accounting_years()

    def create_accounting_year(self, year, period_start, period_end):
        return self.repo.create_accounting_year(year, period_start, period_end)

    def year_end_control_check(self, year):
        year_row = self.repo.get_accounting_year(year)
        if not year_row:
            raise ValueError(f"Accounting year {year} does not exist.")
        start_date = year_row["period_start"]
        end_date = year_row["period_end"]
        journals = self.repo.posted_journals_between(start_date, end_date)
        unbalanced = self.repo.unbalanced_journals_between(start_date, end_date)
        bank = []
        try:
            bank = self.repo.list_bank_transactions(status="Unmatched")
            bank = [
                x for x in bank
                if start_date <= x["transaction_date"] <= end_date
            ]
        except Exception:
            bank = []
        trial = self.trial_balance(start_date, end_date)
        debit = round(sum(float(r["debit"] or 0) for r in trial), 2)
        credit = round(sum(float(r["credit"] or 0) for r in trial), 2)
        return {
            "year": year,
            "period_start": start_date,
            "period_end": end_date,
            "posted_journals": len(journals),
            "unbalanced_journals": len(unbalanced),
            "unmatched_bank_transactions": len(bank),
            "trial_balance_balanced": debit == credit,
            "debit": debit,
            "credit": credit,
            "ready_to_close": (
                len(unbalanced) == 0 and
                len(bank) == 0 and
                debit == credit
            ),
        }

    def close_period(self, period_id, actor=None):
        period = self.repo.get_accounting_period(period_id)
        if period:
            if period["status"] == "Closed":
                return
            from datetime import datetime
            self.repo.set_period_status(
                period_id, "Closed", datetime.now().isoformat(timespec="seconds"), actor
            )
            self.audit_event(
                "PERIOD_CLOSED", "accounting_period", period_id,
                f"Accounting period {period['name']} closed.", actor
            )
            return

        # Compatibility with the existing fiscal-year/month period model.
        legacy = self.repo.get_period(period_id)
        if not legacy:
            raise ValueError("Period not found.")
        if legacy["status"] == "Closed":
            return
        self.repo.set_period_status(period_id, "Closed")
        self.audit_event(
            "PERIOD_CLOSED", "fiscal_period", period_id,
            "Fiscal period closed.", actor
        )

    def reopen_period(self, period_id, actor=None):
        period = self.repo.get_accounting_period(period_id)
        if not period:
            raise ValueError("Accounting period not found.")
        self.repo.set_period_status(period_id, "Open", None, None)
        self.audit_event(
            "PERIOD_REOPENED", "accounting_period", period_id,
            f"Accounting period {period['name']} reopened.", actor
        )


    def close_year(self, year, actor=None):
        year_row = self.repo.get_accounting_year(year)
        if not year_row:
            raise ValueError(f"Accounting year {year} does not exist.")
        if year_row["status"] == "Closed":
            raise ValueError("Accounting year is already closed.")
        check = self.year_end_control_check(year)
        if not check["ready_to_close"]:
            raise ValueError(
                "Accounting year cannot be closed: controls are not complete."
            )
        from datetime import datetime
        self.repo.set_year_status(
            year, "Closed", datetime.now().isoformat(timespec="seconds"), actor
        )
        self.audit_event(
            "YEAR_CLOSED", "accounting_year", year,
            f"Accounting year {year} closed.", actor
        )


    def financial_dashboard(self, start_date=None, end_date=None):
        rows = self.repo.management_account_movements(start_date, end_date)

        income = []
        expenses = []
        assets = []
        liabilities = []
        equity = []

        for row in rows:
            debit = float(row["debit"] or 0)
            credit = float(row["credit"] or 0)
            balance = debit - credit
            typ = str(row["account_type"] or "").lower()

            if "income" in typ or "revenue" in typ:
                income.append((row, balance))
            elif "expense" in typ or "cost" in typ:
                expenses.append((row, balance))
            elif "asset" in typ:
                assets.append((row, balance))
            elif "liabil" in typ:
                liabilities.append((row, balance))
            elif "equity" in typ or "capital" in typ:
                equity.append((row, balance))

        # Revenue and expense balances are normalized to positive
        # management values.
        revenue_total = round(sum(-b for _, b in income), 2)
        expense_total = round(sum(b for _, b in expenses), 2)
        net_result = round(revenue_total - expense_total, 2)

        return {
            "revenue": revenue_total,
            "expenses": expense_total,
            "net_result": net_result,
            "assets": round(sum(b for _, b in assets), 2),
            "liabilities": round(-sum(b for _, b in liabilities), 2),
            "equity": round(-sum(b for _, b in equity), 2),
            "income_accounts": [
                {"number": r["number"], "name": r["name"], "amount": round(-b,2)}
                for r,b in income if round(-b,2) != 0
            ],
            "expense_accounts": [
                {"number": r["number"], "name": r["name"], "amount": round(b,2)}
                for r,b in expenses if round(b,2) != 0
            ]
        }
