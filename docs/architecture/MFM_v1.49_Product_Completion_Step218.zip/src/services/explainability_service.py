class ExplainabilityService:
    """
    Adds traceable MFM source references to read-only AI findings.
    """

    def __init__(self, context):
        self.ctx = context

    def recommendations_with_sources(self):
        s = self.ctx.management.snapshot()
        recommendations = self.ctx.recommendations.analyze()
        enriched = []

        for r in recommendations:
            sources = []
            if r["area"] == "Bank":
                sources.append({
                    "module": "Bank",
                    "metric": "Unmatched transactions",
                    "value": s["unmatched_bank"],
                    "source": "bank_transactions"
                })
            elif r["area"] == "Membership":
                sources.append({
                    "module": "Membership",
                    "metric": "Open invoices",
                    "value": s["open_invoices"],
                    "source": "membership_invoices"
                })
            elif r["area"] == "Operations":
                sources.append({
                    "module": "Tasks",
                    "metric": "Overdue tasks",
                    "value": s["overdue_tasks"],
                    "source": "tasks"
                })
            elif r["area"] == "Risk":
                sources.append({
                    "module": "Risk",
                    "metric": "High open risks",
                    "value": s["high_risks"],
                    "source": "risks"
                })
            elif r["area"] == "Management":
                sources.append({
                    "module": "Decisions",
                    "metric": "Pending decisions",
                    "value": s["pending_decisions"],
                    "source": "decisions"
                })
            elif r["area"] == "Finance":
                sources.append({
                    "module": "Accounting",
                    "metric": "Current result",
                    "value": s["result"],
                    "source": "accounting"
                })

            item = dict(r)
            item["sources"] = sources
            item["explanation"] = (
                f"Anbefalingen er baseret på {len(sources)} MFM-datakilde(r)."
                if sources else
                "Anbefalingen er baseret på den aktuelle MFM-status."
            )
            enriched.append(item)

        return enriched

    def explain(self, recommendation):
        sources = recommendation.get("sources", [])
        if not sources:
            return recommendation.get("reason", "")
        source_text = "; ".join(
            f"{x['module']} / {x['metric']}: {x['value']}"
            for x in sources
        )
        return f"{recommendation['reason']} Kilde: {source_text}."
