# MFM v1.49 — Product Completion Step 51

## P0 — Atomic membership invoicing and payment posting

Step 51 extends the transactional-integrity work from bank reconciliation to
the membership accounting workflow.

Two concrete gaps were identified:

1. Creating a membership invoice and recording its accounting journal were not
   performed as one repository transaction.
2. Registering a membership payment and changing the invoice status were two
   separate commits.

The payment case was especially important: a payment row could be committed
while the invoice-status update failed, leaving the financial workflow in a
partially applied state.

The product now:
- creates the membership invoice through an explicit transactional repository
  boundary;
- creates the payment and updates invoice status in one transaction;
- rolls back the payment when the status update fails;
- preserves the invoice's previous status on failure.

No accounting rules or invoice-status semantics were changed. The change only
strengthens atomicity around the existing workflow.

A regression test deliberately forces the invoice status update to fail and
verifies that no payment row remains and the invoice remains Open.

This is a genuine product-completion change because membership billing and
payment posting are financial operations and must not leave partial state.
