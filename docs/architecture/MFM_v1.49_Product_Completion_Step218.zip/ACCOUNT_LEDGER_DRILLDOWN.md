# MFM v1.12 — Account Ledger & Transaction Drill-down

Users can select an account, filter movements by date, inspect debit/credit
activity and select a transaction to open the underlying voucher.

The navigation chain is:

    Report -> Account -> Movement -> Voucher -> Voucher Lines

The GUI remains a presentation layer. Journal lookup and voucher retrieval
are delegated through AccountingService/AccountingRepository.
