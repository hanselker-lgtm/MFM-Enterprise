# MFM v1.27 — Project Work & Task Management

v1.27 turns project activities into actionable work. Tasks can be linked to a
project and optionally to one of its activities, with owner, priority,
deadline, description and status.

The implementation validates activity/project ownership and reuses the
existing project and activity model rather than creating a separate task
universe.
