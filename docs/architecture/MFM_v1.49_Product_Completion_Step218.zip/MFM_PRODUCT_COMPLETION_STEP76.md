# MFM v1.49 — Product Completion Step 76

## P1 — Project budget read target integrity

Step 76 closes the read-side counterpart to Step 75.

Step 75 protected the project budget mutation path by requiring the project
to exist before `set_budget()`. The direct `budget(project_id)` read method
still delegated an unknown project ID to the repository without a deterministic
service-level not-found result.

The product now validates the project target before reading its budget:
- existing project -> return budget information normally;
- unknown project -> `ValueError("Project not found.")`.

This keeps the project budget API contract symmetrical for read and write
operations and prevents stale UI references from being silently interpreted
as a valid zero/empty budget.

A regression test verifies the unknown-project read case.
