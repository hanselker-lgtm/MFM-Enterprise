# MFM v1.49 — Product Completion Step 100

## P1 — Activity financial actuals service boundary

Step 100 extends the read-model integrity work into the derived financial
actuals boundary.

Activity actuals are authoritative from posted expense journal lines
allocated to the activity. The repository derives both `actual` and
`variance`; the service previously returned those persistence values without
normalizing them.

The service now exposes a controlled financial read model:

- `actual` is numeric, finite, non-negative, and rounded to two decimals;
- `variance` is numeric, finite, and rounded to two decimals;
- the project boundary remains enforced;
- the service does not fabricate actuals when no posted expense exists;
- no posted expense lines therefore produce `actual=0.0` and the corresponding
  budget variance.

The implementation was tested against the application's actual journal-based
data model rather than inventing a non-existent `transactions` table.
