# MFM v1.49 — Product Completion Step 50

## P0 — Atomic bank matching and unmatching

Step 50 addresses a concrete financial-integrity gap in the accounting
workflow.

The bank matching operation previously performed two independent database
commits:
1. create the `bank_matches` row;
2. update the bank transaction status/journal reference.

The unmatching operation had the same two-step pattern in reverse.

Because the database helper commits each individual `execute`, a failure in
the second operation could leave the system in a partially-applied state.

The product now performs each match/unmatch as a single database transaction.
If any statement fails, the complete operation rolls back.

A regression test deliberately forces the status update to fail and verifies
that:
- no bank match remains;
- the bank transaction remains `Unmatched`;
- no journal reference is left behind.

No accounting rules were changed. The change strengthens transactional
integrity around an existing workflow.

This is a genuine product-completion change because bank reconciliation is a
financial operation and partial application is not an acceptable final state.
