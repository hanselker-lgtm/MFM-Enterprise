# MFM v1.49 — Product Completion Step 49

## P0 — Restore database identity validation

Step 49 addresses a concrete recovery-safety gap in the restore path.

Before this step, MFM verified that a selected restore file was valid SQLite,
but that did not prove that it was an MFM database. Any unrelated SQLite
database that passed `PRAGMA integrity_check` could therefore reach the restore
replacement step.

The product now validates both:
- SQLite integrity; and
- MFM database identity through required core tables.

The same MFM validation is applied to newly-created backups and to the
pre-restore safety copy.

A restore is rejected before replacing the live database when the selected
file is valid SQLite but does not contain the required MFM core structures.

No migration, conversion or data transformation is performed. This is a
validation gate only.

This is a genuine product-completion change because restore is a destructive
operation and "valid SQLite" is not sufficient evidence that the selected file
is a usable MFM recovery point.
