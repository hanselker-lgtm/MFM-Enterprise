# MFM v1.49 — Product Completion — Step 192

## Accounting Period Close / Reopen Lifecycle Boundary

### Boundary

Existing service boundary:

- `close_period(period_id, actor=None)`
- `reopen_period(period_id, actor=None)`

These functions are treated as one lifecycle boundary rather than two artificial steps.

### Verified contract

- accounting period is persisted as `Open` on creation
- closing persists `Closed`, `closed_at`, and `closed_by`
- closing an already closed period is idempotent under the existing contract
- reopening persists `Open`
- reopening clears `closed_at` and `closed_by`
- `PERIOD_CLOSED` audit event is written
- `PERIOD_REOPENED` audit event is written
- existing repository persistence paths are used

### Architecture decision

No product-code change was required.

The existing service/repository split is retained. No new accounting-period engine, state store, or parallel persistence path is introduced.

### Regression

`tests/test_core.py` adds the Step 192 regression covering the complete close/reopen lifecycle.
