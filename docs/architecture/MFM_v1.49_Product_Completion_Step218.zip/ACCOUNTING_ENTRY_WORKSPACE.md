# MFM v1.10 — Accounting Entry Workspace

The accounting UI now provides a user-facing entry workspace.

Workflow:
1. enter posting date;
2. enter description;
3. add journal lines;
4. select account;
5. enter debit or credit;
6. optionally assign a project ID;
7. check totals;
8. post.

The UI delegates validation and posting to AccountingService. It does not
implement a second accounting engine.

A journal must balance before posting and closed periods are rejected by
the service layer.
