# MFM v1.49 — Product Completion Step 108

## P1 — Operational alert service boundary

The architecture review after Step 107 identified the next real boundary in
the operations layer: `operational_alerts()`.

The existing service generated useful operational alerts but exposed a
repository-derived structure without an explicit read-only/application
contract and parsed persisted due dates without a controlled error boundary.

Step 108 establishes a stable operational alert read model:

- an explicit `as_of` date is returned;
- caller-supplied dates are validated;
- persisted task due dates are validated;
- project financial values used for budget-overrun alerts are validated;
- existing alert types and severity rules are preserved;
- alerts remain deterministically ordered;
- critical/high/total counts are derived from the final alert set;
- the result is explicitly read-only.

No new alert category or business rule was introduced.
