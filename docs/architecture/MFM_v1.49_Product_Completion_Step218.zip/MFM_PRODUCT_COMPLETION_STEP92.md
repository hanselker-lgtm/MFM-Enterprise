# MFM v1.49 — Product Completion Step 92

## P1 — Activity parent-project identifier contract

Step 92 hardens the `project_id` compatibility/integrity field of
`update_activity()`.

Step 91 defined `project_id` as an allowed update input used only for
integrity validation. However, non-numeric or null values could still reach
the integer conversion and produce a raw Python conversion error.

The service now exposes a deterministic domain contract:

- `project_id` must be a valid integer-like identifier;
- it must equal the activity's current parent project;
- `None` is rejected;
- another project ID is rejected;
- invalid input returns `ValueError("Invalid activity project id.")`.

The parent project itself is still verified before the update, preserving
the integrity protection introduced in Step 84.

Two regression tests verify invalid and null project identifiers.
