# MFM v1.49 — Product Completion Step 78

## P0/P1 — Project task ownership protection

Step 78 closes the task-level ownership bypass found during the post-Step 77
lifecycle review.

Activities were protected in Step 70 from being reparented between projects.
Project tasks had the same structural risk: the generic task update API still
accepted `project_id` and could therefore move an existing task to another
project without migrating or validating its dependent activity relationship.

The product now protects task ownership at the service boundary:
- an existing task cannot be reparented to another project through
  `update_project_task()`;
- a cross-project `project_id` update is rejected with
  `ValueError("Task project cannot be changed.")`;
- the original project relationship remains unchanged.

Normal task field updates remain available.

A regression test verifies the cross-project reparenting attempt and confirms
that the task remains attached to its original project.

This is a genuine structural-integrity fix because task ownership determines
the project context for activities, control dashboards, execution views and
financial/project reporting.
