# MFM — Phase A.1 — Step 6
## Navigation Contract & Product-Area Mapping

### Objective
Define a tested contract mapping the existing MainWindow workspace commands into the seven product areas without changing the visible navigation yet.

### Product areas
- Home
- Work
- Projects
- Members
- Finance
- Reports
- Administration

### Mapping principle
The contract is additive and descriptive. It does not replace the existing command registry or switch the visible navigation. Every currently registered workspace command is assigned exactly once.

### Current mapping
**Home**
- Dashboard
- Integrated Operations Dashboard
- Integrated Operations Actions
- Risks
- Decisions

**Work**
- Tasks
- Operational Workboard
- Operational Actions
- Operational Alerts
- My Day
- Daily Execution
- Personal Workspace
- Personal Work Actions
- Today View
- Quick Capture
- Work Intake Triage
- Global Search
- Unified Record View
- Navigation & Workspace Integration

**Projects**
- Projects
- Activities & Projects
- Project Financials
- Project Control
- Project Work
- Project Execution
- Project Execution Actions
- Project Progress Control
- Project Control Actions
- Project Control Cockpit

**Members**
- Members
- Membership Billing
- Dunning
- Member Administration

**Finance**
- Accounting

**Reports**
- No currently registered MainWindow workspace command in the supplied baseline.

**Administration**
- No currently registered MainWindow workspace command in the supplied baseline.

### Important boundary
Reports and Administration are intentionally empty in this contract. No placeholder methods were created and no missing functionality was inferred. Existing services or documentation do not by themselves establish a valid MainWindow workspace command.

### Validation
- `compileall`: passed.
- GUI structure tests: **9 passed**.
- Core/accounting test run was started; the available execution window expired before completion. Therefore the historical 71/71 baseline is still not claimed as fully revalidated.

### Architectural result
The product navigation model is now explicit and testable while the current visible navigation remains unchanged. This provides the controlled seam required before implementing the seven-area navigation in a later step.

### Next step
**Phase A.1 — Step 7: Navigation Adapter / Presentation Model**

Introduce a presentation-level navigation model that consumes the product-area contract and exposes labels, commands and permission metadata without changing the existing workspace implementations.
