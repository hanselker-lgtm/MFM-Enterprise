# MFM — Phase A.1 — Step 5
## MainWindow Command Registry

### Objective
Introduce an explicit, testable command registry between `MainWindow` and its existing GUI workspaces without changing database, repository, service, or business logic.

### Changes
- Replaced the large inline navigation command list in `_build()` with `MainWindow.command_registry()`.
- The registry contains the currently implemented MainWindow workspace handlers only.
- Commands are represented as `(label, method_name)` pairs, keeping the registry independent of a live Tk window.
- `_build()` resolves the method through `getattr(self, method_name)` when constructing the button.
- No placeholder/stub handlers were created for legacy commands that are absent from the supplied codebase.
- No product navigation redesign was implemented yet.

### Current registry
The registry contains 34 resolvable workspace commands. All registered method names are real `MainWindow` methods.

### Validation
- Python `compileall`: passed.
- GUI structure and core tests with `PYTHONPATH=.`: **31 passed**.
- Full pytest run was started but exceeded the available execution window; therefore the historical 71/71 baseline is not claimed as fully revalidated in this environment.

### Architecture boundary
This step changes only the GUI navigation construction. Database, repositories, services, application workflows, permissions, and business rules remain untouched.

### Next step
**Phase A.1 — Step 6: Navigation Contract & Product-Area Mapping.**

The next step will define the mapping from the existing workspace commands into the seven product areas:

- Home
- Work
- Projects
- Members
- Finance
- Reports
- Administration

This mapping will be introduced as a contract first. The visible product navigation will not be switched over until the contract is tested and the legacy workspace coverage is accounted for.
