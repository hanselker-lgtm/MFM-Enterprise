# MFM v1.49 — Product Completion Step 166

## P1 — Work Intake Inbox Boundary

Step 166 reviews the existing `work_intake_inbox()` boundary.

The boundary is an existing service-level read-only wrapper around the
repository's `work_intake_inbox()` query. The repository is the authoritative
source for the intake records and applies the actual intake rule:

- task status is `Open`;
- task is unassigned, represented by either `NULL` or an empty/whitespace
  assignment value.

The repository also supplies the existing project/activity context and
ordering for the inbox.

The service boundary does not introduce a new intake engine, assignment
workflow, task source, or mutation path. It exposes the repository result with
existing presentation metadata:

- `items`;
- `count`;
- `needs_triage`;
- `rule`.

### Verification

Regression coverage verifies:

- only open and unassigned tasks enter the inbox;
- assigned tasks are excluded;
- completed tasks are excluded;
- repository ordering is preserved;
- project/activity context is retained;
- `count` and `needs_triage` reflect the actual inbox;
- the service boundary does not mutate task state.

### Product-code decision

**NO PRODUCT CODE CHANGE.**

The existing implementation is architecturally consistent with the established
MFM boundary pattern:

```text
work_intake_inbox()
        ↓
repository.work_intake_inbox()
        ↓
existing task data / query contract
```

No parallel logic or new abstraction was required.

### Test result

Compilation passes with:

```text
PYTHONPATH=. python -m compileall -q src
```

Focused regression coverage for Step 166 and the preceding Step 165 boundary
passes:

```text
4 passed, 125 deselected
```

A full `pytest -q` run was also attempted. The baseline contains pre-existing
unrelated failures in `tests/test_accounting_product.py`; the first failure is
`test_project_financial_tracking`, where an existing test attempts to create a
new activity directly in `Active` status although the current product contract
requires new activities to start in `Planned` status. This is outside Step 166
and no product code was changed to accommodate it.

