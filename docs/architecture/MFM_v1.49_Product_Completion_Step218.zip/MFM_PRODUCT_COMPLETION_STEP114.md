# MFM v1.49 — Product Completion Step 114

## P1 — Project Task Workflow Mutation Boundary

Step 114 hardens the existing `transition_project_task()` service boundary.

The service now:
- normalizes incoming status values;
- validates the allowed existing statuses;
- validates task existence and project context;
- delegates legal transition validation to the existing `_validate_task_transition`;
- delegates the actual mutation to the repository's existing
  `transition_project_task()` method.

No new status or workflow rule is introduced.
