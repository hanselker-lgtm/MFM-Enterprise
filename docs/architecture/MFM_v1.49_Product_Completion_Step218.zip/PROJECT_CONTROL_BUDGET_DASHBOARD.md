# MFM v1.26 — Project Control & Budget Dashboard

v1.26 consolidates project-level budget and posted expense actuals into a
single operational control dashboard.

It provides:
- project budget;
- actual posted project expense;
- remaining/variance;
- utilization percentage;
- activity-level budget and actual;
- explicitly visible unallocated project actuals.

Unallocated actuals are not silently assigned to activities. This keeps the
dashboard financially honest and highlights where further allocation may be
needed.
