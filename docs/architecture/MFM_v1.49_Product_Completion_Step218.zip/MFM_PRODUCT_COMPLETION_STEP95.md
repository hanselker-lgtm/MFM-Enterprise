# MFM v1.49 — Product Completion Step 95

## P1 — Activity read-model service boundary

Step 95 hardens the read side of the activity service.

`activities(project_id)` previously returned the repository's raw database
row objects directly. That leaked persistence-layer record types through the
service boundary and allowed callers to depend on database-specific behavior.

The service now materializes each activity row as an independent `dict`.

The contract is therefore:

- project existence is still required;
- the result is always a list;
- each activity is a plain dictionary;
- an empty project returns an empty list;
- mutating a returned dictionary does not mutate persisted database state.

This is a service-boundary improvement rather than a cosmetic refactor:
callers now receive a stable application-level data representation instead
of a persistence object.
