# MFM v1.49 — Product Completion Step 128

## P1 — Activity Execution View Boundary

Step 128 hardens the existing `activity_execution_view()` read boundary.

The established source structure is preserved:

- the activity is loaded from the existing activities table;
- the activity's project remains the authoritative project context;
- existing project tasks remain the task source;
- task status, priority and title are normalized;
- stored task due dates are validated;
- task_count, open, completed, critical and blocked metrics are exposed;
- the result is explicitly read-only.

No new activity/task relationship, task state, or mutation path is introduced.

The verification test uses the existing `create_activity()` service boundary
rather than assuming project creation automatically creates an activity.
