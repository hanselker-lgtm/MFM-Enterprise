# MFM Phase A.1 — Step 3
## MainWindow Dependency & Callback Audit

### Status
Completed as a structural audit and safe consolidation increment.

### Objective
Validate the result of Step 2 before introducing the new product navigation. The audit focuses on MainWindow method ownership, callback locality, GUI-to-application dependencies, and navigation command targets.

### Safe change implemented
The remaining `_mfm_show_*` methods were already physically inside `MainWindow`, but their legacy `_mfm_` names no longer matched the public commands used by `_build()`.

They have therefore been renamed to their public `show_*` names. No business logic was changed.

This removes the old naming artifact and makes the MainWindow command targets real class methods.

### Callback rule
Local callbacks remain local where they capture screen-specific Tkinter state. This includes login callbacks and screen refresh/action callbacks. They are not converted into artificial MainWindow methods.

### Dependency findings
The MainWindow primarily consumes the existing ApplicationContext services through `self.ctx`, including:

- users
- permissions
- management
- projects
- tasks
- risks
- decisions
- accounting
- members
- errors

The audit did not identify a reason to move these responsibilities into the database, repository, or service layers.

### Navigation finding
All 29 legacy `_mfm_show_*` screens now have matching public MainWindow methods and therefore match their existing `_build()` command targets.

However, the current source also contains navigation commands for the following handlers which are not present in the supplied codebase:

- show_bank
- show_users
- show_system
- show_export
- show_audit
- show_ai
- show_assistant
- show_bank_import_matching
- show_year_end_closing
- show_accounting_audit
- show_voucher_documents
- show_account_ledger
- show_accounting_entry
- show_accounting_reports
- show_forecast

These are NOT being invented or stubbed in Step 3. Their absence must be reconciled against the authoritative v1.49 source before implementation.

### Tests
`tests/test_gui_structure.py`: 5 passed.

`python -m compileall -q src`: passed.

A complete `pytest` run was started. The run reached 48 passing tests before the execution environment timeout. Therefore this increment is NOT marked as a complete 71/71 validation.

### Architectural decision
Do not continue into product-navigation implementation until the missing navigation handlers above have been reconciled with the actual v1.49 baseline. Creating placeholder screens would conceal a baseline mismatch and violate the requirement to preserve existing functionality.

### Next step
Phase A.1 — Step 4: Baseline Reconciliation & MainWindow Navigation Contract.

The next step will compare the supplied codebase against the known v1.49 feature inventory and determine whether the missing handlers are:

1. present elsewhere and need reconnecting,
2. omitted from the supplied ZIP,
3. intentionally deferred legacy features, or
4. already represented by another existing workspace.

Only after that reconciliation should we proceed with further MainWindow consolidation.
