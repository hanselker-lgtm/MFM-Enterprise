# MFM v1.49 — Product Completion Step 158

## P1 — Project Control Dashboard Boundary

Step 158 reviews the existing `project_control_dashboard()` boundary.

The service is a project-scoped read model that composes the established
financial, activity, and forecast data without introducing a new source of
truth.

It validates and normalizes:

- budget;
- actual;
- variance;
- utilization;
- activity budget;
- activity actual;
- unallocated actual;
- optional forecast value;
- optional forecast confidence score.

Forecast metadata is preserved for data points, expected months, missing
months, and clamping information. Activity financial values are normalized
through the same existing money validation rule.

The boundary is explicitly read-only.

No product-code change was necessary. Regression coverage verifies project
scope, numeric financial output, forecast metadata, activity collection, and
read-only state.

No new dashboard engine, financial source, forecast source, workflow state,
or mutation path is introduced.
