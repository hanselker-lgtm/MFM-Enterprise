# MFM v1.49 — Product Completion Step 61

## P1 — Project task input integrity

Step 61 closes a concrete data-integrity gap in project task creation.

The task service validated the task title, activity ownership, and priority,
but accepted arbitrary due-date strings and arbitrary status values.

That meant malformed task data could enter the database. In particular, the
project control exception engine uses ISO date parsing for overdue detection,
so an invalid due date could later cause a project cockpit/control operation
to fail instead of returning reliable project information.

The product now validates task creation at the service boundary:
- due dates must be valid ISO dates when supplied;
- task status must be one of Open, In Progress, Blocked, Completed, or Closed;
- blank due dates are normalized to NULL.

Existing valid task creation behavior is unchanged.

Two regression tests verify rejection of invalid due dates and invalid task
statuses.

This is a genuine product-completion change because project execution data
must be valid at creation time rather than relying on downstream dashboards
to cope with malformed records.
