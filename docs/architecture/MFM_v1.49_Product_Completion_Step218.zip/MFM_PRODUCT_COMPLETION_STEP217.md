# MFM v1.49 — Product Completion — Step 217

## Permission Defaults Boundary

Step 217 protects the existing `PermissionService` role-to-permission contract.

### Existing implementation

`PermissionService.ensure_defaults()` seeds the existing permissions and grants the configured defaults to the existing roles:

- Administrator — all permissions
- Manager — dashboard/projects/members/accounting/bank/reports permissions defined by the existing implementation
- User — dashboard/projects/members/accounting/bank view permissions defined by the existing implementation

`PermissionService.can()` remains the authorization read boundary and `permissions_for()` remains the role permission listing boundary.

### Verification

The regression verifies the existing contract for Administrator, Manager and User, including explicit denial of permissions outside each role's configured scope and denial when no user is supplied.

### Architectural decision

**No product code change.**

No new authorization engine, permission store, role model, or parallel authorization path was introduced. The existing `PermissionService` and repositories remain authoritative.
