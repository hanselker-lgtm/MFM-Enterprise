# MFM v1.49 — Product Completion Step 188

## Bank CSV Import Boundary

Step 188 verifies the existing bank CSV import boundary in the actual implementation.

### Boundary

```python
preview_bank_csv(source_path, mapping)
import_bank_csv(bank_account_id, source_path, mapping)
```

The boundary is a real product capability because it converts an external bank CSV into the existing bank-transaction model while preserving the existing accounting/reconciliation path.

### Actual flow

```text
CSV source
   ↓
preview_bank_csv()
   ↓
column mapping + amount parsing
   ↓
import_bank_csv()
   ↓
existing external-reference duplicate check
   ↓
import_bank_transactions()
   ↓
repository.create_bank_transactions_atomic()
   ↓
bank_transactions
```

### Verified contract

- CSV file existence is validated.
- Required mapped columns (`date`, `amount`) are validated.
- European decimal formatting is parsed by the existing implementation.
- Rows with non-numeric amounts are ignored by the existing preview contract.
- Description and external reference are mapped when supplied.
- Existing external references are skipped on a repeated import.
- New rows are persisted through the existing atomic bank-import repository boundary.
- The import result reports `read`, `created`, and `skipped_duplicates`.
- The operation remains within the existing bank reconciliation architecture.

### Architecture assessment

No new bank-import engine was introduced.

No parallel bank data source was introduced.

No reconciliation rules were changed.

No product code change was necessary.

The existing implementation already provides the required atomic persistence through:

```python
create_bank_transactions_atomic()
```

### Regression

A focused regression was added to `tests/test_core.py` covering:

1. mapped CSV preview;
2. European amount parsing;
3. invalid numeric row handling;
4. first import creating two transactions;
5. repeated import skipping both existing external references;
6. final transaction count and references.

Focused result:

```text
1 passed, 168 deselected
```

Related bank regression:

```text
4 passed, 165 deselected
```

Compile:

```text
python -m compileall -q src tests
PASS
```

## Step 188 Status

```text
STEP 188 — COMPLETE

Boundary:
Bank CSV Import

Product code:
NO CHANGE

Regression:
ADDED

Focused regression:
1 PASSED

Related bank regression:
4 PASSED

Compile:
PASS

Documentation:
ADDED
```

## Design Decision

`import_bank_csv()` is retained as an existing accounting-service boundary rather than introducing a new import service. The implementation already delegates persistence to the existing atomic repository operation and therefore does not justify architectural refactoring.

The next step must again be selected by inspecting the actual implementation. No new step should be created merely because another bank-related function exists.
