# MFM v1.49 — Product Completion Step 89

## P1 — Activity budget creation/update consistency

Step 89 closes a consistency gap left by Step 88.

Step 88 hardened activity budget updates, but creation and update did not use
the same normalization and error contract. Creation could store more than
two decimal places and could expose a raw conversion error for non-numeric
input.

The activity budget contract is now consistent across both creation and
update:

- numeric input is required;
- the value must be finite;
- negative values are rejected;
- values are normalized to two decimal places;
- invalid input returns the domain-level `Invalid activity budget.` error.

The duplicate budget validation in `update_activity()` was also removed so
the service has one clear validation boundary rather than performing the same
check twice.

Two regression tests verify creation normalization and the domain error for
non-numeric input.
