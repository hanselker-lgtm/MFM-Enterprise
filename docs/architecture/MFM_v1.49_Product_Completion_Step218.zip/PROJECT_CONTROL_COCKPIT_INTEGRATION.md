# MFM v1.37 — Project Control Cockpit Integration

v1.37 integrates the existing project execution, progress, financial control,
task and exception layers into one project-level cockpit.

No new duplicate business model is introduced. The cockpit is an aggregation
and navigation surface over the existing data and services.
