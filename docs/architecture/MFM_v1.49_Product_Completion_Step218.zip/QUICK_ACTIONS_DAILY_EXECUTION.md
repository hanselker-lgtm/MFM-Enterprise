# MFM v1.32 — Quick Actions & Daily Execution

v1.32 turns the personal work queue into an execution surface. Existing task
workflow rules remain authoritative while quick actions provide direct
Start, Block, Complete and Reopen operations, plus quick edits for deadline,
priority and responsible person.

No duplicate task or workflow engine is introduced.
