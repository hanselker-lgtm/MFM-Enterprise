# MFM v1.49 — Product Completion Step 62

## P1 — Project task update input integrity

Step 61 hardened project task creation, but review of the same data path found
that updates still bypassed those new validations.

`update_project_task()` previously validated priority only. A caller could
therefore create a valid task and subsequently replace its due date or status
with malformed values.

That created a validation asymmetry:
- create path: validated;
- update path: partially validated.

The product now applies the same service-boundary validation to task updates:
- status must be Open, In Progress, Blocked, Completed, or Closed;
- due dates must be valid ISO dates when supplied;
- blank due dates are normalized to NULL;
- existing priority validation remains unchanged.

This keeps project task records valid regardless of whether they were created
or modified.

A regression test verifies rejection of invalid due dates and statuses during
update.

This is a genuine product-completion change because input integrity must hold
for the entire task lifecycle, not only at initial creation.
