# MFM v1.41 — Global Search & Contextual Navigation

v1.41 adds a global search surface across projects, activities, tasks and
members. Search results carry their entity type and intended context/action,
so the UI can route users toward the appropriate workspace.

The feature is deliberately lightweight and builds on existing repository,
service and workspace-context capabilities.
