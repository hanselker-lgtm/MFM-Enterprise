# MFM Phase A.1 — Step 7
## Navigation Adapter / Presentation Model

### Purpose
Introduce a testable presentation model between the existing MainWindow command registry and the future product navigation.

### Changes
- Added immutable `NavigationItem` presentation model.
- Added `MainWindow.navigation_model()`.
- Added `MainWindow.navigation_items(area=None)`.
- Added `MainWindow.navigation_allowed(item)`.
- The model is derived from the existing command registry and product-area contract.
- No Tk widgets are created by the model.
- No database, repository, service, workflow, or business-rule changes.
- No new permission rules were invented. Only the existing `projects.view` permission is represented explicitly because it is already enforced by the current `show_projects()` implementation. Other workspace methods retain their existing authorization behavior.
- Reports and Administration remain empty because no resolvable MainWindow workspace commands exist for those areas in the supplied baseline.

### Validation
- `python -m compileall -q src tests` — passed
- `pytest -q tests/test_gui_structure.py` — **9 passed**

### Not yet changed
- Visible product navigation
- MainWindow `_build()` navigation presentation
- Permission architecture migration
- Database/services/repositories

### Next step
Phase A.1 — Step 8: Product Navigation Rendering Adapter. This will consume the presentation model without changing existing workspace implementations.
