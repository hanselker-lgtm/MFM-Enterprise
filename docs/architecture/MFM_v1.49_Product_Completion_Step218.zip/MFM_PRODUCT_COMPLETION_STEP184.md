# MFM v1.49 — Product Completion — Step 184

## Dunning Communication Boundary

### Boundary

`MemberService.dunning_message()` / `MemberService.record_dunning()`

### Why this is a real boundary

Step 183 verified the read-only `dunning_preview()` boundary. Step 184 verifies the next meaningful transition: converting an approved dunning candidate into a prepared communication and recording that communication in the existing communication log.

This is intentionally treated as one functional boundary rather than three artificial steps for message formatting, recording, and history.

### Existing flow

```text
Dunning preview
    ↓
dunning_message(level)
    ↓
record_dunning()
    ↓
existing repository.add_communication()
    ↓
member_communications
    ↓
communication_history()
```

### Contract verified

- Level 1, 2, and 3 message templates are generated from the existing dunning row.
- `record_dunning()` uses the existing communication repository path.
- Member and invoice references are preserved.
- Communication channel and dunning level are persisted.
- Explicit timestamp and status are preserved.
- The resulting record is retrievable through the existing `communication_history()` boundary.
- The operation records a prepared communication; it does not send email automatically.

### Architecture decision

**No product code change.**

The existing implementation already follows the established architecture and reuses the repository as the authoritative persistence path. No new communication engine, mail transport, or parallel history store is introduced.

### Regression

Added focused regression coverage in `tests/test_core.py` for message levels, recording, persistence, and history retrieval.

Focused test result:

```text
1 passed
```

Compile:

```text
python -m compileall -q src tests
PASS
```
