# MFM v1.49 — Product Completion Step 97

## P1 — Activity status read-model integrity

Step 97 extends the service read-model boundary with the same status contract
already enforced during activity creation and update.

Creation and update reject unsupported activity statuses, but the read model
previously returned persisted status values without verifying that they still
belonged to the supported domain set.

The read service now validates every stored status against:

- Planned
- Active
- On Hold
- Completed
- Cancelled

If persisted data contains an unsupported value, the service fails explicitly
with `ValueError("Invalid stored activity status.")` rather than silently
propagating corrupted domain data to callers.

The test suite verifies both rejection of an invalid stored status and
acceptance of every supported status.
