# MFM v1.49 — Product Completion Step 87

## P1 — Activity creation lifecycle integrity

Step 87 closes the creation-side lifecycle gap exposed by Steps 85–86.

Steps 85 and 86 protected activity status values and transitions after an
activity existed. The creation API, however, accepted a caller-supplied
status and could therefore create an activity directly in `Active`,
`Completed`, or another valid lifecycle state.

The product now establishes a clear creation invariant:

- a new activity must use a recognized activity status;
- every new activity must start in `Planned`;
- lifecycle progression must happen through subsequent validated updates.

Thus creation and mutation now form one coherent lifecycle contract:

Create -> Planned -> validated workflow transitions.

Two regression tests verify rejection of a non-Planned initial status and
rejection of an unknown status, with no activity created in either case.
