# MFM v1.24 — Project Financial Tracking

v1.24 connects project budgets to posted accounting expense lines.

It provides:
- project budget vs actual;
- variance and utilization;
- project expense-line drilldown;
- activity budget overview;
- a project financial workspace.

Actuals are deliberately based on posted expense-account journal lines
tagged with the project. Funding/bank counter-lines are not double-counted.

Activity-level actual allocation is not yet claimed: activities currently show
their budgets while actuals remain project-level. This preserves accounting
correctness until journal lines can be assigned to a specific activity.
