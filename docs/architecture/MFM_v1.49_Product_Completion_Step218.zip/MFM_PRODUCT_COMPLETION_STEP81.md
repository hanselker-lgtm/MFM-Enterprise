# MFM v1.49 — Product Completion Step 81

## P1 — Task transition parent-project integrity

Step 81 closes a lifecycle-integrity gap in task status transitions.

The task transition service already verified that the task existed and that
the requested status was valid. It did not, however, verify that the task's
parent project still existed before performing the status mutation.

The product now requires the task's parent project to exist before
`transition_project_task()` can mutate task status.

If the parent project is missing:
- the operation fails with `ValueError("Project not found.")`;
- no task status mutation occurs.

A regression test creates a valid project/task, removes the parent project at
database level to simulate a stale/orphaned record, and verifies that the
transition is rejected and the task remains `Open`.

This is a defensive integrity safeguard for stale/orphaned data.
