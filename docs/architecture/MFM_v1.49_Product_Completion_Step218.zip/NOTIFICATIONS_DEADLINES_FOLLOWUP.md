# MFM v1.30 — Notifications, Deadlines & Operational Follow-up

v1.30 derives actionable operational alerts from the existing project/task
and accounting data. Alerts cover overdue tasks, approaching deadlines,
blocked tasks, missing owners, and project budget overruns.

The implementation is intentionally a follow-up layer, not a new message
queue or approval bureaucracy. It surfaces conditions that already exist in
MFM and lets the user act on them from the operational area.
