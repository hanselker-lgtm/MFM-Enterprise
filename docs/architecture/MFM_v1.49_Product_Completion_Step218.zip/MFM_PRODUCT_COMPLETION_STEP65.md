# MFM v1.49 — Product Completion Step 65

## P1 — Task assignee normalization

Step 65 closes a small but real project-data integrity inconsistency in task
assignment.

The task service already required a non-blank assignee in the explicit
quick-action assignment path, but normal task creation and update paths passed
the supplied assignee string through without normalization.

That could produce logically identical assignees as different stored values,
for example:
- `Alice`
- ` Alice `
- `Alice  `

This affects personal work queues, assignment filters, workload counts and
exception ownership comparisons.

The product now trims task assignee values at the service boundary for both
creation and normal update. Blank values remain allowed where the workflow
intentionally supports unassigned tasks.

Existing valid assignment behavior is unchanged.

Two regression tests verify normalization on create and update.

This is a genuine product-completion change because assignment identity must be
stable across all task mutation paths.
