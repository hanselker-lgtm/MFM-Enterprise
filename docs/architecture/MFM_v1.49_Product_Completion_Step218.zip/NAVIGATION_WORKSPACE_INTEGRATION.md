# MFM v1.40 — Navigation & Workspace Integration

v1.40 introduces a lightweight workspace context and navigation surface.
The active project context can be opened, retained and returned from, while
project/task/activity context can be resolved through the existing service
layer.

The feature is intentionally small: it does not introduce a new router,
duplicate data model, or separate navigation database.
