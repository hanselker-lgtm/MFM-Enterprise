# MFM v1.49 — Product Completion Step 54

## P1 — Voucher document deletion safety

Step 54 addresses a concrete consistency gap in accounting document
attachments.

The existing delete flow removed the database record first and the physical
file second. If filesystem deletion failed, the voucher attachment metadata
was already gone while the physical document remained in storage.

The product now deletes the physical file first and only removes the database
record after the filesystem operation succeeds.

If the file cannot be removed:
- the database record remains;
- the physical file remains;
- the user receives a clear error.

This avoids silent metadata loss and preserves a recoverable attachment state.

No document storage format or attachment metadata model was changed.

A regression test forces the filesystem delete to fail and verifies that the
database record and physical file both remain.

This is a genuine product-completion change because accounting vouchers are
supporting financial documentation and their metadata must not disappear when
the underlying document cannot be removed.
