# MFM v1.11 — Journals & Voucher Viewer

This workspace provides a read-only journal browser and voucher detail view.

The user can:
- browse posted journals;
- see voucher number, date, description and status;
- select a voucher;
- inspect every journal line;
- see account number/name;
- see line description;
- see debit and credit;
- see linked project name where available;
- verify that the selected voucher balances.

The viewer does not alter accounting data. It uses AccountingService as its
single source of truth.
