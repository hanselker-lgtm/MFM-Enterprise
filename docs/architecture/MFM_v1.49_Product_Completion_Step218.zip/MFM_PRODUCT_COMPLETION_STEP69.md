# MFM v1.49 — Product Completion Step 69

## P1 — Activity lifecycle integrity

Step 69 closes two gaps in activity updates.

Activity creation already requires a valid project, while the update path
previously delegated directly to the repository with only a budget check.
That allowed two undesirable outcomes:
- an existing activity could be renamed to whitespace-only content;
- a stale/unknown activity ID could be sent to the update API without a clear
  product-level not-found result.

The product now validates activity updates at the service boundary:
- the target activity must exist;
- activity names are trimmed and must remain non-blank;
- descriptions are normalized by trimming;
- existing budget validation remains unchanged.

A failed validation occurs before repository mutation, so the existing activity
record remains intact.

Two regression tests verify blank-name rejection and unknown-activity handling.

This is a genuine product-completion change because activity records are
structural project execution data and must remain valid throughout their
lifecycle.
