# MFM v1.49 — Product Completion Step 67

## P1 — Project task title integrity on update

Step 67 closes a lifecycle validation gap in project task editing.

Task creation already required a non-blank title, but the normal update path
did not apply the same rule. An existing valid task could therefore be renamed
to whitespace-only content.

That would create an unusable task record and make project execution,
workboards and control views harder to interpret.

The product now applies the same title contract to updates:
- title is converted to text and trimmed;
- blank/whitespace-only titles are rejected;
- description values are normalized by trimming;
- failed validation occurs before repository mutation.

A regression test verifies that a whitespace-only title is rejected and that
the original title remains unchanged.

This is a genuine product-completion change because task validity must remain
true throughout the full record lifecycle, not only at creation.
