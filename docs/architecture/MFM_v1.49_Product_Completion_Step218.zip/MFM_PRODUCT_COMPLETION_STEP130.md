# MFM v1.49 — Product Completion Step 130

## P1 — Project Progress Control Boundary

Step 130 hardens the existing `project_progress_control()` read boundary.

The service continues to use the existing repository source and exposes:

- project identifier;
- task progress;
- project budget, actual, variance and utilization;
- financial status;
- execution status;
- per-activity task counts and progress;
- per-activity financial control status.

Financial values are validated as finite, non-negative numbers before
derived metrics are calculated.

The boundary remains explicitly read-only. No new workflow or mutation path
is introduced.

During verification, the existing repository payload was found not to include
`project_id`; the service now explicitly preserves the requested project
context in the read model rather than changing the repository contract.
