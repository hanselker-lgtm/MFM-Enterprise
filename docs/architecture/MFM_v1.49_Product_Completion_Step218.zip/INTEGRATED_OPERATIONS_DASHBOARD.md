# MFM v1.38 — Integrated Operations Dashboard

v1.38 introduces an organization-level operations dashboard. It aggregates
existing project-control, task, exception and membership summaries into one
operational overview.

The dashboard is intentionally an aggregation surface. It does not create a
second project, accounting, task, or membership data model.
