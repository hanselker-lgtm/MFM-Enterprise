# MFM v1.39 — Integrated Operations Actions

v1.39 makes the organization-level operations view actionable. Existing
projects, exceptions and tasks can be opened and acted on from one integrated
surface.

The action resolver delegates to the existing project/task/exception services;
it does not introduce a parallel action or issue-management model.
