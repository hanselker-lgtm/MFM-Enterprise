# MFM v1.49 Product Completion — Step 208

## Boundary
Chart of Accounts Listing

## Existing implementation

`AccountingService.accounts(include_inactive=False)` delegates directly to the existing
`AccountingRepository.list_accounts(include_inactive=...)` boundary.

The repository is authoritative for account listing and applies:

- active-only filtering by default
- optional inclusion of inactive accounts
- deterministic ordering by account number

## Verification

The regression verifies:

- default listing contains active accounts only
- account numbers are returned in ascending order
- inactive accounts can be explicitly included
- inactive account state is preserved
- no parallel account source or listing logic is introduced

## Product code

**NO PRODUCT CODE CHANGE**

The existing implementation already satisfies the contract.

## Test

`test_step208_chart_of_accounts_listing_boundary`

Result: PASS

## Architectural conclusion

This is a read-only chart-of-accounts boundary. It reuses the existing account repository and
introduces no new accounting engine, cache, store, or persistence path.
