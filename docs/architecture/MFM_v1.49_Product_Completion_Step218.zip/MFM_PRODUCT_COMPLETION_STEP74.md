# MFM v1.49 — Product Completion Step 74

## P1 — Budget numeric integrity + Step 73 artifact continuity repair

Step 74 addresses two concrete completion concerns.

### 1. Budget numeric integrity

Project and activity budgets are business values used for variance,
utilization and over-budget control. Python's `float()` accepts non-finite
values such as NaN and infinity, but those values are not valid business
budgets and can contaminate financial calculations.

The product now rejects non-finite budgets at the service boundary for:
- project creation;
- project budget updates;
- activity creation;
- activity updates.

The error is `ValueError("Budget must be a finite number.")` for projects and
`ValueError("Activity budget must be a finite number.")` for activities.
Negative finite values continue to use the existing negative-budget errors.

### 2. Step 73 continuity repair

During Step 74 verification, the distributed Step 73 archive was found not to
contain the Step 73 project-status changes/tests that had been reported as
complete. This was an artifact-packaging continuity defect, not a reason to
silently proceed.

Step 74 therefore restores the Step 73 project-status contract in the
delivered code and includes its regression tests, so the new archive is
cumulative and contains the actual completed state.

This keeps the MFM v1.49 completion chain internally consistent rather than
building further changes on a missing intermediate change.
