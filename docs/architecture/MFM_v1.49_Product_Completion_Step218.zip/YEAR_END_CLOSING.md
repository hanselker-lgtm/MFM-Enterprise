# MFM v1.17 — Accounting Year-End & Period Closing

This version adds practical accounting-period and year-end controls.

Core workflow:
1. define accounting year/period;
2. run closing controls;
3. identify unbalanced journals and unmatched bank transactions;
4. verify trial balance;
5. close the year;
6. record the closure in the audit trail;
7. allow controlled reopening of periods.

The first implementation deliberately does not invent a complex automatic
retained-earnings closing entry. That belongs in a later year-end accounting
feature once the chart-of-accounts policy is explicitly defined.
