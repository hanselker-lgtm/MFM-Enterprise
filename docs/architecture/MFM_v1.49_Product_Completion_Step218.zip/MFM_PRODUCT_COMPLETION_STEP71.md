# MFM v1.49 — Product Completion Step 71

## P1 — Activity date integrity

Step 71 closes a lifecycle validation gap for activity dates.

Activity dates are persisted as text in the ISO `YYYY-MM-DD` form used by the
project/activity reporting and ordering queries. Before Step 71, the service
layer did not validate the supplied date on either activity creation or
activity update.

The product now:
- validates non-empty activity dates with `date.fromisoformat()`;
- normalizes valid dates to canonical ISO format;
- rejects invalid dates with `ValueError("Invalid activity date.")`;
- preserves an existing valid date when an update is rejected.

Blank/None dates remain supported as before.

Two regression tests cover invalid creation and invalid update.

This is a genuine product-completion change because activity dates are
business data used for ordering, reporting and execution views and therefore
must have a stable format throughout the record lifecycle.
