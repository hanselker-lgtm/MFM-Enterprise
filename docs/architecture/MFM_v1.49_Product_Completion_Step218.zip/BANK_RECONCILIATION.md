# MFM v1.15 — Bank Reconciliation

The accounting module now supports an operational bank reconciliation workflow:

1. import bank transactions;
2. list unmatched/matched transactions;
3. match a bank transaction to a journal;
4. unmatch a transaction;
5. calculate reconciliation totals and status;
6. write audit events for import/match/unmatch.

The workflow deliberately stays practical: it supports reconciliation of
transactions without introducing a new governance layer.
