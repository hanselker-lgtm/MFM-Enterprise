# MFM v1.49 — Product Completion Step 84

## P1 — Activity mutation parent-project integrity

Step 84 extends the parent-project integrity contract from task mutations to
the activity update path.

`create_activity()` already verifies that its project exists, and
`update_activity()` already prevents changing an activity's project. However,
an existing activity could still reach the update repository path without
first verifying that its current parent project still existed.

The service now validates the activity's parent project before any activity
field mutation.

If the parent project is missing:
- the operation fails with `ValueError("Project not found.")`;
- the activity remains unchanged.

A regression test simulates an orphaned activity using a controlled database
fixture and confirms that an update is rejected and no field mutation occurs.
