# MFM Phase A.1 — Step 11
## Regression Baseline Execution & Migration Readiness Review

### Objective
Validate the implemented product-navigation increment against the existing regression baseline before treating the migration as complete.

### Implemented product change
The current MainWindow now presents the seven product areas through the existing product-navigation contract:

- Home
- Work
- Projects
- Members
- Finance
- Reports
- Administration

The implementation reuses the existing MainWindow workspace handlers. No database, repository, service, business-rule, permission-definition, or workspace implementation was changed for this navigation increment.

### Validation executed
- `python -m pytest -q tests/test_gui_structure.py` — **17 passed**
- `python -m pytest -q tests/test_navigation_migration_gate.py tests/test_product_navigation_ui.py` — **22 passed**
- `python -m pytest -q tests/test_core.py` — **25 passed**

The accounting-product test file contains 46 tests. Running the complete file in one pytest process did not finish within the available execution window. The run consistently progressed through the earlier tests and then stalled; individual tests executed successfully. This is recorded as an execution-environment/regression-run limitation, not as a product failure.

### Important finding
The current code already contains the visible product-navigation integration in `_build()`. Therefore the older Step 10 document statement that the visible migration must still remain disabled is stale relative to the current code and must not be used as the source of truth.

The source code and passing GUI tests are the current implementation evidence.

### Decision
**Product navigation implementation: ACCEPTED for the current increment.**

**Full regression baseline: NOT YET CLOSED.**

No further navigation code should be added merely to advance Phase A.1. The next work item is only justified if it addresses the regression-run limitation or another concrete product problem.

### Scope protection
Do not change:

- database
- repositories
- services
- business rules
- permissions
- existing workspace implementations

unless a separate concrete defect is identified.

# MFM Phase A.1 — Step 12
## Fix UI/Service Inbox Consistency

### Concrete product defect
The Work Intake Triage GUI queried all tasks with `status='Open'`, while the authoritative service/repository Inbox rule is `Open + unassigned`.

### Change
The GUI now obtains intake rows through `self.ctx.projects.work_intake_inbox()["items"]` instead of reimplementing the SQL query in the GUI.

### Result
The GUI and service now use the same Inbox definition. Assigned open tasks no longer appear in Work Intake Triage.

### Validation
- `python -m compileall -q src` — passed
- GUI/navigation tests — 22 passed
- Work-intake regression tests — 3 passed, 43 deselected

### Scope protection
No database, repository, business-rule, permission, or workflow model changes were made.
