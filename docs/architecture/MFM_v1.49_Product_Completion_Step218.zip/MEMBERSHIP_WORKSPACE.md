# MFM v1.19 — Members & Memberships

The association layer is now connected to the accounting core.

The workspace supports:
- member records;
- membership types and annual fees;
- active memberships;
- membership invoices;
- payment registration;
- invoice status including overdue;
- member search;
- member-level invoice history;
- management summary of members and outstanding membership revenue.

Membership invoicing posts a receivable/income journal when the standard
accounts exist, and payment registration posts bank/receivable accounting.
