# MFM v1.49 — Product Completion Step 17

## Permission Consistency Across Canonical Product Areas

### Problem

The product navigation had explicit permission codes for selected sensitive
Administration and dashboard commands, but several existing Members, Finance,
and Project entry points did not carry the corresponding permissions. Their
underlying domain permissions already existed (`members.view`,
`accounting.view`, `projects.view`), but the GUI navigation model and direct
entry methods did not consistently enforce them.

This created an inconsistent authorization boundary: the permission model
existed, but some canonical GUI entry points relied only on their parent
navigation state.

### Change

The existing permissions are now reused consistently:

- Members → `members.view`
- Membership Billing → `members.view`
- Dunning → `members.view`
- Member Administration → `members.view`
- Accounting → `accounting.view`
- Chart of Accounts → `accounting.view`
- Journals → `accounting.view`
- Trial Balance → `accounting.view`
- Project Finance and project-control/execution workspaces → `projects.view`

The affected `MainWindow` entry methods now also perform the same permission
check before rendering their content.

No new permission codes, roles, database tables, repositories or services were
introduced.

### Validation

- Python `compileall`: PASS
- `tests/test_gui_structure.py`: **21 passed**
- Full/core tests were not claimed as passed because the supplied package's
  test environment could not resolve `src.database` during collection in the
  current execution environment.

### Product effect

The authorization boundary is now consistent between:

```text
Permission model
      ↓
Product navigation
      ↓
Workspace entry point
      ↓
Existing domain function
```

This closes a concrete Product Gap Review item: **validating permissions
consistently across the UI**.
