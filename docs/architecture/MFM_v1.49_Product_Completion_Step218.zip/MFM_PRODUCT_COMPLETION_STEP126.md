# MFM v1.49 — Product Completion Step 126

## P1 — Quick Action Mutation Boundary

Step 126 hardens the existing `quick_action()` mutation boundary.

The existing action contract is preserved:

- `start` → In Progress
- `block` → Blocked
- `complete` → Completed
- `reopen` → Open
- `deadline` → validated ISO date
- `priority` → Low / Normal / High / Critical
- `assign` → non-empty responsible person

The service validates the action before dispatching it and continues to use
the established task transition and repository mutation methods.

No new action type or workflow state is introduced.
