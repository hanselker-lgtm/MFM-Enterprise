# MFM Phase A.1 — Step 10
## MainWindow Navigation Migration Gate

### Objective
Establish an explicit, testable gate before replacing the known v1.49 visible navigation with the seven product areas.

### Gate conditions
The visible navigation migration is permitted only when all of the following are true:

1. The MainWindow command registry is explicit and resolvable.
2. Every current registry command is mapped exactly once to a product area.
3. The seven product areas exist in the navigation contract.
4. Reports and Administration remain explicitly empty until real existing handlers are identified or implemented through a separate approved product-gap decision.
5. The navigation presentation model is resolvable without constructing Tk widgets.
6. The rendering adapter consumes the presentation model.
7. The controlled preview path works without activating the new navigation.
8. The existing `_build()` still uses the v1.49 navigation while this gate is being evaluated.
9. No database, repository, service, business-rule, permission-definition, or workspace implementation changes are required for the migration itself.
10. The full regression baseline is successfully executed before the visible navigation switch is committed.

### Current gate status
Conditions 1–9 are structurally satisfied by Steps 1–9 and are covered by the GUI structure tests.

Condition 10 is **OPEN**. The available execution environment has repeatedly timed out before completing the full 71-test suite, so the 71/71 baseline is not declared revalidated.

### Decision
**DO NOT replace the visible MainWindow navigation yet.**

Step 10 therefore introduces no functional navigation change. It creates the migration gate so the eventual switch is a controlled, reversible increment rather than another large refactor.

### Next step
Phase A.1 — Step 11: Regression Baseline Execution & Migration Readiness Review.
