# MFM v1.49 — Product Completion Step 98

## P1 — Activity date read-model integrity

Step 98 extends the activity read-model integrity contract established in Steps 95–97.

Creation and update already validate activity dates, but persisted legacy/imported data could still contain an invalid date and be returned directly by the read model. The service now validates stored activity dates when materializing the application read model.

Rules:
- `None` or empty stored dates become `None` in the read model;
- non-empty values must be valid ISO dates;
- valid dates are normalized to ISO format;
- invalid persisted dates fail explicitly with `ValueError("Invalid stored activity date.")`;
- read normalization does not modify persistence.

Two regression tests cover invalid and empty persisted dates.
