# MFM v1.49 — Product Completion Step 59

## P0 — Restore replacement rollback safety

Step 59 closes a critical recovery-path integrity gap.

The restore flow already validated the source backup and created a safety copy
of the live database. However, if replacement of the live database failed
during `copy2()`, the existing exception handler was not entered because the
copy operation happened before the `try` block.

A failed replacement could therefore leave a partial or invalid live database.

The restore operation now treats both replacement and validation as one
protected operation:
- create and validate the safety copy;
- copy the verified backup;
- validate SQLite integrity;
- validate MFM database structure;
- if any replacement/validation step fails, restore the safety copy and
  validate the restored live database;
- remove an incomplete safety copy if creation of the safety copy itself fails.

A regression test simulates a partial restore write followed by an OS error and
verifies that the original live database is restored.

This is a genuine product-completion change because database restore is a
recovery operation and must never leave the live application database in a
partially replaced state.
