# MFM v1.28 — Operational Workboard

v1.28 introduces a daily operational workboard that consolidates open tasks,
priority, deadlines and active project financial status.

It is deliberately a read-oriented control surface over the existing project,
activity, task and accounting models rather than a new workflow system.
