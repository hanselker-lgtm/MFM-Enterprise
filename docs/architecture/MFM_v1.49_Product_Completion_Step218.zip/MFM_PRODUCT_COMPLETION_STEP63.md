# MFM v1.49 — Product Completion Step 63

## P1 — Work-item triage date validation

Step 63 closes a remaining project-task validation bypass.

Steps 61 and 62 hardened task creation and normal task updates, but the
`triage_work_item()` path wrote directly to the tasks table and validated
status/priority without validating the due date.

This created a lifecycle inconsistency:
- create: due date validated;
- standard update: due date validated;
- triage update: due date could bypass validation.

The product now validates triage due dates using the same ISO-date rule as the
other task mutation paths. Blank dates remain normalized to NULL.

A regression test verifies that an invalid triage due date is rejected.

This is a genuine product-completion change because work-intake/triage is an
active task mutation path and must obey the same data-integrity contract as
ordinary task editing.
