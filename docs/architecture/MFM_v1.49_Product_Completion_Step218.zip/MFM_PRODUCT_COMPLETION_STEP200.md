# MFM v1.49 — Product Completion Step 200

## Chart of Accounts Creation Boundary

Step 200 verifies the existing `AccountingService.create_account()` boundary.

This is a real product boundary because it is the service-level mutation path
for adding a user-defined account to the existing chart of accounts.

## Existing implementation

```text
AccountingService.create_account()
        ↓
input normalization
        ↓
account number/name validation
        ↓
account type validation
        ↓
AccountingRepository.create_account()
        ↓
accounts
```

The service trims the account number and name and validates the account type
against the existing supported set:

```text
Asset
Liability
Equity
Income
Expense
```

Persistence remains in the existing accounting repository. No parallel chart
of accounts or new accounting master-data store is introduced.

## Contract verified

Regression coverage verifies:

- surrounding whitespace is normalized;
- the supplied account is persisted;
- account number is preserved after normalization;
- account name is preserved after normalization;
- account type is persisted;
- newly created accounts are active;
- missing account number/name is rejected;
- unsupported account type is rejected.

## Architecture decision

**NO PRODUCT CODE CHANGE.**

The existing implementation already provides the required boundary and
validation. No new account engine, master-data abstraction, or duplicate
persistence path is justified.

## Regression

Focused regression:

```text
1 passed
```

Compile:

```text
python -m compileall -q src tests
PASS
```
