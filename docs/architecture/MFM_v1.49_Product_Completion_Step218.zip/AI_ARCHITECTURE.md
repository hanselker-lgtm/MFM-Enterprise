# MFM AI Architecture — v2.5

## Trend and forecasting

v2.5 introduces a transparent, read-only forecast of monthly accounting result.

Current method:
- aggregate posted accounting data by month;
- calculate monthly income, expenses and result;
- fit a simple linear trend to the historical result;
- produce a short forecast and a simple residual-based uncertainty band.

The forecast is explicitly advisory. It does not model external factors,
structural breaks, seasonality or causal relationships. Forecast quality
depends on the quantity and quality of historical MFM data.

This design follows standard forecasting practice: historical data should
be examined for trend/seasonality, models should be evaluated, and forecasts
should communicate uncertainty rather than presenting a future value as fact.
