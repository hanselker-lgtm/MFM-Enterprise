# MFM v1.20 — Membership Billing & Payment Management

This version adds the operational annual billing cycle:
- billing preview by year;
- detection of memberships already invoiced in the year;
- batch creation of membership invoices;
- duplicate-safe reruns;
- payment-status summary;
- outstanding/overdue invoice list.

The batch process deliberately uses the existing invoice service, so each
created invoice remains connected to the accounting journal and audit flow.
