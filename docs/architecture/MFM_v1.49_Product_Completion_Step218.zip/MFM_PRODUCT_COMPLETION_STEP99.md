# MFM v1.49 — Product Completion Step 99

## P1 — Activity budget read-model integrity

Step 99 completes the budget integrity contract on the activity read side.

Step 96 normalized persisted budget values to a two-decimal float, but a
malformed stored value could still raise a raw conversion exception or a
negative legacy value could pass through the read model.

The read model now explicitly validates persisted budget data before exposing
it:

- missing/null/zero-like values become `0.0`;
- the value must be numeric;
- the value must be finite;
- the value cannot be negative;
- the exposed value is rounded to two decimal places.

Invalid persisted data raises the domain-level
`ValueError("Invalid stored activity budget.")`.

This completes the parallel read-side integrity checks for activity budget,
status, and date.
