# MFM v1.49 — Product Completion Step 79

## P1 — Execution and activity target integrity

Step 79 closes the remaining target-validation gaps in project execution
views.

The project service already had strong target guards for financial and control
reads, but several execution-facing methods still delegated IDs directly to
the repository:
- project activity listing;
- project execution view;
- activity execution view;
- project progress control;
- project control exceptions.

The product now:
- requires an existing project for all five project-scoped reads;
- requires the selected activity to belong to the selected project for
  `activity_execution_view()`;
- returns deterministic service-level errors before repository reads.

Errors:
- `ValueError("Project not found.")`
- `ValueError("Activity does not belong to selected project.")`

A regression test covers invalid project targets and a cross-project activity
execution-view attempt.

This extends the same ownership and target-integrity model established in
Steps 70, 75, 76, 77 and 78 into the execution/control layer.
