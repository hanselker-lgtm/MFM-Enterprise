# MFM v1.49 — Product Completion Step 215

## Boundary
**Membership Billing UI → Service Consistency**

## Concrete product gap

The existing member workspace correctly used `MemberService.memberships()` to
load memberships, but the invoice action then reached directly into
`MemberService.repo.list_memberships()` to recover the member id. This bypassed
the service boundary and duplicated repository knowledge in the GUI.

## Change

The invoice action now uses the selected member id already represented by the
member workspace and calls the existing service boundary directly:

```text
Member workspace selection
        ↓
MemberService.memberships()
        ↓
MemberService.invoice_membership(membership_id, member_id, amount)
        ↓
existing repository/accounting path
```

No repository API, service API, database schema, accounting workflow, or member
model was changed.

## Architectural decision

**PRODUCT CODE CHANGE — YES, CONCRETE DEFECT FIXED.**

This is a UI/service consistency fix. The GUI no longer depends on the
internal `repo` attribute of `MemberService`. This preserves the service as the
application boundary and removes a real coupling rather than creating an
artificial abstraction.

## Regression coverage

Added a GUI structural regression verifying that the member workspace invoice
path does not bypass the MemberService repository and continues to use the
existing `invoice_membership()` boundary.
