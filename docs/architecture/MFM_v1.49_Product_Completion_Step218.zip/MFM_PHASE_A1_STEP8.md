# MFM Phase A.1 — Step 8
## Product Navigation Rendering Adapter

### Objective
Establish a rendering adapter between the Phase A.1 navigation presentation model and the existing MainWindow workspaces without activating the new product navigation yet.

### Changes
- Added `MainWindow.build_product_navigation(parent)`.
- The adapter consumes `navigation_items(area)` rather than duplicating navigation definitions.
- Existing handlers are resolved through `getattr(self, item.command)`.
- Existing permission evaluation is applied through `navigation_allowed(item)`.
- The adapter returns the created navigation container and button map for controlled integration/testing.
- `_build()` is intentionally unchanged; the legacy visible navigation remains active until the adapter is validated and Phase A migration is approved.
- Corrected the Step 7 presentation-model label lookup so command names resolve to their registered labels.

### Scope protection
No database, repository, service, workflow, business-rule, permission-definition, or workspace implementation was changed.

### Validation
- `python -m compileall -q src`: PASS
- `pytest -q tests/test_gui_structure.py`: **15 passed**
- `PYTHONPATH=. pytest -q`: collection succeeded and **36 tests passed before the execution environment timeout**. The full 71-test baseline therefore remains not fully revalidated.

### Next step
Phase A.1 — Step 9: Controlled MainWindow Integration Preview. The adapter should be exercised through an isolated preview/test path before replacing the existing visible navigation in `_build()`.
