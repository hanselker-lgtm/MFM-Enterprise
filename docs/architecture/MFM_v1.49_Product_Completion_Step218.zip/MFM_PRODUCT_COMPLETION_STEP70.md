# MFM v1.49 — Product Completion Step 70

## P0/P1 — Activity project ownership protection

Step 70 closes a structural ownership bypass discovered during the activity
lifecycle review.

Step 69 hardened activity updates, but the generic update API still accepted
`project_id` as an arbitrary field. That meant an activity could potentially
be reparented from Project A to Project B after creation.

This is unsafe because existing project tasks reference the activity. Moving
the activity without migrating or validating those tasks could create
cross-project relationships and corrupt project execution/control views.

The product now protects activity ownership at the service boundary:
- an activity's `project_id` cannot be changed through the generic update API;
- an attempted cross-project reparenting is rejected;
- the original project relationship remains unchanged.

Normal activity field updates continue to work.

A regression test verifies that attempting to move an activity to another
project is rejected and that the original project_id remains intact.

This is a genuine product-completion change because project ownership is a
structural invariant shared by activities and their dependent tasks.
