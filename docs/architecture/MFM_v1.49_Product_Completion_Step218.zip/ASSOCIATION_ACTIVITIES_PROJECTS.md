# MFM v1.23 — Association Activities & Projects

v1.23 connects the association's real work to the existing project and
accounting model. It adds project-linked activities with dates, status and
budgets, plus an operational workspace for selecting a project and reviewing
its activities and budget totals.

The implementation intentionally reuses the existing project and accounting
foundation rather than creating another parallel planning system.
