# MFM v1.49 — Product Completion Step 182

## Outstanding Invoices Boundary

### Boundary

`MemberService.outstanding_invoices(billing_year=None)`

### Why this is a real boundary

The boundary provides a stable read model of invoices with a positive outstanding balance. It is distinct from `payment_status_summary()`: the summary aggregates counts and totals, while `outstanding_invoices()` preserves invoice-level detail needed for operational follow-up.

### Existing flow

```text
outstanding_invoices()
        ↓
repo.list_invoices()
        ↓
optional billing-year filter
        ↓
repo.invoice_paid_amount()
        ↓
existing invoice_status()
        ↓
invoice-level outstanding rows
```

### Architecture decision

No product-code change was required.

The implementation already uses the repository as the authoritative source, reuses the existing payment amount lookup and invoice-status contract, and performs no mutation.

No new invoice engine, payment store, or parallel outstanding-balance calculation was introduced.

### Regression coverage

The Step 182 regression verifies:

- paid invoices are excluded
- partially paid invoices remain with the correct outstanding amount
- unpaid invoices remain with the correct outstanding amount
- billing-year filtering is respected
- returned rows have positive outstanding balances
- the boundary remains read-only

### Verification

- Focused Step 182 regression: PASS
- Compileall: PASS
- Product code changed: NO

## Result

**STEP 182 — COMPLETE**
