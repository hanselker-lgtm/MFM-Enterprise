# MFM v1.49 — Product Completion Step 174

## P1 — Management Snapshot Boundary

Step 174 reviews the existing `ManagementService.snapshot()` boundary.

This is a genuine cross-domain read/composition boundary. It provides the
management-level summary used by the existing management/attention surface,
without becoming a second source of operational, financial, membership, risk,
or decision data.

## Existing implementation

The boundary composes established service/repository results:

```text
ManagementService.snapshot()
        ↓
        ├── projects.count()
        ├── tasks.count_open()
        ├── tasks.count_overdue(today)
        ├── risks.count_open()
        ├── risks.count_high()
        ├── decisions.count_pending()
        ├── members.members()
        ├── members.invoices()
        ├── bank.summary()
        └── accounting.income_statement()
```

The service derives only the management-level values required by the
existing contract:

- project count;
- open and overdue task counts;
- open/high-risk counts;
- pending decisions;
- member count;
- unpaid membership invoices;
- unmatched bank transactions;
- income, expenses and result.

`attention_items()` consumes this snapshot rather than introducing another
cross-domain aggregation source.

## Architecture decision

**NO PRODUCT CODE CHANGE.**

The existing implementation is already correctly positioned as a thin
cross-domain orchestration/read boundary. Creating a new management data
store, duplicating accounting/task/risk/member queries, or introducing a
parallel dashboard engine would add architecture without fixing a demonstrated
product defect.

## Regression coverage

Additional regression coverage verifies that the snapshot remains a
composition of current domain services and that the returned management model
is read-only with respect to the underlying task state.

The existing management snapshot/attention regression remains part of the
protected contract as well.
