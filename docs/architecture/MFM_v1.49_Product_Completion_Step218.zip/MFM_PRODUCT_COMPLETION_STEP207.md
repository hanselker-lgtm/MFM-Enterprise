# MFM v1.49 — Product Completion Step 207

## Fiscal Year Listing Boundary

Step 207 verifies the existing `AccountingService.fiscal_years()` read boundary.

This is a small but real master-data navigation contract: after fiscal-year
creation, the service exposes the authoritative fiscal-year records through
the existing repository listing path. It is intentionally treated as a read
boundary rather than introducing any new fiscal-year abstraction.

### Existing flow

```text
AccountingService.fiscal_years()
        ↓
AccountingRepository.list_fiscal_years()
        ↓
fiscal_years
```

The repository orders the records by fiscal year descending.

### Contract verified

Regression coverage verifies:

- multiple existing fiscal years are returned;
- the returned year values are preserved;
- the existing database IDs are preserved;
- newly created fiscal years retain the existing `Open` status;
- fiscal years are returned in the repository's existing descending-year order.

### Architecture decision

**NO PRODUCT CODE CHANGE.**

The implementation is already a correct thin read boundary over the
existing fiscal-year master data. No new service logic, cache, data source,
or fiscal-year abstraction is justified.

### Regression

Focused regression:

```text
1 passed
```

Compile:

```text
python -m compileall -q src tests
PASS
```
