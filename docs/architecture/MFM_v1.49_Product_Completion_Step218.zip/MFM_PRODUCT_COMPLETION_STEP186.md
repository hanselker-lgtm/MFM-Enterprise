# MFM v1.49 — Product Completion Step 186

## Invoice Status Refresh Boundary

Step 186 verifies the existing `MemberService.refresh_invoice_statuses()` maintenance boundary.

The boundary is meaningful because persisted invoice status is derived state. Payment amounts and
invoice due dates are authoritative inputs, while the stored status can become stale and therefore
needs an explicit reconciliation path.

The existing flow is:

```text
refresh_invoice_statuses()
        ↓
repo.list_invoices()
        ↓
repo.invoice_paid_amount()
        ↓
existing invoice_status() contract
        ↓
repo.update_invoice_status() when required
```

No new status engine, payment source, invoice model, or parallel reconciliation path was introduced.

### Verified contract

- overdue invoices are refreshed to `Overdue`;
- partially paid invoices are refreshed to `Partially Paid`;
- fully paid invoices are refreshed to `Paid`;
- status is derived from existing payment and due-date data;
- only stale statuses are written by the existing implementation.

### Product code

**NO PRODUCT CODE CHANGE.**

The existing maintenance boundary already satisfies the contract.

### Regression

A focused regression deliberately makes persisted invoice statuses stale and verifies that
`refresh_invoice_statuses()` restores the statuses from the authoritative payment/due-date state.

```text
Focused regression: PASS
Compile: PASS
```
