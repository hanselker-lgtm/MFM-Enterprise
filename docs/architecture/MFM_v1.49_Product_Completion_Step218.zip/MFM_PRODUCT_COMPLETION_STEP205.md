# MFM v1.49 — Product Completion — Step 205

## Standard Chart-of-Accounts Seed Boundary

### Boundary

Existing service boundary:

```python
seed_standard_accounts()
```

This boundary is part of `ApplicationContext` initialization and establishes the
standard chart of accounts used by the existing accounting model.

### Existing flow

```text
ApplicationContext
        ↓
AccountingService.seed_standard_accounts()
        ↓
existing account repository
        ↓
standard accounts available
```

The implementation checks existing account numbers before inserting defaults.
Therefore initialization is intentionally idempotent for the standard account
set and does not create duplicate accounts when the seed operation is run again.

### Contract verified

- the nine existing standard accounts are present;
- account numbers, names, and account types match the existing implementation;
- seeded accounts are active;
- the seed operation can be invoked again without creating duplicates;
- existing account IDs remain stable when the seed is repeated.

### Architectural assessment

No product-code change was required.

The existing service/repository path is already the correct source of the
standard chart of accounts. No new account master-data store, initialization
engine, or parallel seeding mechanism was introduced.

### Regression

Focused regression:

```text
1 passed
```

Compile:

```text
python -m compileall -q src tests
PASS
```
