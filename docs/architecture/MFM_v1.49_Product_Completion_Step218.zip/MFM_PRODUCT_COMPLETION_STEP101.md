# MFM v1.49 — Product Completion Step 101

## P1 — Project financial tracking service boundary

Step 101 moves the service-boundary hardening from activity financial actuals
to the project-level financial tracking model.

`financial_tracking()` previously returned the repository result directly.
That result contained a database row for the project and raw numeric values.

The service now exposes a stable application-level model:

- `project` is an independent dictionary;
- `budget`, `activity_budget`, `actual`, `variance`, and `utilization` are
  validated finite numeric values;
- monetary values are exposed to two decimal places;
- budget, activity budget, and actual cannot be negative;
- `activity_count` is exposed as an integer;
- invalid stored financial tracking data fails explicitly.

This is the first project-level financial read boundary after the activity
financial boundary in Step 100.
