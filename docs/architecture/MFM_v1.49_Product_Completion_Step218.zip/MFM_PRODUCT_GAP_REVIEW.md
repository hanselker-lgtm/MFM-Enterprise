# MFM — Product Gap Review
## Review after v1.49 — Work Intake Inbox & Triage Queue

**Review purpose**

This review is deliberately not a feature-generation exercise. Its purpose is to
determine what MFM actually needs to become a useful finished application, what
is already sufficient, what is incomplete, and what should *not* be built.

---

## 1. Executive conclusion

MFM has reached a point where the next priority should **not** be another long
sequence of narrowly named v1.x features.

The current product already contains substantial capability in:

- accounting
- membership administration
- membership billing and dunning
- projects and activities
- project budgets and financial control
- tasks and operational work
- risks and decisions
- search and contextual records
- personal work / Today View
- quick capture and triage
- banking and reconciliation
- audit and year-end control
- reporting / dashboards

The strongest gap is now **product completeness and integration**, not lack of
additional concepts.

### Recommended direction

Before adding more features, MFM should enter a **stabilisation and product
completion phase** focused on:

1. fixing UI/service inconsistencies
2. simplifying navigation
3. completing the real end-to-end user journeys
4. strengthening backup/restore, export and operational safety
5. validating permissions consistently
6. improving data integrity and error handling
7. deciding which existing capabilities should remain visible versus remain
   behind the scenes
8. performing a real usability pass with the perspective of a small association

---

# 2. Current technical/product baseline

The current source contains:

- **43 Python source files**
- **11 repositories**
- **21 service modules**
- **1 main GUI**
- **71 automated tests**
- **71/71 tests currently passing**

The database schema contains core areas for:

- organisation
- users / roles / permissions
- members / memberships
- membership invoices / payments
- member events / communications
- projects / activities / tasks
- risks / decisions
- project budgets
- accounting periods / years
- bank accounts / transactions / matching
- chart of accounts
- fiscal years / periods
- journals / journal lines
- voucher documents
- audit events

This means the application is no longer a small accounting prototype. It has
become a broad association-management application.

---

# 3. The most important product finding

## MFM has more functionality than it currently has product coherence.

The navigation currently exposes a very large number of workspaces directly:

- Dashboard
- Projects
- Tasks
- Risks
- Decisions
- Accounting
- Members
- Membership Billing
- Dunning
- Member Administration
- Activities & Projects
- Project Financials
- Project Control
- Project Work
- Operational Workboard
- Operational Actions
- Operational Alerts
- My Day
- Daily Execution
- Project Execution
- Project Execution Actions
- Project Progress Control
- Project Control Actions
- Project Control Cockpit
- Integrated Operations
- Integrated Operations Actions
- Navigation & Workspace
- Global Search
- Unified Record View
- Personal Workspace
- Personal Work Actions
- Today View
- Quick Capture
- Work Intake Triage
- Bank
- Users
- System
- Export
- Audit
- AI Assistant
- MFM Assistant
- Bank Import & Matching
- Year-End & Closing
- Financial Dashboard
- Accounting Audit
- Voucher Documents
- Account Ledger
- Journals & Vouchers
- Accounting Entry
- Accounting & Reports
- Forecast

This is the clearest signal that we should **stop adding navigation items**.

The user should not have to understand MFM's development history in order to
use MFM.

---

# 4. Product gaps by priority

## P0 — Must fix before significant feature expansion

### P0.1 End-to-end application flow

The product needs a small number of clear primary journeys.

Recommended primary journeys:

**A. Daily work**

Quick Capture → Inbox → Assignment → My Work → Today → Execute

**B. Project management**

Project → Activity → Work → Cost → Control

**C. Membership**

Member → Membership → Billing → Payment → Dunning → Accounting

**D. Accounting**

Entry → Voucher → Journal → Reconciliation → Period Close → Reporting

**E. Governance / control**

Risk → Decision → Action → Follow-up → Audit

These already largely exist in the code. The gap is that they are not yet
presented as coherent user journeys.

### P0.2 UI/service consistency

The v1.49 review uncovered an important example.

The service layer correctly defines the Inbox as:

> Open + unassigned

but the current GUI triage implementation still contains a broader query for
open tasks.

Therefore v1.49 should be regarded as **functionally specified but not fully
UI-complete** until the GUI and service use the same rule.

This is exactly the kind of issue that a Product Gap Review should catch.

### P0.3 Navigation simplification

The navigation must be redesigned around user jobs rather than development
versions.

Suggested top-level areas:

- **Home**
- **Work**
- **Projects**
- **Members**
- **Finance**
- **Reports**
- **Administration**

Everything else should be contextual or placed inside these areas.

### P0.4 Operational safety

A real association application needs confidence around:

- backup
- restore
- export
- error recovery
- auditability
- data integrity
- accidental destructive actions

The codebase already contains backup/restore and export services. The product
gap is making these capabilities obvious, safe and usable rather than merely
having service methods.

---

# 5. P1 — Important completion gaps

## P1.1 Dashboard needs to become useful, not bigger

The answer is not another dashboard.

The Home screen should answer:

- What needs my attention?
- What is overdue?
- What needs approval?
- What is financially important?
- What is happening with members?
- What requires action today?

The existing operational, financial and membership information should be
summarised here.

## P1.2 Member lifecycle completeness

The database and services already cover a strong membership core.

The remaining product question is whether the complete lifecycle is usable
without jumping between technical workspaces:

Member → Membership → Invoice → Payment → Communication → Dunning → Status.

## P1.3 Accounting usability

The accounting engine is significantly more mature than the current UI
experience.

The important remaining work is therefore:

- fast everyday entry
- clear voucher handling
- easy drill-down
- reconciliation confidence
- period-close confidence
- understandable reports

Not more accounting concepts.

## P1.4 Project financial control

This area is already broad.

The next useful work should be validating that a user can answer, quickly:

> What was budgeted?
>
> What has been spent?
>
> What remains?
>
> What is committed?
>
> What is going wrong?

If the existing screens already answer those questions, stop adding features.

## P1.5 Error handling and user feedback

The application has an ErrorService and AuditService.

The product gap is consistent use of these mechanisms so that users receive
clear, actionable feedback rather than technical exceptions.

---

# 6. P2 — Useful, but only if a real user need is demonstrated

Potential future work includes:

- recurring tasks
- richer calendar integration
- document management improvements
- richer member communications
- configurable dashboards
- stronger reporting
- import/export enhancements
- assistant/AI improvements

None of these should automatically become the next MFM version.

They should require a concrete user problem first.

---

# 7. Things we should NOT build now

This is an important part of the review.

## Do not build another task system

We already have:

Task → My Work → Today → Execution.

Keep it.

## Do not build a separate workflow engine

The existing status/action model is sufficient for the current product.

## Do not create an Inbox database

v1.49 correctly treats the Inbox as a filtered view of existing tasks.

Keep that principle.

## Do not create another dashboard for every subsystem

Use contextual summaries instead.

## Do not add AI merely because MFM has AI services

AI must solve a concrete problem.

## Do not create additional project-control layers

The current project-control functionality is already extensive.

## Do not keep adding navigation buttons

The navigation problem is now more important than the navigation feature set.

---

# 8. Recommended product architecture from here

The product should converge toward this:

```text
                         MFM
                          |
       +------------------+------------------+
       |                  |                  |
      HOME             WORK             BUSINESS
       |                  |                  |
   Attention         My Work          +------+------+------+
   Today             Today            |      |      |      |
   Alerts            Inbox         Members Projects Finance
                                      |       |       |
                                      +-------+-------+
                                              |
                                           REPORTS
                                              |
                                       ADMINISTRATION
```

The existing detailed capabilities remain underneath.

The user sees the **job**, not the implementation history.

---

# 9. Product maturity assessment

| Area | Current state | Gap |
|---|---|---|
| Accounting engine | Strong | UX / finalisation |
| Membership | Strong core | Lifecycle UX |
| Billing | Strong core | Final workflow polish |
| Banking | Strong core | Operational usability |
| Projects | Strong | Simplification / integration |
| Tasks | Strong | Avoid further expansion |
| Work management | Strong | Consolidate |
| Search | Good foundation | Contextual integration |
| Record view | Good foundation | Consolidate |
| Audit | Present | Consistent exposure |
| Permissions | Present | Verify across UI |
| Backup/restore | Present | Productise / test |
| Export | Present | Productise |
| Reporting | Present | Simplify |
| AI | Present | Do not expand without use case |
| Navigation | Overgrown | **Major gap** |
| UX coherence | Partial | **Major gap** |
| End-to-end workflows | Partial | **Major gap** |
| Testing | Strong baseline | Add integration/UI tests |

---

# 10. Recommended next phase

Instead of MFM v1.50, I recommend a temporary product phase:

# MFM Stabilisation & Product Completion

### Phase A — Clean-up

- reconcile GUI and service behaviour
- remove duplicate paths
- simplify navigation
- fix inconsistent terminology
- remove dead/duplicate UI where appropriate

### Phase B — Core journeys

Test the five journeys end-to-end:

1. Daily Work
2. Project Management
3. Membership
4. Accounting
5. Governance / Control

### Phase C — Operational safety

- backup
- restore
- export
- audit
- permissions
- error handling
- data integrity

### Phase D — Usability

Run the application as if we were an ordinary association administrator.

Ask:

> Can I find it?
>
> Can I understand it?
>
> Can I complete the task?
>
> Do I know what happened?
>
> Can I undo/recover when appropriate?

### Phase E — Only then decide v1.50

At that point, the next feature should come from a demonstrated gap rather
than from the version number.

---

# 11. Final Product Gap Review conclusion

The review changes my recommendation for the next step.

**We should NOT immediately build MFM v1.50.**

The product has reached the point where additional functionality risks creating
complexity faster than value.

The next development target should therefore be:

> **MFM Product Completion & Stabilisation**

with the explicit goal of turning the large set of existing capabilities into
a coherent, usable association-management application.

The guiding rule from this point forward is:

> **No feature unless it solves a real user problem, removes friction, closes
> a real product gap, or materially improves control/safety.**

That should become the product gate for all future MFM development.
