# MFM v1.49 — Product Completion Step 86

## P1 — Activity status workflow enforcement

Step 86 extends the state-machine protection established for project tasks to
activity status mutations.

Step 85 validated activity status values, but a generic `update_activity()`
call could still move an activity directly between any two valid status
values. That meant the activity status vocabulary was protected, but the
workflow itself was not.

The service now enforces:

- Planned -> Active / On Hold / Cancelled
- Active -> On Hold / Completed / Cancelled
- On Hold -> Active / Cancelled
- Completed -> no further transition
- Cancelled -> no further transition

An invalid transition fails with:
`ValueError("Invalid activity workflow transition: ...")`

Two regression tests verify both rejection of a workflow bypass and a valid
multi-step progression.
