# MFM v1.49 — Product Completion Step 82

## P1 — Task status workflow enforcement

Step 82 closes a workflow bypass in the project-task mutation layer.

MFM already had `transition_project_task()` with an explicit status state
machine. However, `update_project_task()` and `triage_work_item()` could write
the `status` field directly through generic mutation paths, allowing callers
to bypass those workflow rules.

The product now uses one shared `_validate_task_transition()` rule set.

### Protected mutation paths

- `transition_project_task()`
- `update_project_task(status=...)`
- `triage_work_item(status=...)`

The allowed workflow remains:

- Open -> In Progress / Blocked / Completed / Closed
- In Progress -> Blocked / Completed / Open
- Blocked -> In Progress / Open
- Completed -> Closed / Open
- Closed -> no further transitions

Invalid transitions now fail with:
`ValueError("Invalid workflow transition: ...")`

Normal non-status task updates remain unaffected.

Two regression tests verify that both generic update and triage cannot bypass
the workflow state machine.
