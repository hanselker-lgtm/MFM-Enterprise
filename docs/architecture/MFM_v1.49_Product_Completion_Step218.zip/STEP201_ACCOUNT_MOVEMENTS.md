# MFM v1.49 Product Completion — Step 201

## Boundary

**Account Movements Boundary**

Existing service boundary:

```python
account_movements(account_id, start_date=None, end_date=None)
```

## Decision

This is a genuine read boundary because it provides account-scoped journal-line
movements with optional date filtering. It is the drill-down path between the
General Ledger and account-level financial detail.

The implementation is already architecturally correct:

```text
account_movements()
        ↓
AccountingRepository.account_movements()
        ↓
posted journal lines
        ↓
account-scoped read result
```

The repository remains the authoritative source. No parallel accounting logic,
new data store, or new reporting engine is introduced.

## Verification

Regression coverage verifies:

- account scoping;
- posted journal movement retrieval;
- journal date;
- journal description;
- debit and credit values;
- start/end date filtering;
- exclusion of movements outside the requested period.

## Product code

**NO PRODUCT CODE CHANGE**

The existing implementation is retained unchanged.

## Result

- focused regression: PASS
- compileall: PASS
- ZIP integrity: PASS
