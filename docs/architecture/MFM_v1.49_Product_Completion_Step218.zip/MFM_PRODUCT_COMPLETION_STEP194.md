# MFM v1.49 — Product Completion Step 194

## Voucher Document Lifecycle Boundary

Step 194 verifies the existing voucher-document boundary around accounting journals.

## Boundary

```text
attach_voucher_document()
        ↓
source validation
        ↓
journal validation
        ↓
SHA-256 + deterministic storage name
        ↓
existing repository voucher_documents persistence
        ↓
voucher_documents()
        ↓
voucher_document()
        ↓
remove_voucher_document()
```

## Architectural assessment

The existing implementation is already the correct boundary:

- the journal remains the authoritative accounting record
- voucher metadata is persisted through `AccountingRepository`
- the physical file is stored separately from accounting data
- SHA-256 provides document identity/integrity metadata
- removal deletes the physical file before deleting the database record
- a storage deletion failure leaves the database record intact

No second document store, document engine, or accounting source of truth is introduced.

## Verified contract

- missing source file is rejected
- missing journal is rejected
- attachment is copied to the configured storage directory
- original filename is preserved in metadata
- MIME type is detected
- file size is persisted
- SHA-256 digest is persisted
- stored filename is deterministic from journal number + digest + source filename
- existing stored file is not unnecessarily rewritten
- document can be listed and retrieved
- successful removal deletes both storage file and database record
- failed physical deletion leaves the database record intact

## Implementation decision

**NO PRODUCT CODE CHANGE.**

The implementation already satisfies the required contract.

## Regression

Added:

```text
test_step194_voucher_document_lifecycle_boundary
```

Result:

```text
1 passed
```

## Validation

```text
python -m compileall -q src tests
PASS
```

Step 194 is complete.
