# MFM v1.14 — Accounting Audit & Control

MFM now has an audit-event store and an accounting control screen.

Audit events capture:
- timestamp;
- event type;
- entity type and ID;
- description;
- optional actor;
- optional metadata.

The current posting workflow records JOURNAL_POSTED events.

The control check verifies:
- trial balance debits equal credits;
- balance sheet is balanced;
- number of posted journals;
- number of audit events in the selected period.

This is an operational control layer, not a new architecture governance layer.
