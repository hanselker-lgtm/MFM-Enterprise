# MFM v1.49 — Product Completion Step 60

## P1 — Prevent restoring the active database onto itself

Step 60 addresses a concrete restore workflow safety gap.

The restore service validated the selected source as a valid MFM database, but
did not explicitly reject the application's currently active database file as
the restore source.

Selecting the active database as its own restore source is not a meaningful
restore operation and can enter the replacement/rollback path unnecessarily.
It can also produce platform-dependent same-file copy errors.

The product now rejects this condition before creating a safety copy or
starting replacement.

The user receives a clear validation error:
"The selected restore source is the active MFM database."

No valid restore workflow is changed.

A regression test verifies that passing the active database path to restore
is rejected before any replacement occurs.

This is a genuine product-completion change because destructive recovery
operations should reject self-targeting input explicitly rather than relying
on filesystem behavior.
