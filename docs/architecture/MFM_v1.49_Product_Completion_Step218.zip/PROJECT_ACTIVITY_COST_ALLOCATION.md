# MFM v1.25 — Project & Activity Cost Allocation

v1.25 extends journal lines with an optional activity allocation alongside
the existing project allocation. The accounting service validates that an
activity exists and belongs to the selected project.

Posted expense journal lines tagged with an activity are now aggregated to
that activity's actual cost, producing budget, actual, variance and
utilization at activity level.

Existing project-only allocations remain valid, so the feature is backward
compatible.
