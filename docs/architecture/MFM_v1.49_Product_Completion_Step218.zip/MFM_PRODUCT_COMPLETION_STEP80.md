# MFM v1.49 — Product Completion Step 80

## P1 — Execution write and quick-capture target integrity

Step 80 closes two remaining project-target validation gaps found in the
execution/write surface after Step 79.

### Execution action

`execution_action(project_id, task_id, ...)` already checked whether the task
belonged to the selected project, but it did not first verify that the
project itself existed. The service now applies `_require_project()` before
loading or mutating the task.

An unknown project therefore fails with:
`ValueError("Project not found.")`

No task status mutation occurs.

### Quick capture

`quick_capture()` required a project but did not explicitly validate that the
supplied project ID existed before proceeding to contextual activity/task
processing. The service now verifies the supplied project before any further
work.

An unknown project fails with:
`ValueError("Project not found.")`

These changes extend the project-target integrity contract from execution
reads into execution writes and contextual task creation.

Two regression tests cover the cases.
