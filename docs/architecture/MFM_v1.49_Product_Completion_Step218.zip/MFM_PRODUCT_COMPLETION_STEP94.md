# MFM v1.49 — Product Completion Step 94

## P1 — Validation-only parent identifier semantics

Step 94 closes a subtle mutation-contract gap in `update_activity()`.

`project_id` is not a mutable activity field. It is accepted only so the
service can validate that the caller is operating against the activity's
current parent project.

A project-id-only update previously became a silent no-op after validation.
The service now rejects that call explicitly.

A project ID may still accompany a real update, where it is validated and
then removed before persistence.

This makes the distinction explicit:

- `project_id` only -> rejected;
- `project_id` + real activity field -> allowed;
- different project ID -> rejected.

Two regression tests cover both the rejection and the valid combined update.
