# MFM v1.46 — Daily Work Prioritization & Today View

v1.46 derives a Today View from the existing personal task model. Work is
grouped into overdue, due today, blocked, high-priority and other buckets.
No new task model is introduced.
