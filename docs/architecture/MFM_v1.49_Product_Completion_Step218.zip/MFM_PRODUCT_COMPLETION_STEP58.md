# MFM v1.49 — Product Completion Step 58

## P1 — Backup copy failure cleanup

Step 58 addresses a concrete recovery-point integrity gap.

The backup workflow already removed a destination file when post-copy
integrity validation failed. However, a filesystem failure during the
`copy2()` operation itself occurred before that cleanup block was entered.

A failed copy could therefore leave a partial backup file at the requested
destination.

The product now covers both stages with the same cleanup boundary:
- copy failure -> partial destination is removed;
- SQLite integrity failure -> destination is removed;
- MFM-structure validation failure -> destination is removed;
- successful validation -> backup is retained.

The existing protection against overwriting an existing backup is unchanged.

A regression test simulates a copy that creates a partial file and then raises
an operating-system error. The test verifies that no partial recovery point
remains.

This is a genuine product-completion change because a partial backup file
must never be presented as a usable MFM recovery point.
