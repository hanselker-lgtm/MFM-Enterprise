# MFM v1.49 — Product Completion Step 85

## P1 — Activity status mutation contract

Step 85 strengthens the activity mutation surface after Step 84.

The parent-project integrity guard introduced in Step 84 remains the first
boundary for activity updates. Step 85 adds explicit service-level validation
for activity status values so generic activity updates cannot write arbitrary
status strings directly to the repository.

The accepted activity statuses are:

- Planned
- Active
- On Hold
- Completed
- Cancelled

Invalid values fail with:
`ValueError("Invalid activity status.")`

The activity remains unchanged.

This keeps activity state values controlled at the service boundary rather
than relying on callers or the database repository to provide valid values.

A regression test verifies rejection of an invalid activity status and
confirms that the existing status remains `Planned`.
