# MFM Windows Deployment

## Development run
Use:

    python run_mfm.py

## Build a Windows executable
On a Windows development machine with Python installed:

    build_windows.bat

The build script installs PyInstaller and creates:

    dist\MFM\MFM.exe

## Production preparation
Before production use:
- change the bootstrap `admin/admin` credentials;
- create a real organization profile;
- make a database backup;
- verify role permissions;
- test restore;
- keep the generated `dist\MFM` directory intact.

## Important
This is a packaging foundation, not a signed MSI installer. Code signing,
MSI/EXE installer creation, automatic updates and enterprise deployment
are separate release-engineering tasks.
