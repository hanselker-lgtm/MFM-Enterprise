# MFM v1.49 — Product Completion Step 93

## P1 — Activity creation field normalization

Step 93 closes a small but concrete consistency gap between activity
creation and activity update.

`update_activity()` already treated a null description as an empty
description and supported an explicit empty activity date. `create_activity()`
did not apply the same normalization: a `None` description could become the
literal string `None`, and an empty date was handled only implicitly.

The creation contract is now aligned with update behavior:

- `description=None` becomes an empty string;
- empty description is stored as empty;
- `activity_date=None` or `""` means no date;
- non-empty dates continue to require ISO-date validation.

Two regression tests verify both normalization rules.
