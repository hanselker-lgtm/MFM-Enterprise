# MFM v1.49 — Product Completion Step 56

## P1 — Remove plaintext password retention from forced first-run login

Step 56 addresses a concrete credential-handling issue in the GUI.

During the mandatory bootstrap-password change, the GUI previously copied the
new plaintext password into `_last_new_password` and then used that value to
authenticate the user again.

The re-authentication was unnecessary because the login had already
authenticated the user and the forced password-change operation had completed
successfully.

The product now:
- performs the required password change;
- retains the already authenticated user object;
- does not store the new plaintext password in GUI instance state;
- does not submit the plaintext password a second time.

This reduces the lifetime and exposure of plaintext credentials in application
memory without changing the forced first-run security behavior.

A regression test verifies that the plaintext-password state variable and
second authentication path are absent from the main window implementation.

This is a genuine product-completion/security change because credential data
should not be retained in GUI state when it is not required for the workflow.
