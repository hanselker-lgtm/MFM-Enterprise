# MFM v1.49 — Product Completion Step 75

## P1 — Project budget mutation target integrity

Step 75 closes the remaining project-budget mutation lifecycle gap found after
the Step 74 financial integrity work.

`set_budget()` already rejected negative and non-finite values, but an unknown
project ID was still passed through to the repository without an explicit
product-level not-found result.

The product now verifies that the project exists before budget validation and
mutation:
- existing project -> normal budget validation/update;
- unknown project -> `ValueError("Project not found.")`;
- no repository mutation occurs for an unknown target.

A regression test verifies the stale/unknown project case.

This is a genuine product-completion change because budget mutation is a
financial write operation and must never silently target a record that no
longer exists.
