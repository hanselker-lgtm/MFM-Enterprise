class ProjectService:
    def __init__(self, repo):
        self.repo = repo

    def create(self, name, description="", status="Planned", budget=0):
        name = str(name).strip()
        if not name:
            raise ValueError("Project name is required.")
        budget = float(budget or 0)
        if budget < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.create(name, str(description).strip(), status, budget)

    def list(self):
        return self.repo.list()

    def count(self):
        return self.repo.count()

    def set_budget(self, project_id, amount):
        amount = float(amount)
        if amount < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.set_budget(project_id, amount)

    def budget(self, project_id):
        return self.repo.project_budget(project_id)

    def create_activity(self, project_id, name, description="", activity_date=None,
                        status="Planned", budget=0):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")
        name=str(name).strip()
        if not name: raise ValueError("Activity name is required.")
        budget=float(budget or 0)
        if budget < 0: raise ValueError("Activity budget cannot be negative.")
        return self.repo.create_activity(project_id,name,str(description).strip(),
                                          activity_date,status,budget)

    def activities(self, project_id):
        return self.repo.list_activities(project_id)

    def update_activity(self, activity_id, **fields):
        if "budget" in fields and float(fields["budget"]) < 0:
            raise ValueError("Activity budget cannot be negative.")
        return self.repo.update_activity(activity_id,**fields)

    def activity_summary(self, project_id):
        return dict(self.repo.project_activity_summary(project_id))
