class ProjectRepository:
    def __init__(self, db):
        self.db = db

    def list(self):
        return self.db.fetch_all("SELECT * FROM projects ORDER BY id DESC")

    def create(self, name, description, status, budget):
        return self.db.execute(
            "INSERT INTO projects(name,description,status,budget) VALUES(?,?,?,?)",
            (name, description, status, budget)
        )

    def count(self):
        return self.db.fetch_one("SELECT COUNT(*) c FROM projects")["c"]

    def set_budget(self, project_id, amount):
        project = self.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        existing = self.db.fetch_one(
            "SELECT id FROM project_budgets WHERE project_id=?", (project_id,)
        )
        if existing:
            self.db.execute(
                "UPDATE project_budgets SET budget_amount=? WHERE project_id=?",
                (amount, project_id)
            )
            return existing["id"]
        return self.db.execute(
            "INSERT INTO project_budgets(project_id,budget_amount) VALUES(?,?)",
            (project_id, amount)
        )

    def project_budget(self, project_id):
        return self.db.fetch_one(
            "SELECT * FROM project_budgets WHERE project_id=?", (project_id,)
        )

    def list_activities(self, project_id):
        return self.db.fetch_all(
            """SELECT * FROM activities
               WHERE project_id=? ORDER BY activity_date DESC, id DESC""",
            (project_id,)
        )

    def create_activity(self, project_id, name, description, activity_date,
                        status="Planned", budget=0):
        return self.db.execute(
            """INSERT INTO activities
               (project_id,name,description,activity_date,status,budget)
               VALUES(?,?,?,?,?,?)""",
            (project_id,name,description,activity_date,status,budget)
        )

    def update_activity(self, activity_id, **fields):
        allowed={"name","description","activity_date","status","budget"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates: return None
        sql="UPDATE activities SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql,tuple(updates.values())+(activity_id,))
        return self.db.fetch_one("SELECT * FROM activities WHERE id=?", (activity_id,))

    def project_activity_summary(self, project_id):
        return self.db.fetch_one(
            """SELECT COUNT(*) activity_count,
                      COALESCE(SUM(budget),0) activity_budget
               FROM activities WHERE project_id=?""",
            (project_id,)
        )
