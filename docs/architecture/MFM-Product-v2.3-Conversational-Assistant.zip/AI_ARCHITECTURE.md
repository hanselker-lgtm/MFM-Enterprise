# MFM AI Architecture — v2.3

## Unified assistant

v2.3 combines three read-only capabilities:
1. deterministic data queries;
2. data-driven insights;
3. prioritized recommendations.

The assistant is a presentation and routing layer over those services.
It does not receive direct write access to the database.

## Conversation boundary

User -> AssistantService -> MFM services -> database -> response.

Any future language model may be inserted as an interpretation/explanation
layer, but factual retrieval should remain grounded in MFM service results.
Write operations must remain explicit, permission-checked and auditable.
