import ast
from pathlib import Path


MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def _tree():
    return ast.parse(MAIN_WINDOW.read_text(encoding="utf-8"))


def _main_window_class():
    tree = _tree()
    return next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
    )


def test_mainwindow_core_methods_are_class_methods():
    cls = _main_window_class()
    methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    expected = {
        "__init__", "_login", "_build", "allowed", "denied",
        "clear", "card", "show_dashboard", "table", "show_projects",
        "show_project_finance", "new_project", "show_tasks", "new_task",
        "show_risks", "new_risk", "show_decisions", "new_decision",
        "show_accounting", "show_accounts", "new_account", "show_journals",
        "show_trial_balance", "refresh", "run", "show_financial_dashboard",
    }
    assert expected <= methods


def test_no_legacy_mfm_extension_functions_remain_top_level():
    tree = _tree()
    top_level_functions = {
        node.name for node in tree.body if isinstance(node, ast.FunctionDef)
    }
    assert top_level_functions == set()


def test_mainwindow_public_workspaces_are_real_methods():
    cls = _main_window_class()
    methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    expected = {
        "show_members", "show_membership_billing", "show_dunning", "show_member_admin",
        "show_activities", "show_project_financials", "show_project_control", "show_project_work",
        "show_operational_workboard", "show_operational_actions", "show_operational_alerts", "show_my_day",
        "show_daily_execution", "show_project_execution", "show_project_execution_actions",
        "show_project_progress_control", "show_project_control_actions", "show_project_control_cockpit",
        "show_integrated_operations_dashboard", "show_integrated_operations_actions", "show_workspace_integration",
        "show_global_search", "show_unified_record_view", "show_personal_workspace",
        "show_personal_work_actions", "show_today_view", "show_quick_capture", "show_work_intake_triage",
    }
    assert expected <= methods


def test_mainwindow_local_callbacks_remain_local():
    cls = _main_window_class()
    login = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "_login"
    )
    nested_names = {
        node.name for node in login.body if isinstance(node, ast.FunctionDef)
    }
    assert {"do_login", "on_close"} <= nested_names


def test_financial_dashboard_refresh_remains_a_local_callback():
    cls = _main_window_class()
    method = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "show_financial_dashboard"
    )
    nested_names = {
        node.name for node in method.body if isinstance(node, ast.FunctionDef)
    }
    assert "refresh" in nested_names


def test_mainwindow_command_registry_is_explicit_and_resolvable():
    cls = _main_window_class()
    registry = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "command_registry"
    )
    returns = [node for node in ast.walk(registry) if isinstance(node, ast.Return)]
    assert len(returns) == 1
    value = returns[0].value
    assert isinstance(value, (ast.Tuple, ast.List))
    commands = [(item.elts[0].value, item.elts[1].value) for item in value.elts]
    methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    assert len(commands) == len(set(commands))
    assert all(method in methods for _, method in commands)
    assert all(label.strip() and method.startswith("show_") for label, method in commands)


def test_product_navigation_contract_has_seven_product_areas():
    cls = _main_window_class()
    contract = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "product_navigation_contract"
    )
    returns = [node for node in ast.walk(contract) if isinstance(node, ast.Return)]
    assert len(returns) == 1
    value = returns[0].value
    assert isinstance(value, ast.Tuple)
    areas = [item.elts[0].value for item in value.elts]
    assert areas == ["Home", "Work", "Projects", "Members", "Finance", "Reports", "Administration"]


def test_product_navigation_contract_covers_every_registry_command_once():
    cls = _main_window_class()
    registry_node = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "command_registry")
    registry_return = next(node for node in ast.walk(registry_node) if isinstance(node, ast.Return)).value
    registry_methods = [item.elts[1].value for item in registry_return.elts]

    contract_node = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "product_navigation_contract")
    contract_return = next(node for node in ast.walk(contract_node) if isinstance(node, ast.Return)).value
    mapped = []
    for area in contract_return.elts:
        commands = area.elts[1]
        mapped.extend(item.value for item in commands.elts)

    assert len(mapped) == len(set(mapped))
    assert set(mapped) == set(registry_methods)


def test_product_navigation_contract_keeps_only_truly_unmapped_area_empty():
    cls = _main_window_class()
    contract_node = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "product_navigation_contract")
    contract_return = next(node for node in ast.walk(contract_node) if isinstance(node, ast.Return)).value
    areas = {item.elts[0].value: item.elts[1] for item in contract_return.elts}
    assert [item.value for item in areas["Administration"].elts] == [
        "show_administration", "show_users", "show_audit", "show_backup_restore", "show_export"
    ]
    assert [item.value for item in areas["Reports"].elts] == ["show_financial_dashboard"]



def test_navigation_model_is_explicit_and_resolvable():
    cls = _main_window_class()
    names = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    assert "navigation_model" in names
    assert "navigation_items" in names
    assert "navigation_allowed" in names


def test_navigation_model_has_one_item_per_contract_command():
    ns = {}
    exec(compile(_tree(), str(MAIN_WINDOW), "exec"), ns)
    model = ns["MainWindow"].navigation_model()
    contract = ns["MainWindow"].product_navigation_contract()
    expected = sum(len(commands) for _, commands in contract)
    assert len(model) == expected
    assert len({item.command for item in model}) == expected
    assert all(item.label.strip() for item in model)
    assert all(item.area for item in model)


def test_navigation_model_uses_existing_permissions_for_visible_sensitive_commands():
    ns = {}
    exec(compile(_tree(), str(MAIN_WINDOW), "exec"), ns)
    model = ns["MainWindow"].navigation_model()
    expected = {
        "show_dashboard": "dashboard.view",
        "show_projects": "projects.view",
        "show_financial_dashboard": "dashboard.view",
        "show_users": "users.manage",
        "show_audit": "dashboard.view",
        "show_backup_restore": "system.backup",
        "show_export": "reports.export",
    }
    actual = {item.command: item.permission_code for item in model if item.command in expected}
    assert actual == expected


def test_navigation_model_preserves_existing_permission_boundary():
    ns = {}
    exec(compile(_tree(), str(MAIN_WINDOW), "exec"), ns)
    model = ns["MainWindow"].navigation_model()
    projects = next(item for item in model if item.command == "show_projects")
    assert projects.permission_code == "projects.view"
    assert next(item for item in model if item.command == "show_users").permission_code == "users.manage"
    assert next(item for item in model if item.command == "show_backup_restore").permission_code == "system.backup"
    assert next(item for item in model if item.command == "show_export").permission_code == "reports.export"


def test_navigation_items_can_filter_by_product_area():
    ns = {}
    exec(compile(_tree(), str(MAIN_WINDOW), "exec"), ns)
    cls = ns["MainWindow"]
    work = cls.navigation_items("Work")
    assert work
    assert all(item.area == "Work" for item in work)
    assert cls.navigation_items("Reports")
    assert cls.navigation_items("Administration")


def test_product_navigation_rendering_adapter_exists_and_uses_model():
    cls = _main_window_class()
    method = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "build_product_navigation"
    )
    source = ast.unparse(method)
    assert "navigation_items" in source
    assert "navigation_allowed" in source
    assert "getattr" in source


def test_product_navigation_rendering_adapter_is_not_activated_by_build_yet():
    cls = _main_window_class()
    build = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "_build"
    )
    source = ast.unparse(build)
    assert "build_product_navigation" not in source
    assert "product_navigation_contract" in source


def test_controlled_product_navigation_preview_exists():
    cls = _main_window_class()
    method = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "preview_product_navigation"
    )
    source = ast.unparse(method)
    assert "build_product_navigation" in source
    assert "existing navigation remains active" in source


def test_controlled_preview_does_not_activate_product_navigation():
    cls = _main_window_class()
    build = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "_build"
    )
    source = ast.unparse(build)
    assert "preview_product_navigation" not in source
    assert "build_product_navigation" not in source
    assert "product_navigation_contract" in source
