import shutil
import logging
from src.services.error_service import ErrorService
import csv
import tempfile
import sqlite3
import pytest
from pathlib import Path
from src.database.db import Database
from src.database.schema import initialize_schema
from src.application.context import ApplicationContext

def test_core_crud():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.projects.create("Test Project")
        ctx.tasks.create("Test Task")
        ctx.risks.create("Test Risk", "High")
        ctx.decisions.create("Test Decision")
        assert ctx.projects.count() == 1
        assert ctx.tasks.count_open() == 1
        assert ctx.risks.count_high() == 1
        assert ctx.decisions.count_pending() == 1


def test_accounting_balanced_posting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        jid = ctx.accounting.post_journal(
            1,
            "Membership payment",
            [
                {"account_id": bank["id"], "debit": 500, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 500},
            ],
        )
        assert jid == 1
        assert db.fetch_one("SELECT status FROM journals WHERE id=?", (jid,))["status"] == "Posted"

def test_accounting_rejects_unbalanced_journal():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        a = accounts[0]
        b = accounts[1]
        try:
            ctx.accounting.post_journal(
                1, "Invalid", [
                    {"account_id": a["id"], "debit": 100, "credit": 0},
                    {"account_id": b["id"], "debit": 0, "credit": 90},
                ])
            assert False, "Expected ValueError"
        except ValueError:
            pass


def test_fiscal_year_creates_12_open_periods():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.accounting.create_fiscal_year(2026)
        periods = ctx.accounting.periods(2026)
        assert len(periods) == 12
        assert all(p["status"] == "Open" for p in periods)
        assert periods[0]["start_date"] == "2026-01-01"
        assert periods[-1]["end_date"] == "2026-12-31"

def test_journal_number_is_automatic():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        ctx.accounting.post_journal(None, "First", [
            {"account_id": bank["id"], "debit": 10, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 10},
        ])
        ctx.accounting.post_journal(None, "Second", [
            {"account_id": bank["id"], "debit": 20, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 20},
        ])
        rows = db.fetch_all("SELECT journal_no FROM journals ORDER BY id")
        assert [r["journal_no"] for r in rows] == [1, 2]


def test_financial_reports():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        expense = next(a for a in accounts if a["number"] == "5000")
        ctx.accounting.post_journal(None, "Income", [
            {"account_id": bank["id"], "debit": 1000, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 1000},
        ])
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": expense["id"], "debit": 300, "credit": 0},
            {"account_id": bank["id"], "debit": 0, "credit": 300},
        ])
        income_report = ctx.accounting.income_statement()
        assert income_report["total_income"] == 1000
        assert income_report["total_expenses"] == 300
        assert income_report["result"] == 700


def test_project_budget_vs_actual():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Restoration")
        ctx.projects.set_budget(project_id, 1000)
        accounts = ctx.accounting.accounts()
        expense = next(a for a in accounts if a["number"] == "5000")
        bank = next(a for a in accounts if a["number"] == "1000")
        ctx.accounting.post_journal(None, "Project expense", [
            {"account_id": expense["id"], "debit": 250, "credit": 0, "project_id": project_id},
            {"account_id": bank["id"], "debit": 0, "credit": 250, "project_id": project_id},
        ])
        r = ctx.accounting.project_budget_vs_actual(project_id)
        assert r["budget"] == 1000
        assert r["actual"] == 250
        assert r["variance"] == 750
        assert r["utilization"] == 25


def test_membership_core():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member("M001", "Hans", "Hansen")
        type_id = ctx.members.create_membership_type("Ordinary", 500)
        membership_id = ctx.members.add_membership(member_id, type_id)
        invoice_id = ctx.members.invoice_membership(membership_id, member_id, 500)
        assert member_id == 1
        assert membership_id == 1
        assert invoice_id == 1
        assert ctx.members.members()[0]["member_no"] == "M001"
        assert ctx.members.invoices()[0]["amount"] == 500


def test_membership_payment_posts_to_accounting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member("M002", "Test", "Member")
        type_id = ctx.members.create_membership_type("Ordinary", 500)
        membership_id = ctx.members.add_membership(member_id, type_id)
        invoice_id = ctx.members.invoice_membership(membership_id, member_id, 500)
        payment_id = ctx.members.register_payment(invoice_id, 500)
        assert payment_id == 1
        invoice = db.fetch_one("SELECT status FROM membership_invoices WHERE id=?", (invoice_id,))
        assert invoice["status"] == "Paid"
        journals = db.fetch_all("SELECT * FROM journals WHERE status='Posted' ORDER BY id")
        # One journal records the invoice and one records the payment.
        assert len(journals) == 2
        invoice_journal = db.fetch_one(
            "SELECT journal_id FROM membership_invoices WHERE id=?", (invoice_id,)
        )
        assert invoice_journal["journal_id"] == journals[0]["id"]
        payment_row = db.fetch_one(
            "SELECT journal_id FROM membership_payments WHERE id=?", (payment_id,)
        )
        assert payment_row["journal_id"] == journals[1]["id"]
        lines = db.fetch_all("SELECT * FROM journal_lines WHERE journal_id=?", (journals[1]["id"],))
        assert sum(x["debit"] for x in lines) == 500
        assert sum(x["credit"] for x in lines) == 500


def test_bank_reconciliation():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main Bank", "123")
        bank = next(a for a in ctx.accounting.accounts() if a["number"] == "1000")
        income = next(a for a in ctx.accounting.accounts() if a["number"] == "3000")
        journal_id = ctx.accounting.post_journal(None, "Bank deposit", [
            {"account_id": bank["id"], "debit": 500, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 500},
        ])
        tx_id = ctx.bank.import_transaction(bank_id, 500, "Bank deposit")
        assert len(ctx.bank.unmatched()) == 1
        candidates = ctx.bank.candidates(500)
        assert any(x["id"] == journal_id for x in candidates)
        ctx.bank.match(tx_id, journal_id)
        assert ctx.bank.summary()["matched"] == 1
        assert ctx.bank.summary()["unmatched"] == 0


def test_management_snapshot_and_attention():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.tasks.create("Overdue task", due_date="2000-01-01")
        ctx.risks.create("High risk", "High")
        ctx.decisions.create("Pending decision")
        snapshot = ctx.management.snapshot()
        assert snapshot["open_tasks"] == 1
        assert snapshot["overdue_tasks"] == 1
        assert snapshot["high_risks"] == 1
        assert snapshot["pending_decisions"] == 1
        priorities = [x[0] for x in ctx.management.attention_items()]
        assert "HIGH" in priorities



def test_management_snapshot_composes_current_domain_services_without_mutation():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        project_id = ctx.projects.create("Management snapshot project")
        task_id = ctx.projects.create_project_task(
            project_id, "Open management task", due_date="2026-08-30"
        )
        before_task = dict(db.fetch_one("SELECT * FROM tasks WHERE id=?", (task_id,)))
        ctx.risks.create("Open risk", "High")
        ctx.decisions.create("Pending decision")

        snapshot = ctx.management.snapshot()

        assert snapshot["projects"] == 1
        assert snapshot["open_tasks"] == 1
        assert snapshot["open_risks"] == 1
        assert snapshot["high_risks"] == 1
        assert snapshot["pending_decisions"] == 1
        assert snapshot["members"] == 0
        assert snapshot["unmatched_bank"] == 0
        assert "income" in snapshot
        assert "expenses" in snapshot
        assert "result" in snapshot
        assert dict(db.fetch_one("SELECT * FROM tasks WHERE id=?", (task_id,))) == before_task


def test_management_attention_items_uses_snapshot_contract():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.tasks.create("Overdue management task", due_date="2000-01-01")
        ctx.risks.create("High management risk", "High")

        items = ctx.management.attention_items()
        messages = [message for _, message in items]

        assert any("overdue" in message for message in messages)
        assert any("high-risk" in message for message in messages)

def test_user_authentication():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        user = ctx.users.authenticate("admin", "admin")
        assert user is not None
        assert user["role_name"] == "Administrator"
        assert ctx.users.authenticate("admin", "wrong") is None


def test_backup_restore():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.system.set_setting("company_name", "Test Association")
        backup = base / "backup.db"
        ctx.system.backup(backup)
        assert backup.exists()
        ctx.system.set_setting("company_name", "Changed")
        safety = ctx.system.restore(backup)
        assert safety.exists()
        restored = Database(db.path)
        assert restored.fetch_one(
            "SELECT value FROM app_settings WHERE key='company_name'"
        )["value"] == "Test Association"


def test_restore_creates_unique_safety_copies():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        backup = base / "backup.db"
        ctx.system.backup(backup)

        first = ctx.system.restore(backup)
        second = ctx.system.restore(backup)

        assert first != second
        assert first.exists()
        assert second.exists()



def test_restore_rejects_invalid_sqlite_backup_and_preserves_database():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.system.set_setting("company_name", "Protected")

        invalid_backup = base / "invalid.db"
        invalid_backup.write_text("not a sqlite database")

        import pytest
        with pytest.raises(ValueError, match="valid SQLite database"):
            ctx.system.restore(invalid_backup)

        assert db.fetch_one(
            "SELECT value FROM app_settings WHERE key='company_name'"
        )["value"] == "Protected"


def test_global_search():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M100", "Hans", "Search")
        ctx.projects.create("Álvur Restoration", "Historic vessel project")
        ctx.tasks.create("Prepare restoration application")
        results = ctx.search.search("Hans")
        assert any(x["entity"] == "Member" for x in results)
        results = ctx.search.search("Álvur")
        assert any(x["entity"] == "Project" for x in results)
        results = ctx.search.search("restoration")
        assert any(x["entity"] == "Project" for x in results)
        assert any(x["entity"] == "Task" for x in results)



def test_step213_global_search_boundary_preserves_existing_project_search_contract():
    """Step 213: verify the project-facing global-search boundary without changing search architecture."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        project_id = ctx.projects.create("Step 213 Search Project", "Boundary search project")
        activity_id = ctx.projects.create_activity(project_id, "Search Activity")
        task_id = ctx.projects.create_project_task(project_id, "Search Task", "Boundary task")
        member_id = ctx.members.create_member("M213", "Search", "Member")

        result = ctx.projects.global_search("Search", limit=20)

        assert result["query"] == "Search"
        assert result["limit"] == 20
        assert result["read_only"] is True
        assert result["count"] == len(result["results"])

        by_type = {(item["type"], item["id"]): item for item in result["results"]}
        assert ("Projekt", project_id) in by_type
        assert ("Aktivitet", activity_id) in by_type
        assert ("Opgave", task_id) in by_type
        assert ("Medlem", member_id) in by_type

        assert by_type[("Projekt", project_id)]["context"] == "project"
        assert by_type[("Projekt", project_id)]["action"] == "open_project"
        assert by_type[("Aktivitet", activity_id)]["context"] == "activity"
        assert by_type[("Aktivitet", activity_id)]["action"] == "open_activity"
        assert by_type[("Opgave", task_id)]["context"] == "task"
        assert by_type[("Opgave", task_id)]["action"] == "open_task"
        assert by_type[("Medlem", member_id)]["context"] == "member"
        assert by_type[("Medlem", member_id)]["action"] == "open_member"

        empty = ctx.projects.global_search("   ")
        assert empty["query"] == ""
        assert empty["results"] == []
        assert empty["count"] == 0

        with pytest.raises(ValueError, match="Invalid search limit"):
            ctx.projects.global_search("Search", 0)

def test_exports():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M300", "Export", "Test")
        ctx.projects.create("Export Project")
        member_file = base / "members.csv"
        project_file = base / "projects.csv"
        ctx.export.export_members(member_file)
        ctx.export.export_projects(project_file)
        assert "Export,Test" in member_file.read_text(encoding="utf-8-sig")
        assert "Export Project" in project_file.read_text(encoding="utf-8-sig")


def test_organization_settings():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.organization.save(
            "Álvur Preservation Association",
            "12345678",
            "Harbour Road 1",
            "5000",
            "Odense",
            "Denmark",
            "info@example.org",
            "+45 12345678",
            "DKK",
            1
        )
        org = ctx.organization.get()
        assert org["name"] == "Álvur Preservation Association"
        assert org["currency"] == "DKK"
        assert org["fiscal_year_start"] == 1


def test_role_permissions():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        assert ctx.permissions.can(admin, "users.manage")
        manager_role = ctx.users.repo.get_role("Manager")
        manager_id = ctx.users.repo.create_user(
            "manager", "Manager User", ctx.users._hash("pw"), manager_role["id"]
        )
        manager = ctx.users.authenticate("manager", "pw")
        assert manager is not None
        assert ctx.permissions.can(manager, "projects.edit")
        assert not ctx.permissions.can(manager, "users.manage")
        user_role = ctx.users.repo.get_role("User")
        ctx.users.repo.create_user(
            "basic", "Basic User", ctx.users._hash("pw"), user_role["id"]
        )
        basic = ctx.users.authenticate("basic", "pw")
        assert ctx.permissions.can(basic, "projects.view")
        assert not ctx.permissions.can(basic, "projects.edit")


def test_audit_and_error_logging():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.audit.success(admin, "TEST_ACTION", "Test", 1, "Completed")
        rows = ctx.audit.list()
        assert rows[0]["action"] == "TEST_ACTION"
        assert rows[0]["status"] == "SUCCESS"
        ctx.audit.failure(admin, "TEST_FAILURE", "Test", 2, "Example failure")
        rows = ctx.audit.list()
        assert rows[0]["status"] == "FAILURE"
        assert rows[0]["message"] == "Example failure"



def test_step195_accounting_audit_event_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        event_id = ctx.accounting.audit_event(
            "STEP195_TEST", "journal", 42,
            "Accounting audit boundary test.",
            actor="tester",
            metadata={"source": "step195", "severity": "info"},
        )

        assert event_id == 1
        rows = ctx.accounting.audit_events(entity_type="journal", entity_id=42)
        assert len(rows) == 1
        row = rows[0]
        assert row["event_type"] == "STEP195_TEST"
        assert row["entity_type"] == "journal"
        assert row["entity_id"] == 42
        assert row["description"] == "Accounting audit boundary test."
        assert row["actor"] == "tester"
        assert '"source": "step195"' in row["metadata"]

        assert ctx.accounting.audit_events(entity_type="journal", entity_id=99) == []


def test_windows_packaging_assets():
    root = Path(__file__).resolve().parents[1]
    assert (root / "VERSION").read_text(encoding="utf-8").strip() == "1.7.0"
    assert (root / "run_mfm.py").exists()
    assert (root / "build_windows.ps1").exists()
    assert (root / "build_windows.bat").exists()
    assert (root / "DEPLOYMENT.md").exists()


def test_ai_insights_are_read_only():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.organization.save("AI Test Organization")
        before = db.fetch_one("SELECT COUNT(*) c FROM audit_log")["c"]
        insights = ctx.ai.insights()
        after = db.fetch_one("SELECT COUNT(*) c FROM audit_log")["c"]
        assert insights
        assert before == after


def test_natural_language_queries():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M500", "Query", "Member")
        answer = ctx.query.answer("Hvor mange medlemmer har vi?")
        assert "1" in answer
        finance = ctx.query.answer("Hvordan ser økonomien ud?")
        assert "Resultat:" in finance
        bank = ctx.query.answer("Hvordan ser bankafstemningen ud?")
        assert "Ikke-afstemte:" in bank


def test_recommendations():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main")
        ctx.bank.import_transaction(bank_id, 100, "Unmatched")
        recs = ctx.recommendations.analyze()
        assert any(r["area"] == "Bank" for r in recs)
        assert all("reason" in r for r in recs)


def test_unified_assistant():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.members.create_member("M900", "Assistant", "Test")
        status = ctx.assistant.respond("Hvordan går det?")
        assert "Resultat:" in status
        members = ctx.assistant.respond("Hvor mange medlemmer har vi?")
        assert "1" in members
        advice = ctx.assistant.respond("Hvad bør jeg gøre?")
        assert advice


def test_explainable_recommendations():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main")
        ctx.bank.import_transaction(bank_id, 100, "Needs matching")
        rows = ctx.explainability.recommendations_with_sources()
        bank_rows = [r for r in rows if r["area"] == "Bank"]
        assert bank_rows
        assert bank_rows[0]["sources"][0]["source"] == "bank_transactions"
        assert "MFM-datakilde" in bank_rows[0]["explanation"]


def test_forecast():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        income = next(a for a in accounts if a["number"] == "3000")
        expense = next(a for a in accounts if a["number"] == "5000")

        bank = next(a for a in accounts if a["number"] == "1000")
        ctx.accounting.post_journal(
            1, "January", [
                {"account_id": bank["id"], "debit": 1000, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 1000},
            ], "2026-01-15"
        )
        ctx.accounting.post_journal(
            2, "January expense", [
                {"account_id": expense["id"], "debit": 600, "credit": 0},
                {"account_id": bank["id"], "debit": 0, "credit": 600},
            ], "2026-01-20"
        )
        ctx.accounting.post_journal(
            3, "February", [
                {"account_id": bank["id"], "debit": 1200, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 1200},
            ], "2026-02-15"
        )
        ctx.accounting.post_journal(
            4, "February expense", [
                {"account_id": expense["id"], "debit": 700, "credit": 0},
                {"account_id": bank["id"], "debit": 0, "credit": 700},
            ], "2026-02-20"
        )
        result = ctx.forecast.forecast(3)
        assert result["available"] is True
        assert len(result["forecasts"]) == 3
        assert result["forecasts"][0]["value"] > 0


def test_project_financial_forecast_requires_history():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project = ctx.projects.create("Forecast Project", budget=1000)
        result = ctx.projects.financial_forecast(project, 1)
        assert result["available"] is False



def test_backup_does_not_overwrite_existing_recovery_point():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        backup = base / "backup.db"
        ctx.system.backup(backup)
        original = backup.read_bytes()
        with pytest.raises(FileExistsError):
            ctx.system.backup(backup)
        assert backup.read_bytes() == original


def test_export_creates_audit_record_and_refuses_overwrite():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.current_user = admin
        ctx.members.create_member("M901", "Audit", "Export")
        path = base / "members.csv"
        ctx.export.export_members(path)
        rows = ctx.audit.list()
        assert any(r["action"] == "EXPORT" and r["entity_type"] == "members"
                   and r["status"] == "SUCCESS" for r in rows)
        original = path.read_bytes()
        with pytest.raises(FileExistsError):
            ctx.export.export_members(path)
        assert path.read_bytes() == original
        rows = ctx.audit.list()
        assert any(r["action"] == "EXPORT" and r["entity_type"] == "members"
                   and r["status"] == "FAILURE" for r in rows)


def test_restore_rejects_valid_sqlite_that_is_not_an_mfm_database():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        source = base / "unrelated.db"
        with sqlite3.connect(source) as conn:
            conn.execute("CREATE TABLE unrelated(id INTEGER PRIMARY KEY)")
            conn.commit()
        before = db.fetch_one("SELECT COUNT(*) AS n FROM users")["n"]
        with pytest.raises(ValueError, match="not a valid MFM database"):
            ctx.system.restore(source)
        after = db.fetch_one("SELECT COUNT(*) AS n FROM users")["n"]
        assert after == before


def test_bank_match_is_atomic_when_status_update_fails():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.current_user = admin
        # Satisfy the journal foreign key with a real journal.
        account = next(
            (a for a in ctx.accounting.repo.list_accounts() if a["number"] == "1000"),
            None,
        )
        if account is None:
            account_id = ctx.accounting.create_account("1000", "Test Account", "Asset")
            account = ctx.accounting.repo.get_account(account_id)
        journal = ctx.accounting.repo.create_posted_journal(
            "ATOMIC-001", "2026-08-20", "Atomic test",
            [(account["id"], "Atomic", 10.0, 0.0, None)]
        )
        bank_id = db.execute(
            "INSERT INTO bank_accounts(name,account_number) VALUES(?,?)",
            ("Test Bank", "123"),
        )
        tx = ctx.accounting.repo.create_bank_transaction(
            bank_id, "2026-08-20", 10.0, "Atomic", "EXT-ATOMIC", "Unmatched"
        )
        with db.connect() as conn:
            conn.execute(
                "CREATE TRIGGER fail_bank_status BEFORE UPDATE OF status ON bank_transactions "
                "BEGIN SELECT RAISE(ABORT, 'forced status failure'); END;"
            )
        with pytest.raises(Exception, match="forced status failure"):
            ctx.accounting.repo.match_bank_transaction_atomic(tx, journal, 10.0)
        assert ctx.accounting.repo.get_bank_match(tx) is None
        current = next(
            r for r in ctx.accounting.repo.list_bank_transactions()
            if r["id"] == tx
        )
        assert current["status"] == "Unmatched"
        assert current["journal_id"] is None


def test_membership_payment_is_atomic_when_invoice_status_update_fails():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member("AT51", "Atomic", "Payment")
        mtype = ctx.members.create_membership_type("Atomic", 500)
        membership_id = ctx.members.add_membership(member_id, mtype)
        invoice_id = ctx.members.invoice_membership(membership_id, member_id, 500)
        with db.connect() as conn:
            conn.execute(
                "CREATE TRIGGER fail_invoice_status BEFORE UPDATE OF status ON membership_invoices "
                "BEGIN SELECT RAISE(ABORT, 'forced invoice status failure'); END;"
            )
        with pytest.raises(Exception, match="forced invoice status failure"):
            ctx.members.register_payment(invoice_id, 500, "2026-08-20")
        assert db.fetch_one(
            "SELECT COUNT(*) AS n FROM membership_payments WHERE invoice_id=?",
            (invoice_id,),
        )["n"] == 0
        assert db.fetch_one(
            "SELECT status FROM membership_invoices WHERE id=?", (invoice_id,)
        )["status"] == "Open"


def test_bank_import_batch_is_atomic_when_one_row_fails():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = db.execute(
            "INSERT INTO bank_accounts(name,account_number) VALUES(?,?)",
            ("Import Test Bank", "B52"),
        )
        with db.connect() as conn:
            conn.execute(
                "CREATE TRIGGER fail_second_import BEFORE INSERT ON bank_transactions "
                "WHEN NEW.external_reference='FAIL-52' "
                "BEGIN SELECT RAISE(ABORT, 'forced import failure'); END;"
            )
        rows = [
            {"transaction_date":"2026-08-20","amount":10.0,
             "description":"First","external_reference":"OK-52"},
            {"transaction_date":"2026-08-20","amount":20.0,
             "description":"Second","external_reference":"FAIL-52"},
        ]
        with pytest.raises(Exception, match="forced import failure"):
            ctx.accounting.import_bank_transactions(bank_id, rows)
        assert db.fetch_one(
            "SELECT COUNT(*) AS n FROM bank_transactions WHERE bank_account_id=?",
            (bank_id,),
        )["n"] == 0


def test_project_budget_update_keeps_legacy_and_normalized_budget_in_sync():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Budget Sync", budget=100)
        ctx.projects.set_budget(project_id, 250)
        project = db.fetch_one("SELECT budget FROM projects WHERE id=?", (project_id,))
        normalized = db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",
            (project_id,),
        )
        assert float(project["budget"]) == 250.0
        assert float(normalized["budget_amount"]) == 250.0


def test_step194_voucher_document_lifecycle_boundary():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        account = next(a for a in ctx.accounting.repo.list_accounts() if a["number"] == "1000")
        journal = ctx.accounting.repo.create_posted_journal(
            "DOC-194", "2026-08-21", "Voucher document lifecycle",
            [(account["id"], "Document", 25.0, 0.0, None)]
        )
        source = base / "invoice-194.txt"
        source.write_text("voucher document 194", encoding="utf-8")
        storage = base / "attachments"

        doc_id = ctx.accounting.attach_voucher_document(
            journal, source, "Supplier invoice", storage
        )
        doc = ctx.accounting.voucher_document(doc_id)
        assert doc["file_name"] == source.name
        assert doc["description"] == "Supplier invoice"
        assert doc["mime_type"] == "text/plain"
        assert doc["file_size"] == source.stat().st_size
        import hashlib
        expected_digest = hashlib.sha256(source.read_bytes()).hexdigest()
        assert doc["sha256"] == expected_digest
        stored = Path(doc["stored_name"])
        assert stored.exists()
        assert stored.parent == storage
        assert stored.name == f"DOC-194_{expected_digest[:12]}_{source.name}"

        listed = ctx.accounting.voucher_documents(journal)
        assert [row["id"] for row in listed] == [doc_id]

        assert ctx.accounting.remove_voucher_document(doc_id) is True
        assert not stored.exists()
        assert ctx.accounting.voucher_document(doc_id) is None


def test_voucher_document_delete_does_not_remove_db_record_when_file_delete_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        account = next(a for a in ctx.accounting.repo.list_accounts() if a["number"] == "1000")
        journal = ctx.accounting.repo.create_posted_journal(
            "DOC-54", "2026-08-20", "Document delete safety",
            [(account["id"], "Document", 10.0, 0.0, None)]
        )
        storage = base / "storage"
        storage.mkdir()
        source = base / "source.txt"
        source.write_text("voucher", encoding="utf-8")
        stored = storage / "voucher-54.txt"
        stored.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
        doc_id = ctx.accounting.repo.add_voucher_document(
            journal,
            source.name,
            str(stored),
            "text/plain",
            stored.stat().st_size,
            "test-sha-54",
            "Test document",
            "2026-08-20T12:00:00",
        )
        doc = ctx.accounting.voucher_document(doc_id)
        target = Path(doc["stored_name"])
        assert target.exists()

        original_unlink = Path.unlink
        def fail_unlink(self, *args, **kwargs):
            if self == target:
                raise OSError("forced storage delete failure")
            return original_unlink(self, *args, **kwargs)
        monkeypatch.setattr(Path, "unlink", fail_unlink)

        with pytest.raises(ValueError, match="could not be removed from storage"):
            ctx.accounting.remove_voucher_document(doc_id)

        assert ctx.accounting.voucher_document(doc_id) is not None
        assert target.exists()


def test_export_cleans_partial_temp_file_when_write_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        target = base / "members.csv"
        class FailingWriter:
            def writerow(self, row):
                pass
            def writerows(self, rows):
                raise OSError("forced export failure")
        def fake_writer(fh):
            return FailingWriter()
        monkeypatch.setattr(csv, "writer", fake_writer)
        with pytest.raises(OSError, match="forced export failure"):
            ctx.export.export_members(target)
        assert not target.exists()
        assert not target.with_name(target.name + ".tmp").exists()


def test_forced_password_change_does_not_store_plaintext_password_in_main_window():
    text = (Path(__file__).resolve().parents[1] / "src" / "gui" / "main_window.py").read_text(
        encoding="utf-8"
    )
    assert "_last_new_password" not in text
    assert "authenticate(username.get(), self._last_new_password)" not in text


def test_error_service_does_not_silently_swallow_audit_failure(caplog):
    class FailingAudit:
        def failure(self, user, action, message):
            raise RuntimeError("forced audit failure")

    service = ErrorService(FailingAudit())
    with caplog.at_level(logging.ERROR):
        result = service.handle(
            RuntimeError("primary operation failure"),
            user="admin",
            action="STEP57_TEST",
        )
    assert result == "primary operation failure"
    assert any("MFM audit failure while handling action STEP57_TEST" in r.message
               for r in caplog.records)


def test_backup_cleans_partial_destination_when_copy_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        destination = base / "failed_backup.db"

        def partial_copy(src, dst, *args, **kwargs):
            Path(dst).write_bytes(b"partial-backup")
            raise OSError("forced backup copy failure")

        monkeypatch.setattr(shutil, "copy2", partial_copy)
        with pytest.raises(OSError, match="forced backup copy failure"):
            ctx.system.backup(destination)
        assert not destination.exists()


def test_restore_rolls_back_when_replacement_copy_fails(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        original_value = db.fetch_one(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users'"
        )["name"]
        backup = base / "backup.db"
        ctx.system.backup(backup)

        original_copy2 = shutil.copy2
        calls = {"n": 0}
        def fail_restore_copy(src, dst, *args, **kwargs):
            if Path(dst) == db.path:
                calls["n"] += 1
                if calls["n"] == 1:
                    Path(dst).write_bytes(b"partial-restore")
                    raise OSError("forced restore replacement failure")
            return original_copy2(src, dst, *args, **kwargs)

        monkeypatch.setattr(shutil, "copy2", fail_restore_copy)
        with pytest.raises(OSError, match="forced restore replacement failure"):
            ctx.system.restore(backup)

        restored = Database(db.path)
        assert restored.fetch_one(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users'"
        )["name"] == original_value
        assert db.path.exists()


def test_restore_rejects_active_database_as_restore_source():
    with tempfile.TemporaryDirectory() as d:
        base = Path(d)
        db = Database(base / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="active MFM database"):
            ctx.system.restore(db.path)


def test_create_project_task_rejects_invalid_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 61")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.create_project_task(
                project_id, "Bad date task", due_date="2026-99-99"
            )


def test_create_project_task_rejects_invalid_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 61")
        with pytest.raises(ValueError, match="Invalid task status"):
            ctx.projects.create_project_task(
                project_id, "Bad status task", status="Bogus"
            )


def test_update_project_task_rejects_invalid_due_date_and_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 62")
        task_id = ctx.projects.create_project_task(project_id, "Update validation")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.update_project_task(task_id, due_date="2026-99-99")
        with pytest.raises(ValueError, match="Invalid task status"):
            ctx.projects.update_project_task(task_id, status="Bogus")


def test_triage_work_item_rejects_invalid_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 63")
        task_id = ctx.projects.create_project_task(project_id, "Triage validation")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.triage_work_item(task_id, due_date="2026-99-99")


def test_quick_action_deadline_rejects_invalid_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 64")
        task_id = ctx.projects.create_project_task(project_id, "Quick action validation")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.quick_action(task_id, "deadline", "2026-99-99")


def test_create_project_task_normalizes_assignee_whitespace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 65")
        task_id = ctx.projects.create_project_task(
            project_id, "Assignment normalization", assigned_to="  Alice  "
        )
        task = ctx.projects.repo.task_by_id(task_id)
        assert task["assigned_to"] == "Alice"


def test_update_project_task_normalizes_assignee_whitespace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 65 update")
        task_id = ctx.projects.create_project_task(project_id, "Assignment update")
        ctx.projects.update_project_task(task_id, assigned_to="  Bob  ")
        task = ctx.projects.repo.task_by_id(task_id)
        assert task["assigned_to"] == "Bob"


def test_update_project_task_rejects_activity_from_another_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 66 A")
        project_b = ctx.projects.create("Step 66 B")
        activity_b = ctx.projects.create_activity(project_b, "Foreign activity")
        task_a = ctx.projects.create_project_task(project_a, "Activity ownership")
        with pytest.raises(ValueError, match="Activity does not belong"):
            ctx.projects.update_project_task(task_a, activity_id=activity_b)


def test_update_project_task_rejects_blank_title():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 67")
        task_id = ctx.projects.create_project_task(project_id, "Original title")
        with pytest.raises(ValueError, match="Task title is required"):
            ctx.projects.update_project_task(task_id, title="   ")
        assert ctx.projects.repo.task_by_id(task_id)["title"] == "Original title"


def test_update_project_task_rejects_unknown_task():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project task not found"):
            ctx.projects.update_project_task(999999, title="Does not exist")


def test_update_activity_rejects_blank_name():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 69")
        activity_id = ctx.projects.create_activity(project_id, "Original activity")
        with pytest.raises(ValueError, match="Activity name is required"):
            ctx.projects.update_activity(activity_id, name="   ")
        assert ctx.projects.repo.db.fetch_one(
            "SELECT name FROM activities WHERE id=?", (activity_id,)
        )["name"] == "Original activity"


def test_update_activity_rejects_unknown_activity():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Activity not found"):
            ctx.projects.update_activity(999999, name="Does not exist")


def test_update_activity_rejects_cross_project_reparenting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 70 A")
        project_b = ctx.projects.create("Step 70 B")
        activity_id = ctx.projects.create_activity(project_a, "Protected activity")
        with pytest.raises(ValueError, match="Activity project cannot be changed"):
            ctx.projects.update_activity(activity_id, project_id=project_b)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id FROM activities WHERE id=?", (activity_id,)
        )
        assert int(row["project_id"]) == int(project_a)


def test_create_activity_rejects_invalid_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 71 create")
        with pytest.raises(ValueError, match="Invalid activity date"):
            ctx.projects.create_activity(project_id, "Date validation", activity_date="2026-99-99")


def test_update_activity_rejects_invalid_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 71 update")
        activity_id = ctx.projects.create_activity(project_id, "Date update", activity_date="2026-08-21")
        with pytest.raises(ValueError, match="Invalid activity date"):
            ctx.projects.update_activity(activity_id, activity_date="2026-99-99")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT activity_date FROM activities WHERE id=?", (activity_id,)
        )
        assert row["activity_date"] == "2026-08-21"


def test_create_project_rejects_invalid_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Invalid project status"):
            ctx.projects.create("Step 73 invalid", status="Bogus")


def test_create_project_normalizes_status_whitespace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 73 normalize", status=" Active ")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT status FROM projects WHERE id=?", (project_id,)
        )
        assert row["status"] == "Active"


def test_project_budget_rejects_non_finite_values():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.create("Step 74 finite project", budget=value)
        project_id = ctx.projects.create("Step 74 budget target")
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.set_budget(project_id, value)


def test_activity_budget_rejects_non_finite_values():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 74 activity budget")
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.create_activity(project_id, "Finite budget", budget=value)
        activity_id = ctx.projects.create_activity(project_id, "Budget update", budget=100)
        for value in ("nan", "inf", "-inf"):
            with pytest.raises(ValueError, match="finite number"):
                ctx.projects.update_activity(activity_id, budget=value)


def test_set_budget_rejects_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.set_budget(999999, 1000)


def test_project_budget_read_rejects_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.budget(999999)


def test_project_financial_reads_reject_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        methods = [
            ctx.projects.activity_summary,
            ctx.projects.financial_tracking,
            ctx.projects.financial_report,
            ctx.projects.financial_forecast,
            ctx.projects.expense_lines,
            ctx.projects.activity_financials,
            ctx.projects.activity_financial_detail,
            ctx.projects.project_control_dashboard,
            ctx.projects.project_tasks,
        ]
        for method in methods:
            with pytest.raises(ValueError, match="Project not found"):
                method(999999)


def test_update_project_task_rejects_cross_project_reparenting():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 78 A")
        project_b = ctx.projects.create("Step 78 B")
        task_id = ctx.projects.create_project_task(project_a, "Protected task")
        with pytest.raises(ValueError, match="Task project cannot be changed"):
            ctx.projects.update_project_task(task_id, project_id=project_b)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id FROM tasks WHERE id=?", (task_id,)
        )
        assert int(row["project_id"]) == int(project_a)


def test_project_execution_reads_reject_invalid_targets():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 79 A")
        project_b = ctx.projects.create("Step 79 B")
        activity_id = ctx.projects.create_activity(project_a, "Execution activity")
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.activities(999999)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.project_execution_view(999999)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.project_progress_control(999999)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.project_control_exceptions(999999)
        with pytest.raises(ValueError, match="Activity does not belong"):
            ctx.projects.activity_execution_view(project_b, activity_id)


def test_execution_action_rejects_unknown_project_before_task_mutation():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 80 project")
        task_id = ctx.projects.create_project_task(project_id, "Protected execution task")
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.execution_action(999999, task_id, "complete")
        assert ctx.projects.repo.task_by_id(task_id)["status"] == "Open"


def test_quick_capture_rejects_unknown_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.quick_capture("Invalid project task", project_id=999999)


def test_transition_task_requires_existing_parent_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 81 project")
        task_id = ctx.projects.create_project_task(project_id, "Transition task")
        db.execute("DELETE FROM projects WHERE id=?", (project_id,))
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.transition_project_task(task_id, "Completed")
        assert ctx.projects.repo.task_by_id(task_id)["status"] == "Open"


def test_update_task_status_uses_workflow_transition_rules():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 82 workflow")
        task_id = ctx.projects.create_project_task(project_id, "Workflow protected task")
        ctx.projects.update_project_task(task_id, status="In Progress")
        assert ctx.projects.repo.task_by_id(task_id)["status"] == "In Progress"
        with pytest.raises(ValueError, match="Invalid workflow transition"):
            ctx.projects.update_project_task(task_id, status="Closed")
        assert ctx.projects.repo.task_by_id(task_id)["status"] == "In Progress"


def test_triage_status_uses_workflow_transition_rules():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 82 triage")
        task_id = ctx.projects.create_project_task(project_id, "Triage workflow task")
        ctx.projects.triage_work_item(task_id, status="In Progress")
        with pytest.raises(ValueError, match="Invalid workflow transition"):
            ctx.projects.triage_work_item(task_id, status="Closed")
        assert ctx.projects.repo.task_by_id(task_id)["status"] == "In Progress"


def test_create_project_task_requires_existing_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.create_project_task(999999, "Invalid parent task")


def test_triage_requires_existing_parent_project_even_without_status_change():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 83 triage")
        task_id = ctx.projects.create_project_task(project_id, "Orphan triage task")
        db.execute("DELETE FROM projects WHERE id=?", (project_id,))
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.triage_work_item(task_id, assigned_to="Alice")


def test_quick_action_requires_existing_parent_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 83 quick")
        task_id = ctx.projects.create_project_task(project_id, "Orphan quick task")
        db.execute("DELETE FROM projects WHERE id=?", (project_id,))
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.quick_action(task_id, "assign", "Alice")


def test_update_activity_requires_existing_parent_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 84 activity")
        activity_id = ctx.projects.create_activity(project_id, "Orphan activity")
        import sqlite3
        with sqlite3.connect(db.path) as conn:
            conn.execute("PRAGMA foreign_keys=OFF")
            conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
            conn.commit()
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.update_activity(activity_id, name="Blocked update")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT name FROM activities WHERE id=?", (activity_id,)
        )
        assert row["name"] == "Orphan activity"


def test_update_activity_validates_status_without_bypassing_project_integrity():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 85 activity status")
        activity_id = ctx.projects.create_activity(project_id, "Status activity")
        with pytest.raises(ValueError, match="Invalid activity status"):
            ctx.projects.update_activity(activity_id, status="NotAStatus")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT status FROM activities WHERE id=?", (activity_id,)
        )
        assert row["status"] == "Planned"


def test_activity_status_workflow_prevents_direct_bypass():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 86 activity workflow")
        activity_id = ctx.projects.create_activity(project_id, "Workflow activity")
        ctx.projects.update_activity(activity_id, status="Active")
        ctx.projects.update_activity(activity_id, status="Completed")
        with pytest.raises(ValueError, match="Invalid activity workflow transition"):
            ctx.projects.update_activity(activity_id, status="Planned")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT status FROM activities WHERE id=?", (activity_id,)
        )
        assert row["status"] == "Completed"


def test_activity_status_workflow_allows_normal_progression():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 86 progression")
        activity_id = ctx.projects.create_activity(project_id, "Progression activity")
        ctx.projects.update_activity(activity_id, status="Active")
        ctx.projects.update_activity(activity_id, status="On Hold")
        ctx.projects.update_activity(activity_id, status="Active")
        ctx.projects.update_activity(activity_id, status="Completed")
        assert ctx.projects.repo.db.fetch_one(
            "SELECT status FROM activities WHERE id=?", (activity_id,)
        )["status"] == "Completed"


def test_create_activity_requires_planned_initial_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 87 activity creation")
        with pytest.raises(ValueError, match="New activities must start in Planned"):
            ctx.projects.create_activity(project_id, "Invalid initial activity", status="Active")
        assert ctx.projects.activities(project_id) == []


def test_create_activity_rejects_unknown_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 87 status validation")
        with pytest.raises(ValueError, match="Invalid activity status"):
            ctx.projects.create_activity(project_id, "Invalid status", status="Unknown")
        assert ctx.projects.activities(project_id) == []


def test_update_activity_rejects_negative_budget():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 88 budget")
        activity_id = ctx.projects.create_activity(project_id, "Budget activity", budget=100)
        with pytest.raises(ValueError, match="Activity budget cannot be negative"):
            ctx.projects.update_activity(activity_id, budget=-1)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT budget FROM activities WHERE id=?", (activity_id,)
        )
        assert float(row["budget"]) == 100.0


def test_update_activity_rejects_non_numeric_budget():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 88 budget type")
        activity_id = ctx.projects.create_activity(project_id, "Budget type activity", budget=50)
        with pytest.raises(ValueError, match="Invalid activity budget"):
            ctx.projects.update_activity(activity_id, budget="not-a-number")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT budget FROM activities WHERE id=?", (activity_id,)
        )
        assert float(row["budget"]) == 50.0


def test_create_activity_normalizes_budget_to_two_decimals():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 89 budget normalization")
        activity_id = ctx.projects.create_activity(project_id, "Normalized budget", budget=123.456)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT budget FROM activities WHERE id=?", (activity_id,)
        )
        assert float(row["budget"]) == 123.46


def test_create_activity_rejects_non_numeric_budget_with_domain_error():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 89 budget type")
        with pytest.raises(ValueError, match="Invalid activity budget"):
            ctx.projects.create_activity(project_id, "Invalid budget", budget="abc")
        assert ctx.projects.activities(project_id) == []


def test_update_activity_can_clear_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 90 date")
        activity_id = ctx.projects.create_activity(
            project_id, "Date activity", activity_date="2026-08-21"
        )
        ctx.projects.update_activity(activity_id, activity_date=None)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT activity_date FROM activities WHERE id=?", (activity_id,)
        )
        assert row["activity_date"] is None


def test_update_activity_rejects_invalid_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 90 invalid date")
        activity_id = ctx.projects.create_activity(
            project_id, "Invalid date activity", activity_date="2026-08-21"
        )
        with pytest.raises(ValueError, match="Invalid activity date"):
            ctx.projects.update_activity(activity_id, activity_date="2026-99-99")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT activity_date FROM activities WHERE id=?", (activity_id,)
        )
        assert row["activity_date"] == "2026-08-21"


def test_update_activity_rejects_unsupported_fields():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 91 fields")
        activity_id = ctx.projects.create_activity(project_id, "Field contract")
        with pytest.raises(ValueError, match="Unsupported activity fields"):
            ctx.projects.update_activity(activity_id, arbitrary_field="blocked")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT name FROM activities WHERE id=?", (activity_id,)
        )
        assert row["name"] == "Field contract"


def test_update_activity_rejects_empty_update():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 91 empty")
        activity_id = ctx.projects.create_activity(project_id, "Empty update")
        with pytest.raises(ValueError, match="No activity fields supplied"):
            ctx.projects.update_activity(activity_id)


def test_update_activity_rejects_invalid_project_id():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 92 project id")
        activity_id = ctx.projects.create_activity(project_id, "Project id activity")
        with pytest.raises(ValueError, match="Invalid activity project id"):
            ctx.projects.update_activity(activity_id, project_id="abc")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id FROM activities WHERE id=?", (activity_id,)
        )
        assert row["project_id"] == project_id


def test_update_activity_rejects_null_project_id():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 92 null project")
        activity_id = ctx.projects.create_activity(project_id, "Null project activity")
        with pytest.raises(ValueError, match="Invalid activity project id"):
            ctx.projects.update_activity(activity_id, project_id=None)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id FROM activities WHERE id=?", (activity_id,)
        )
        assert row["project_id"] == project_id


def test_create_activity_normalizes_null_description_to_empty():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 93 description")
        activity_id = ctx.projects.create_activity(project_id, "Null description", description=None)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT description FROM activities WHERE id=?", (activity_id,)
        )
        assert row["description"] == ""


def test_create_activity_treats_empty_date_as_no_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 93 date")
        activity_id = ctx.projects.create_activity(project_id, "Empty date", activity_date="")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT activity_date FROM activities WHERE id=?", (activity_id,)
        )
        assert row["activity_date"] is None


def test_update_activity_rejects_project_id_only_update():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 94 project only")
        activity_id = ctx.projects.create_activity(project_id, "Project-only update")
        with pytest.raises(ValueError, match="Project ID is validation-only"):
            ctx.projects.update_activity(activity_id, project_id=project_id)
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id, name FROM activities WHERE id=?", (activity_id,)
        )
        assert row["project_id"] == project_id
        assert row["name"] == "Project-only update"


def test_update_activity_allows_project_id_validation_with_real_update():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 94 combined")
        activity_id = ctx.projects.create_activity(project_id, "Original")
        ctx.projects.update_activity(activity_id, project_id=project_id, name="Updated")
        row = ctx.projects.repo.db.fetch_one(
            "SELECT project_id, name FROM activities WHERE id=?", (activity_id,)
        )
        assert row["project_id"] == project_id
        assert row["name"] == "Updated"


def test_activities_returns_independent_dict_records():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 95 records")
        ctx.projects.create_activity(project_id, "Activity record")
        rows = ctx.projects.activities(project_id)
        assert len(rows) == 1
        assert isinstance(rows[0], dict)
        assert rows[0]["name"] == "Activity record"
        rows[0]["name"] = "Mutated caller copy"
        persisted = ctx.projects.repo.db.fetch_one(
            "SELECT name FROM activities WHERE id=?", (rows[0]["id"],)
        )
        assert persisted["name"] == "Activity record"


def test_activities_returns_empty_list_for_project_without_activities():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 95 empty")
        rows = ctx.projects.activities(project_id)
        assert rows == []
        assert isinstance(rows, list)


def test_activities_normalizes_budget_in_read_model():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 96 budget read model")
        activity_id = ctx.projects.create_activity(project_id, "Budget read", budget=123.456)
        ctx.projects.repo.db.execute(
            "UPDATE activities SET budget=? WHERE id=?", (123.4567, activity_id)
        )
        row = ctx.projects.activities(project_id)[0]
        assert row["budget"] == 123.46


def test_activities_preserves_zero_budget_as_float():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 96 zero budget")
        ctx.projects.create_activity(project_id, "Zero budget", budget=0)
        row = ctx.projects.activities(project_id)[0]
        assert row["budget"] == 0.0
        assert isinstance(row["budget"], float)


def test_activities_rejects_invalid_persisted_status():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 97 status read model")
        activity_id = ctx.projects.create_activity(project_id, "Status read")
        ctx.projects.repo.db.execute(
            "UPDATE activities SET status=? WHERE id=?", ("CorruptStatus", activity_id)
        )
        with pytest.raises(ValueError, match="Invalid stored activity status"):
            ctx.projects.activities(project_id)


def test_activities_accepts_all_supported_persisted_statuses():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 97 valid statuses")
        statuses = ["Planned", "Active", "On Hold", "Completed", "Cancelled"]
        for i, status in enumerate(statuses):
            aid = ctx.projects.create_activity(project_id, f"Status {i}")
            ctx.projects.repo.db.execute(
                "UPDATE activities SET status=? WHERE id=?", (status, aid)
            )
        rows = ctx.projects.activities(project_id)
        assert {r["status"] for r in rows} == set(statuses)


def test_activities_rejects_invalid_persisted_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 98 date read model")
        activity_id = ctx.projects.create_activity(project_id, "Date read")
        ctx.projects.repo.db.execute(
            "UPDATE activities SET activity_date=? WHERE id=?", ("2026-99-99", activity_id)
        )
        with pytest.raises(ValueError, match="Invalid stored activity date"):
            ctx.projects.activities(project_id)


def test_activities_normalizes_empty_persisted_activity_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 98 empty date")
        activity_id = ctx.projects.create_activity(project_id, "Empty date")
        ctx.projects.repo.db.execute(
            "UPDATE activities SET activity_date=? WHERE id=?", ("", activity_id)
        )
        row = ctx.projects.activities(project_id)[0]
        assert row["activity_date"] is None


def test_activities_rejects_invalid_persisted_budget():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 99 invalid budget")
        activity_id = ctx.projects.create_activity(project_id, "Budget integrity")
        ctx.projects.repo.db.execute(
            "UPDATE activities SET budget=? WHERE id=?", ("not-a-number", activity_id)
        )
        with pytest.raises(ValueError, match="Invalid stored activity budget"):
            ctx.projects.activities(project_id)


def test_activities_rejects_negative_persisted_budget():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 99 negative budget")
        activity_id = ctx.projects.create_activity(project_id, "Budget integrity")
        ctx.projects.repo.db.execute(
            "UPDATE activities SET budget=? WHERE id=?", (-1, activity_id)
        )
        with pytest.raises(ValueError, match="Invalid stored activity budget"):
            ctx.projects.activities(project_id)


def test_activity_financials_returns_normalized_actuals():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 100 actuals")
        activity_id = ctx.projects.create_activity(project_id, "Actuals")
        # No posted expense lines means the authoritative derived actual is zero.
        rows = ctx.projects.activity_financials(project_id)
        assert len(rows) == 1
        assert rows[0]["id"] == activity_id
        assert rows[0]["actual"] == 0.0
        assert rows[0]["variance"] == 0.0
        assert isinstance(rows[0]["actual"], float)


def test_activity_financials_preserves_project_activity_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        p1 = ctx.projects.create("Step 100 p1")
        p2 = ctx.projects.create("Step 100 p2")
        ctx.projects.create_activity(p1, "P1 activity")
        ctx.projects.create_activity(p2, "P2 activity")
        rows = ctx.projects.activity_financials(p1)
        assert len(rows) == 1
        assert rows[0]["name"] == "P1 activity"


def test_financial_tracking_returns_stable_service_model():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 101 tracking", budget=1000)
        result = ctx.projects.financial_tracking(project_id)
        assert isinstance(result["project"], dict)
        assert result["budget"] == 1000.0
        assert result["activity_budget"] == 0.0
        assert result["activity_count"] == 0
        assert result["actual"] == 0.0
        assert result["variance"] == 1000.0
        assert result["utilization"] == 0.0
        result["project"]["name"] = "Caller mutation"
        persisted = ctx.projects.repo.db.fetch_one(
            "SELECT name FROM projects WHERE id=?", (project_id,)
        )
        assert persisted["name"] == "Step 101 tracking"


def test_financial_tracking_preserves_project_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        p1 = ctx.projects.create("Step 101 p1", budget=500)
        p2 = ctx.projects.create("Step 101 p2", budget=700)
        ctx.projects.create_activity(p1, "P1 activity", budget=100)
        result = ctx.projects.financial_tracking(p1)
        assert result["project"]["id"] == p1
        assert result["activity_budget"] == 100.0
        assert result["activity_count"] == 1
        assert result["project"]["id"] != p2


def test_financial_report_returns_stable_service_model():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 102 report", budget=1000)
        result = ctx.projects.financial_report(project_id)
        assert isinstance(result["project"], dict)
        assert result["budget"] == 1000.0
        assert result["actual"] == 0.0
        assert result["revenue"] == 0.0
        assert result["funding"] == 0.0
        assert result["project_result"] == 0.0
        assert result["variance"] == 1000.0
        assert result["utilization"] == 0.0
        assert result["read_only"] is True
        result["project"]["name"] = "Caller mutation"
        persisted = ctx.projects.repo.db.fetch_one(
            "SELECT name FROM projects WHERE id=?", (project_id,)
        )
        assert persisted["name"] == "Step 102 report"


def test_financial_report_preserves_project_financial_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 102 boundary", budget=250)
        activity_id = ctx.projects.create_activity(project_id, "Report activity", budget=100)
        result = ctx.projects.financial_report(project_id)
        assert result["project"]["id"] == project_id
        assert result["budget"] == 250.0
        assert result["actual"] == 0.0
        assert result["variance"] == 250.0
        assert result["read_only"] is True
        assert activity_id > 0


def test_financial_forecast_returns_stable_read_model_when_history_is_insufficient():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 103 forecast")
        result = ctx.projects.financial_forecast(project_id)
        assert result["available"] is False
        assert result["history"] == []
        assert result["forecasts"] == []
        assert result["confidence"] == "insufficient_history"
        assert result["confidence_score"] == 0.0
        assert result["read_only"] is True


def test_financial_forecast_preserves_advisory_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 103 advisory boundary")
        result = ctx.projects.financial_forecast(project_id, periods=1)
        assert result["available"] is False
        assert "warning" in result
        assert "read_only" in result
        assert "missing_months" in result




def test_project_control_dashboard_returns_stable_read_model():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 158 dashboard")
        result = ctx.projects.project_control_dashboard(project_id)
        assert result["project_id"] == project_id
        assert result["read_only"] is True
        for key in ("budget", "actual", "variance", "utilization",
                    "activity_budget", "activity_actual", "unallocated_actual"):
            assert isinstance(result[key], float)
            assert result[key] >= 0
        assert isinstance(result["activities"], list)
        assert isinstance(result["forecast_data_points"], int)
        assert isinstance(result["forecast_expected_months"], int)


def test_project_control_dashboard_validates_project():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.project_control_dashboard(999999)


def test_quick_action_dispatches_task_controls():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 159 quick action")
        task_id = ctx.projects.create_project_task(
            project_id, "Quick task", "Task", None, "Hans", "Normal",
            "2026-08-24", "Open"
        )
        result = ctx.projects.quick_action(task_id, "start")
        assert result["status"] == "In Progress"
        result = ctx.projects.quick_action(task_id, "priority", "Critical")
        assert result["priority"] == "Critical"
        result = ctx.projects.quick_action(task_id, "deadline", "2026-08-30")
        assert result["due_date"] == "2026-08-30"


def test_quick_action_rejects_invalid_inputs_and_unknown_task():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 159 validation")
        task_id = ctx.projects.create_project_task(
            project_id, "Validation task", "Task", None, "Hans", "Normal",
            None, "Open"
        )
        with pytest.raises(ValueError, match="Unknown quick action"):
            ctx.projects.quick_action(task_id, "delete")
        with pytest.raises(ValueError, match="Invalid priority"):
            ctx.projects.quick_action(task_id, "priority", "Urgent")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.quick_action(task_id, "deadline", "not-a-date")
        with pytest.raises(ValueError, match="Task not found"):
            ctx.projects.quick_action(999999, "start")


def test_execution_action_enforces_project_scope_and_dispatches():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 160 execution action")
        other_id = ctx.projects.create("Other project")
        task_id = ctx.projects.create_project_task(
            project_id, "Execution", "Task", None, "Hans", "Normal",
            None, "Open"
        )
        result = ctx.projects.execution_action(project_id, task_id, "start")
        assert result["status"] == "In Progress"
        with pytest.raises(ValueError, match="does not belong"):
            ctx.projects.execution_action(other_id, task_id, "complete")
        with pytest.raises(ValueError, match="Unknown execution action"):
            ctx.projects.execution_action(project_id, task_id, "delete")


def test_execution_action_requires_project_and_task_scope():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 160 validation")
        with pytest.raises(ValueError, match="Task does not belong"):
            ctx.projects.execution_action(project_id, 999999, "start")


def test_integrated_operations_action_dispatches_existing_boundaries():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 161 integrated action")
        task_id = ctx.projects.create_project_task(
            project_id, "Open task", "Task", None, "Hans", "Normal",
            None, "Open"
        )

        project = ctx.projects.integrated_operations_action("open_project", project_id=project_id)
        assert project["project"]["id"] == project_id

        tasks = ctx.projects.integrated_operations_action("open_tasks", project_id=project_id)
        assert {x["id"] for x in tasks["tasks"]} == {task_id}

        result = ctx.projects.integrated_operations_action(
            "start", project_id=project_id, task_id=task_id
        )
        assert result["status"] == "In Progress"

        exceptions = ctx.projects.integrated_operations_action(
            "open_exceptions", project_id=project_id
        )
        assert isinstance(exceptions["exceptions"], list)


def test_integrated_operations_action_validates_required_context():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        with pytest.raises(ValueError, match="Project is required"):
            ctx.projects.integrated_operations_action("open_project")

        with pytest.raises(ValueError, match="Project and task are required"):
            ctx.projects.integrated_operations_action("complete")

        with pytest.raises(ValueError, match="Unknown integrated operations action"):
            ctx.projects.integrated_operations_action("delete", project_id=1)

        with pytest.raises(ValueError, match="Project and exception are required"):
            ctx.projects.integrated_operations_action("create_exception_followup", project_id=1)


def test_contextual_action_dispatches_task_and_followup():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 162 contextual action")
        activity_id = ctx.projects.create_activity(project_id, "Context activity")
        task_id = ctx.projects.create_project_task(
            project_id, "Context task", "Task", activity_id, "Hans", "Normal",
            None, "Open"
        )

        result = ctx.projects.contextual_action("task", task_id, "start")
        assert result["status"] == "In Progress"

        related = ctx.projects.contextual_action(
            "task", task_id, "open_related",
            {"type": "activity", "id": activity_id}
        )
        assert related["record"]["id"] == activity_id

        followup = ctx.projects.contextual_action(
            "activity", activity_id, "create_followup", "Hans"
        )
        assert isinstance(followup["task_id"], int)


def test_contextual_action_validates_record_and_action():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 162 validation")
        activity_id = ctx.projects.create_activity(project_id, "Activity")

        with pytest.raises(ValueError, match="Unknown contextual action"):
            ctx.projects.contextual_action("activity", activity_id, "delete")

        with pytest.raises(ValueError, match="Related record type and id are required"):
            ctx.projects.contextual_action("activity", activity_id, "open_related", {})

        with pytest.raises(ValueError, match="Responsible person is required"):
            ctx.projects.contextual_action("activity", activity_id, "create_followup", "")


def test_unified_record_view_composes_related_data():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 163 unified project")
        activity_id = ctx.projects.create_activity(project_id, "Unified activity")
        task_id = ctx.projects.create_project_task(
            project_id, "Unified task", "Task", activity_id, "Hans", "High",
            None, "Open"
        )

        project = ctx.projects.unified_record_view("project", project_id)
        assert project["read_only"] is True
        assert project["type"] == "project"
        assert project["record"]["id"] == project_id
        assert {x["id"] for x in project["related"]["activities"]} == {activity_id}
        assert {x["id"] for x in project["related"]["tasks"]} == {task_id}

        activity = ctx.projects.unified_record_view("activity", activity_id)
        assert activity["record"]["id"] == activity_id
        assert {x["id"] for x in activity["related"]["tasks"]} == {task_id}

        task = ctx.projects.unified_record_view("task", task_id)
        assert task["related"]["project_id"] == project_id
        assert task["related"]["activity_id"] == activity_id
        assert "complete" in task["actions"]


def test_unified_record_view_validates_type_and_id():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Unknown record type"):
            ctx.projects.unified_record_view("invoice", 1)
        with pytest.raises(ValueError, match="Invalid record id"):
            ctx.projects.unified_record_view("project", 0)


def test_personal_workspace_builds_owner_task_summary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 164 personal workspace")
        ctx.projects.create_project_task(
            project_id, "Blocked task", "Task", None, "Hans", "High",
            None, "Blocked"
        )
        ctx.projects.create_project_task(
            project_id, "Open task", "Task", None, "Hans", "Normal",
            None, "Open"
        )
        result = ctx.projects.personal_workspace("Hans")
        assert result["summary"]["open"] == 2
        assert result["summary"]["blocked"] == 1
        assert len(result["blocked"]) == 1


def test_personal_workspace_empty_owner_returns_empty_workspace():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        result = ctx.projects.personal_workspace("")
        assert result["tasks"] == []
        assert result["summary"] == {"open": 0, "overdue": 0, "blocked": 0}


def test_personal_work_queue_returns_scoped_metrics():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 165 queue")
        ctx.projects.create_project_task(
            project_id, "Today", "Task", None, "Hans", "Critical",
            "2026-08-22", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Blocked", "Task", None, "Hans", "Normal",
            "2026-08-25", "Blocked"
        )
        ctx.projects.create_project_task(
            project_id, "Other", "Task", None, "Else", "Critical",
            "2026-08-22", "Open"
        )
        result = ctx.projects.personal_work_queue("Hans", "2026-08-22")
        assert result["person"] == "Hans"
        assert result["as_of"] == "2026-08-22"
        assert result["horizon"] == "2026-08-29"
        assert result["metrics"] == {
            "open": 2, "overdue": 0, "today": 1,
            "next_7_days": 2, "critical": 1, "blocked": 1
        }
        assert result["read_only"] is True


def test_personal_work_queue_validates_owner_and_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="responsible person"):
            ctx.projects.personal_work_queue("")
        with pytest.raises(ValueError, match="Invalid personal work queue date"):
            ctx.projects.personal_work_queue("Hans", "not-a-date")


def test_personal_work_action_dispatches_through_existing_execution_path():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 167 personal action")
        task_id = ctx.projects.create_project_task(
            project_id, "Personal task", "Task", None, "Hans", "Normal",
            None, "Open"
        )

        result = ctx.projects.personal_work_action("Hans", task_id, "start")
        assert result["task"]["id"] == task_id
        assert result["task"]["status"] == "In Progress"
        assert result["result"]["status"] == "In Progress"

        result = ctx.projects.personal_work_action("Hans", task_id, "complete")
        assert result["task"]["status"] == "Completed"
        assert result["result"]["status"] == "Completed"


def test_personal_work_action_enforces_owner_scope():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 167 owner scope")
        task_id = ctx.projects.create_project_task(
            project_id, "Owned task", "Task", None, "Hans", "Normal",
            None, "Open"
        )

        with pytest.raises(ValueError, match="not assigned to this user"):
            ctx.projects.personal_work_action("Else", task_id, "complete")

        assert ctx.projects.repo.task_by_id(task_id)["status"] == "Open"


def test_personal_work_action_validates_owner_task_and_action():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 167 validation")
        task_id = ctx.projects.create_project_task(
            project_id, "Validation task", "Task", None, "Hans", "Normal",
            None, "Open"
        )

        with pytest.raises(ValueError, match="Owner is required"):
            ctx.projects.personal_work_action("", task_id, "complete")
        with pytest.raises(ValueError, match="Task not found"):
            ctx.projects.personal_work_action("Hans", 999999, "complete")
        with pytest.raises(ValueError, match="Unknown personal work action"):
            ctx.projects.personal_work_action("Hans", task_id, "delete")


def test_personal_work_action_preserves_existing_task_model():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 167 task model")
        task_id = ctx.projects.create_project_task(
            project_id, "Reopenable task", "Task", None, "Hans", "High",
            "2026-08-30", "Completed"
        )

        result = ctx.projects.personal_work_action("Hans", task_id, "reopen")
        task = result["task"]
        assert task["id"] == task_id
        assert task["status"] == "Open"
        assert task["priority"] == "High"
        assert task["due_date"] == "2026-08-30"


def test_work_intake_inbox_returns_open_unassigned_tasks_in_repository_order():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 166 intake")
        activity_id = ctx.projects.create_activity(project_id, "Intake activity")

        critical_id = ctx.projects.create_project_task(
            project_id, "Critical intake", "Task", activity_id, None, "Critical",
            "2026-08-25", "Open"
        )
        normal_id = ctx.projects.create_project_task(
            project_id, "Normal intake", "Task", activity_id, "Hans", "Normal",
            "2026-08-24", "Open"
        )
        high_id = ctx.projects.create_project_task(
            project_id, "High intake", "Task", activity_id, "", "High",
            "2026-08-23", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Completed", "Task", activity_id, None, "Critical",
            "2026-08-22", "Completed"
        )

        result = ctx.projects.work_intake_inbox()

        assert result["rule"] == "Open + unassigned"
        assert result["needs_triage"] == 2
        assert result["count"] == 2
        assert [item["id"] for item in result["items"]] == [critical_id, high_id]
        assert result["items"][0]["project_name"] == "Step 166 intake"
        assert result["items"][0]["activity_name"] == "Intake activity"
        assert result["items"][0]["assigned_to"] in (None, "")
        assert result["items"][1]["assigned_to"] == ""
        assert normal_id not in {item["id"] for item in result["items"]}


def test_work_intake_inbox_is_read_only_service_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 166 read only")
        task_id = ctx.projects.create_project_task(
            project_id, "Unassigned", "Task", None, None, "Normal", None, "Open"
        )

        before = ctx.projects.repo.task_by_id(task_id)
        result = ctx.projects.work_intake_inbox()
        after = ctx.projects.repo.task_by_id(task_id)

        assert result["items"][0]["id"] == task_id
        assert before == after


def test_operational_workboard_composes_open_tasks_and_projects():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        project_id = ctx.projects.create("Step 168 workboard")
        ctx.projects.create_project_task(
            project_id, "Normal task", "Task", None, "Hans", "Normal",
            "2026-08-25", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Critical task", "Task", None, "Hans", "Critical",
            "2026-08-28", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Completed task", "Task", None, "Hans", "High",
            "2026-08-22", "Completed"
        )
        ctx.projects.create_project_task(
            project_id, "Closed task", "Task", None, "Hans", "High",
            "2026-08-22", "Closed"
        )

        result = ctx.projects.operational_workboard("2026-08-22")

        assert result["as_of"] == "2026-08-22"
        assert result["read_only"] is True
        assert [item["title"] for item in result["items"]] == [
            "Critical task", "Normal task"
        ]
        assert result["counts"] == {
            "total": 2,
            "open": 2,
            "high_priority": 1,
        }
        assert result["projects"][0]["id"] == project_id


def test_operational_workboard_orders_priority_then_due_date_then_title():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 168 workboard ordering")

        ctx.projects.create_project_task(
            project_id, "High later", "Task", None, "Hans", "High",
            "2026-08-30", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "High earlier", "Task", None, "Hans", "High",
            "2026-08-25", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Critical later", "Task", None, "Hans", "Critical",
            "2026-08-31", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Normal", "Task", None, "Hans", "Normal",
            None, "Open"
        )

        result = ctx.projects.operational_workboard("2026-08-22")

        assert [item["title"] for item in result["items"]] == [
            "Critical later", "High earlier", "High later", "Normal"
        ]


def test_operational_workboard_validates_date_and_stored_due_dates():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        with pytest.raises(ValueError, match="Invalid operational workboard date"):
            ctx.projects.operational_workboard("not-a-date")

        project_id = ctx.projects.create("Step 168 invalid due date")
        task_id = ctx.projects.create_project_task(
            project_id, "Bad date", "Task", None, "Hans", "Normal",
            "2026-08-25", "Open"
        )
        db.execute("UPDATE tasks SET due_date=? WHERE id=?", ("not-a-date", task_id))

        with pytest.raises(ValueError, match="Invalid operational workboard due date"):
            ctx.projects.operational_workboard("2026-08-22")


def test_operational_alerts_composes_task_alerts_and_counts():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 169 alerts", budget=1000)
        ctx.projects.create_project_task(
            project_id, "Overdue unassigned", "Task", None, "", "High",
            "2026-08-20", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Blocked soon", "Task", None, "Hans", "Normal",
            "2026-08-25", "Blocked"
        )
        ctx.projects.create_project_task(
            project_id, "Completed ignored", "Task", None, "", "Critical",
            "2026-08-20", "Completed"
        )

        result = ctx.projects.operational_alerts("2026-08-22")

        assert result["as_of"] == "2026-08-22"
        assert result["read_only"] is True
        assert result["counts"] == {"critical": 1, "high": 3, "total": 4}
        assert [a["type"] for a in result["alerts"]] == [
            "overdue_task", "missing_owner", "deadline_soon", "blocked_task"
        ]


def test_operational_alerts_detects_budget_overrun():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 169 budget", budget=100)
        accounts = ctx.accounting.accounts()
        expense = next(a for a in accounts if a["number"] == "5000")
        bank = next(a for a in accounts if a["number"] == "1000")
        ctx.accounting.post_journal(None, "Project expense", [
            {"account_id": expense["id"], "debit": 150, "credit": 0,
             "project_id": project_id},
            {"account_id": bank["id"], "debit": 0, "credit": 150,
             "project_id": project_id},
        ], journal_date="2026-08-22")

        result = ctx.projects.operational_alerts("2026-08-22")

        overrun = [a for a in result["alerts"] if a["type"] == "budget_overrun"]
        assert len(overrun) == 1
        assert overrun[0]["severity"] == "Critical"
        assert overrun[0]["project"] == "Step 169 budget"


def test_operational_alerts_validates_date_and_stored_data():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Invalid operational alert date"):
            ctx.projects.operational_alerts("not-a-date")

        project_id = ctx.projects.create("Step 169 invalid alert date")
        task_id = ctx.projects.create_project_task(
            project_id, "Bad due", "Task", None, "Hans", "Normal",
            "2026-08-25", "Open"
        )
        db.execute("UPDATE tasks SET due_date=? WHERE id=?", ("bad-date", task_id))
        with pytest.raises(ValueError, match="Invalid stored task due date"):
            ctx.projects.operational_alerts("2026-08-22")


def test_operational_alerts_rejects_invalid_financial_data():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 169 invalid financial")
        db.execute("UPDATE projects SET budget=? WHERE id=?", ("not-a-number", project_id))
        with pytest.raises(ValueError, match="Invalid stored operational alert financial data"):
            ctx.projects.operational_alerts("2026-08-22")

# MFM v1.49 Product Completion — Step 170

def test_triage_work_item_updates_existing_task_fields_without_new_source():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 170 triage")
        task_id = ctx.projects.create_project_task(project_id, "Inbox item")

        result = ctx.projects.triage_work_item(
            {"id": task_id}, "  Hans  ", "Critical", "2026-08-29"
        )

        assert result["id"] == task_id
        assert result["assigned_to"] == "Hans"
        assert result["priority"] == "Critical"
        assert result["due_date"] == "2026-08-29"
        assert result["status"] == "Open"
        assert ctx.projects.repo.task_by_id(task_id)["assigned_to"] == "Hans"


def test_triage_work_item_uses_existing_workflow_transition_rules():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 170 workflow")
        task_id = ctx.projects.create_project_task(project_id, "Triage workflow")

        result = ctx.projects.triage_work_item(task_id, status="In Progress")
        assert result["status"] == "In Progress"

        with pytest.raises(ValueError, match="Invalid workflow transition"):
            ctx.projects.triage_work_item(task_id, status="Closed")

        assert ctx.projects.repo.task_by_id(task_id)["status"] == "In Progress"


def test_triage_work_item_rejects_invalid_mutation_inputs_before_write():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 170 validation")
        task_id = ctx.projects.create_project_task(project_id, "Protected triage")

        with pytest.raises(ValueError, match="Invalid task priority"):
            ctx.projects.triage_work_item(task_id, priority="Urgent")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.triage_work_item(task_id, due_date="not-a-date")
        with pytest.raises(ValueError, match="Invalid task status"):
            ctx.projects.triage_work_item(task_id, status="Bogus")

        task = ctx.projects.repo.task_by_id(task_id)
        assert task["assigned_to"] == ""
        assert task["priority"] == "Normal"
        assert task["due_date"] is None
        assert task["status"] == "Open"


def test_today_view_composes_existing_personal_work_and_buckets():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 171 Today")
        overdue = ctx.projects.create_project_task(
            project_id, "Overdue", assigned_to="Hans", priority="Normal",
            due_date="2026-08-20", status="Open"
        )
        due_today = ctx.projects.create_project_task(
            project_id, "Due Today", assigned_to="Hans", priority="Normal",
            due_date="2026-08-22", status="Open"
        )
        critical = ctx.projects.create_project_task(
            project_id, "Critical", assigned_to="Hans", priority="Critical",
            due_date="2026-08-30", status="Open"
        )
        blocked = ctx.projects.create_project_task(
            project_id, "Blocked", assigned_to="Hans", priority="Normal",
            due_date="2026-08-31", status="Blocked"
        )
        other = ctx.projects.create_project_task(
            project_id, "Other", assigned_to="Hans", priority="Normal",
            due_date="2026-09-10", status="Open"
        )
        completed = ctx.projects.create_project_task(
            project_id, "Completed", assigned_to="Hans", priority="High",
            due_date="2026-08-22", status="Open"
        )
        ctx.projects.personal_work_action("Hans", completed, "complete")

        result = ctx.projects.today_view("Hans", "2026-08-22")

        assert result["owner"] == "Hans"
        assert result["as_of"] == "2026-08-22"
        assert result["summary"] == {
            "total": 5,
            "due_today": 1,
            "overdue": 1,
            "high_priority": 1,
            "blocked": 1,
        }
        assert overdue in [t["id"] for t in result["buckets"]["overdue"]]
        assert due_today in [t["id"] for t in result["buckets"]["due_today"]]
        assert critical in [t["id"] for t in result["buckets"]["high_priority"]]
        assert blocked in [t["id"] for t in result["buckets"]["blocked"]]
        assert other in [t["id"] for t in result["buckets"]["other"]]
        assert completed not in [t["id"] for t in result["tasks"]]
        assert result["read_only"] is True


def test_today_view_validates_owner_date_and_stored_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 171 Validation")
        task_id = ctx.projects.create_project_task(
            project_id, "Task", assigned_to="Hans", due_date="2026-08-25"
        )

        with pytest.raises(ValueError, match="responsible person"):
            ctx.projects.today_view("")
        with pytest.raises(ValueError, match="Invalid today view date"):
            ctx.projects.today_view("Hans", "not-a-date")

        db.execute("UPDATE tasks SET due_date=? WHERE id=?", ("not-a-date", task_id))
        with pytest.raises(ValueError, match="Invalid stored task due date"):
            ctx.projects.today_view("Hans", "2026-08-22")


def test_today_view_is_read_only_and_uses_repository_scope():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 171 Read Only")
        task_id = ctx.projects.create_project_task(
            project_id, "Visible", assigned_to="Hans", due_date="2026-08-22"
        )
        ctx.projects.create_project_task(
            project_id, "Other Owner", assigned_to="Else", due_date="2026-08-22"
        )

        before = dict(ctx.projects.repo.task_by_id(task_id))
        result = ctx.projects.today_view("Hans", "2026-08-22")
        after = dict(ctx.projects.repo.task_by_id(task_id))

        assert [t["id"] for t in result["tasks"]] == [task_id]
        assert before == after
        assert result["read_only"] is True


def test_my_day_composes_personal_work_queue_into_sections():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 172 My Day")
        ctx.projects.create_project_task(
            project_id, "Overdue", "Task", None, "Hans", "Normal",
            "2026-08-20", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Today", "Task", None, "Hans", "High",
            "2026-08-22", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Critical", "Task", None, "Hans", "Critical",
            "2026-08-30", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Blocked", "Task", None, "Hans", "Normal",
            "2026-08-31", "Blocked"
        )
        ctx.projects.create_project_task(
            project_id, "Other owner", "Task", None, "Else", "Critical",
            "2026-08-22", "Open"
        )

        result = ctx.projects.my_day("Hans", "2026-08-22")

        assert result["person"] == "Hans"
        assert result["as_of"] == "2026-08-22"
        assert result["metrics"] == {
            "total": 4, "overdue": 1, "today": 1,
            "critical": 1, "blocked": 1
        }
        assert [t["title"] for t in result["sections"]["overdue"]] == ["Overdue"]
        assert [t["title"] for t in result["sections"]["today"]] == ["Today"]
        assert [t["title"] for t in result["sections"]["critical"]] == ["Critical"]
        assert [t["title"] for t in result["sections"]["blocked"]] == ["Blocked"]
        assert result["read_only"] is True


def test_my_day_validates_owner_date_and_stored_due_date():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 172 validation")

        with pytest.raises(ValueError, match="responsible person"):
            ctx.projects.my_day("", "2026-08-22")
        with pytest.raises(ValueError, match="Invalid My Day date"):
            ctx.projects.my_day("Hans", "not-a-date")

        task_id = ctx.projects.create_project_task(
            project_id, "Bad due date", "Task", None, "Hans", "Normal",
            "2026-08-22", "Open"
        )
        ctx.projects.repo.db.execute(
            "UPDATE tasks SET due_date=? WHERE id=?", ("not-a-date", task_id)
        )
        with pytest.raises(ValueError, match="Invalid stored task due date"):
            ctx.projects.my_day("Hans", "2026-08-22")


def test_my_day_reuses_personal_work_queue_scope_and_does_not_mutate():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 172 read only")
        task_id = ctx.projects.create_project_task(
            project_id, "Open task", "Task", None, "Hans", "High",
            "2026-08-22", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Closed task", "Task", None, "Hans", "Critical",
            "2026-08-22", "Closed"
        )

        before = dict(ctx.projects.repo.task_by_id(task_id))
        result = ctx.projects.my_day("Hans", "2026-08-22")
        after = dict(ctx.projects.repo.task_by_id(task_id))

        assert [t["id"] for t in result["tasks"]] == [task_id]
        assert before == after
        assert result["read_only"] is True


def test_quick_capture_creates_open_task_through_existing_task_path():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 173 capture")
        activity_id = ctx.projects.create_activity(project_id, "Activity")

        result = ctx.projects.quick_capture(
            "Captured task", project_id, activity_id,
            "Hans", "High", "2026-08-30", "Captured description"
        )

        assert result["project_id"] == project_id
        assert result["activity_id"] == activity_id
        assert result["title"] == "Captured task"
        assert result["description"] == "Captured description"
        assert result["assigned_to"] == "Hans"
        assert result["priority"] == "High"
        assert result["due_date"] == "2026-08-30"
        assert result["status"] == "Open"


def test_quick_capture_validates_capture_inputs_before_mutation():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 173 validation")
        before = len(ctx.projects.repo.project_tasks(project_id))

        with pytest.raises(ValueError, match="Task title is required"):
            ctx.projects.quick_capture("", project_id)
        with pytest.raises(ValueError, match="Invalid task priority"):
            ctx.projects.quick_capture("Bad priority", project_id, priority="Urgent")
        with pytest.raises(ValueError, match="Invalid task due date"):
            ctx.projects.quick_capture("Bad date", project_id, due_date="2026-99-99")
        with pytest.raises(ValueError, match="Activity must belong"):
            ctx.projects.quick_capture("Bad activity", project_id, activity_id=999999)

        assert len(ctx.projects.repo.project_tasks(project_id)) == before


def test_quick_capture_preserves_project_activity_scope_and_defaults():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_a = ctx.projects.create("Step 173 A")
        project_b = ctx.projects.create("Step 173 B")
        activity_b = ctx.projects.create_activity(project_b, "Activity B")

        with pytest.raises(ValueError, match="Activity must belong"):
            ctx.projects.quick_capture(
                "Cross-project capture", project_a, activity_id=activity_b
            )

        result = ctx.projects.quick_capture("Default capture", project_a)
        assert result["project_id"] == project_a
        assert result["activity_id"] is None
        assert result["assigned_to"] == ""
        assert result["priority"] == "Normal"
        assert result["due_date"] is None
        assert result["status"] == "Open"


def test_project_progress_control_returns_stable_read_model():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 175 progress control")
        ctx.projects.set_budget(project_id, 1000)
        activity_id = ctx.projects.create_activity(project_id, "Progress activity")
        ctx.projects.create_project_task(
            project_id, "Open task", "Task", activity_id, "Hans", "Normal",
            None, "Open"
        )
        completed_id = ctx.projects.create_project_task(
            project_id, "Completed task", "Task", activity_id, "Hans", "Normal",
            None, "Open"
        )
        ctx.projects.quick_action(completed_id, "complete")

        result = ctx.projects.project_progress_control(project_id)

        assert result["project_id"] == project_id
        assert result["budget"] == 1000.0
        assert result["actual"] == 0.0
        assert result["variance"] == 1000.0
        assert result["utilization"] == 0.0
        assert result["task_progress"] == 50.0
        assert result["execution_status"] == "In progress"
        assert result["financial_status"] == "On budget"
        assert result["read_only"] is True
        assert len(result["tasks"]) == 2
        assert len(result["activities"]) == 1
        assert result["activities"][0]["task_count"] == 2
        assert result["activities"][0]["completed_tasks"] == 1
        assert result["activities"][0]["progress"] == 50.0


def test_project_progress_control_preserves_activity_financial_contract():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 175 activity financial")
        activity_id = ctx.projects.create_activity(project_id, "Budgeted activity")
        db.execute(
            "UPDATE activities SET budget=? WHERE id=?",
            (250.0, activity_id),
        )
        result = ctx.projects.project_progress_control(project_id)

        activity = result["activities"][0]
        assert activity["id"] == activity_id
        assert activity["budget"] == 250.0
        assert activity["actual"] == 0.0
        assert activity["variance"] == 250.0
        assert activity["utilization"] == 0.0
        assert activity["control_status"] == "OK"
        assert result["read_only"] is True


def test_project_progress_control_validates_project_and_persisted_money():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        with pytest.raises(ValueError, match="Project not found"):
            ctx.projects.project_progress_control(999999)

        project_id = ctx.projects.create("Step 175 validation")
        db.execute(
            "UPDATE projects SET budget=? WHERE id=?",
            (-10.0, project_id),
        )
        with pytest.raises(ValueError, match="Invalid project progress budget"):
            ctx.projects.project_progress_control(project_id)


def test_member_administration_overview_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.members.create_member("M-177", "A", "Active")
        suspended = ctx.members.create_member("M-178", "B", "Suspended")
        resigned = ctx.members.create_member("M-179", "C", "Resigned")
        deceased = ctx.members.create_member("M-180", "D", "Deceased")

        ctx.members.change_member_status(suspended, "Suspended")
        ctx.members.change_member_status(resigned, "Resigned")
        ctx.members.change_member_status(deceased, "Deceased")

        overview = ctx.members.administration_overview()

        assert overview == {
            "total": 4,
            "active": 1,
            "inactive": 0,
            "suspended": 1,
            "resigned": 1,
            "deceased": 1,
        }


def test_member_card_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.members.create_member(
            "M-178", "Step", "Member", email="member@example.dk",
            joined_date="2026-01-10"
        )
        member = ctx.members.members()[0]
        membership_type = ctx.members.create_membership_type("Standard", 300)
        membership_id = ctx.members.add_membership(
            member["id"], membership_type, "2026-01-10"
        )
        invoice_id = ctx.members.invoice_membership(
            membership_id, member["id"], 300,
            invoice_date="2026-01-10", due_date="2026-01-24"
        )
        ctx.members.register_join(member["id"], "2026-01-10")

        card = ctx.members.member_card(member["id"])
        assert card["member"]["id"] == member["id"]
        assert len(card["memberships"]) == 1
        assert card["memberships"][0]["id"] == membership_id
        assert len(card["invoices"]) == 1
        assert card["invoices"][0]["id"] == invoice_id
        assert "events" in card
        assert len(card["events"]) >= 1

        with pytest.raises(ValueError, match="Member not found"):
            ctx.members.member_card(999999)


def test_billing_preview_is_read_only_and_detects_existing_invoice():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.members.create_member("M-179", "Billing", "Preview")
        member = ctx.members.members()[0]
        membership_type = ctx.members.create_membership_type("Annual", 400)
        ctx.members.add_membership(member["id"], membership_type, "2026-01-01")
        membership = ctx.members.memberships()[0]

        preview = ctx.members.billing_preview(2026, "2026-01-05", "2026-01-19")
        assert len(preview) == 1
        assert preview[0]["membership_id"] == membership["id"]
        assert preview[0]["amount"] == 400.0
        assert preview[0]["already_invoiced"] is False
        assert preview[0]["existing_invoice_no"] is None
        assert ctx.members.invoices() == []

        invoice_id = ctx.members.invoice_membership(
            membership["id"], member["id"], 400, "2026-01-05", "2026-01-19"
        )
        assert invoice_id is not None

        preview_after = ctx.members.billing_preview(2026, "2026-01-05", "2026-01-19")
        assert len(preview_after) == 1
        assert preview_after[0]["already_invoiced"] is True
        assert preview_after[0]["existing_invoice_no"] is not None
        assert len(ctx.members.invoices()) == 1


def test_bill_memberships_creates_only_new_invoices_and_skips_existing():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.members.create_member("M-180", "Batch", "Billing")
        member = ctx.members.members()[0]
        membership_type = ctx.members.create_membership_type("Annual", 500)
        membership_id = ctx.members.add_membership(
            member["id"], membership_type, "2026-01-01"
        )

        first = ctx.members.bill_memberships(
            2026, "2026-01-05", "2026-01-19"
        )
        assert first["billing_year"] == 2026
        assert first["created_count"] == 1
        assert first["skipped_count"] == 0
        assert len(first["created"]) == 1
        assert first["created"][0]["membership_id"] == membership_id
        assert len(ctx.members.invoices()) == 1

        second = ctx.members.bill_memberships(
            2026, "2026-01-05", "2026-01-19"
        )
        assert second["created_count"] == 0
        assert second["skipped_count"] == 1
        assert second["skipped"][0]["already_invoiced"] is True
        assert len(ctx.members.invoices()) == 1


def test_outstanding_invoices_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.members.create_member("M-182", "Outstanding", "Invoices")
        member = ctx.members.members()[0]
        membership_type = ctx.members.create_membership_type("Annual", 100)
        membership_id = ctx.members.add_membership(
            member["id"], membership_type, "2026-01-01"
        )

        paid_id = ctx.members.invoice_membership(
            membership_id, member["id"], 100, "2026-01-05", "2026-01-19"
        )
        partial_id = ctx.members.invoice_membership(
            membership_id, member["id"], 200, "2026-02-05", "2026-12-19"
        )
        open_id = ctx.members.invoice_membership(
            membership_id, member["id"], 300, "2026-08-01", "2026-12-31"
        )
        other_year_id = ctx.members.invoice_membership(
            membership_id, member["id"], 400, "2025-08-01", "2025-12-31"
        )

        ctx.members.register_payment(paid_id, 100, "2026-01-10")
        ctx.members.register_payment(partial_id, 50, "2026-02-10")

        rows = ctx.members.outstanding_invoices(2026)

        assert len(rows) == 2
        assert {row["id"] for row in rows} == {partial_id, open_id}
        partial = next(row for row in rows if row["id"] == partial_id)
        open_row = next(row for row in rows if row["id"] == open_id)
        assert partial["paid_amount"] == 50
        assert partial["outstanding"] == 150.0
        assert open_row["paid_amount"] == 0
        assert open_row["outstanding"] == 300.0

        assert all(row["outstanding"] > 0 for row in rows)
        assert other_year_id not in {row["id"] for row in rows}



def test_dunning_preview_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        active = []
        for no, first, last in [("M-183-A", "Active", "Overdue"),
                                ("M-183-P", "Partial", "Overdue"),
                                ("M-183-PD", "Paid", "Overdue"),
                                ("M-183-I", "Inactive", "Overdue"),
                                ("M-183-F", "Future", "Due")]:
            ctx.members.create_member(no, first, last)
            active.append(next(m for m in ctx.members.members() if m["member_no"] == no))

        membership_type = ctx.members.create_membership_type("Annual", 100)
        invoice_ids = []
        for member, amount, due in [
            (active[0], 200, "2026-08-01"),
            (active[1], 300, "2026-08-10"),
            (active[2], 400, "2026-08-05"),
            (active[3], 500, "2026-08-03"),
            (active[4], 600, "2026-12-31"),
        ]:
            membership_id = ctx.members.add_membership(
                member["id"], membership_type, "2026-01-01"
            )
            invoice_ids.append(ctx.members.invoice_membership(
                membership_id, member["id"], amount, "2026-01-01", due
            ))

        ctx.members.register_payment(invoice_ids[1], 100, "2026-08-15")
        ctx.members.register_payment(invoice_ids[2], 400, "2026-08-06")
        ctx.members.change_member_status(active[3]["id"], "Inactive")

        before_invoices = len(ctx.members.invoices())
        rows = ctx.members.dunning_preview("2026-08-22")
        after_invoices = len(ctx.members.invoices())

        assert [row["invoice_id"] for row in rows] == [invoice_ids[0], invoice_ids[1]]
        first, partial = rows
        assert first["outstanding"] == 200.0
        assert first["paid_amount"] == 0.0
        assert first["days_overdue"] == 21
        assert first["name"] == "Active Overdue"
        assert partial["outstanding"] == 200.0
        assert partial["paid_amount"] == 100.0
        assert partial["days_overdue"] == 12
        assert partial["email"] is not None
        assert before_invoices == after_invoices == 5

def test_payment_status_summary_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.members.create_member("M-181", "Payment", "Summary")
        member = ctx.members.members()[0]
        membership_type = ctx.members.create_membership_type("Annual", 100)
        membership_id = ctx.members.add_membership(member["id"], membership_type, "2026-01-01")

        paid_id = ctx.members.invoice_membership(
            membership_id, member["id"], 100, "2026-01-05", "2026-01-19"
        )
        partial_id = ctx.members.invoice_membership(
            membership_id, member["id"], 200, "2026-02-05", "2026-02-19"
        )
        overdue_id = ctx.members.invoice_membership(
            membership_id, member["id"], 300, "2026-03-05", "2026-03-19"
        )
        open_id = ctx.members.invoice_membership(
            membership_id, member["id"], 400, "2026-08-01", "2026-12-19"
        )

        ctx.members.register_payment(paid_id, 100, "2026-01-10")
        ctx.members.register_payment(partial_id, 50, "2026-02-10")

        before = len(ctx.members.invoices())
        summary = ctx.members.payment_status_summary(2026)
        after = len(ctx.members.invoices())

        assert summary == {
            "invoices": 4,
            "paid": 1,
            "partially_paid": 1,
            "open": 1,
            "overdue": 1,
            "invoiced": 1000.0,
            "paid_amount": 150.0,
            "outstanding": 850.0,
        }
        assert before == after == 4

        filtered = ctx.members.payment_status_summary(2025)
        assert filtered["invoices"] == 0
        assert filtered["invoiced"] == 0.0
        assert filtered["outstanding"] == 0.0


def test_dunning_communication_boundary():
    """Step 184: dunning message preparation and communication audit logging."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        member_id = ctx.members.create_member(
            "M-184", "Test", "Dunning", email="dunning@example.org", phone="123"
        )
        membership_type_id = ctx.members.create_membership_type("Annual", 500)
        membership_id = ctx.members.add_membership(member_id, membership_type_id, "2026-01-01")
        invoice_id = ctx.members.invoice_membership(
            membership_id, member_id, 500, "2026-01-01", "2026-01-15"
        )

        preview = ctx.members.dunning_preview("2026-02-01")
        assert len(preview) == 1
        row = preview[0]

        subject1, body1 = ctx.members.dunning_message(row, 1)
        subject2, body2 = ctx.members.dunning_message(row, 2)
        subject3, body3 = ctx.members.dunning_message(row, 3)
        assert "Påmindelse" in subject1
        assert "Rykker" in subject2
        assert "Sidste betalingspåmindelse" in subject3
        assert str(row["invoice_no"]) in body1
        assert str(row["invoice_no"]) in body2
        assert str(row["invoice_no"]) in body3

        communication_id = ctx.members.record_dunning(
            row, level=2, channel="Email", sent_at="2026-02-01T10:00:00", status="Prepared"
        )
        assert communication_id == 1

        history = ctx.members.communication_history(member_id=member_id, invoice_id=invoice_id)
        assert len(history) == 1
        entry = history[0]
        assert entry["member_id"] == member_id
        assert entry["invoice_id"] == invoice_id
        assert entry["channel"] == "Email"
        assert entry["communication_type"] == "Dunning-2"
        assert entry["status"] == "Prepared"
        assert "Rykker" in entry["subject"]
        assert str(row["invoice_no"]) in entry["body"]


def test_member_lifecycle_administration_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        member_id = ctx.members.create_member(
            "M-185", "Lifecycle", "Member", email="old@example.dk",
            joined_date="2026-01-01"
        )
        membership_type = ctx.members.create_membership_type("Standard", 300)
        membership_id = ctx.members.add_membership(
            member_id, membership_type, "2026-01-01"
        )

        updated = ctx.members.update_member_contact(
            member_id,
            email="new@example.dk",
            phone="12345678",
            city="Odense",
            ignored_field="must_not_be_persisted",
        )
        assert updated["email"] == "new@example.dk"
        assert updated["phone"] == "12345678"
        assert updated["city"] == "Odense"
        assert "ignored_field" not in updated
        assert any(e["event_type"] == "Contact Updated" for e in ctx.members.member_events(member_id))

        changed = ctx.members.change_member_status(
            member_id, "Suspended", event_date="2026-02-01", reason="Temporary hold"
        )
        assert changed["status"] == "Suspended"
        status_event = next(
            e for e in ctx.members.member_events(member_id)
            if e["event_type"] == "Status Change"
        )
        assert status_event["old_status"] == "Active"
        assert status_event["new_status"] == "Suspended"
        assert status_event["description"] == "Temporary hold"

        joined = ctx.members.register_join(member_id, "2026-03-01", reason="Rejoined")
        assert joined["status"] == "Active"
        assert joined["joined_date"] == "2026-03-01"

        left = ctx.members.register_leave(member_id, "2026-04-15", reason="Member resigned")
        assert left["status"] == "Resigned"
        membership = ctx.members.memberships()[0]
        assert membership["id"] == membership_id
        assert membership["status"] == "Ended"
        assert membership["end_date"] == "2026-04-15"

        event_types = [e["event_type"] for e in ctx.members.member_events(member_id)]
        assert "Contact Updated" in event_types
        assert "Status Change" in event_types
        assert "Joined" in event_types
        assert "Resigned" in event_types

        with pytest.raises(ValueError, match="Invalid member status"):
            ctx.members.change_member_status(member_id, "Unknown")


def test_invoice_status_refresh_boundary():
    """Step 186: refresh persisted membership invoice statuses from authoritative payment/due-date state."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        member_id = ctx.members.create_member("M-186", "Invoice", "Status")
        membership_type_id = ctx.members.create_membership_type("Annual", 100)
        membership_id = ctx.members.add_membership(member_id, membership_type_id, "2026-01-01")

        overdue_id = ctx.members.invoice_membership(
            membership_id, member_id, 100, "2026-01-01", "2026-01-15"
        )
        partial_id = ctx.members.invoice_membership(
            membership_id, member_id, 100, "2026-02-01", "2026-02-15"
        )
        paid_id = ctx.members.invoice_membership(
            membership_id, member_id, 100, "2026-03-01", "2026-03-15"
        )

        ctx.members.register_payment(partial_id, 40, "2026-02-10")
        ctx.members.register_payment(paid_id, 100, "2026-03-10")

        # Deliberately leave persisted statuses stale and let the maintenance
        # boundary recalculate them from payment amounts and due dates.
        db.execute("UPDATE membership_invoices SET status='Open'")
        ctx.members.refresh_invoice_statuses()

        statuses = {
            row["id"]: row["status"]
            for row in db.fetch_all(
                "SELECT id,status FROM membership_invoices ORDER BY id"
            )
        }
        assert statuses[overdue_id] == "Overdue"
        assert statuses[partial_id] == "Partially Paid"
        assert statuses[paid_id] == "Paid"


def test_year_end_closing_boundary_controls_and_closes_year():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        ctx.accounting.create_accounting_year(2026, "2026-01-01", "2026-12-31")
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        ctx.accounting.post_journal(None, "Year-end income", [
            {"account_id": bank["id"], "debit": 500, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 500},
        ], journal_date="2026-12-15")

        check = ctx.accounting.year_end_control_check(2026)
        assert check["year"] == 2026
        assert check["posted_journals"] == 1
        assert check["unbalanced_journals"] == 0
        assert check["unmatched_bank_transactions"] == 0
        assert check["trial_balance_balanced"] is True
        assert check["ready_to_close"] is True

        ctx.accounting.close_year(2026, actor="test-user")
        year = ctx.accounting.repo.get_accounting_year(2026)
        assert year["status"] == "Closed"
        audit = ctx.accounting.audit_events(entity_type="accounting_year", entity_id=2026)
        assert any(event["event_type"] == "YEAR_CLOSED" for event in audit)

        with pytest.raises(ValueError, match="already closed"):
            ctx.accounting.close_year(2026)


def test_bank_csv_import_boundary():
    """Step 188: verify CSV bank import, mapping, and duplicate protection."""
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        db = Database(root / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("CSV Bank", "456")
        csv_path = root / "bank.csv"
        csv_path.write_text(
            "Date;Amount;Description;Reference\n"
            "2026-08-20;1.234,50;Member payment;REF-001\n"
            "2026-08-21;250,00;Bank fee;REF-002\n"
            "2026-08-22;not-a-number;Ignored;REF-003\n",
            encoding="utf-8",
        )
        mapping = {
            "date": "Date",
            "amount": "Amount",
            "description": "Description",
            "reference": "Reference",
        }

        preview = ctx.accounting.preview_bank_csv(csv_path, mapping)
        assert preview["headers"] == ["Date", "Amount", "Description", "Reference"]
        assert len(preview["rows"]) == 2
        assert preview["rows"][0]["amount"] == 1234.50
        assert preview["rows"][0]["external_reference"] == "REF-001"

        result = ctx.accounting.import_bank_csv(bank_id, csv_path, mapping)
        assert result["read"] == 2
        assert result["created"] == 2
        assert result["skipped_duplicates"] == 0

        result_again = ctx.accounting.import_bank_csv(bank_id, csv_path, mapping)
        assert result_again["read"] == 2
        assert result_again["created"] == 0
        assert result_again["skipped_duplicates"] == 2

        transactions = ctx.accounting.repo.list_bank_transactions(bank_id)
        assert len(transactions) == 2
        assert {r["external_reference"] for r in transactions} == {"REF-001", "REF-002"}


def test_step189_suggest_bank_matches_is_deterministic_and_read_only():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Main Bank", "123")
        bank = next(a for a in ctx.accounting.accounts() if a["number"] == "1000")
        income = next(a for a in ctx.accounting.accounts() if a["number"] == "3000")
        journal_id = ctx.accounting.post_journal(
            None,
            "Bank deposit",
            [
                {"account_id": bank["id"], "debit": 500, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 500},
            ],
        )
        tx_id = ctx.bank.import_transaction(bank_id, 500, "Bank deposit")
        before = db.fetch_one(
            "SELECT status, journal_id FROM bank_transactions WHERE id=?",
            (tx_id,),
        )

        suggestions = ctx.accounting.suggest_bank_matches(bank_id)

        assert len(suggestions) == 1
        assert suggestions[0]["transaction_id"] == tx_id
        assert suggestions[0]["suggestion"]["journal_id"] == journal_id
        assert suggestions[0]["suggestion"]["score"] == 100
        assert suggestions[0]["suggestion"]["reason"] == "Amount match"

        after = db.fetch_one(
            "SELECT status, journal_id FROM bank_transactions WHERE id=?",
            (tx_id,),
        )
        assert dict(after) == dict(before)


def test_step190_bank_match_approval_and_unmatch_boundary():
    """Step 190: explicit match approval persists atomically and can be reversed."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        admin = ctx.users.authenticate("admin", "admin")
        ctx.current_user = admin

        bank_id = ctx.bank.create_account("Approval Bank", "190")
        bank = next(a for a in ctx.accounting.accounts() if a["number"] == "1000")
        income = next(a for a in ctx.accounting.accounts() if a["number"] == "3000")
        journal_id = ctx.accounting.post_journal(
            None,
            "Approved bank match",
            [
                {"account_id": bank["id"], "debit": 250, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 250},
            ],
        )
        tx_id = ctx.bank.import_transaction(bank_id, 250, "Approved deposit")

        matched_id = ctx.accounting.match_bank_transaction(tx_id, journal_id)
        assert matched_id == tx_id
        match = ctx.accounting.repo.get_bank_match(tx_id)
        assert match["journal_id"] == journal_id
        current = next(
            r for r in ctx.accounting.repo.list_bank_transactions(bank_id)
            if r["id"] == tx_id
        )
        assert current["status"] == "Matched"
        assert current["journal_id"] == journal_id

        with pytest.raises(ValueError, match="already matched"):
            ctx.accounting.match_bank_transaction(tx_id, journal_id)

        ctx.accounting.unmatch_bank_transaction(tx_id)
        assert ctx.accounting.repo.get_bank_match(tx_id) is None
        current = next(
            r for r in ctx.accounting.repo.list_bank_transactions(bank_id)
            if r["id"] == tx_id
        )
        assert current["status"] == "Unmatched"
        assert current["journal_id"] is None

        actions = [r["event_type"] for r in ctx.accounting.audit_events()]
        assert "BANK_MATCHED" in actions
        assert "BANK_UNMATCHED" in actions


def test_step191_bank_reconciliation_summary_is_scoped_and_read_only():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        bank_id = ctx.bank.create_account("Summary Bank", "191")
        other_bank_id = ctx.bank.create_account("Other Bank", "191-B")

        tx1 = ctx.bank.import_transaction(bank_id, 100, "Matched payment")
        tx2 = ctx.bank.import_transaction(bank_id, -25, "Unmatched fee")
        ctx.bank.import_transaction(other_bank_id, 999, "Other account")

        bank = next(a for a in ctx.accounting.accounts() if a["number"] == "1000")
        expense = next(a for a in ctx.accounting.accounts() if a["number"] == "5100")
        journal_id = ctx.accounting.post_journal(
            None, "Summary match",
            [
                {"account_id": bank["id"], "debit": 100, "credit": 0},
                {"account_id": expense["id"], "debit": 0, "credit": 100},
            ],
        )
        ctx.accounting.match_bank_transaction(tx1, journal_id)

        before = [dict(r) for r in ctx.accounting.repo.list_bank_transactions(bank_id)]
        summary = ctx.accounting.bank_reconciliation_summary(bank_id)

        assert summary == {
            "transaction_count": 2,
            "matched_count": 1,
            "unmatched_count": 1,
            "total": 75.0,
            "matched_total": 100.0,
            "unmatched_total": -25.0,
            "reconciled": False,
        }

        after = [dict(r) for r in ctx.accounting.repo.list_bank_transactions(bank_id)]
        assert after == before

        ctx.accounting.match_bank_transaction(tx2, journal_id, matched_amount=-25)
        summary = ctx.accounting.bank_reconciliation_summary(bank_id)
        assert summary["transaction_count"] == 2
        assert summary["matched_count"] == 2
        assert summary["unmatched_count"] == 0
        assert summary["total"] == 75.0
        assert summary["matched_total"] == 75.0
        assert summary["unmatched_total"] == 0.0
        assert summary["reconciled"] is True


def test_step192_accounting_period_close_and_reopen_lifecycle():
    """Step 192: accounting period close/reopen is persistent and audited."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        period_id = ctx.accounting.create_accounting_period(
            "2026-08-01", "2026-08-31", "August 2026"
        )
        period = ctx.accounting.repo.get_accounting_period(period_id)
        assert period["status"] == "Open"

        ctx.accounting.close_period(period_id, actor="tester")
        period = ctx.accounting.repo.get_accounting_period(period_id)
        assert period["status"] == "Closed"
        assert period["closed_at"]
        assert period["closed_by"] == "tester"

        # Closing an already closed period is idempotent under the existing contract.
        ctx.accounting.close_period(period_id, actor="tester-2")
        period = ctx.accounting.repo.get_accounting_period(period_id)
        assert period["status"] == "Closed"
        assert period["closed_by"] == "tester"

        ctx.accounting.reopen_period(period_id, actor="reopener")
        period = ctx.accounting.repo.get_accounting_period(period_id)
        assert period["status"] == "Open"
        assert period["closed_at"] is None
        assert period["closed_by"] is None

        events = ctx.accounting.audit_events(
            entity_type="accounting_period", entity_id=period_id
        )
        assert [e["event_type"] for e in events] == [
            "PERIOD_REOPENED",
            "PERIOD_CLOSED",
        ]


def test_step193_accounting_control_check_boundary():
    """Step 193: accounting control check aggregates existing control sources."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")

        journal_id = ctx.accounting.post_journal(
            1,
            "Control check posting",
            [
                {"account_id": bank["id"], "debit": 250, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 250},
            ],
            journal_date="2026-08-22",
        )

        result = ctx.accounting.accounting_control_check(
            start_date="2026-01-01", end_date="2026-12-31"
        )

        assert result["trial_balance_balanced"] is True
        assert result["trial_debit"] == 250.0
        assert result["trial_credit"] == 250.0
        assert result["balance_sheet_balanced"] is True
        assert result["posted_journals"] == 1
        assert result["audit_events"] == 1
        assert result["overall_ok"] is True
        assert journal_id == 1


def test_step196_general_ledger_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")
        expense = next(a for a in accounts if a["number"] == "5000")

        ctx.accounting.post_journal(None, "Income", [
            {"account_id": bank["id"], "debit": 1000, "credit": 0,
             "description": "Membership receipt"},
            {"account_id": income["id"], "debit": 0, "credit": 1000,
             "description": "Membership income"},
        ], journal_date="2026-01-10")
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": expense["id"], "debit": 250, "credit": 0,
             "description": "Supplies"},
            {"account_id": bank["id"], "debit": 0, "credit": 250,
             "description": "Supplies payment"},
        ], journal_date="2026-02-15")

        all_rows = ctx.accounting.general_ledger()
        assert len(all_rows) == 4
        assert [r["journal_no"] for r in all_rows] == [1, 1, 2, 2]
        assert all(r["journal_date"] in {"2026-01-10", "2026-02-15"} for r in all_rows)
        assert all(r["number"] and r["name"] for r in all_rows)
        assert all(r["debit"] is not None and r["credit"] is not None for r in all_rows)

        january = ctx.accounting.general_ledger(
            start_date="2026-01-01", end_date="2026-01-31"
        )
        assert len(january) == 2
        assert all(r["journal_date"] == "2026-01-10" for r in january)

        empty = ctx.accounting.general_ledger(
            start_date="2026-03-01", end_date="2026-03-31"
        )
        assert empty == []


def test_step198_balance_sheet_boundary():
    """Step 198: balance sheet remains a read-only accounting statement boundary."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        payables = next(a for a in accounts if a["number"] == "2000")
        income = next(a for a in accounts if a["number"] == "3000")
        expense = next(a for a in accounts if a["number"] == "5000")
        equity = next(a for a in accounts if a["number"] == "8000")

        ctx.accounting.post_journal(None, "Income", [
            {"account_id": bank["id"], "debit": 1000, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 1000},
        ], journal_date="2026-01-10")
        ctx.accounting.post_journal(None, "Expense", [
            {"account_id": expense["id"], "debit": 250, "credit": 0},
            {"account_id": bank["id"], "debit": 0, "credit": 250},
        ], journal_date="2026-02-10")
        ctx.accounting.post_journal(None, "Liability", [
            {"account_id": bank["id"], "debit": 500, "credit": 0},
            {"account_id": payables["id"], "debit": 0, "credit": 500},
        ], journal_date="2026-03-10")
        ctx.accounting.post_journal(None, "Equity", [
            {"account_id": bank["id"], "debit": 250, "credit": 0},
            {"account_id": equity["id"], "debit": 0, "credit": 250},
        ], journal_date="2026-04-10")

        as_of = ctx.accounting.balance_sheet("2026-03-31")
        assert as_of["total_assets"] == 1250.0
        assert as_of["total_liabilities"] == 500.0
        assert as_of["retained_equity"] == 0.0
        assert as_of["current_result"] == 750.0
        assert as_of["total_equity"] == 750.0
        assert as_of["liabilities_and_equity"] == 1250.0
        assert as_of["balanced"] is True
        assert as_of["as_of_date"] == "2026-03-31"

        after = ctx.accounting.balance_sheet("2026-04-30")
        assert after["total_assets"] == 1500.0
        assert after["total_equity"] == 1000.0
        assert after["liabilities_and_equity"] == 1500.0
        assert after["balanced"] is True


def test_step199_financial_dashboard_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = {a["number"]: a for a in ctx.accounting.accounts()}
        bank = accounts["1000"]
        income = accounts["3000"]
        expense = accounts["5000"]

        ctx.accounting.post_journal(1, "In range", [
            {"account_id": bank["id"], "debit": 1000, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 1000},
        ], journal_date="2026-03-15")
        ctx.accounting.post_journal(2, "In range expense", [
            {"account_id": expense["id"], "debit": 300, "credit": 0},
            {"account_id": bank["id"], "debit": 0, "credit": 300},
        ], journal_date="2026-03-20")
        ctx.accounting.post_journal(3, "Outside range", [
            {"account_id": bank["id"], "debit": 500, "credit": 0},
            {"account_id": income["id"], "debit": 0, "credit": 500},
        ], journal_date="2026-04-02")

        result = ctx.accounting.financial_dashboard("2026-03-01", "2026-03-31")

        assert result["revenue"] == 1000.0
        assert result["expenses"] == 300.0
        assert result["net_result"] == 700.0
        assert result["assets"] == 700.0
        assert result["income_accounts"] == [
            {"number": "3000", "name": "Membership Income", "amount": 1000.0}
        ]
        assert result["expense_accounts"] == [
            {"number": "5000", "name": "Operating Expenses", "amount": 300.0}
        ]


def test_step200_chart_of_accounts_creation_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        account_id = ctx.accounting.create_account(
            "  6100 ", "  Vessel Maintenance ", " Expense "
        )
        account = ctx.accounting.repo.get_account(account_id)

        assert account["number"] == "6100"
        assert account["name"] == "Vessel Maintenance"
        assert account["account_type"] == "Expense"
        assert account["active"] == 1

        with pytest.raises(ValueError, match="Account number and name are required"):
            ctx.accounting.create_account("", "", "Expense")

        with pytest.raises(ValueError, match="Invalid account type"):
            ctx.accounting.create_account("6200", "Invalid", "Other")


def test_step201_account_movements_boundary():
    """Step 201: verify account-scoped posted journal movement read path."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = ctx.accounting.accounts()
        bank = next(a for a in accounts if a["number"] == "1000")
        income = next(a for a in accounts if a["number"] == "3000")

        ctx.accounting.post_journal(
            None,
            "In range",
            [
                {"account_id": bank["id"], "debit": 100, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 100},
            ],
            journal_date="2026-03-15",
        )
        ctx.accounting.post_journal(
            None,
            "Out of range",
            [
                {"account_id": bank["id"], "debit": 50, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 50},
            ],
            journal_date="2026-04-15",
        )

        rows = ctx.accounting.account_movements(
            bank["id"], "2026-03-01", "2026-03-31"
        )
        assert len(rows) == 1
        row = rows[0]
        assert row["journal_date"] == "2026-03-15"
        assert row["journal_description"] == "In range"
        assert float(row["debit"]) == 100.0
        assert float(row["credit"]) == 0.0
        

def test_step202_accounting_period_master_data_boundary():
    """Step 202: verify the existing accounting year/period master-data path."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        year_id = ctx.accounting.create_accounting_year(
            2027, "2027-01-01", "2027-12-31"
        )
        assert year_id is not None
        years = ctx.accounting.list_accounting_years()
        year = next(y for y in years if y["year"] == 2027)
        assert year["status"] == "Open"
        assert year["period_start"] == "2027-01-01"
        assert year["period_end"] == "2027-12-31"

        period_id = ctx.accounting.create_accounting_period(
            "2027-01-01", "2027-01-31", "January 2027"
        )
        assert period_id is not None
        periods = ctx.accounting.list_accounting_periods()
        period = next(p for p in periods if p["id"] == period_id)
        assert period["name"] == "January 2027"
        assert period["status"] == "Open"
        assert period["period_start"] == "2027-01-01"
        assert period["period_end"] == "2027-01-31"

        with pytest.raises(Exception):
            ctx.accounting.create_accounting_period(
                "2027-01-01", "2027-01-31", "Duplicate January 2027"
            )


def test_step203_fiscal_year_creation_boundary():
    """Step 203: verify the existing fiscal-year creation lifecycle."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        year_id = ctx.accounting.create_fiscal_year(2028)
        assert year_id is not None

        year = ctx.accounting.repo.get_fiscal_year(2028)
        assert year is not None
        periods = ctx.accounting.periods(2028)
        assert len(periods) == 12
        assert periods[0]["period_no"] == 1
        assert periods[0]["start_date"] == "2028-01-01"
        assert periods[0]["end_date"] == "2028-01-31"
        assert periods[-1]["period_no"] == 12
        assert periods[-1]["start_date"] == "2028-12-01"
        assert periods[-1]["end_date"] == "2028-12-31"

        with pytest.raises(ValueError, match="already exists"):
            ctx.accounting.create_fiscal_year(2028)

        with pytest.raises(ValueError, match="supported range"):
            ctx.accounting.create_fiscal_year(1899)


def test_step204_fiscal_period_management_boundary():
    """Step 204: verify the existing fiscal-period listing boundary."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        ctx.accounting.create_fiscal_year(2029)
        periods = ctx.accounting.periods(2029)

        assert len(periods) == 12
        assert [p["period_no"] for p in periods] == list(range(1, 13))
        assert periods[0]["start_date"] == "2029-01-01"
        assert periods[0]["end_date"] == "2029-01-31"
        assert periods[-1]["start_date"] == "2029-12-01"
        assert periods[-1]["end_date"] == "2029-12-31"

        # Existing contract: unknown fiscal year returns an empty list.
        assert ctx.accounting.periods(2099) == []


def test_step205_standard_account_seed_boundary():
    """Step 205: verify standard chart-of-accounts seeding is complete and idempotent."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        expected = {
            "1000": ("Bank", "Asset"),
            "1100": ("Cash", "Asset"),
            "1200": ("Receivables", "Asset"),
            "2000": ("Payables", "Liability"),
            "3000": ("Membership Income", "Income"),
            "4000": ("Grants and Donations", "Income"),
            "5000": ("Operating Expenses", "Expense"),
            "5100": ("Project Expenses", "Expense"),
            "8000": ("Accumulated Funds", "Equity"),
        }

        accounts = {a["number"]: a for a in ctx.accounting.accounts()}
        assert set(expected).issubset(accounts)
        for number, (name, account_type) in expected.items():
            assert accounts[number]["name"] == name
            assert accounts[number]["account_type"] == account_type
            assert accounts[number]["active"] == 1

        before_ids = {number: accounts[number]["id"] for number in expected}
        ctx.accounting.seed_standard_accounts()
        after = {a["number"]: a for a in ctx.accounting.accounts()}
        assert len(after) == len(accounts)
        assert {number: after[number]["id"] for number in expected} == before_ids


def test_step206_trial_balance_boundary():
    """Step 206: verify the existing posted-journal trial-balance read boundary."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        accounts = {a["number"]: a for a in ctx.accounting.accounts()}
        bank = accounts["1000"]
        income = accounts["3000"]
        expense = accounts["5000"]

        ctx.accounting.post_journal(
            None, "March income", [
                {"account_id": bank["id"], "debit": 1000, "credit": 0},
                {"account_id": income["id"], "debit": 0, "credit": 1000},
            ], journal_date="2026-03-15"
        )
        ctx.accounting.post_journal(
            None, "April expense", [
                {"account_id": expense["id"], "debit": 250, "credit": 0},
                {"account_id": bank["id"], "debit": 0, "credit": 250},
            ], journal_date="2026-04-15"
        )

        rows = ctx.accounting.trial_balance("2026-03-01", "2026-03-31")
        by_number = {row["number"]: row for row in rows}

        assert by_number["1000"]["debit"] == 1000
        assert by_number["1000"]["credit"] == 0
        assert by_number["3000"]["debit"] == 0
        assert by_number["3000"]["credit"] == 1000
        assert by_number["5000"]["debit"] == 0
        assert by_number["5000"]["credit"] == 0
        assert round(sum(float(row["debit"] or 0) for row in rows), 2) == 1000
        assert round(sum(float(row["credit"] or 0) for row in rows), 2) == 1000

        # The repository boundary is based on Posted journals only; the April
        # journal must therefore not affect the March trial balance.
        assert all(row["debit"] >= 0 and row["credit"] >= 0 for row in rows)


def test_step208_chart_of_accounts_listing_boundary():
    """Step 208: verify account listing scope and deterministic ordering."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        active_accounts = ctx.accounting.accounts()
        numbers = [a["number"] for a in active_accounts]
        assert numbers == sorted(numbers)
        assert all(a["active"] == 1 for a in active_accounts)

        inactive_id = ctx.accounting.create_account("6050", "Inactive Test", "Expense")
        db.execute("UPDATE accounts SET active=0 WHERE id=?", (inactive_id,))

        visible = ctx.accounting.accounts()
        assert all(a["id"] != inactive_id for a in visible)

        all_accounts = ctx.accounting.accounts(include_inactive=True)
        assert any(a["id"] == inactive_id and a["active"] == 0 for a in all_accounts)
        assert [a["number"] for a in all_accounts] == sorted(a["number"] for a in all_accounts)


def test_step209_project_budget_vs_actual_boundary_is_read_only_and_uses_project_actuals():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 209 Project")
        ctx.projects.set_budget(project_id, 1200)
        accounts = ctx.accounting.accounts()
        expense = next(a for a in accounts if a["number"] == "5000")
        bank = next(a for a in accounts if a["number"] == "1000")
        ctx.accounting.post_journal(None, "Project expense", [
            {"account_id": expense["id"], "debit": 300, "credit": 0, "project_id": project_id},
            {"account_id": bank["id"], "debit": 0, "credit": 300, "project_id": project_id},
        ])

        before = ctx.projects.budget(project_id)["budget_amount"]
        result = ctx.accounting.project_budget_vs_actual(project_id)
        after = ctx.projects.budget(project_id)["budget_amount"]

        assert result == {
            "budget": 1200.0,
            "actual": 300.0,
            "variance": 900.0,
            "utilization": 25.0,
        }
        assert after == before


def test_step210_project_control_cockpit_boundary_is_read_only_and_composes_existing_layers():
    """Step 210: verify the project control cockpit aggregates existing control paths."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        project_id = ctx.projects.create("Step 210 Cockpit")
        ctx.projects.set_budget(project_id, 1000)
        ctx.projects.create_project_task(
            project_id, "Open task", "Task", None, "Hans", "High",
            "2026-08-30", "Open"
        )
        ctx.projects.create_project_task(
            project_id, "Closed task", "Task", None, "Hans", "Normal",
            "2026-08-20", "Closed"
        )

        before = ctx.projects.repo.db.fetch_one(
            "SELECT budget FROM projects WHERE id=?", (project_id,)
        )
        result = ctx.projects.project_control_cockpit(project_id)
        after = ctx.projects.repo.db.fetch_one(
            "SELECT budget FROM projects WHERE id=?", (project_id,)
        )

        assert result["project"]["id"] == project_id
        assert result["control"]["budget"] == 1000.0
        assert result["tasks"]
        assert result["open_tasks"] == 1
        assert result["assigned_open_tasks"] == 1
        assert result["read_only"] is True
        assert result["summary"]["open_tasks"] == 1
        assert result["summary"]["assigned_open_tasks"] == 1
        assert before == after


def test_step211_task_detail_boundary():
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)
        project_id = ctx.projects.create("Step 211 task detail")
        task_id = ctx.projects.create_project_task(
            project_id,
            "Detail task",
            "Task detail description",
            None,
            "Hans",
            "High",
            "2026-08-30",
            "Open",
        )

        before_task = dict(ctx.projects.repo.task_by_id(task_id))
        before_project = dict(ctx.projects.repo.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,)))

        result = ctx.projects.task_detail(task_id)

        assert result["read_only"] is True
        assert result["task"]["id"] == task_id
        assert result["task"]["project_id"] == project_id
        assert result["task"]["title"] == "Detail task"
        assert result["task"]["description"] == "Task detail description"
        assert result["task"]["priority"] == "High"
        assert result["task"]["due_date"] == "2026-08-30"
        assert result["project"]["id"] == project_id
        assert result["project"]["name"] == "Step 211 task detail"
        assert dict(ctx.projects.repo.task_by_id(task_id)) == before_task
        assert dict(ctx.projects.repo.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))) == before_project

        with pytest.raises(ValueError, match="Task not found"):
            ctx.projects.task_detail(999999)


def test_step212_workspace_context_boundary():
    """Step 212: verify workspace context resolves existing project/task/activity paths."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        project_id = ctx.projects.create("Step 212 workspace")
        activity_id = ctx.projects.create_activity(project_id, "Workspace activity")
        task_id = ctx.projects.create_project_task(
            project_id,
            "Workspace task",
            "Task context",
            activity_id,
            "Hans",
            "Normal",
            None,
            "Open",
        )

        project_context = ctx.projects.workspace_context("project", project_id)
        assert project_context["type"] == "project"
        assert project_context["id"] == project_id
        assert project_context["data"]["project"]["id"] == project_id

        task_context = ctx.projects.workspace_context("task", task_id)
        assert task_context["type"] == "task"
        assert task_context["id"] == task_id
        assert task_context["data"]["id"] == task_id
        assert task_context["data"]["project_id"] == project_id

        activity_context = ctx.projects.workspace_context("activity", activity_id)
        assert activity_context["type"] == "activity"
        assert activity_context["id"] == activity_id
        assert activity_context["data"]["id"] == activity_id
        assert activity_context["data"]["project_id"] == project_id

        with pytest.raises(ValueError, match="Project is required"):
            ctx.projects.workspace_context("project")

        with pytest.raises(ValueError, match="Task not found"):
            ctx.projects.workspace_context("task", 999999)

        with pytest.raises(ValueError, match="Unknown workspace context"):
            ctx.projects.workspace_context("unknown", project_id)


def test_step214_product_navigation_contract_is_complete_and_resolvable():
    from src.gui.main_window import MainWindow

    registry = MainWindow.command_registry()
    registry_commands = {command for _label, command in registry}
    assert len(registry) == len(registry_commands)

    contract = MainWindow.product_navigation_contract()
    areas = {area for area, _commands in contract}
    assert areas == {
        "Home", "Work", "Projects", "Members",
        "Finance", "Reports", "Administration",
    }

    contracted_commands = [command for _area, commands in contract for command in commands]
    assert len(contracted_commands) == len(set(contracted_commands))
    assert set(contracted_commands).issubset(registry_commands)

    model = MainWindow.navigation_model()
    assert len(model) == len(contracted_commands)
    assert {item.command for item in model} == set(contracted_commands)
    assert all(item.area in areas for item in model)
    assert all(item.label for item in model)

    for item in model:
        assert callable(getattr(MainWindow, item.command, None))

    by_area = {area: MainWindow.navigation_items(area) for area in areas}
    assert all(by_area[area] for area in areas)
    assert sum(len(items) for items in by_area.values()) == len(model)


def test_step216_export_service_boundary_covers_all_existing_exporters(tmp_path):
    db = Database(tmp_path / "test.db")
    initialize_schema(db)
    ctx = ApplicationContext(db)
    admin = ctx.users.authenticate("admin", "admin")
    ctx.current_user = admin

    ctx.members.create_member("M216", "Export", "Boundary")
    project_id = ctx.projects.create("Step 216 Export Project", budget=1000)
    ctx.projects.create_activity(project_id, "Export Activity")

    exporters = [
        ("members", ctx.export.export_members),
        ("projects", ctx.export.export_projects),
        ("journals", ctx.export.export_journals),
        ("invoices", ctx.export.export_invoices),
        ("bank_transactions", ctx.export.export_bank_transactions),
        ("trial_balance", ctx.export.export_trial_balance),
    ]

    for label, exporter in exporters:
        path = tmp_path / f"{label}.csv"
        result = exporter(path)
        assert result == path
        assert path.exists()
        assert path.read_text(encoding="utf-8-sig").splitlines()[0]
        assert not path.with_name(path.name + ".tmp").exists()

    exports = [r for r in ctx.audit.list() if r["action"] == "EXPORT"]
    assert len(exports) == len(exporters)
    assert all(r["status"] == "SUCCESS" for r in exports)


def test_step217_permission_defaults_boundary_preserves_role_contract():
    """Step 217: protect the existing role-to-permission default contract."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        admin = ctx.users.authenticate("admin", "admin")
        manager_role = ctx.users.repo.get_role("Manager")
        user_role = ctx.users.repo.get_role("User")

        manager_id = ctx.users.repo.create_user(
            "step217-manager", "Step 217 Manager", ctx.users._hash("pw"), manager_role["id"]
        )
        user_id = ctx.users.repo.create_user(
            "step217-user", "Step 217 User", ctx.users._hash("pw"), user_role["id"]
        )
        manager = ctx.users.authenticate("step217-manager", "pw")
        user = ctx.users.authenticate("step217-user", "pw")

        assert ctx.permissions.can(admin, "users.manage") is True
        assert ctx.permissions.can(manager, "projects.view") is True
        assert ctx.permissions.can(manager, "projects.edit") is True
        assert ctx.permissions.can(manager, "bank.reconcile") is True
        assert ctx.permissions.can(manager, "users.manage") is False
        assert ctx.permissions.can(user, "projects.view") is True
        assert ctx.permissions.can(user, "projects.edit") is False
        assert ctx.permissions.can(user, "bank.reconcile") is False
        assert ctx.permissions.can(None, "projects.view") is False

        manager_permissions = {p["code"] for p in ctx.permissions.permissions_for(manager)}
        user_permissions = {p["code"] for p in ctx.permissions.permissions_for(user)}
        assert "projects.edit" in manager_permissions
        assert "users.manage" not in manager_permissions
        assert "projects.view" in user_permissions
        assert "projects.edit" not in user_permissions


def test_step219_exception_followup_boundary_creates_scoped_task():
    """Step 219: protect exception-to-follow-up task creation and validation."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        project_id = ctx.projects.create("Step 219 exception project")
        activity_id = ctx.projects.create_activity(project_id, "Exception activity")
        exception = {
            "type": "Budget",
            "severity": "Critical",
            "title": "Cost overrun",
            "message": "Review unexpected project cost.",
            "activity_id": activity_id,
            "due_date": "2026-09-01",
        }

        task_id = ctx.projects.create_exception_followup(
            project_id, exception, "  Hans  "
        )
        task = dict(ctx.projects.repo.task_by_id(task_id))

        assert task["project_id"] == project_id
        assert task["activity_id"] == activity_id
        assert task["title"] == "Opfølgning: Cost overrun"
        assert task["description"] == "Review unexpected project cost."
        assert task["assigned_to"] == "Hans"
        assert task["priority"] == "High"
        assert task["due_date"] == "2026-09-01"
        assert task["status"] == "Open"

        with pytest.raises(ValueError, match="Responsible person is required"):
            ctx.projects.create_exception_followup(project_id, exception, "  ")
        with pytest.raises(ValueError, match="Exception title is required"):
            ctx.projects.create_exception_followup(
                project_id, {**exception, "title": "   "}, "Hans"
            )
        with pytest.raises(ValueError, match="Invalid exception severity"):
            ctx.projects.create_exception_followup(
                project_id, {**exception, "severity": "Severe"}, "Hans"
            )
        with pytest.raises(ValueError, match="Invalid exception follow-up due date"):
            ctx.projects.create_exception_followup(
                project_id, {**exception, "due_date": "not-a-date"}, "Hans"
            )


def test_step218_risk_decision_operational_boundary():
    """Step 218: protect the existing risk/decision service contracts and management integration."""
    with tempfile.TemporaryDirectory() as d:
        db = Database(Path(d) / "test.db")
        initialize_schema(db)
        ctx = ApplicationContext(db)

        assert ctx.risks.list() == []
        assert ctx.decisions.list() == []
        assert ctx.risks.count_open() == 0
        assert ctx.risks.count_high() == 0
        assert ctx.decisions.count_pending() == 0

        risk_id = ctx.risks.create(
            "  Operational risk  ",
            "High",
            "  Hans  ",
            "  Review control  ",
        )
        decision_id = ctx.decisions.create(
            "  Pending decision  ",
            "  Hans  ",
            "  Approve remediation path  ",
        )

        risks = [dict(row) for row in ctx.risks.list()]
        decisions = [dict(row) for row in ctx.decisions.list()]

        risk = next(row for row in risks if row["id"] == risk_id)
        decision = next(row for row in decisions if row["id"] == decision_id)

        assert risk["title"] == "Operational risk"
        assert risk["severity"] == "High"
        assert risk["status"] == "Open"
        assert risk["owner"] == "Hans"
        assert risk["mitigation"] == "Review control"

        assert decision["title"] == "Pending decision"
        assert decision["status"] == "Pending"
        assert decision["owner"] == "Hans"
        assert decision["decision_text"] == "Approve remediation path"

        assert ctx.risks.count_open() == 1
        assert ctx.risks.count_high() == 1
        assert ctx.decisions.count_pending() == 1

        snapshot = ctx.management.snapshot()
        assert snapshot["open_risks"] == 1
        assert snapshot["high_risks"] == 1
        assert snapshot["pending_decisions"] == 1

        attention = ctx.management.attention_items()
        assert any("high-risk" in message for _level, message in attention)
        assert any("pending" in message for _level, message in attention)

        with pytest.raises(ValueError, match="Risk title is required"):
            ctx.risks.create("   ")
        with pytest.raises(ValueError, match="Invalid risk severity"):
            ctx.risks.create("Invalid severity", "Severe")
        with pytest.raises(ValueError, match="Decision title is required"):
            ctx.decisions.create("   ")
