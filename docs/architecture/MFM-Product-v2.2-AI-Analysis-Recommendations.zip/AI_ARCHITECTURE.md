# MFM AI Architecture — v2.2

## Analysis boundary

v2.2 adds a deterministic recommendation layer above the MFM services.
Recommendations are derived from current data and always expose a reason.

The recommendation layer is read-only. It does not mutate MFM records.

## Recommendation contract

Every recommendation contains:
- priority
- area
- recommendation
- reason

## Future LLM integration

An LLM may explain or prioritize these structured findings, but it should
not bypass application services or database permissions. Any future write
action must be explicit, authenticated and auditable.
