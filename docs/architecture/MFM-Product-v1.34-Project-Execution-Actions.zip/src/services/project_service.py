class ProjectService:
    def __init__(self, repo):
        self.repo = repo

    def create(self, name, description="", status="Planned", budget=0):
        name = str(name).strip()
        if not name:
            raise ValueError("Project name is required.")
        budget = float(budget or 0)
        if budget < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.create(name, str(description).strip(), status, budget)

    def list(self):
        return self.repo.list()

    def count(self):
        return self.repo.count()

    def set_budget(self, project_id, amount):
        amount = float(amount)
        if amount < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.set_budget(project_id, amount)

    def budget(self, project_id):
        return self.repo.project_budget(project_id)

    def create_activity(self, project_id, name, description="", activity_date=None,
                        status="Planned", budget=0):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")
        name=str(name).strip()
        if not name: raise ValueError("Activity name is required.")
        budget=float(budget or 0)
        if budget < 0: raise ValueError("Activity budget cannot be negative.")
        return self.repo.create_activity(project_id,name,str(description).strip(),
                                          activity_date,status,budget)

    def activities(self, project_id):
        return self.repo.list_activities(project_id)

    def update_activity(self, activity_id, **fields):
        if "budget" in fields and float(fields["budget"]) < 0:
            raise ValueError("Activity budget cannot be negative.")
        return self.repo.update_activity(activity_id,**fields)

    def activity_summary(self, project_id):
        return dict(self.repo.project_activity_summary(project_id))

    def financial_tracking(self, project_id):
        return self.repo.project_financial_tracking(project_id)

    def expense_lines(self, project_id):
        return self.repo.project_expense_lines(project_id)

    def activity_financials(self, project_id):
        return self.repo.activity_actuals(project_id)

    def activity_financial_detail(self, project_id):
        rows=self.repo.activity_financial_detail(project_id)
        result=[]
        for r in rows:
            budget=float(r["budget"] or 0)
            actual=round(float(r["actual"] or 0),2)
            result.append({
                "id":r["id"],"name":r["name"],"status":r["status"],
                "budget":budget,"actual":actual,
                "variance":round(budget-actual,2),
                "utilization":round(actual/budget*100,2) if budget else 0.0
            })
        return result

    def project_control_dashboard(self, project_id):
        data=self.repo.project_control_dashboard(project_id)
        data["activities"]=[
            {
                **dict(a),
                "budget":float(a["budget"] or 0),
                "actual":round(float(a["actual"] or 0),2),
                "variance":round(float(a["budget"] or 0)-float(a["actual"] or 0),2),
                "utilization":round(float(a["actual"] or 0)/float(a["budget"])*100,2)
                    if float(a["budget"] or 0) else 0.0
            }
            for a in data["activities"]
        ]
        return data

    def project_tasks(self, project_id):
        return self.repo.project_tasks(project_id)

    def create_project_task(self, project_id, title, description="", activity_id=None,
                            assigned_to="", priority="Normal", due_date=None,
                            status="Open"):
        title=str(title).strip()
        if not title: raise ValueError("Task title is required.")
        if activity_id is not None:
            activity=self.repo.db.fetch_one("SELECT * FROM activities WHERE id=?", (activity_id,))
            if not activity or int(activity["project_id"]) != int(project_id):
                raise ValueError("Task activity must belong to the selected project.")
        if priority not in {"Low","Normal","High","Critical"}:
            raise ValueError("Invalid task priority.")
        return self.repo.create_project_task(project_id,title,str(description).strip(),
                                              activity_id,assigned_to,priority,due_date,status)

    def update_project_task(self, task_id, **fields):
        if "priority" in fields and fields["priority"] not in {"Low","Normal","High","Critical"}:
            raise ValueError("Invalid task priority.")
        return self.repo.update_project_task(task_id,**fields)

    def operational_workboard(self, assigned_to=None):
        data=self.repo.operational_workboard(assigned_to)
        tasks=data["tasks"]
        from datetime import date, timedelta
        today=date.today()
        overdue=[t for t in tasks if t.get("due_date") and t["due_date"] < today.isoformat()]
        critical=[t for t in tasks if t.get("priority")=="Critical"]
        high=[t for t in tasks if t.get("priority")=="High"]
        horizon=(today+timedelta(days=7)).isoformat()
        week_tasks=[t for t in tasks if t.get("due_date") and t["due_date"] <= horizon]
        for p in data["projects"]:
            budget=float(p["budget"] or 0)
            actual=float(p["actual"] or 0)
            p["budget"]=budget
            p["actual"]=round(actual,2)
            p["variance"]=round(budget-actual,2)
            p["utilization"]=round(actual/budget*100,2) if budget else 0.0
        data["metrics"]={"open_tasks":len(tasks),"critical_tasks":len(critical),
            "high_tasks":len(high),"overdue_tasks":len(overdue),
            "next_7_days":len(week_tasks),"active_projects":len(data["projects"])}
        return data

    def transition_project_task(self, task_id, new_status):
        allowed={"Open","In Progress","Blocked","Completed","Closed"}
        if new_status not in allowed:
            raise ValueError("Invalid task status.")
        task=self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        current=task["status"]
        transitions={
            "Open":{"In Progress","Blocked","Completed","Closed"},
            "In Progress":{"Blocked","Completed","Open"},
            "Blocked":{"In Progress","Open"},
            "Completed":{"Closed","Open"},
            "Closed":set()
        }
        if new_status not in transitions.get(current,set()):
            raise ValueError(f"Invalid workflow transition: {current} -> {new_status}")
        return self.repo.transition_project_task(task_id,new_status)

    def task_detail(self, task_id):
        task=self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        return dict(task)

    def operational_alerts(self, today=None):
        from datetime import date, datetime
        today=date.fromisoformat(today) if today else date.today()
        data=self.repo.operational_alerts(today.isoformat())
        alerts=[]
        for t in data["tasks"]:
            due=date.fromisoformat(t["due_date"])
            days=(due-today).days
            if not t.get("assigned_to"):
                alerts.append({"type":"missing_owner","severity":"High",
                               "title":"Opgave mangler ansvarlig","task_id":t["id"],
                               "project":t["project_name"],"due_date":t["due_date"],
                               "message":t["title"]})
            if days < 0:
                alerts.append({"type":"overdue_task","severity":"Critical",
                               "title":"Opgave er forfalden","task_id":t["id"],
                               "project":t["project_name"],"due_date":t["due_date"],
                               "message":t["title"]})
            elif days <= 7:
                alerts.append({"type":"deadline_soon","severity":"High",
                               "title":"Deadline nærmer sig","task_id":t["id"],
                               "project":t["project_name"],"due_date":t["due_date"],
                               "message":t["title"]})
            if t.get("status")=="Blocked":
                alerts.append({"type":"blocked_task","severity":"High",
                               "title":"Opgave er blokeret","task_id":t["id"],
                               "project":t["project_name"],"due_date":t["due_date"],
                               "message":t["title"]})
        for p in data["projects"]:
            budget=float(p["budget"] or 0);actual=float(p["actual"] or 0)
            if budget and actual > budget:
                alerts.append({"type":"budget_overrun","severity":"Critical",
                               "title":"Projekt overskrider budget","project":p["name"],
                               "message":f"{actual:.2f} > {budget:.2f}"})
        order={"Critical":0,"High":1,"Normal":2}
        alerts.sort(key=lambda x:(order.get(x["severity"],9),x.get("due_date",""),x["title"]))
        return {"alerts":alerts,"counts":{
            "critical":sum(a["severity"]=="Critical" for a in alerts),
            "high":sum(a["severity"]=="High" for a in alerts),
            "total":len(alerts)}}

    def personal_work_queue(self, assigned_to, today=None):
        from datetime import date, timedelta
        if not str(assigned_to).strip():
            raise ValueError("A responsible person is required.")
        day=date.fromisoformat(today) if today else date.today()
        rows=self.repo.personal_work_queue(str(assigned_to).strip(),day.isoformat(),
                                           (day+timedelta(days=7)).isoformat())
        tasks=[dict(r) for r in rows]
        overdue=[t for t in tasks if t.get("due_date") and t["due_date"] < day.isoformat()]
        due_today=[t for t in tasks if t.get("due_date")==day.isoformat()]
        next_7=[t for t in tasks if t.get("due_date") and
                day.isoformat() <= t["due_date"] <= (day+timedelta(days=7)).isoformat()]
        critical=[t for t in tasks if t.get("priority")=="Critical"]
        blocked=[t for t in tasks if t.get("status")=="Blocked"]
        return {"person":str(assigned_to).strip(),"tasks":tasks,
                "metrics":{"open":len(tasks),"overdue":len(overdue),
                           "today":len(due_today),"next_7_days":len(next_7),
                           "critical":len(critical),"blocked":len(blocked)}}

    def my_day(self, assigned_to, today=None):
        data=self.personal_work_queue(assigned_to,today)
        data["today_tasks"]=[t for t in data["tasks"] if t.get("due_date") == 
                             (today or __import__("datetime").date.today().isoformat())]
        return data

    def quick_action(self, task_id, action, value=None):
        task=self.repo.task_by_id(task_id)
        if not task:
            raise ValueError("Task not found.")
        action=str(action).strip().lower()
        if action=="start":
            return self.transition_project_task(task_id,"In Progress")
        if action=="block":
            return self.transition_project_task(task_id,"Blocked")
        if action=="complete":
            return self.transition_project_task(task_id,"Completed")
        if action=="reopen":
            return self.transition_project_task(task_id,"Open")
        if action=="deadline":
            if value:
                from datetime import date
                date.fromisoformat(str(value))
            return self.repo.quick_update_task(task_id,due_date=value or None)
        if action=="priority":
            if value not in {"Low","Normal","High","Critical"}:
                raise ValueError("Invalid priority.")
            return self.repo.quick_update_task(task_id,priority=value)
        if action=="assign":
            if not str(value or "").strip():
                raise ValueError("Responsible person is required.")
            return self.repo.quick_update_task(task_id,assigned_to=str(value).strip())
        raise ValueError("Unknown quick action.")

    def project_execution_view(self, project_id):
        data=self.repo.project_execution_view(project_id)
        tasks=data["tasks"]
        total=len(tasks)
        completed=sum(t["status"] in {"Completed","Closed"} for t in tasks)
        data["task_progress"]=round(completed/total*100,2) if total else 0.0
        for a in data["activities"]:
            at=[t for t in tasks if t["activity_id"]==a["id"]]
            done=sum(t["status"] in {"Completed","Closed"} for t in at)
            a["task_count"]=len(at)
            a["completed_tasks"]=done
            a["progress"]=round(done/len(at)*100,2) if at else 0.0
            a["budget"]=float(a["budget"] or 0)
            a["actual"]=round(float(a["actual"] or 0),2)
            a["variance"]=round(a["budget"]-a["actual"],2)
            a["utilization"]=round(a["actual"]/a["budget"]*100,2) if a["budget"] else 0.0
        return data

    def activity_execution_view(self, project_id, activity_id):
        data=self.repo.activity_execution_view(project_id,activity_id)
        tasks=data["tasks"]
        done=sum(t["status"] in {"Completed","Closed"} for t in tasks)
        data["progress"]=round(done/len(tasks)*100,2) if tasks else 0.0
        data["open_tasks"]=sum(t["status"] not in {"Completed","Closed"} for t in tasks)
        return data

    def execution_action(self, project_id, task_id, action, value=None):
        task=self.repo.task_by_id(task_id)
        if not task or int(task["project_id"]) != int(project_id):
            raise ValueError("Task does not belong to selected project.")
        if action in {"start","block","complete","reopen"}:
            return self.quick_action(task_id,action,value)
        if action in {"deadline","priority","assign"}:
            return self.quick_action(task_id,action,value)
        raise ValueError("Unknown execution action.")
