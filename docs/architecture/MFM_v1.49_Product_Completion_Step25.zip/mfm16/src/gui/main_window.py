import tkinter as tk
from dataclasses import dataclass
from tkinter import ttk, messagebox, simpledialog, filedialog
from datetime import date

@dataclass(frozen=True)
class NavigationItem:
    """Immutable presentation model for one product-navigation item.

    ``permission_code`` is deliberately optional.  Step 7 does not invent
    authorization rules that are not already present in the v1.49 GUI.
    Existing workspace methods remain the authoritative permission boundary
    until the permission contract is explicitly migrated in a later step.
    """

    area: str
    label: str
    command: str
    permission_code: str | None = None


class MainWindow:
    def __init__(self, context):
        self.ctx = context
        self.root = tk.Tk()
        self.root.title("MFM — MaritimForeningsManager")
        self.root.geometry("1100x700")
        self.current_user = None
        self._login()

    def _login(self):
        win = tk.Toplevel(self.root)
        win.title("MFM Login")
        win.geometry("360x220")
        win.transient(self.root)
        win.grab_set()

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="MFM Login", font=("Segoe UI", 16, "bold")).pack(pady=(0,12))
        ttk.Label(frame, text="Username").pack(anchor="w")
        username = ttk.Entry(frame)
        username.pack(fill="x", pady=(0,8))
        ttk.Label(frame, text="Password").pack(anchor="w")
        password = ttk.Entry(frame, show="*")
        password.pack(fill="x")

        def do_login():
            user = self.ctx.users.authenticate(username.get(), password.get())
            if not user:
                messagebox.showerror("MFM Login", "Invalid username or password.")
                return
            self.current_user = user
            win.destroy()
            self._build()

        ttk.Button(frame, text="Login", command=do_login).pack(pady=14)
        win.protocol("WM_DELETE_WINDOW", self.root.destroy)
        username.focus_set()
        self.root.withdraw()

        def on_close():
            if win.winfo_exists():
                win.destroy()
            self.root.destroy()
        win.protocol("WM_DELETE_WINDOW", on_close)
        self.root.wait_window(win)
        if self.current_user:
            self.root.deiconify()

    def _build(self):
        top = ttk.Frame(self.root, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text="MFM — Management & Intelligence", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Button(top, text="Refresh", command=self.refresh).pack(side="right")
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(top, textvariable=self.search_var, width=35)
        search_entry.pack(side="right", padx=8)
        ttk.Button(top, text="Search", command=self.run_search).pack(side="right")
        search_entry.bind("<Return>", lambda event: self.run_search())

        # Product navigation: keep the top level focused on what the user
        # wants to do, while exposing existing workspaces in a second row.
        # This replaces the legacy version-by-version flat command bar without
        # changing any workspace implementation.
        self.product_nav = ttk.Frame(self.root, padding=(12,0))
        self.product_nav.pack(fill="x")
        self.workspace_nav = ttk.Frame(self.root, padding=(12,4,12,0))
        self.workspace_nav.pack(fill="x")

        for area, _commands in self.product_navigation_contract():
            ttk.Button(
                self.product_nav,
                text=area,
                command=lambda selected=area: self.show_product_area(selected),
            ).pack(side="left", padx=(0,6))

        self.body = ttk.Frame(self.root, padding=12)
        self.body.pack(fill="both", expand=True)
        self.show_product_area("Home")

    def show_product_area(self, area):
        """Display existing workspace commands for one product area."""
        for child in self.workspace_nav.winfo_children():
            child.destroy()

        items = self.navigation_items(area)
        for item in items:
            command = getattr(self, item.command)
            button = ttk.Button(
                self.workspace_nav,
                text=item.label,
                command=command,
            )
            button.pack(side="left", padx=(0,4))
            if not self.navigation_allowed(item):
                button.state(["disabled"])

        if area == "Home":
            self.show_dashboard()

    @classmethod
    def command_registry(cls):
        """Return the currently supported MainWindow navigation commands.

        The registry is intentionally string-based so command definitions are
        explicit and testable without constructing a Tk window. Missing legacy
        handlers are not silently replaced with stubs.
        """
        return (
            ("Dashboard", "show_dashboard"),
            ("Projects", "show_projects"),
            ("Project Finance", "show_project_finance"),
            ("Tasks", "show_tasks"),
            ("Risks", "show_risks"),
            ("Decisions", "show_decisions"),
            ("Accounting", "show_accounting"),
            ("Chart of Accounts", "show_accounts"),
            ("Journals", "show_journals"),
            ("Trial Balance", "show_trial_balance"),
            ("Financial Dashboard", "show_financial_dashboard"),
            ("Members", "show_members"),
            ("Membership Billing", "show_membership_billing"),
            ("Dunning", "show_dunning"),
            ("Member Administration", "show_member_admin"),
            ("Activities & Projects", "show_activities"),
            ("Project Financials", "show_project_financials"),
            ("Project Control", "show_project_control"),
            ("Project Work", "show_project_work"),
            ("Operational Workboard", "show_operational_workboard"),
            ("Operational Actions", "show_operational_actions"),
            ("Operational Alerts", "show_operational_alerts"),
            ("My Day", "show_my_day"),
            ("Daily Execution", "show_daily_execution"),
            ("Project Execution", "show_project_execution"),
            ("Project Execution Actions", "show_project_execution_actions"),
            ("Project Progress Control", "show_project_progress_control"),
            ("Project Control Actions", "show_project_control_actions"),
            ("Project Control Cockpit", "show_project_control_cockpit"),
            ("Integrated Operations", "show_integrated_operations_dashboard"),
            ("Integrated Operations Actions", "show_integrated_operations_actions"),
            ("Navigation & Workspace", "show_workspace_integration"),
            ("Global Search", "show_global_search"),
            ("Unified Record View", "show_unified_record_view"),
            ("Personal Workspace", "show_personal_workspace"),
            ("Personal Work Actions", "show_personal_work_actions"),
            ("Today View", "show_today_view"),
            ("Quick Capture", "show_quick_capture"),
            ("Work Intake Triage", "show_work_intake_triage"),
            ("Administration", "show_administration"),
            ("Users", "show_users"),
            ("Audit", "show_audit"),
            ("Backup & Restore", "show_backup_restore"),
            ("Export", "show_export"),
        )

    @classmethod
    def product_navigation_contract(cls):
        """Map existing workspace commands to the seven product areas.

        This is a contract only; the visible navigation remains unchanged in
        this phase. Empty areas explicitly represent capabilities that do not
        currently have a resolvable MainWindow workspace command in the
        supplied v1.49 codebase.
        """
        return (
            ("Home", (
                "show_dashboard",
                "show_integrated_operations_dashboard",
                "show_integrated_operations_actions",
                "show_risks",
                "show_decisions",
            )),
            ("Work", (
                "show_tasks",
                "show_operational_workboard",
                "show_operational_actions",
                "show_operational_alerts",
                "show_my_day",
                "show_daily_execution",
                "show_personal_workspace",
                "show_personal_work_actions",
                "show_today_view",
                "show_quick_capture",
                "show_work_intake_triage",
                "show_global_search",
                "show_unified_record_view",
                "show_workspace_integration",
            )),
            ("Projects", (
                "show_projects",
                "show_project_finance",
                "show_activities",
                "show_project_financials",
                "show_project_control",
                "show_project_work",
                "show_project_execution",
                "show_project_execution_actions",
                "show_project_progress_control",
                "show_project_control_actions",
                "show_project_control_cockpit",
            )),
            ("Members", (
                "show_members",
                "show_membership_billing",
                "show_dunning",
                "show_member_admin",
            )),
            ("Finance", (
                "show_accounting",
                "show_accounts",
                "show_journals",
                "show_trial_balance",
            )),
            ("Reports", (
                "show_financial_dashboard",
            )),
            ("Administration", (
                "show_administration",
                "show_users",
                "show_audit",
                "show_backup_restore",
                "show_export",
            )),
        )

    @classmethod
    def navigation_model(cls):
        """Return the product navigation as a presentation model.

        The model is derived from the existing command registry and product
        navigation contract.  It does not create widgets and therefore can be
        tested independently of Tk.
        """
        labels = {method: label for label, method in cls.command_registry()}
        permission_codes = {
            "show_dashboard": "dashboard.view",
            "show_projects": "projects.view",
            "show_project_finance": "projects.view",
            "show_activities": "projects.view",
            "show_project_financials": "projects.view",
            "show_project_control": "projects.view",
            "show_project_work": "projects.view",
            "show_project_execution": "projects.view",
            "show_project_execution_actions": "projects.view",
            "show_project_progress_control": "projects.view",
            "show_project_control_actions": "projects.view",
            "show_project_control_cockpit": "projects.view",
            "show_members": "members.view",
            "show_membership_billing": "members.view",
            "show_dunning": "members.view",
            "show_member_admin": "members.view",
            "show_accounting": "accounting.view",
            "show_accounts": "accounting.view",
            "show_journals": "accounting.view",
            "show_trial_balance": "accounting.view",
            "show_financial_dashboard": "dashboard.view",
            "show_users": "users.manage",
            "show_audit": "audit.view",
            "show_backup_restore": "system.backup",
            "show_export": "reports.export",
        }
        model = []
        for area, commands in cls.product_navigation_contract():
            for command in commands:
                model.append(
                    NavigationItem(
                        area=area,
                        label=labels[command],
                        command=command,
                        permission_code=permission_codes.get(command),
                    )
                )
        return tuple(model)

    @classmethod
    def navigation_items(cls, area=None):
        """Return navigation presentation items, optionally for one area."""
        items = cls.navigation_model()
        if area is None:
            return items
        return tuple(item for item in items if item.area == area)

    def navigation_allowed(self, item):
        """Evaluate only permissions already defined by the current GUI.

        Items without a migrated permission code remain governed by their
        existing workspace method, avoiding accidental authorization changes.
        """
        if item.permission_code is None:
            return True
        return self.allowed(item.permission_code)

    def build_product_navigation(self, parent):
        """Render the product navigation model without changing workspace code.

        This adapter is intentionally separate from ``_build`` in Phase A.1.
        It creates one navigation group per product area and wires each item
        to the existing MainWindow command. Empty product areas are rendered
        as disabled groups only when they contain no commands.
        """
        container = ttk.Frame(parent)
        buttons = {}
        for area in ("Home", "Work", "Projects", "Members", "Finance", "Reports", "Administration"):
            items = self.navigation_items(area)
            group = ttk.LabelFrame(container, text=area, padding=(6, 4))
            group.pack(side="left", padx=(0, 6), fill="y")
            for item in items:
                command = getattr(self, item.command)
                button = ttk.Button(group, text=item.label, command=command)
                button.pack(side="left", padx=2)
                if not self.navigation_allowed(item):
                    button.state(["disabled"])
                buttons[item.command] = button
        return container, buttons

    def preview_product_navigation(self, parent):
        """Build an isolated product-navigation preview for Phase A.1.

        The preview deliberately uses a caller-supplied parent and never
        replaces the existing ``_build`` navigation. This provides a controlled
        integration point for validating the complete contract/model/adapter
        chain before the visible MainWindow navigation is migrated.
        """
        preview = ttk.LabelFrame(
            parent,
            text="Product Navigation Preview",
            padding=(8, 6),
        )
        preview.pack(fill="x", pady=(0, 8))
        ttk.Label(
            preview,
            text="Phase A.1 preview — existing navigation remains active",
        ).pack(anchor="w", pady=(0, 6))
        navigation, buttons = self.build_product_navigation(preview)
        navigation.pack(fill="x")
        return preview, buttons

    def show_administration(self):
        self.clear()
        ttk.Label(self.body, text="Administration", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(
            self.body,
            text="System administration, access control, audit, backup and export.",
        ).pack(anchor="w", pady=(4, 12))
        buttons = ttk.Frame(self.body)
        buttons.pack(fill="x")
        actions = [
            ("Users", self.show_users, "users.manage"),
            ("Audit", self.show_audit, "audit.view"),
            ("Backup & Restore", self.show_backup_restore, "system.backup"),
            ("Export", self.show_export, "reports.export"),
        ]
        for label, command, permission in actions:
            button = ttk.Button(buttons, text=label, command=command)
            button.pack(side="left", padx=(0, 6))
            if permission and not self.allowed(permission):
                button.state(["disabled"])

    def show_users(self):
        if not self.allowed("users.manage"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Users & Roles", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        self.table(["id", "username", "display_name", "active", "role_name"], self.ctx.users.users())

    def show_audit(self):
        if not self.allowed("audit.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Audit Log", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        self.table(["id", "username", "action", "entity_type", "entity_id", "status"], self.ctx.audit.list())

    def show_backup_restore(self):
        if not self.allowed("system.backup"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Backup & Restore", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(
            self.body,
            text="Backups are integrity-checked before restore and the current database is preserved before replacement.",
            wraplength=800,
        ).pack(anchor="w", pady=8)
        buttons = ttk.Frame(self.body)
        buttons.pack(anchor="w", pady=8)

        def backup():
            path = filedialog.asksaveasfilename(
                title="Create MFM Backup",
                defaultextension=".db",
                filetypes=[("SQLite database", "*.db"), ("All files", "*.*")],
            )
            if not path:
                return
            try:
                self.ctx.system.backup(path)
                messagebox.showinfo("MFM Backup", "Backup created and integrity-checked.")
            except Exception as exc:
                self.ctx.errors.handle(exc, self.current_user, "Backup")
                messagebox.showerror("MFM Backup", str(exc))

        def restore():
            path = filedialog.askopenfilename(
                title="Restore MFM Backup",
                filetypes=[("SQLite database", "*.db"), ("All files", "*.*")],
            )
            if not path:
                return
            if not messagebox.askyesno("MFM Restore", "Restore this backup? The current database will be preserved first."):
                return
            try:
                self.ctx.system.restore(path)
                messagebox.showinfo("MFM Restore", "Backup restored and integrity-checked. Restart MFM before continuing work.")
            except Exception as exc:
                self.ctx.errors.handle(exc, self.current_user, "Restore")
                messagebox.showerror("MFM Restore", str(exc))

        ttk.Button(buttons, text="Create Backup", command=backup).pack(side="left", padx=(0, 6))
        ttk.Button(buttons, text="Restore Backup", command=restore).pack(side="left")

    def show_export(self):
        if not self.allowed("reports.export"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Data Export", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        exports = [
            ("Members", self.ctx.export.export_members),
            ("Projects", self.ctx.export.export_projects),
            ("Journals", self.ctx.export.export_journals),
            ("Invoices", self.ctx.export.export_invoices),
            ("Bank Transactions", self.ctx.export.export_bank_transactions),
            ("Trial Balance", self.ctx.export.export_trial_balance),
        ]
        for label, exporter in exports:
            def run_export(exporter=exporter, label=label):
                path = filedialog.asksaveasfilename(
                    title=f"Export {label}",
                    defaultextension=".csv",
                    filetypes=[("CSV", "*.csv"), ("All files", "*.*")],
                )
                if not path:
                    return
                try:
                    exporter(path)
                    messagebox.showinfo("MFM Export", f"{label} exported successfully.")
                except Exception as exc:
                    self.ctx.errors.handle(exc, self.current_user, f"Export {label}")
                    messagebox.showerror("MFM Export", str(exc))
            ttk.Button(self.body, text=label, command=run_export).pack(anchor="w", pady=3)

    def allowed(self, code):
        return self.ctx.permissions.can(self.current_user, code)

    def denied(self):
        messagebox.showwarning("MFM Access", "You do not have permission for this function.")

    def clear(self):
        for child in self.body.winfo_children():
            child.destroy()

    def card(self, parent, title, value, row, col):
        f = ttk.LabelFrame(parent, text=title, padding=18)
        f.grid(row=row, column=col, sticky="nsew", padx=6, pady=6)
        ttk.Label(f, text=str(value), font=("Segoe UI", 22, "bold")).pack()
        return f

    def show_dashboard(self):
        self.clear()
        ttk.Label(self.body, text="Management Dashboard", font=("Segoe UI", 18, "bold")).pack(anchor="w")
    
        snapshot = self.ctx.management.snapshot()
        grid = ttk.Frame(self.body)
        grid.pack(fill="x", pady=12)
        for c in range(4):
            grid.columnconfigure(c, weight=1)
    
        cards = [
            ("Projects", snapshot["projects"]),
            ("Open Tasks", snapshot["open_tasks"]),
            ("Open Risks", snapshot["open_risks"]),
            ("Pending Decisions", snapshot["pending_decisions"]),
            ("Members", snapshot["members"]),
            ("Open Invoices", snapshot["open_invoices"]),
            ("Unmatched Bank", snapshot["unmatched_bank"]),
            ("Result", f"{snapshot['result']:,.2f}"),
        ]
        for i, (title, value) in enumerate(cards):
            self.card(grid, title, value, i // 4, i % 4)
    
        ttk.Label(self.body, text="Attention Required", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(12, 6))
        attention = self.ctx.management.attention_items()
        tree = ttk.Treeview(self.body, columns=("priority","item"), show="headings", height=6)
        tree.heading("priority", text="Priority")
        tree.heading("item", text="Item")
        tree.column("priority", width=110)
        tree.column("item", width=700)
        for priority, item in attention:
            tree.insert("", "end", values=(priority, item))
        tree.pack(fill="x")
    
        ttk.Separator(self.body).pack(fill="x", pady=14)
        ttk.Label(
            self.body,
            text=f"Income {snapshot['income']:,.2f}  |  Expenses {snapshot['expenses']:,.2f}  |  Result {snapshot['result']:,.2f}",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor="w")
    
    def table(self, columns, rows):
        tree = ttk.Treeview(self.body, columns=columns, show="headings")
        for c in columns:
            tree.heading(c, text=c.replace("_"," ").title())
            tree.column(c, width=180)
        for row in rows:
            tree.insert("", "end", values=[row[c] for c in columns])
        tree.pack(fill="both", expand=True, pady=10)
        return tree

    def show_projects(self):
        if not self.allowed("projects.view"):
            self.denied()
            return
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Projects", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="Project Finance", command=self.show_project_finance).pack(side="right", padx=(0,6))
        ttk.Button(head, text="New Project", command=self.new_project).pack(side="right")
        self.table(["id","name","status","budget"], self.ctx.projects.list())


    def show_project_finance(self):
        if not self.allowed("projects.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Project Finance", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        projects = self.ctx.projects.list()
        if not projects:
            ttk.Label(self.body, text="Create a project first.").pack(anchor="w", pady=10)
            return
        project_names = {str(p["id"]): p["name"] for p in projects}
        selected = tk.StringVar(value=str(projects[0]["id"]))
        row = ttk.Frame(self.body); row.pack(fill="x", pady=10)
        ttk.Label(row, text="Project:").pack(side="left")
        combo = ttk.Combobox(row, textvariable=selected, values=list(project_names.keys()), state="readonly", width=10)
        combo.pack(side="left", padx=6)
    
        output = ttk.LabelFrame(self.body, text="Budget vs Actual", padding=12)
        output.pack(fill="x", pady=10)
    
        def refresh():
            for w in output.winfo_children(): w.destroy()
            pid = int(selected.get())
            result = self.ctx.accounting.project_budget_vs_actual(pid)
            ttk.Label(output, text=f"Budget: {result['budget']:,.2f}").pack(anchor="w")
            ttk.Label(output, text=f"Actual: {result['actual']:,.2f}").pack(anchor="w")
            ttk.Label(output, text=f"Variance: {result['variance']:,.2f}").pack(anchor="w")
            ttk.Label(output, text=f"Utilization: {result['utilization']:.1f}%").pack(anchor="w")
    
        ttk.Button(row, text="Refresh", command=refresh).pack(side="left")
        refresh()

    def new_project(self):
        if not self.allowed("projects.edit"):
            self.denied()
            return
        name = simpledialog.askstring("New Project", "Project name:")
        if not name: return
        try:
            self.ctx.projects.create(name)
            self.show_projects()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_tasks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Tasks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Task", command=self.new_task).pack(side="right")
        self.table(["id","title","status","due_date","owner"], self.ctx.tasks.list())

    def new_task(self):
        title = simpledialog.askstring("New Task", "Task title:")
        if not title: return
        try:
            self.ctx.tasks.create(title)
            self.show_tasks()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_risks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Risks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Risk", command=self.new_risk).pack(side="right")
        self.table(["id","title","severity","status","owner"], self.ctx.risks.list())

    def new_risk(self):
        title = simpledialog.askstring("New Risk", "Risk title:")
        if not title: return
        try:
            self.ctx.risks.create(title)
            self.show_risks()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_decisions(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Decisions", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Decision", command=self.new_decision).pack(side="right")
        self.table(["id","title","status","owner"], self.ctx.decisions.list())

    def new_decision(self):
        title = simpledialog.askstring("New Decision", "Decision title:")
        if not title: return
        try:
            self.ctx.decisions.create(title)
            self.show_decisions()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))


    def show_accounting(self):
        if not self.allowed("accounting.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Accounting", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        buttons = ttk.Frame(self.body)
        buttons.pack(fill="x", pady=8)
        ttk.Button(buttons, text="Chart of Accounts", command=self.show_accounts).pack(side="left", padx=(0,6))
        ttk.Button(buttons, text="Journals", command=self.show_journals).pack(side="left", padx=(0,6))
        ttk.Button(buttons, text="Trial Balance", command=self.show_trial_balance).pack(side="left")
        ttk.Label(self.body, text="Accounting Core v0.1: balanced double-entry journals and trial balance.").pack(anchor="w", pady=10)

    def show_accounts(self):
        if not self.allowed("accounting.view"):
            self.denied()
            return
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Chart of Accounts", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Account", command=self.new_account).pack(side="right")
        self.table(["number","name","account_type"], self.ctx.accounting.accounts())

    def new_account(self):
        number = simpledialog.askstring("New Account", "Account number:")
        if not number: return
        name = simpledialog.askstring("New Account", "Account name:")
        if not name: return
        account_type = simpledialog.askstring(
            "New Account", "Type (Asset, Liability, Income, Expense):",
            initialvalue="Expense")
        try:
            self.ctx.accounting.create_account(number, name, account_type)
            self.show_accounts()
        except Exception as e:
            messagebox.showerror("MFM Accounting", str(e))

    def show_journals(self):
        if not self.allowed("accounting.view"):
            self.denied()
            return
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Posted Journals", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Label(self.body, text="Journal entry creation UI is the next accounting increment.").pack(anchor="w", pady=8)
        self.table(["journal_no","journal_date","description","status"], self.ctx.accounting.journals())

    def show_trial_balance(self):
        if not self.allowed("accounting.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body, text="Trial Balance", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        self.table(["number","name","debit","credit"], self.ctx.accounting.trial_balance())

    def refresh(self):
        self.show_dashboard()

    def run(self):
        self.root.mainloop()


    def show_financial_dashboard(self):
        self.clear()
        ttk.Label(
            self.body, text="Financial Reporting & Management Dashboard",
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w")
        ttk.Label(
            self.body,
            text="Overblik over indtægter, omkostninger, resultat og balance."
        ).pack(anchor="w", pady=(2, 10))

        controls = ttk.Frame(self.body)
        controls.pack(fill="x", pady=6)

        ttk.Label(controls, text="Fra:").pack(side="left")
        start = ttk.Entry(controls, width=12)
        start.pack(side="left", padx=4)
        ttk.Label(controls, text="Til:").pack(side="left")
        end = ttk.Entry(controls, width=12)
        end.pack(side="left", padx=4)

        cards = ttk.Frame(self.body)
        cards.pack(fill="x", pady=10)

        values = {}
        for key, title in [
            ("revenue","Indtægter"),
            ("expenses","Omkostninger"),
            ("net_result","Årets resultat"),
            ("assets","Aktiver"),
            ("liabilities","Forpligtelser"),
            ("equity","Egenkapital")
        ]:
            frame = ttk.LabelFrame(cards, text=title)
            frame.pack(side="left", fill="x", expand=True, padx=3)
            label = ttk.Label(frame, text="0,00", font=("Segoe UI", 14, "bold"))
            label.pack(padx=8, pady=10)
            values[key] = label

        tree = ttk.Treeview(
            self.body,
            columns=("number","name","amount"),
            show="headings"
        )
        for col, title, width in [
            ("number","Konto",100),
            ("name","Navn",300),
            ("amount","Beløb",150)
        ]:
            tree.heading(col, text=title)
            tree.column(col, width=width)
        tree.pack(fill="both", expand=True, pady=8)

        def refresh():
            r = self.ctx.accounting.financial_dashboard(
                start.get().strip() or None,
                end.get().strip() or None
            )
            for k, label in values.items():
                label.config(text=f'{r[k]:,.2f}')
            for item in tree.get_children():
                tree.delete(item)
            for row in r["income_accounts"]:
                tree.insert("", "end", values=(
                    row["number"], row["name"], f'{row["amount"]:,.2f}'
                ))
            for row in r["expense_accounts"]:
                tree.insert("", "end", values=(
                    row["number"], row["name"], f'-{row["amount"]:,.2f}'
                ))

        ttk.Button(controls, text="Opdater", command=refresh).pack(side="left", padx=6)
        refresh()

    def _mfm_member_clear(self):
        for child in self.body.winfo_children():
            child.destroy()

    def show_members(self):
        if not self.allowed("members.view"):
            self.denied()
            return
        self._mfm_member_clear()
        self.ctx.members.refresh_invoice_statuses()

        ttk.Label(self.body, text="Members & Memberships",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,
                  text="Medlemmer, medlemskaber, kontingenter, fakturaer og betalinger."
                  ).pack(anchor="w",pady=(2,10))

        summary=self.ctx.members.summary()
        cards=ttk.Frame(self.body); cards.pack(fill="x",pady=6)
        for title,key in [
            ("Medlemmer","members"),("Aktive","active_members"),
            ("Aktive medlemskaber","active_memberships"),
            ("Åbne fakturaer","open_invoices"),
            ("Udestående","outstanding")
        ]:
            f=ttk.LabelFrame(cards,text=title)
            f.pack(side="left",fill="x",expand=True,padx=3)
            value=summary[key]
            txt=f"{float(value):,.2f}" if key=="outstanding" else str(value)
            ttk.Label(f,text=txt,font=("Segoe UI",13,"bold")).pack(padx=8,pady=8)

        toolbar=ttk.Frame(self.body); toolbar.pack(fill="x",pady=6)
        search=tk.StringVar()
        ttk.Label(toolbar,text="Søg:").pack(side="left")
        ttk.Entry(toolbar,textvariable=search,width=30).pack(side="left",padx=5)

        tree=ttk.Treeview(self.body,
            columns=("no","name","email","phone","status","joined"),
            show="headings")
        for c,t,w in [
            ("no","Medlemsnr.",100),("name","Navn",240),("email","E-mail",220),
            ("phone","Telefon",130),("status","Status",100),("joined","Indmeldt",110)
        ]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=6)

        selected_id={"value":None}

        def load():
            for x in tree.get_children(): tree.delete(x)
            rows=self.ctx.members.search(search.get()) if search.get().strip() else self.ctx.members.members()
            for r in rows:
                tree.insert("", "end", iid=str(r["id"]), values=(
                    r["member_no"],f'{r["first_name"]} {r["last_name"]}',
                    r["email"],r["phone"],r["status"],r["joined_date"] or ""
                ))

        def new_member():
            win=tk.Toplevel(self.root); win.title("Nyt medlem"); win.geometry("420x430")
            fields={}
            for label,key in [
                ("Medlemsnr.","member_no"),("Fornavn","first_name"),("Efternavn","last_name"),
                ("E-mail","email"),("Telefon","phone"),("Adresse","address"),
                ("Postnr.","postal_code"),("By","city"),("Indmeldelsesdato","joined_date")
            ]:
                ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
                e=ttk.Entry(win); e.pack(fill="x",padx=15); fields[key]=e
            fields["joined_date"].insert(0,date.today().isoformat())
            def save():
                try:
                    self.ctx.members.create_member(
                        fields["member_no"].get(),fields["first_name"].get(),fields["last_name"].get(),
                        **{k:v.get() for k,v in fields.items() if k not in ("member_no","first_name","last_name")}
                    )
                    win.destroy(); load()
                except Exception as exc:
                    messagebox.showerror("Medlem",str(exc))
            ttk.Button(win,text="Gem",command=save).pack(pady=14)

        def membership():
            sel=tree.selection()
            if not sel: return
            member_id=int(sel[0])
            types=self.ctx.members.membership_types()
            if not types:
                messagebox.showwarning("Medlemskab","Opret først en medlemskabstype.")
                return
            win=tk.Toplevel(self.root); win.title("Tilknyt medlemskab"); win.geometry("400x220")
            mapping={f'{x["name"]} — {float(x["annual_fee"]):,.2f}':x for x in types}
            var=tk.StringVar(value=list(mapping)[0])
            ttk.Label(win,text="Medlemskabstype").pack(anchor="w",padx=15,pady=8)
            ttk.Combobox(win,textvariable=var,values=list(mapping),state="readonly").pack(fill="x",padx=15)
            ttk.Label(win,text="Startdato").pack(anchor="w",padx=15,pady=(8,2))
            start=tk.Entry(win); start.pack(fill="x",padx=15); start.insert(0,date.today().isoformat())
            def save():
                try:
                    self.ctx.members.add_membership(member_id,mapping[var.get()]["id"],start.get())
                    win.destroy(); load()
                except Exception as exc: messagebox.showerror("Medlemskab",str(exc))
            ttk.Button(win,text="Gem",command=save).pack(pady=12)

        def invoice():
            sel=tree.selection()
            if not sel: return
            memberships=[m for m in self.ctx.members.memberships() if m["id"] and m["member_no"]==tree.item(sel[0])["values"][0]]
            if not memberships:
                messagebox.showwarning("Faktura","Medlemmet har intet aktivt medlemskab.")
                return
            m=memberships[0]
            self.ctx.members.invoice_membership(m["id"],m["id"] if False else
                next(x["id"] for x in self.ctx.members.repo.list_memberships() if x["member_no"]==m["member_no"] and x["membership_type"]==m["membership_type"]),
                float(m["annual_fee"]))
            load()

        def open_member():
            sel=tree.selection()
            if not sel: return
            member_id=int(sel[0])
            member=self.ctx.members.member(member_id)
            invoices=self.ctx.members.member_invoices(member_id)
            win=tk.Toplevel(self.root); win.title("Medlemsdetaljer"); win.geometry("850x500")
            ttk.Label(win,text=f'{member["member_no"]} — {member["first_name"]} {member["last_name"]}',
                      font=("Segoe UI",14,"bold")).pack(anchor="w",padx=12,pady=10)
            ttk.Label(win,text=f'{member["email"]} | {member["phone"]} | {member["address"]}, {member["postal_code"]} {member["city"]}').pack(anchor="w",padx=12)
            inv=ttk.Treeview(win,columns=("no","date","due","amount","paid","status"),show="headings")
            for c,t,w in [("no","Faktura",80),("date","Dato",100),("due","Forfald",100),("amount","Beløb",100),("paid","Betalt",100),("status","Status",130)]:
                inv.heading(c,text=t); inv.column(c,width=w)
            inv.pack(fill="both",expand=True,padx=12,pady=12)
            for r in invoices:
                status=self.ctx.members.invoice_status(r)
                inv.insert("", "end", values=(r["invoice_no"],r["invoice_date"],r["due_date"],
                    f'{float(r["amount"]):,.2f}',f'{float(r["paid_amount"]):,.2f}',status))

        ttk.Button(toolbar,text="Nyt medlem",command=new_member).pack(side="left",padx=4)
        ttk.Button(toolbar,text="Tilknyt medlemskab",command=membership).pack(side="left",padx=4)
        ttk.Button(toolbar,text="Opret kontingentfaktura",command=invoice).pack(side="left",padx=4)
        ttk.Button(toolbar,text="Vis detaljer",command=open_member).pack(side="left",padx=4)
        ttk.Button(toolbar,text="Opdater",command=load).pack(side="left",padx=4)
        search.bind("<KeyRelease>",lambda e:load())
        tree.bind("<Double-1>",lambda e:open_member())
        load()

    def show_membership_billing(self):
        if not self.allowed("members.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body,text="Membership Billing & Payment Management",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Årlig masseopkrævning, betalingsstatus og restancer.").pack(anchor="w",pady=(2,10))

        controls=ttk.Frame(self.body); controls.pack(fill="x",pady=6)
        ttk.Label(controls,text="År:").pack(side="left")
        year=tk.StringVar(value=str(date.today().year))
        ttk.Entry(controls,textvariable=year,width=8).pack(side="left",padx=5)
        ttk.Label(controls,text="Fakturadato:").pack(side="left")
        invdate=tk.StringVar(value=date.today().isoformat())
        ttk.Entry(controls,textvariable=invdate,width=12).pack(side="left",padx=5)
        ttk.Label(controls,text="Forfald:").pack(side="left")
        due=tk.StringVar(value=date.today().isoformat())
        ttk.Entry(controls,textvariable=due,width=12).pack(side="left",padx=5)

        summary_frame=ttk.Frame(self.body); summary_frame.pack(fill="x",pady=6)
        summary_labels={}
        for key,title in [("invoices","Fakturaer"),("invoiced","Faktureret"),
                          ("paid_amount","Betalt"),("outstanding","Udestående")]:
            f=ttk.LabelFrame(summary_frame,text=title)
            f.pack(side="left",fill="x",expand=True,padx=3)
            lab=ttk.Label(f,text="0,00",font=("Segoe UI",13,"bold"))
            lab.pack(padx=8,pady=8); summary_labels[key]=lab

        tree=ttk.Treeview(self.body,
            columns=("member_no","name","type","amount","invoiced","invoice_no"),
            show="headings")
        for c,t,w in [("member_no","Medlemsnr.",100),("name","Navn",220),
                      ("type","Type",160),("amount","Beløb",110),
                      ("invoiced","Allerede faktureret",130),("invoice_no","Faktura",90)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        preview_cache=[]
        def refresh():
            nonlocal preview_cache
            y=int(year.get())
            preview_cache=self.ctx.members.billing_preview(y,invdate.get(),due.get())
            for x in tree.get_children(): tree.delete(x)
            for r in preview_cache:
                tree.insert("", "end", values=(r["member_no"],r["name"],r["membership_type"],
                    f'{r["amount"]:,.2f}',"Ja" if r["already_invoiced"] else "Nej",
                    r["existing_invoice_no"] or ""))
            sm=self.ctx.members.payment_status_summary(y)
            for k,lab in summary_labels.items():
                lab.config(text=f'{sm[k]:,.2f}' if k!="invoices" else str(sm[k]))

        def bill():
            try:
                r=self.ctx.members.bill_memberships(int(year.get()),invdate.get(),due.get())
                refresh()
                messagebox.showinfo("Masseopkrævning",
                    f'Oprettet: {r["created_count"]}\nSprunget over: {r["skipped_count"]}')
            except Exception as exc:
                messagebox.showerror("Masseopkrævning",str(exc))

        ttk.Button(controls,text="Preview",command=refresh).pack(side="left",padx=5)
        ttk.Button(controls,text="Opret alle kontingentfakturaer",command=bill).pack(side="left",padx=5)
        refresh()

    def show_dunning(self):
        if not self.allowed("members.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body,text="Member Communication & Dunning",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Forfaldne kontingenter, påmindelser og rykkerhistorik."
                  ).pack(anchor="w",pady=(2,10))
        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        ttk.Label(top,text="Pr. dato:").pack(side="left")
        asof=tk.StringVar(value=date.today().isoformat())
        ttk.Entry(top,textvariable=asof,width=12).pack(side="left",padx=5)

        tree=ttk.Treeview(self.body,
            columns=("invoice","member","due","days","amount","paid","outstanding"),
            show="headings")
        for c,t,w in [("invoice","Faktura",90),("member","Medlem",240),
                      ("due","Forfald",100),("days","Dage",70),
                      ("amount","Beløb",100),("paid","Betalt",100),
                      ("outstanding","Udestående",120)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)
        cache={}

        def refresh():
            cache.clear()
            for x in tree.get_children(): tree.delete(x)
            rows=self.ctx.members.dunning_preview(asof.get())
            for idx,r in enumerate(rows):
                cache[str(idx)]=r
                tree.insert("", "end", iid=str(idx), values=(
                    r["invoice_no"],r["name"],r["due_date"],r["days_overdue"],
                    f'{r["amount"]:,.2f}',f'{r["paid_amount"]:,.2f}',
                    f'{r["outstanding"]:,.2f}'
                ))

        def prepare(level):
            sel=tree.selection()
            if not sel: return
            row=cache[sel[0]]
            try:
                cid=self.ctx.members.record_dunning(row,level)
                messagebox.showinfo("Kommunikation",f"Kommunikation oprettet som kladde/log. ID: {cid}")
            except Exception as exc:
                messagebox.showerror("Kommunikation",str(exc))

        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        ttk.Button(top,text="Påmindelse",command=lambda:prepare(1)).pack(side="left",padx=5)
        ttk.Button(top,text="Rykker",command=lambda:prepare(2)).pack(side="left",padx=5)
        ttk.Button(top,text="Sidste påmindelse",command=lambda:prepare(3)).pack(side="left",padx=5)
        refresh()

    def show_member_admin(self):
        if not self.allowed("members.view"):
            self.denied()
            return
        self.clear()
        ttk.Label(self.body,text="Member & Association Administration",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Medlemsstatus, ind-/udmeldelse, kontaktdata og medlemskort."
                  ).pack(anchor="w",pady=(2,10))

        overview=self.ctx.members.administration_overview()
        cards=ttk.Frame(self.body); cards.pack(fill="x",pady=5)
        for key,title in [("total","I alt"),("active","Aktive"),("inactive","Inaktive"),
                          ("suspended","Suspenderede"),("resigned","Udmeldte")]:
            f=ttk.LabelFrame(cards,text=title); f.pack(side="left",fill="x",expand=True,padx=3)
            ttk.Label(f,text=str(overview[key]),font=("Segoe UI",13,"bold")).pack(padx=8,pady=8)

        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        search=tk.StringVar()
        ttk.Label(top,text="Søg:").pack(side="left")
        ttk.Entry(top,textvariable=search,width=28).pack(side="left",padx=5)
        tree=ttk.Treeview(self.body,columns=("no","name","email","status","joined"),
                          show="headings")
        for c,t,w in [("no","Medlemsnr.",100),("name","Navn",220),
                      ("email","E-mail",220),("status","Status",110),("joined","Indmeldt",100)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)
        cache={}

        def refresh():
            cache.clear()
            for x in tree.get_children(): tree.delete(x)
            rows=self.ctx.members.search(search.get()) if search.get().strip() else self.ctx.members.members()
            for r in rows:
                cache[str(r["id"])]=r
                tree.insert("", "end", iid=str(r["id"]),
                            values=(r["member_no"],f'{r["first_name"]} {r["last_name"]}',
                                    r["email"],r["status"],r["joined_date"] or ""))

        def status_change(status):
            sel=tree.selection()
            if not sel: return
            try:
                self.ctx.members.change_member_status(int(sel[0]),status,
                    reason=f"Status ændret via medlemsadministration til {status}.")
                refresh()
            except Exception as exc:
                messagebox.showerror("Medlemsstatus",str(exc))

        def show_card():
            sel=tree.selection()
            if not sel: return
            card=self.ctx.members.member_card(int(sel[0]))
            m=card["member"]
            lines=[
                f"Medlemsnr.: {m['member_no']}",
                f"Navn: {m['first_name']} {m['last_name']}",
                f"E-mail: {m['email']}",
                f"Telefon: {m['phone']}",
                f"Adresse: {m['address']}, {m['postal_code']} {m['city']}",
                f"Status: {m['status']}",
                "",
                f"Medlemskaber: {len(card['memberships'])}",
                f"Fakturaer: {len(card['invoices'])}",
                f"Administrationshændelser: {len(card['events'])}"
            ]
            messagebox.showinfo("Medlemskort","\n".join(lines))

        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=4)
        ttk.Button(top,text="Medlemskort",command=show_card).pack(side="left",padx=4)
        for status,label in [("Active","Aktiv"),("Inactive","Inaktiv"),
                             ("Suspended","Suspenderet"),("Resigned","Udmeldt")]:
            ttk.Button(top,text=label,command=lambda x=status:status_change(x)).pack(side="left",padx=2)
        search.bind("<Return>",lambda e:refresh())
        refresh()

    def show_activities(self):
        self.clear()
        ttk.Label(self.body,text="Association Activities & Projects",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Projekter, aktiviteter, budgetter og fremdrift."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        project_var=tk.StringVar(value=next(iter(project_map), ""))
        combo=ttk.Combobox(top,textvariable=project_var,values=list(project_map),
                           state="readonly",width=35)
        combo.pack(side="left",padx=5)

        stats=ttk.Frame(self.body); stats.pack(fill="x",pady=5)
        stat_labels={}
        for key,title in [("budget","Projektbudget"),("activity_budget","Aktivitetsbudget"),
                          ("activity_count","Aktiviteter")]:
            f=ttk.LabelFrame(stats,text=title); f.pack(side="left",fill="x",expand=True,padx=3)
            lab=ttk.Label(f,text="0,00",font=("Segoe UI",13,"bold"))
            lab.pack(padx=8,pady=8); stat_labels[key]=lab

        tree=ttk.Treeview(self.body,columns=("name","date","status","budget"),show="headings")
        for c,t,w in [("name","Aktivitet",260),("date","Dato",110),
                      ("status","Status",120),("budget","Budget",120)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            if not project_map: return
            pid=project_map.get(project_var.get())
            if not pid: return
            for x in tree.get_children(): tree.delete(x)
            rows=self.ctx.projects.activities(pid)
            for r in rows:
                tree.insert("", "end", iid=str(r["id"]),
                            values=(r["name"],r["activity_date"] or "",
                                    r["status"],f'{float(r["budget"]):,.2f}'))
            proj=next((x for x in projects if x["id"]==pid),None)
            sm=self.ctx.projects.activity_summary(pid)
            stat_labels["budget"].config(text=f'{float(proj["budget"]):,.2f}' if proj else "0,00")
            stat_labels["activity_budget"].config(text=f'{float(sm["activity_budget"]):,.2f}')
            stat_labels["activity_count"].config(text=str(sm["activity_count"]))

        def new_activity():
            pid=project_map.get(project_var.get())
            if not pid: return
            win=tk.Toplevel(self.root); win.title("Ny aktivitet"); win.geometry("430x360")
            fields={}
            for label,key in [("Navn","name"),("Beskrivelse","description"),
                              ("Dato","activity_date"),("Budget","budget")]:
                ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
                e=ttk.Entry(win); e.pack(fill="x",padx=15); fields[key]=e
            fields["activity_date"].insert(0,date.today().isoformat())
            fields["budget"].insert(0,"0")
            def save():
                try:
                    self.ctx.projects.create_activity(pid,fields["name"].get(),
                        fields["description"].get(),fields["activity_date"].get(),
                        "Planned",float(fields["budget"].get() or 0))
                    win.destroy(); refresh()
                except Exception as exc: messagebox.showerror("Aktivitet",str(exc))
            ttk.Button(win,text="Gem",command=save).pack(pady=14)

        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        ttk.Button(top,text="Ny aktivitet",command=new_activity).pack(side="left",padx=5)
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        refresh()

    def show_project_financials(self):
        self.clear()
        ttk.Label(self.body,text="Project Financial Tracking",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Budget, faktisk projektforbrug og afvigelser."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        var=tk.StringVar(value=next(iter(project_map),""))
        combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                           state="readonly",width=35)
        combo.pack(side="left",padx=5)

        cards=ttk.Frame(self.body); cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("budget","Budget"),("actual","Faktisk forbrug"),
                          ("variance","Rest / afvigelse"),("utilization","Forbrug %")]:
            f=ttk.LabelFrame(cards,text=title); f.pack(side="left",fill="x",expand=True,padx=3)
            lab=ttk.Label(f,text="0,00",font=("Segoe UI",13,"bold")); lab.pack(padx=8,pady=8)
            labels[key]=lab

        ttk.Label(self.body,text="Aktiviteter",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(10,2))
        act=ttk.Treeview(self.body,columns=("name","budget","actual","variance","status"),
                         show="headings",height=8)
        for c,t,w in [("name","Aktivitet",260),("budget","Budget",110),
                      ("actual","Forbrug",110),("variance","Rest",110),("status","Status",110)]:
            act.heading(c,text=t); act.column(c,width=w)
        act.pack(fill="both",expand=True,pady=5)

        ttk.Label(self.body,text="Projektposteringer",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        lines=ttk.Treeview(self.body,columns=("date","journal","account","description","amount"),
                           show="headings",height=8)
        for c,t,w in [("date","Dato",100),("journal","Journal",80),("account","Konto",170),
                      ("description","Beskrivelse",280),("amount","Beløb",110)]:
            lines.heading(c,text=t); lines.column(c,width=w)
        lines.pack(fill="both",expand=True,pady=5)

        def refresh():
            pid=project_map.get(var.get())
            if not pid: return
            data=self.ctx.projects.financial_tracking(pid)
            labels["budget"].config(text=f'{data["budget"]:,.2f}')
            labels["actual"].config(text=f'{data["actual"]:,.2f}')
            labels["variance"].config(text=f'{data["variance"]:,.2f}')
            labels["utilization"].config(text=f'{data["utilization"]:.1f}%')
            for x in act.get_children(): act.delete(x)
            for r in self.ctx.projects.activity_financials(pid):
                act.insert("", "end", values=(r["name"],f'{float(r["budget"]):,.2f}',
                    f'{float(r["actual"]):,.2f}',f'{float(r["variance"]):,.2f}',r["status"]))
            for x in lines.get_children(): lines.delete(x)
            for r in self.ctx.projects.expense_lines(pid):
                amount=float(r["debit"] or 0)-float(r["credit"] or 0)
                lines.insert("", "end", values=(r["journal_date"],r["journal_no"],
                    f'{r["account_number"]} {r["account_name"]}',
                    r["line_description"] or r["journal_description"],
                    f'{amount:,.2f}'))

        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        refresh()

    def show_project_control(self):
        self.clear()
        ttk.Label(self.body,text="Project Control & Budget Dashboard",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Samlet projektstyring: budget, forbrug, afvigelser og aktiviteter."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        var=tk.StringVar(value=next(iter(project_map),""))
        combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                           state="readonly",width=38)
        combo.pack(side="left",padx=5)

        cards=ttk.Frame(self.body); cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("budget","Budget"),("actual","Forbrug"),
                          ("variance","Rest / afvigelse"),("utilization","Forbrug %"),
                          ("forecast","Forecast næste måned"),
                          ("unallocated_actual","Ikke aktivitetsfordelt")]:
            f=ttk.LabelFrame(cards,text=title); f.pack(side="left",fill="x",expand=True,padx=2)
            lab=ttk.Label(f,text="0,00",font=("Segoe UI",12,"bold")); lab.pack(padx=6,pady=8)
            labels[key]=lab

        tree=ttk.Treeview(self.body,
            columns=("name","status","budget","actual","variance","utilization"),
            show="headings")
        for c,t,w in [("name","Aktivitet",240),("status","Status",100),
                      ("budget","Budget",105),("actual","Forbrug",105),
                      ("variance","Rest",105),("utilization","Forbrug %",100)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=10)

        def refresh():
            pid=project_map.get(var.get())
            if not pid: return
            data=self.ctx.projects.project_control_dashboard(pid)
            forecast=self.ctx.projects.financial_forecast(pid,1)
            for key in ("budget","actual","variance","unallocated_actual"):
                labels[key].config(text=f'{data[key]:,.2f}')
            labels["utilization"].config(text=f'{data["utilization"]:.1f}%')
            if forecast["available"] and forecast["forecasts"]:
                labels["forecast"].config(text=f'{forecast["forecasts"][0]["value"]:,.2f}')
            else:
                labels["forecast"].config(text="Ikke tilgængelig")
            for x in tree.get_children(): tree.delete(x)
            for a in data["activities"]:
                tree.insert("", "end", values=(
                    a["name"],a["status"],f'{a["budget"]:,.2f}',
                    f'{a["actual"]:,.2f}',f'{a["variance"]:,.2f}',
                    f'{a["utilization"]:.1f}%'))

        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        refresh()

    def show_project_work(self):
        self.clear()
        ttk.Label(self.body,text="Project Work & Task Management",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Opgaver, ansvarlige, deadlines, prioritet og status."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        var=tk.StringVar(value=next(iter(project_map),""))
        combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                           state="readonly",width=38); combo.pack(side="left",padx=5)

        tree=ttk.Treeview(self.body,columns=("title","activity","owner","priority","due","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",260),("activity","Aktivitet",180),
                      ("owner","Ansvarlig",140),("priority","Prioritet",100),
                      ("due","Deadline",105),("status","Status",110)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            pid=project_map.get(var.get())
            if not pid:return
            for x in tree.get_children():tree.delete(x)
            for r in self.ctx.projects.project_tasks(pid):
                tree.insert("", "end", iid=str(r["id"]),
                    values=(r["title"],r["activity_name"] or "",r["assigned_to"] or "",
                            r["priority"],r["due_date"] or "",r["status"]))

        def new_task():
            pid=project_map.get(var.get())
            if not pid:return
            win=tk.Toplevel(self.root); win.title("Ny opgave"); win.geometry("460x520")
            fields={}
            for label,key in [("Titel","title"),("Beskrivelse","description"),
                              ("Ansvarlig","assigned_to"),("Deadline","due_date")]:
                ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
                e=ttk.Entry(win);e.pack(fill="x",padx=15);fields[key]=e
            ttk.Label(win,text="Prioritet").pack(anchor="w",padx=15,pady=(8,2))
            priority=tk.StringVar(value="Normal")
            ttk.Combobox(win,textvariable=priority,values=["Low","Normal","High","Critical"],
                         state="readonly").pack(fill="x",padx=15)
            ttk.Label(win,text="Aktivitet (valgfri ID)").pack(anchor="w",padx=15,pady=(8,2))
            activity=tk.StringVar(); ttk.Entry(win,textvariable=activity).pack(fill="x",padx=15)
            def save():
                try:
                    aid=int(activity.get()) if activity.get().strip() else None
                    self.ctx.projects.create_project_task(pid,fields["title"].get(),
                        fields["description"].get(),aid,fields["assigned_to"].get(),
                        priority.get(),fields["due_date"].get() or None,"Open")
                    win.destroy();refresh()
                except Exception as exc:messagebox.showerror("Opgave",str(exc))
            ttk.Button(win,text="Gem",command=save).pack(pady=16)

        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        ttk.Button(top,text="Ny opgave",command=new_task).pack(side="left",padx=5)
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        refresh()

    def show_operational_workboard(self):
        self.clear()
        ttk.Label(self.body,text="Operational Workboard",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Det daglige overblik over opgaver, deadlines og aktive projekter."
                  ).pack(anchor="w",pady=(2,10))

        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("open_tasks","Åbne opgaver"),("critical_tasks","Kritiske"),
                          ("high_tasks","Høj prioritet"),("overdue_tasks","Forfaldne"),
                          ("next_7_days","Næste 7 dage"),("active_projects","Aktive projekter")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            lab=ttk.Label(f,text="0",font=("Segoe UI",14,"bold"));lab.pack(padx=6,pady=8)
            labels[key]=lab

        ttk.Label(self.body,text="Mine / åbne opgaver",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        tasks=ttk.Treeview(self.body,columns=("title","project","activity","priority","due","status"),
                           show="headings",height=10)
        for c,t,w in [("title","Opgave",230),("project","Projekt",170),("activity","Aktivitet",150),
                      ("priority","Prioritet",90),("due","Deadline",100),("status","Status",100)]:
            tasks.heading(c,text=t);tasks.column(c,width=w)
        tasks.pack(fill="both",expand=True,pady=5)

        ttk.Label(self.body,text="Aktive projekter",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        projects=ttk.Treeview(self.body,columns=("name","status","budget","actual","variance","util"),
                              show="headings",height=7)
        for c,t,w in [("name","Projekt",220),("status","Status",100),("budget","Budget",105),
                      ("actual","Forbrug",105),("variance","Rest",105),("util","Forbrug %",100)]:
            projects.heading(c,text=t);projects.column(c,width=w)
        projects.pack(fill="both",expand=True,pady=5)

        def refresh():
            data=self.ctx.projects.operational_workboard()
            for k,v in data["metrics"].items(): labels[k].config(text=str(v))
            for x in tasks.get_children():tasks.delete(x)
            for t in data["tasks"]:
                tasks.insert("", "end", values=(t["title"],t["project_name"] or "",
                    t["activity_name"] or "",t["priority"],t["due_date"] or "",t["status"]))
            for x in projects.get_children():projects.delete(x)
            for p in data["projects"]:
                projects.insert("", "end", values=(p["name"],p["status"],
                    f'{p["budget"]:,.2f}',f'{p["actual"]:,.2f}',
                    f'{p["variance"]:,.2f}',f'{p["utilization"]:.1f}%'))
        ttk.Button(self.body,text="Opdater",command=refresh).pack(anchor="e",pady=5)
        refresh()

    def show_operational_actions(self):
        self.clear()
        ttk.Label(self.body,text="Operational Actions & Workflow",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Arbejd direkte fra Workboard: åbn, start, blokér og afslut opgaver."
                  ).pack(anchor="w",pady=(2,10))

        tree=ttk.Treeview(self.body,columns=("title","project","activity","priority","due","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",240),("project","Projekt",170),
                      ("activity","Aktivitet",150),("priority","Prioritet",90),
                      ("due","Deadline",105),("status","Status",110)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        action=ttk.Frame(self.body);action.pack(fill="x",pady=5)
        status=tk.StringVar(value="In Progress")
        ttk.Label(action,text="Ny status:").pack(side="left")
        ttk.Combobox(action,textvariable=status,
                     values=["Open","In Progress","Blocked","Completed","Closed"],
                     state="readonly",width=16).pack(side="left",padx=5)

        def refresh():
            for x in tree.get_children():tree.delete(x)
            data=self.ctx.projects.operational_workboard()
            for t in data["tasks"]:
                tree.insert("", "end", iid=str(t["id"]),
                    values=(t["title"],t["project_name"] or "",t["activity_name"] or "",
                            t["priority"],t["due_date"] or "",t["status"]))
        def selected():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Opgave","Vælg en opgave først.")
                return None
            return int(sel[0])
        def transition():
            tid=selected()
            if tid is None:return
            try:
                self.ctx.projects.transition_project_task(tid,status.get())
                refresh()
            except Exception as exc:messagebox.showerror("Workflow",str(exc))
        def complete():
            tid=selected()
            if tid is None:return
            try:
                self.ctx.projects.transition_project_task(tid,"Completed")
                refresh()
            except Exception as exc:messagebox.showerror("Workflow",str(exc))
        def open_task():
            tid=selected()
            if tid is None:return
            t=self.ctx.projects.task_detail(tid)
            messagebox.showinfo("Opgavedetaljer",
                f'Projekt: {t["project_name"] or ""}\n'
                f'Aktivitet: {t["activity_name"] or ""}\n'
                f'Opgave: {t["title"]}\n'
                f'Ansvarlig: {t["assigned_to"] or ""}\n'
                f'Prioritet: {t["priority"]}\n'
                f'Deadline: {t["due_date"] or ""}\n'
                f'Status: {t["status"]}\n\n{t["description"] or ""}')
        ttk.Button(action,text="Åbn detaljer",command=open_task).pack(side="left",padx=4)
        ttk.Button(action,text="Skift status",command=transition).pack(side="left",padx=4)
        ttk.Button(action,text="Færdig",command=complete).pack(side="left",padx=4)
        ttk.Button(action,text="Opdater",command=refresh).pack(side="left",padx=4)
        refresh()

    def show_operational_alerts(self):
        self.clear()
        ttk.Label(self.body,text="Notifications, Deadlines & Follow-up",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Viser kun forhold, der kræver opmærksomhed."
                  ).pack(anchor="w",pady=(2,10))

        summary=ttk.Frame(self.body);summary.pack(fill="x",pady=5)
        critical=ttk.LabelFrame(summary,text="Kritiske");critical.pack(side="left",fill="x",expand=True,padx=3)
        high=ttk.LabelFrame(summary,text="Høj prioritet");high.pack(side="left",fill="x",expand=True,padx=3)
        total=ttk.LabelFrame(summary,text="I alt");total.pack(side="left",fill="x",expand=True,padx=3)
        labs=[ttk.Label(critical,text="0",font=("Segoe UI",14,"bold")),
              ttk.Label(high,text="0",font=("Segoe UI",14,"bold")),
              ttk.Label(total,text="0",font=("Segoe UI",14,"bold"))]
        for l,f in zip(labs,[critical,high,total]):l.pack(pady=8)

        tree=ttk.Treeview(self.body,columns=("severity","title","project","due","message"),
                          show="headings")
        for c,t,w in [("severity","Niveau",90),("title","Hændelse",220),
                      ("project","Projekt",180),("due","Deadline",105),("message","Detalje",300)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            data=self.ctx.projects.operational_alerts()
            labs[0].config(text=str(data["counts"]["critical"]))
            labs[1].config(text=str(data["counts"]["high"]))
            labs[2].config(text=str(data["counts"]["total"]))
            for x in tree.get_children():tree.delete(x)
            for i,a in enumerate(data["alerts"]):
                tree.insert("", "end", iid=str(i),
                            values=(a["severity"],a["title"],a.get("project",""),
                                    a.get("due_date",""),a.get("message","")))
        ttk.Button(self.body,text="Opdater",command=refresh).pack(anchor="e",pady=5)
        refresh()

    def show_my_day(self):
        self.clear()
        ttk.Label(self.body,text="Personal Work Queue & My Day",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Dit personlige arbejdsbord: hvad skal jeg gøre nu og den næste uge?"
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Ansvarlig:").pack(side="left")
        people=sorted({(x.get("assigned_to") or "").strip() for x in self.ctx.projects.operational_workboard()["tasks"]
                       if (x.get("assigned_to") or "").strip()})
        person=tk.StringVar(value=people[0] if people else "")
        combo=ttk.Combobox(top,textvariable=person,values=people,width=28)
        combo.pack(side="left",padx=5)

        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("overdue","Forfaldne"),("today","I dag"),
                          ("next_7_days","Næste 7 dage"),("critical","Kritiske"),("blocked","Blokerede")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="0",font=("Segoe UI",13,"bold"));l.pack(pady=8);labels[key]=l

        tree=ttk.Treeview(self.body,columns=("title","project","activity","priority","due","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",240),("project","Projekt",170),("activity","Aktivitet",150),
                      ("priority","Prioritet",90),("due","Deadline",105),("status","Status",105)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            if not person.get().strip(): return
            data=self.ctx.projects.my_day(person.get().strip())
            for k in labels:labels[k].config(text=str(data["metrics"][k]))
            for x in tree.get_children():tree.delete(x)
            for t in data["tasks"]:
                tree.insert("", "end", iid=str(t["id"]),
                            values=(t["title"],t["project_name"] or "",t["activity_name"] or "",
                                    t["priority"],t["due_date"] or "",t["status"]))
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        refresh()

    def show_daily_execution(self):
        self.clear()
        ttk.Label(self.body,text="Quick Actions & Daily Execution",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Udfør de vigtigste handlinger direkte fra din arbejdsdag."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
        ttk.Label(top,text="Ansvarlig:").pack(side="left")
        people=sorted({(x.get("assigned_to") or "").strip()
                       for x in self.ctx.projects.operational_workboard()["tasks"]
                       if (x.get("assigned_to") or "").strip()})
        person=tk.StringVar(value=people[0] if people else "")
        combo=ttk.Combobox(top,textvariable=person,values=people,width=28)
        combo.pack(side="left",padx=5)

        tree=ttk.Treeview(self.body,columns=("title","project","priority","due","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",260),("project","Projekt",190),
                      ("priority","Prioritet",95),("due","Deadline",105),("status","Status",115)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        action=ttk.Frame(self.body); action.pack(fill="x",pady=5)
        def selected():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Daglig udførelse","Vælg en opgave først.")
                return None
            return int(sel[0])
        def run_action(name,value=None):
            tid=selected()
            if tid is None:return
            try:
                self.ctx.projects.quick_action(tid,name,value)
                refresh()
            except Exception as exc:
                messagebox.showerror("Quick Action",str(exc))
        ttk.Button(action,text="▶ Start",command=lambda:run_action("start")).pack(side="left",padx=3)
        ttk.Button(action,text="■ Bloker",command=lambda:run_action("block")).pack(side="left",padx=3)
        ttk.Button(action,text="✓ Færdig",command=lambda:run_action("complete")).pack(side="left",padx=3)
        ttk.Button(action,text="↶ Åbn igen",command=lambda:run_action("reopen")).pack(side="left",padx=3)

        def edit():
            tid=selected()
            if tid is None:return
            win=tk.Toplevel(self.root);win.title("Hurtig redigering");win.geometry("400x300")
            ttk.Label(win,text="Deadline (YYYY-MM-DD)").pack(anchor="w",padx=15,pady=(12,2))
            due=tk.StringVar();ttk.Entry(win,textvariable=due).pack(fill="x",padx=15)
            ttk.Label(win,text="Prioritet").pack(anchor="w",padx=15,pady=(10,2))
            pr=tk.StringVar(value="Normal")
            ttk.Combobox(win,textvariable=pr,values=["Low","Normal","High","Critical"],
                         state="readonly").pack(fill="x",padx=15)
            ttk.Label(win,text="Ansvarlig").pack(anchor="w",padx=15,pady=(10,2))
            owner=tk.StringVar(value=person.get());ttk.Entry(win,textvariable=owner).pack(fill="x",padx=15)
            def save():
                try:
                    if due.get().strip():run_action("deadline",due.get().strip())
                    run_action("priority",pr.get())
                    run_action("assign",owner.get())
                    win.destroy();refresh()
                except Exception as exc:messagebox.showerror("Redigering",str(exc))
            ttk.Button(win,text="Gem",command=save).pack(pady=15)
        ttk.Button(action,text="Redigér",command=edit).pack(side="left",padx=8)
        ttk.Button(action,text="Opdater",command=lambda:refresh()).pack(side="left",padx=3)

        def refresh():
            if not person.get().strip():return
            data=self.ctx.projects.my_day(person.get().strip())
            for x in tree.get_children():tree.delete(x)
            for t in data["tasks"]:
                tree.insert("", "end",iid=str(t["id"]),
                            values=(t["title"],t["project_name"] or "",t["priority"],
                                    t["due_date"] or "",t["status"]))
        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        refresh()

    def show_project_execution(self):
        self.clear()
        ttk.Label(self.body,text="Activity & Project Execution",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Projektfremdrift, aktiviteter, opgaver og økonomi i ét samlet billede."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        var=tk.StringVar(value=next(iter(project_map),""))
        combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                           state="readonly",width=38);combo.pack(side="left",padx=5)

        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("task_progress","Opgavefremdrift"),("budget","Budget"),
                          ("actual","Forbrug"),("variance","Rest"),("utilization","Forbrug %")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="0",font=("Segoe UI",12,"bold"));l.pack(pady=8);labels[key]=l

        ttk.Label(self.body,text="Aktiviteter",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        acts=ttk.Treeview(self.body,columns=("name","status","progress","budget","actual","variance"),
                          show="headings",height=7)
        for c,t,w in [("name","Aktivitet",220),("status","Status",100),("progress","Fremdrift",95),
                      ("budget","Budget",105),("actual","Forbrug",105),("variance","Rest",105)]:
            acts.heading(c,text=t);acts.column(c,width=w)
        acts.pack(fill="x",pady=4)

        ttk.Label(self.body,text="Opgaver",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        tasks=ttk.Treeview(self.body,columns=("title","activity","owner","priority","due","status"),
                           show="headings",height=9)
        for c,t,w in [("title","Opgave",240),("activity","Aktivitet",160),("owner","Ansvarlig",130),
                      ("priority","Prioritet",90),("due","Deadline",105),("status","Status",110)]:
            tasks.heading(c,text=t);tasks.column(c,width=w)
        tasks.pack(fill="both",expand=True,pady=4)

        def refresh():
            pid=project_map.get(var.get())
            if not pid:return
            d=self.ctx.projects.project_execution_view(pid)
            labels["task_progress"].config(text=f'{d["task_progress"]:.1f}%')
            labels["budget"].config(text=f'{d["budget"]:,.2f}')
            labels["actual"].config(text=f'{d["actual"]:,.2f}')
            labels["variance"].config(text=f'{d["variance"]:,.2f}')
            labels["utilization"].config(text=f'{d["utilization"]:.1f}%')
            for x in acts.get_children():acts.delete(x)
            for a in d["activities"]:
                acts.insert("", "end",values=(a["name"],a["status"],f'{a["progress"]:.1f}%',
                    f'{a["budget"]:,.2f}',f'{a["actual"]:,.2f}',f'{a["variance"]:,.2f}'))
            for x in tasks.get_children():tasks.delete(x)
            for t in d["tasks"]:
                tasks.insert("", "end",values=(t["title"],t["activity_name"] or "",
                    t["assigned_to"] or "",t["priority"],t["due_date"] or "",t["status"]))
        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        refresh()

    def show_project_execution_actions(self):
        self.clear()
        ttk.Label(self.body,text="Project Execution Actions",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Arbejd direkte i projektet og filtrér ned på aktivitet."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        pv=tk.StringVar(value=next(iter(project_map),""))
        pc=ttk.Combobox(top,textvariable=pv,values=list(project_map),
                        state="readonly",width=34);pc.pack(side="left",padx=5)
        ttk.Label(top,text="Aktivitet:").pack(side="left",padx=(10,0))
        av=tk.StringVar(value="Alle")
        ac=ttk.Combobox(top,textvariable=av,values=["Alle"],state="readonly",width=24)
        ac.pack(side="left",padx=5)

        info=ttk.Label(self.body,text="");info.pack(anchor="w",pady=5)
        tree=ttk.Treeview(self.body,columns=("title","activity","owner","priority","due","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",250),("activity","Aktivitet",170),
                      ("owner","Ansvarlig",130),("priority","Prioritet",95),
                      ("due","Deadline",105),("status","Status",110)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def load_activities():
            pid=project_map.get(pv.get())
            if not pid:return
            d=self.ctx.projects.project_execution_view(pid)
            names=["Alle"]+[f'{a["id"]} — {a["name"]}' for a in d["activities"]]
            ac["values"]=names
            if av.get() not in names:av.set("Alle")

        def refresh():
            pid=project_map.get(pv.get())
            if not pid:return
            d=self.ctx.projects.project_execution_view(pid)
            selected=av.get()
            aid=None if selected=="Alle" else int(selected.split(" — ",1)[0])
            tasks=d["tasks"] if aid is None else [t for t in d["tasks"] if t["activity_id"]==aid]
            done=sum(t["status"] in {"Completed","Closed"} for t in tasks)
            progress=(done/len(tasks)*100) if tasks else 0
            info.config(text=f'{len(tasks)} opgaver · {progress:.1f}% færdig')
            for x in tree.get_children():tree.delete(x)
            for t in tasks:
                tree.insert("", "end",iid=str(t["id"]),
                            values=(t["title"],t["activity_name"] or "",
                                    t["assigned_to"] or "",t["priority"],
                                    t["due_date"] or "",t["status"]))

        def selected():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Execution","Vælg en opgave først.");return None
            return int(sel[0])
        def act(name,value=None):
            tid=selected()
            if tid is None:return
            try:
                self.ctx.projects.execution_action(project_map[pv.get()],tid,name,value)
                refresh()
            except Exception as exc:messagebox.showerror("Execution Action",str(exc))

        actions=ttk.Frame(self.body);actions.pack(fill="x",pady=5)
        for text,name in [("▶ Start","start"),("■ Bloker","block"),
                          ("✓ Færdig","complete"),("↶ Åbn igen","reopen")]:
            ttk.Button(actions,text=text,command=lambda n=name:act(n)).pack(side="left",padx=3)
        ttk.Button(actions,text="Opdater",command=refresh).pack(side="left",padx=8)
        pc.bind("<<ComboboxSelected>>",lambda e:(load_activities(),refresh()))
        ac.bind("<<ComboboxSelected>>",lambda e:refresh())
        load_activities();refresh()

    def show_project_progress_control(self):
        self.clear()
        ttk.Label(self.body,text="Project Progress & Financial Control",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Projektfremdrift og økonomisk kontrol i samme cockpit."
                  ).pack(anchor="w",pady=(2,10))
        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        var=tk.StringVar(value=next(iter(project_map),""))
        combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                           state="readonly",width=38);combo.pack(side="left",padx=5)
        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("execution_status","Fremdrift"),("task_progress","Opgave %"),
                          ("financial_status","Økonomi"),("budget","Budget"),
                          ("actual","Forbrug"),("variance","Afvigelse"),("utilization","Forbrug %")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="—",font=("Segoe UI",11,"bold"));l.pack(pady=8);labels[key]=l
        ttk.Label(self.body,text="Aktivitetskontrol",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        tree=ttk.Treeview(self.body,columns=("name","progress","budget","actual","variance","util","status"),
                          show="headings")
        for c,t,w in [("name","Aktivitet",210),("progress","Fremdrift",90),("budget","Budget",100),
                      ("actual","Forbrug",100),("variance","Afvigelse",105),("util","Forbrug %",95),
                      ("status","Kontrol",110)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)
        def refresh():
            pid=project_map.get(var.get())
            if not pid:return
            d=self.ctx.projects.project_progress_control(pid)
            for k in labels:
                v=d[k]
                labels[k].config(text=f'{v:,.2f}' if isinstance(v,(int,float)) else str(v))
            for x in tree.get_children():tree.delete(x)
            for a in d["activities"]:
                tree.insert("", "end",values=(a["name"],f'{a["progress"]:.1f}%',
                    f'{a["budget"]:,.2f}',f'{a["actual"]:,.2f}',f'{a["variance"]:,.2f}',
                    f'{a["utilization"]:.1f}%',a["control_status"]))
        combo.bind("<<ComboboxSelected>>",lambda e:refresh())
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        refresh()

    def show_project_control_actions(self):
        self.clear()
        ttk.Label(self.body,text="Project Control Actions & Exceptions",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Find problemer, forstå dem og opret en konkret opfølgning."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        pm={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        pv=tk.StringVar(value=next(iter(pm),""))
        pc=ttk.Combobox(top,textvariable=pv,values=list(pm),state="readonly",width=38)
        pc.pack(side="left",padx=5)

        counts=ttk.Label(self.body,text="");counts.pack(anchor="w",pady=5)
        tree=ttk.Treeview(self.body,columns=("severity","title","activity","message"),
                          show="headings")
        for c,t,w in [("severity","Niveau",90),("title","Problem",220),
                      ("activity","Aktivitet",180),("message","Detalje",330)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            pid=pm.get(pv.get())
            if not pid:return
            d=self.ctx.projects.project_control_exceptions(pid)
            counts.config(text=f'Kritiske: {d["counts"]["critical"]} · Høje: {d["counts"]["high"]} · I alt: {d["counts"]["total"]}')
            for x in tree.get_children():tree.delete(x)
            for i,e in enumerate(d["exceptions"]):
                tree.insert("", "end",iid=str(i),
                            values=(e["severity"],e["title"],e.get("activity",""),e.get("message","")))
        def create_followup():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Opfølgning","Vælg en undtagelse først.");return
            pid=pm.get(pv.get());d=self.ctx.projects.project_control_exceptions(pid)
            e=d["exceptions"][int(sel[0])]
            owner=tk.simpledialog.askstring("Ansvarlig","Hvem skal følge op?",parent=self.root)
            if not owner:return
            try:
                self.ctx.projects.create_exception_followup(pid,e,owner)
                messagebox.showinfo("Opfølgning","Opfølgningsopgaven er oprettet.")
                refresh()
            except Exception as exc:messagebox.showerror("Opfølgning",str(exc))
        actions=ttk.Frame(self.body);actions.pack(fill="x",pady=5)
        ttk.Button(actions,text="Opret opfølgning",command=create_followup).pack(side="left",padx=3)
        ttk.Button(actions,text="Opdater",command=refresh).pack(side="left",padx=3)
        pc.bind("<<ComboboxSelected>>",lambda e:refresh())
        refresh()

    def show_project_control_cockpit(self):
        self.clear()
        ttk.Label(self.body,text="Project Control Cockpit",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Ét samlet projektbillede: fremdrift, økonomi, exceptions og arbejde."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        pm={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        pv=tk.StringVar(value=next(iter(pm),""))
        pc=ttk.Combobox(top,textvariable=pv,values=list(pm),state="readonly",width=40)
        pc.pack(side="left",padx=5)

        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("task_progress","Fremdrift"),("financial_status","Økonomi"),
                          ("budget","Budget"),("actual","Forbrug"),("variance","Rest"),
                          ("utilization","Forbrug %"),("open_tasks","Åbne opgaver"),
                          ("exception_total","Exceptions")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="—",font=("Segoe UI",10,"bold"));l.pack(pady=7);labels[key]=l

        pan=ttk.Panedwindow(self.body,orient="horizontal");pan.pack(fill="both",expand=True,pady=8)
        left=ttk.Frame(pan);right=ttk.Frame(pan);pan.add(left,weight=3);pan.add(right,weight=2)

        ttk.Label(left,text="Aktiviteter",font=("Segoe UI",12,"bold")).pack(anchor="w")
        acts=ttk.Treeview(left,columns=("name","progress","budget","actual","variance","status"),
                          show="headings",height=8)
        for c,t,w in [("name","Aktivitet",190),("progress","Fremdrift",80),("budget","Budget",95),
                      ("actual","Forbrug",95),("variance","Rest",95),("status","Kontrol",105)]:
            acts.heading(c,text=t);acts.column(c,width=w)
        acts.pack(fill="both",expand=True,pady=4)

        ttk.Label(right,text="Exceptions",font=("Segoe UI",12,"bold")).pack(anchor="w")
        exc=ttk.Treeview(right,columns=("severity","title","detail"),show="headings",height=8)
        for c,t,w in [("severity","Niveau",75),("title","Problem",170),("detail","Detalje",220)]:
            exc.heading(c,text=t);exc.column(c,width=w)
        exc.pack(fill="both",expand=True,pady=4)

        ttk.Label(left,text="Åbne opgaver",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        tasks=ttk.Treeview(left,columns=("title","activity","owner","due","status"),
                           show="headings",height=7)
        for c,t,w in [("title","Opgave",210),("activity","Aktivitet",140),
                      ("owner","Ansvarlig",120),("due","Deadline",100),("status","Status",100)]:
            tasks.heading(c,text=t);tasks.column(c,width=w)
        tasks.pack(fill="both",expand=True,pady=4)

        def refresh():
            pid=pm.get(pv.get())
            if not pid:return
            d=self.ctx.projects.project_control_cockpit(pid)
            c=d["control"]
            labels["task_progress"].config(text=f'{c["task_progress"]:.1f}%')
            labels["financial_status"].config(text=c["financial_status"])
            labels["budget"].config(text=f'{c["budget"]:,.2f}')
            labels["actual"].config(text=f'{c["actual"]:,.2f}')
            labels["variance"].config(text=f'{c["variance"]:,.2f}')
            labels["utilization"].config(text=f'{c["utilization"]:.1f}%')
            labels["open_tasks"].config(text=str(d["open_tasks"]))
            labels["exception_total"].config(text=str(d["exception_counts"]["total"]))
            for x in acts.get_children():acts.delete(x)
            for a in d["activities"]:
                acts.insert("", "end",values=(a["name"],f'{a["progress"]:.1f}%',
                    f'{a["budget"]:,.2f}',f'{a["actual"]:,.2f}',f'{a["variance"]:,.2f}',
                    a["control_status"]))
            for x in exc.get_children():exc.delete(x)
            for i,e in enumerate(d["exceptions"]):
                exc.insert("", "end",iid=str(i),values=(e["severity"],e["title"],e.get("message","")))
            for x in tasks.get_children():tasks.delete(x)
            for t in d["tasks"]:
                if t["status"] in {"Completed","Closed"}:continue
                tasks.insert("", "end",iid=str(t["id"]),values=(t["title"],t["activity_name"] or "",
                    t["assigned_to"] or "",t["due_date"] or "",t["status"]))

        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        pc.bind("<<ComboboxSelected>>",lambda e:refresh())
        refresh()

    def show_integrated_operations_dashboard(self):
        self.clear()
        ttk.Label(self.body,text="Integrated Operations Dashboard",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Ét samlet overblik over foreningens aktive projekter og aktuelle driftsforhold."
                  ).pack(anchor="w",pady=(2,10))

        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("active","Aktive projekter"),("open_tasks","Åbne opgaver"),
                          ("exceptions","Exceptions"),("over_budget","Over budget"),
                          ("active_members","Aktive medlemmer"),("total_members","Medlemmer")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="—",font=("Segoe UI",11,"bold"));l.pack(pady=7);labels[key]=l

        ttk.Label(self.body,text="Projektstatus",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
        tree=ttk.Treeview(self.body,columns=("name","progress","budget","actual","variance","tasks","exceptions"),
                          show="headings")
        for c,t,w in [("name","Projekt",210),("progress","Fremdrift",90),("budget","Budget",105),
                      ("actual","Forbrug",105),("variance","Rest",105),("tasks","Åbne opgaver",105),
                      ("exceptions","Exceptions",100)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=5)

        def refresh():
            d=self.ctx.projects.integrated_operations_dashboard()
            ps=d["project_summary"];ts=d["task_summary"];ms=d["member_summary"]
            labels["active"].config(text=str(ps["active"]))
            labels["open_tasks"].config(text=str(ps["open_tasks"]))
            labels["exceptions"].config(text=str(ps["exceptions"]))
            labels["over_budget"].config(text=str(ps["over_budget"]))
            labels["active_members"].config(text=str(ms.get("active_members") or 0))
            labels["total_members"].config(text=str(ms.get("total_members") or 0))
            for x in tree.get_children():tree.delete(x)
            for p in d["projects"]:
                tree.insert("", "end",iid=str(p["id"]),
                            values=(p["name"],f'{p["progress"]:.1f}%',
                                    f'{p["budget"]:,.2f}',f'{p["actual"]:,.2f}',
                                    f'{p["variance"]:,.2f}',p["open_tasks"],p["exceptions"]))
        ttk.Button(self.body,text="Opdater",command=refresh).pack(anchor="e",pady=5)
        refresh()

    def show_integrated_operations_actions(self):
        self.clear()
        ttk.Label(self.body,text="Integrated Operations Actions",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Gå fra overblik til konkret projekt, problem eller opgave."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=5)
        ttk.Label(top,text="Projekt:").pack(side="left")
        projects=self.ctx.projects.list()
        pm={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        pv=tk.StringVar(value=next(iter(pm),""))
        pc=ttk.Combobox(top,textvariable=pv,values=list(pm),state="readonly",width=38)
        pc.pack(side="left",padx=5)

        nb=ttk.Notebook(self.body);nb.pack(fill="both",expand=True,pady=8)
        exf=ttk.Frame(nb);tsk=ttk.Frame(nb);nb.add(exf,text="Exceptions");nb.add(tsk,text="Åbne opgaver")

        ex=ttk.Treeview(exf,columns=("severity","title","detail"),show="headings")
        for c,t,w in [("severity","Niveau",90),("title","Problem",230),("detail","Detalje",350)]:
            ex.heading(c,text=t);ex.column(c,width=w)
        ex.pack(fill="both",expand=True,pady=5)

        tf=ttk.Frame(tsk);tf.pack(fill="x",pady=5)
        ttk.Label(tf,text="Handling:").pack(side="left")
        action=tk.StringVar(value="start")
        ttk.Combobox(tf,textvariable=action,values=["start","block","complete","reopen"],
                     state="readonly",width=14).pack(side="left",padx=5)
        tt=ttk.Treeview(tsk,columns=("title","activity","owner","due","status"),show="headings")
        for c,t,w in [("title","Opgave",250),("activity","Aktivitet",160),
                      ("owner","Ansvarlig",130),("due","Deadline",105),("status","Status",110)]:
            tt.heading(c,text=t);tt.column(c,width=w)
        tt.pack(fill="both",expand=True,pady=5)

        def refresh():
            pid=pm.get(pv.get())
            if not pid:return
            d=self.ctx.projects.project_control_exceptions(pid)
            for x in ex.get_children():ex.delete(x)
            for i,e in enumerate(d["exceptions"]):
                ex.insert("", "end",iid=str(i),values=(e["severity"],e["title"],e.get("message","")))
            q=self.ctx.projects.integrated_operations_action("open_tasks",project_id=pid)
            for x in tt.get_children():tt.delete(x)
            for t in q["tasks"]:
                tt.insert("", "end",iid=str(t["id"]),
                          values=(t["title"],t["activity_name"] or "",t["assigned_to"] or "",
                                  t["due_date"] or "",t["status"]))

        def run_task_action():
            sel=tt.selection()
            if not sel:
                messagebox.showinfo("Handling","Vælg en opgave først.");return
            pid=pm.get(pv.get())
            try:
                self.ctx.projects.integrated_operations_action(action.get(),
                    project_id=pid,task_id=int(sel[0]))
                refresh()
            except Exception as exc:messagebox.showerror("Handling",str(exc))

        def followup():
            sel=ex.selection()
            if not sel:
                messagebox.showinfo("Opfølgning","Vælg en exception først.");return
            pid=pm.get(pv.get())
            try:
                d=self.ctx.projects.integrated_operations_action("create_exception_followup",
                    project_id=pid,exception_index=int(sel[0]))
                owner=tk.simpledialog.askstring("Ansvarlig","Hvem skal følge op?",parent=self.root)
                if owner:
                    self.ctx.projects.create_exception_followup(pid,d["exception"],owner)
                    refresh()
            except Exception as exc:messagebox.showerror("Opfølgning",str(exc))

        buttons=ttk.Frame(self.body);buttons.pack(fill="x",pady=5)
        ttk.Button(buttons,text="Opret opfølgning",command=followup).pack(side="left",padx=3)
        ttk.Button(buttons,text="Udfør valgt opgavehandling",command=run_task_action).pack(side="left",padx=3)
        ttk.Button(buttons,text="Opdater",command=refresh).pack(side="left",padx=3)
        pc.bind("<<ComboboxSelected>>",lambda e:refresh())
        refresh()

    def show_workspace_integration(self):
        self.clear()
        ttk.Label(self.body,text="Navigation & Workspace Integration",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Sammenhængende arbejdsområde med aktiv kontekst og hurtig navigation."
                  ).pack(anchor="w",pady=(2,10))

        bar=ttk.Frame(self.body);bar.pack(fill="x",pady=6)
        ttk.Label(bar,text="Kontekst:").pack(side="left")
        projects=self.ctx.projects.list()
        pm={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        pv=tk.StringVar(value=next(iter(pm),""))
        pc=ttk.Combobox(bar,textvariable=pv,values=list(pm),state="readonly",width=38)
        pc.pack(side="left",padx=5)

        history=[]
        status=ttk.Label(self.body,text="Ingen aktiv kontekst")
        status.pack(anchor="w",pady=4)

        body=ttk.Frame(self.body);body.pack(fill="both",expand=True,pady=8)
        title=ttk.Label(body,text="");title.pack(anchor="w")
        detail=ttk.Label(body,text="",justify="left")
        detail.pack(anchor="w",pady=8)

        def show_project(pid, push=True):
            if push and pv.get(): history.append(pv.get())
            match=next((k for k,v in pm.items() if v==pid),None)
            if match: pv.set(match)
            data=self.ctx.projects.workspace_context("project",pid)["data"]
            status.config(text=f'Aktiv kontekst: Projekt #{pid}')
            title.config(text=data["project"]["name"],font=("Segoe UI",14,"bold"))
            c=data["control"]
            detail.config(text=(
                f'Fremdrift: {c["task_progress"]:.1f}%    '
                f'Økonomi: {c["financial_status"]}\n'
                f'Budget: {c["budget"]:,.2f}    Forbrug: {c["actual"]:,.2f}    '
                f'Rest: {c["variance"]:,.2f}\n'
                f'Åbne opgaver: {data["open_tasks"]}    '
                f'Exceptions: {data["exception_counts"]["total"]}'))
        def open_cockpit():
            pid=pm.get(pv.get())
            if pid: show_project(pid)
        def back():
            if history:
                old=history.pop()
                pv.set(old); show_project(pm[old],push=False)
        ttk.Button(bar,text="Åbn projekt",command=open_cockpit).pack(side="left",padx=4)
        ttk.Button(bar,text="← Tilbage",command=back).pack(side="left",padx=4)
        ttk.Button(bar,text="Ryd kontekst",command=lambda:(status.config(text="Ingen aktiv kontekst"),
            title.config(text=""),detail.config(text=""))).pack(side="left",padx=4)
        pc.bind("<<ComboboxSelected>>",lambda e:open_cockpit())
        if pm: show_project(next(iter(pm.values())),push=False)

    def show_global_search(self):
        self.clear()
        ttk.Label(self.body,text="Global Search",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Søg på tværs af MFM uden først at vælge et modul."
                  ).pack(anchor="w",pady=(2,10))
        bar=ttk.Frame(self.body);bar.pack(fill="x",pady=6)
        q=tk.StringVar()
        entry=ttk.Entry(bar,textvariable=q,width=55);entry.pack(side="left",padx=(0,5))
        tree=ttk.Treeview(self.body,columns=("type","title","subtitle"),show="headings")
        for c,t,w in [("type","Type",100),("title","Resultat",250),("subtitle","Detalje",400)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)
        results=[]
        def search():
            nonlocal results
            results=self.ctx.projects.global_search(q.get())
            for x in tree.get_children():tree.delete(x)
            for i,r in enumerate(results):
                tree.insert("", "end",iid=str(i),
                            values=(r["type"],r["title"],r["subtitle"]))
        def open_selected():
            sel=tree.selection()
            if not sel:return
            r=results[int(sel[0])]
            try:
                if r["context"]=="project":
                    self.show_project_control_cockpit()
                    # cockpit is project selectable; set its selector where possible
                elif r["context"]=="task":
                    data=self.ctx.projects.workspace_context("task",r["id"])["data"]
                    messagebox.showinfo("Opgave",f'{data.get("title","")}\nStatus: {data.get("status","")}')
                elif r["context"]=="activity":
                    data=self.ctx.projects.workspace_context("activity",r["id"])["data"]
                    messagebox.showinfo("Aktivitet",f'{data.get("name","")}\nStatus: {data.get("status","")}')
                else:
                    messagebox.showinfo("Medlem",r["title"])
            except Exception as exc:
                messagebox.showerror("Global Search",str(exc))
        ttk.Button(bar,text="Søg",command=search).pack(side="left")
        ttk.Button(bar,text="Åbn valgt",command=open_selected).pack(side="left",padx=5)
        entry.bind("<Return>",lambda e:search())
        entry.focus_set()

    def show_unified_record_view(self):
        self.clear()
        ttk.Label(self.body,text="Unified Record View",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Én samlet detaljevisning for det valgte MFM-objekt."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
        ttk.Label(top,text="Type:").pack(side="left")
        rt=tk.StringVar(value="project")
        ttk.Combobox(top,textvariable=rt,
                     values=["project","activity","task","member"],
                     state="readonly",width=14).pack(side="left",padx=5)
        ttk.Label(top,text="ID:").pack(side="left",padx=(10,2))
        rid=tk.StringVar();ttk.Entry(top,textvariable=rid,width=12).pack(side="left")
        result=ttk.LabelFrame(self.body,text="Record");result.pack(fill="x",pady=6)
        fields=ttk.Label(result,text="",justify="left");fields.pack(anchor="w",padx=8,pady=8)
        rel=ttk.Treeview(self.body,columns=("type","title","detail"),show="headings")
        for c,t,w in [("type","Type",110),("title","Objekt",240),("detail","Detalje",430)]:
            rel.heading(c,text=t);rel.column(c,width=w)
        rel.pack(fill="both",expand=True,pady=6)
        def open_view():
            try:
                d=self.ctx.projects.unified_record_view(rt.get(),int(rid.get()))
                fields.config(text="\n".join(f"{k}: {v}" for k,v in d["record"].items()))
                for x in rel.get_children():rel.delete(x)
                for k,v in d["related"].items():
                    if isinstance(v,list):
                        for item in v:
                            title=item.get("name") or item.get("title") or k
                            rel.insert("", "end",values=(k,title,str(item)[:180]))
                    elif isinstance(v,dict):
                        rel.insert("", "end",values=(k,v.get("name") or v.get("title") or k,str(v)[:180]))
                    else:
                        rel.insert("", "end",values=(k,str(v),str(v)))
            except Exception as exc:
                messagebox.showerror("Unified Record View",str(exc))
        ttk.Button(top,text="Åbn",command=open_view).pack(side="left",padx=6)
        ttk.Button(top,text="Global Search",command=self.show_global_search).pack(side="left")

    def show_personal_workspace(self):
        self.clear()
        ttk.Label(self.body,text="Personal Workspace & My Work",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Din egen arbejdsflade: åbne opgaver, deadlines og blokeringer."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=5)
        ttk.Label(top,text="Ansvarlig:").pack(side="left")
        owner=tk.StringVar(value="")
        ent=ttk.Entry(top,textvariable=owner,width=30);ent.pack(side="left",padx=5)

        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("open","Åbne"),("overdue","Forfaldne"),("blocked","Blokerede")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="0",font=("Segoe UI",11,"bold"));l.pack(pady=7);labels[key]=l

        tree=ttk.Treeview(self.body,columns=("title","project","activity","due","priority","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",240),("project","Projekt",180),("activity","Aktivitet",150),
                      ("due","Deadline",105),("priority","Prioritet",95),("status","Status",110)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            d=self.ctx.projects.personal_workspace(owner.get())
            for k in labels: labels[k].config(text=str(d["summary"][k]))
            for x in tree.get_children():tree.delete(x)
            for t in d["tasks"]:
                tree.insert("", "end",iid=str(t["id"]),
                            values=(t["title"],t["project_name"] or "",t["activity_name"] or "",
                                    t["due_date"] or "",t["priority"],t["status"]))
        ttk.Button(top,text="Vis mit arbejde",command=refresh).pack(side="left",padx=5)
        ent.bind("<Return>",lambda e:refresh())
        ent.focus_set()

    def show_personal_work_actions(self):
        self.clear()
        ttk.Label(self.body,text="Personal Work Actions & Daily Execution",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Arbejd direkte fra din personlige opgaveliste."
                  ).pack(anchor="w",pady=(2,10))

        top=ttk.Frame(self.body);top.pack(fill="x",pady=5)
        ttk.Label(top,text="Ansvarlig:").pack(side="left")
        owner=tk.StringVar()
        ent=ttk.Entry(top,textvariable=owner,width=28);ent.pack(side="left",padx=5)
        ttk.Label(top,text="Handling:").pack(side="left",padx=(12,2))
        action=tk.StringVar(value="start")
        ttk.Combobox(top,textvariable=action,
                     values=["start","block","complete","reopen"],
                     state="readonly",width=12).pack(side="left",padx=5)

        tree=ttk.Treeview(self.body,columns=("title","project","activity","due","priority","status"),
                          show="headings")
        for c,t,w in [("title","Opgave",240),("project","Projekt",180),("activity","Aktivitet",150),
                      ("due","Deadline",105),("priority","Prioritet",95),("status","Status",110)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        def refresh():
            d=self.ctx.projects.personal_workspace(owner.get())
            for x in tree.get_children():tree.delete(x)
            for t in d["tasks"]:
                tree.insert("", "end",iid=str(t["id"]),
                            values=(t["title"],t["project_name"] or "",t["activity_name"] or "",
                                    t["due_date"] or "",t["priority"],t["status"]))
        def execute():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Daglig udførelse","Vælg en opgave først.");return
            try:
                self.ctx.projects.personal_work_action(owner.get(),int(sel[0]),action.get())
                refresh()
            except Exception as exc:
                messagebox.showerror("Daglig udførelse",str(exc))
        def open_context():
            sel=tree.selection()
            if not sel:return
            task=self.ctx.projects.workspace_context("task",int(sel[0]))["data"]
            messagebox.showinfo("Opgave",
                f'{task.get("title","")}\nProjekt ID: {task.get("project_id")}\n'
                f'Aktivitet ID: {task.get("activity_id")}\nStatus: {task.get("status","")}')
        ttk.Button(top,text="Vis mit arbejde",command=refresh).pack(side="left",padx=5)
        ttk.Button(top,text="Udfør",command=execute).pack(side="left",padx=3)
        ttk.Button(top,text="Åbn kontekst",command=open_context).pack(side="left",padx=3)
        ent.bind("<Return>",lambda e:refresh())
        ent.focus_set()

    def show_today_view(self):
        self.clear()
        ttk.Label(self.body,text="Today View",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Prioriteret arbejdsoversigt for i dag."
                  ).pack(anchor="w",pady=(2,10))
        top=ttk.Frame(self.body);top.pack(fill="x",pady=5)
        ttk.Label(top,text="Ansvarlig:").pack(side="left")
        owner=tk.StringVar(); ent=ttk.Entry(top,textvariable=owner,width=28)
        ent.pack(side="left",padx=5)
        cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
        labels={}
        for key,title in [("total","Åbne"),("due_today","I dag"),("overdue","Forfaldne"),
                          ("high_priority","Høj prioritet"),("blocked","Blokerede")]:
            f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
            l=ttk.Label(f,text="0",font=("Segoe UI",11,"bold"));l.pack(pady=7);labels[key]=l
        tree=ttk.Treeview(self.body,columns=("bucket","title","project","activity","due","priority","status"),
                          show="headings")
        for c,t,w in [("bucket","Prioritet",105),("title","Opgave",230),("project","Projekt",170),
                      ("activity","Aktivitet",145),("due","Deadline",105),("priority","Niveau",90),
                      ("status","Status",105)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)
        def refresh():
            d=self.ctx.projects.today_view(owner.get())
            for k,l in labels.items(): l.config(text=str(d["summary"][k]))
            for x in tree.get_children(): tree.delete(x)
            order=[("overdue","Forfalden"),("due_today","I dag"),("blocked","Blokeret"),
                   ("high_priority","Høj prioritet"),("other","Øvrige")]
            for key,label in order:
                for t in d["buckets"][key]:
                    tree.insert("", "end",iid=str(t["id"]),
                                values=(label,t["title"],t["project_name"] or "",
                                        t["activity_name"] or "",t["due_date"] or "",
                                        t["priority"],t["status"]))
        ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
        ttk.Button(top,text="My Work",command=self.show_personal_work_actions).pack(side="left",padx=3)
        ent.bind("<Return>",lambda e:refresh()); ent.focus_set()

    def show_quick_capture(self):
        self.clear()
        ttk.Label(self.body,text="Quick Capture & Work Intake",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Opret en ny arbejdsopgave med så få felter som muligt."
                  ).pack(anchor="w",pady=(2,10))

        form=ttk.Frame(self.body);form.pack(fill="x",pady=8)
        title=tk.StringVar(); project=tk.StringVar(); activity=tk.StringVar()
        owner=tk.StringVar(); priority=tk.StringVar(value="Normal"); due=tk.StringVar()
        projects=self.ctx.projects.list()
        pm={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
        ttk.Label(form,text="Opgave").grid(row=0,column=0,sticky="w",pady=4)
        ttk.Entry(form,textvariable=title,width=65).grid(row=0,column=1,sticky="ew",pady=4)
        ttk.Label(form,text="Projekt").grid(row=1,column=0,sticky="w",pady=4)
        pc=ttk.Combobox(form,textvariable=project,values=list(pm),state="readonly",width=45)
        pc.grid(row=1,column=1,sticky="w",pady=4)
        ttk.Label(form,text="Aktivitet ID").grid(row=2,column=0,sticky="w",pady=4)
        ttk.Entry(form,textvariable=activity,width=15).grid(row=2,column=1,sticky="w",pady=4)
        ttk.Label(form,text="Ansvarlig").grid(row=3,column=0,sticky="w",pady=4)
        ttk.Entry(form,textvariable=owner,width=30).grid(row=3,column=1,sticky="w",pady=4)
        ttk.Label(form,text="Prioritet").grid(row=4,column=0,sticky="w",pady=4)
        ttk.Combobox(form,textvariable=priority,values=["Low","Normal","High","Critical"],
                     state="readonly",width=15).grid(row=4,column=1,sticky="w",pady=4)
        ttk.Label(form,text="Deadline").grid(row=5,column=0,sticky="w",pady=4)
        ttk.Entry(form,textvariable=due,width=18).grid(row=5,column=1,sticky="w",pady=4)
        ttk.Label(form,text="Beskrivelse").grid(row=6,column=0,sticky="nw",pady=4)
        desc=tk.Text(form,height=4,width=65);desc.grid(row=6,column=1,sticky="ew",pady=4)
        form.columnconfigure(1,weight=1)
        msg=ttk.Label(self.body,text="");msg.pack(anchor="w",pady=5)

        def capture():
            try:
                pid=pm.get(project.get())
                aid=int(activity.get()) if activity.get().strip() else None
                task=self.ctx.projects.quick_capture(title.get(),pid,aid,owner.get(),
                                                     priority.get(),due.get().strip() or None,
                                                     desc.get("1.0","end").strip())
                msg.config(text=f'Oprettet opgave #{task["id"]}: {task["title"]}')
                title.set("");due.set("");desc.delete("1.0","end")
            except Exception as exc:
                messagebox.showerror("Quick Capture",str(exc))
        ttk.Button(self.body,text="Opret opgave",command=capture).pack(anchor="w",pady=5)
        ttk.Button(self.body,text="Today View",command=self.show_today_view).pack(anchor="w")
        if pm: pc.set(next(iter(pm)))
        pc.focus_set()

    def show_work_intake_triage(self):
        self.clear()
        ttk.Label(self.body,text="Work Intake Triage & Assignment",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(self.body,text="Se kun åbne, endnu ikke tildelte opgaver og gør dem klar til arbejde."
                  ).pack(anchor="w",pady=(2,10))

        tree=ttk.Treeview(self.body,columns=("id","title","project","owner","priority","due","status"),
                          show="headings")
        for c,t,w in [("id","ID",55),("title","Opgave",250),("project","Projekt",180),
                      ("owner","Ansvarlig",130),("priority","Prioritet",95),
                      ("due","Deadline",105),("status","Status",110)]:
            tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,pady=8)

        form=ttk.Frame(self.body);form.pack(fill="x",pady=5)
        owner=tk.StringVar(); priority=tk.StringVar(value="Normal"); due=tk.StringVar()
        ttk.Label(form,text="Ansvarlig").grid(row=0,column=0,padx=3,pady=3)
        ttk.Entry(form,textvariable=owner,width=22).grid(row=0,column=1,padx=3,pady=3)
        ttk.Label(form,text="Prioritet").grid(row=0,column=2,padx=3,pady=3)
        ttk.Combobox(form,textvariable=priority,values=["Low","Normal","High","Critical"],
                     state="readonly",width=12).grid(row=0,column=3,padx=3,pady=3)
        ttk.Label(form,text="Deadline").grid(row=0,column=4,padx=3,pady=3)
        ttk.Entry(form,textvariable=due,width=14).grid(row=0,column=5,padx=3,pady=3)

        def refresh():
            # Use the service-defined inbox rule: Open + unassigned.
            # The GUI must not reimplement a broader SQL definition here.
            rows=self.ctx.projects.work_intake_inbox()["items"]
            for x in tree.get_children(): tree.delete(x)
            for d in rows:
                tree.insert("", "end",iid=str(d["id"]),
                            values=(d["id"],d["title"],d.get("project_name") or "",
                                    d.get("assigned_to") or "",d.get("priority") or "",
                                    d.get("due_date") or "",d.get("status") or ""))
        def load():
            sel=tree.selection()
            if not sel:return
            r=tree.item(sel[0],"values")
            owner.set(r[3]);priority.set(r[4] or "Normal");due.set(r[5])
        def assign():
            sel=tree.selection()
            if not sel:
                messagebox.showinfo("Triage","Vælg en opgave først.");return
            try:
                self.ctx.projects.triage_work_item(int(sel[0]),owner.get(),
                                                   priority.get(),due.get().strip() or None)
                refresh()
            except Exception as exc: messagebox.showerror("Triage",str(exc))
        ttk.Button(form,text="Indlæs valgt",command=load).grid(row=0,column=6,padx=4)
        ttk.Button(form,text="Gem triage",command=assign).grid(row=0,column=7,padx=4)
        ttk.Button(form,text="Opdater",command=refresh).grid(row=0,column=8,padx=4)
        refresh()

