class ProjectRepository:
    def __init__(self, db):
        self.db = db

    def list(self):
        return self.db.fetch_all("SELECT * FROM projects ORDER BY id DESC")

    def create(self, name, description, status, budget):
        return self.db.execute(
            "INSERT INTO projects(name,description,status,budget) VALUES(?,?,?,?)",
            (name, description, status, budget)
        )

    def count(self):
        return self.db.fetch_one("SELECT COUNT(*) c FROM projects")["c"]

    def set_budget(self, project_id, amount):
        project = self.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        existing = self.db.fetch_one(
            "SELECT id FROM project_budgets WHERE project_id=?", (project_id,)
        )
        if existing:
            self.db.execute(
                "UPDATE project_budgets SET budget_amount=? WHERE project_id=?",
                (amount, project_id)
            )
            return existing["id"]
        return self.db.execute(
            "INSERT INTO project_budgets(project_id,budget_amount) VALUES(?,?)",
            (project_id, amount)
        )

    def project_budget(self, project_id):
        return self.db.fetch_one(
            "SELECT * FROM project_budgets WHERE project_id=?", (project_id,)
        )

    def list_activities(self, project_id):
        return self.db.fetch_all(
            """SELECT * FROM activities
               WHERE project_id=? ORDER BY activity_date DESC, id DESC""",
            (project_id,)
        )

    def create_activity(self, project_id, name, description, activity_date,
                        status="Planned", budget=0):
        return self.db.execute(
            """INSERT INTO activities
               (project_id,name,description,activity_date,status,budget)
               VALUES(?,?,?,?,?,?)""",
            (project_id,name,description,activity_date,status,budget)
        )

    def update_activity(self, activity_id, **fields):
        allowed={"name","description","activity_date","status","budget"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates: return None
        sql="UPDATE activities SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql,tuple(updates.values())+(activity_id,))
        return self.db.fetch_one("SELECT * FROM activities WHERE id=?", (activity_id,))

    def project_activity_summary(self, project_id):
        return self.db.fetch_one(
            """SELECT COUNT(*) activity_count,
                      COALESCE(SUM(budget),0) activity_budget
               FROM activities WHERE project_id=?""",
            (project_id,)
        )

    def project_financial_tracking(self, project_id):
        project=self.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        budget=self.db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",(project_id,))
        activity=self.db.fetch_one(
            """SELECT COALESCE(SUM(budget),0) activity_budget,
                      COUNT(*) activity_count
               FROM activities WHERE project_id=?""",(project_id,))
        actual=self.db.fetch_one(
            """SELECT COALESCE(SUM(jl.debit),0) actual_debit,
                      COALESCE(SUM(jl.credit),0) actual_credit
               FROM journal_lines jl
               JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.project_id=? AND j.status='Posted'
                 AND a.account_type='Expense'""",(project_id,))
        budget_amount=float(budget["budget_amount"]) if budget else float(project["budget"] or 0)
        actual_amount=round(float(actual["actual_debit"] or 0)-float(actual["actual_credit"] or 0),2)
        return {
            "project":project,
            "budget":budget_amount,
            "activity_budget":float(activity["activity_budget"] or 0),
            "activity_count":int(activity["activity_count"] or 0),
            "actual":actual_amount,
            "variance":round(budget_amount-actual_amount,2),
            "utilization":round(actual_amount/budget_amount*100,2) if budget_amount else 0.0
        }

    def project_financial_forecast(self, project_id, periods=3):
        """Return a transparent advisory expense forecast from posted project actuals."""
        periods=max(1,min(int(periods),12))
        rows=self.db.fetch_all(
            """SELECT substr(j.journal_date,1,7) month,
                      COALESCE(SUM(jl.debit-jl.credit),0) actual
               FROM journal_lines jl
               JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.project_id=? AND j.status='Posted'
                 AND a.account_type='Expense'
               GROUP BY substr(j.journal_date,1,7)
               ORDER BY month""",(project_id,))
        history=[{"month":r["month"],"actual":round(float(r["actual"] or 0),2)} for r in rows]
        if len(history)<2:
            return {"available":False,"reason":"Der kræves mindst to historiske projektmåneder med bogførte data.","history":history,"forecasts":[]}
        values=[x["actual"] for x in history]
        n=len(values); xs=list(range(n)); xbar=sum(xs)/n; ybar=sum(values)/n
        denom=sum((x-xbar)**2 for x in xs)
        slope=sum((x-xbar)*(y-ybar) for x,y in zip(xs,values))/denom if denom else 0.0
        intercept=ybar-slope*xbar
        forecasts=[]
        for step in range(1,periods+1):
            value=max(0.0,intercept+slope*(n-1+step))
            forecasts.append({"value":round(value,2)})
        return {"available":True,"method":"Linear trend on monthly posted project expense actuals","history":history,"forecasts":forecasts,
                "warning":"Forecast is indicative and read-only."}

    def project_expense_lines(self, project_id):
        return self.db.fetch_all(
            """SELECT j.journal_date,j.journal_no,j.description journal_description,
                      jl.description line_description,a.number account_number,a.name account_name,
                      jl.debit,jl.credit
               FROM journal_lines jl
               JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.project_id=? AND j.status='Posted'
                 AND a.account_type='Expense'
               ORDER BY j.journal_date,j.journal_no,jl.id""",(project_id,)
        )

    def activity_actuals(self, project_id):
        # Activity actuals are authoritative from posted expense journal lines
        # explicitly allocated to the activity.
        return self.db.fetch_all(
            """SELECT a.id,a.name,a.budget,a.status,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual,
                      a.budget - COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) variance
               FROM activities a
               LEFT JOIN journal_lines jl ON jl.activity_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE a.project_id=?
               GROUP BY a.id
               ORDER BY a.activity_date,a.id""",(project_id,)
        )

    def activity_financial_detail(self, project_id):
        return self.db.fetch_all(
            """SELECT a.id,a.name,a.status,a.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM activities a
               LEFT JOIN journal_lines jl ON jl.activity_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE a.project_id=?
               GROUP BY a.id
               ORDER BY a.activity_date,a.id""",(project_id,)
        )

    def project_control_dashboard(self, project_id):
        project=self.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        budget_row=self.db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",(project_id,))
        budget=float(budget_row["budget_amount"]) if budget_row else float(project["budget"] or 0)
        activities=self.db.fetch_all(
            """SELECT a.id,a.name,a.status,a.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM activities a
               LEFT JOIN journal_lines jl ON jl.activity_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE a.project_id=?
               GROUP BY a.id
               ORDER BY a.activity_date,a.id""",(project_id,))
        actual_row=self.db.fetch_one(
            """SELECT COALESCE(SUM(CASE WHEN j.status='Posted' AND a.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM journal_lines jl
               JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.project_id=?""",(project_id,))
        actual=round(float(actual_row["actual"] or 0),2)
        activity_budget=sum(float(a["budget"] or 0) for a in activities)
        activity_actual=sum(float(a["actual"] or 0) for a in activities)
        return {
            "project":project,
            "budget":budget,
            "actual":actual,
            "variance":round(budget-actual,2),
            "utilization":round(actual/budget*100,2) if budget else 0.0,
            "activity_budget":round(activity_budget,2),
            "activity_actual":round(activity_actual,2),
            "unallocated_actual":round(actual-activity_actual,2),
            "activities":[dict(a) for a in activities]
        }

    def project_tasks(self, project_id):
        return self.db.fetch_all(
            """SELECT t.*, a.name activity_name
               FROM tasks t LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.project_id=?
               ORDER BY t.due_date, t.id""",(project_id,)
        )

    def create_project_task(self, project_id, title, description="", activity_id=None,
                            assigned_to="", priority="Normal", due_date=None, status="Open"):
        return self.db.execute(
            """INSERT INTO tasks
               (project_id,activity_id,title,description,assigned_to,priority,due_date,status)
               VALUES(?,?,?,?,?,?,?,?)""",
            (project_id,activity_id,title,description,assigned_to,priority,due_date,status)
        )

    def update_project_task(self, task_id, **fields):
        allowed={"title","description","activity_id","assigned_to","priority","due_date","status"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates:return None
        sql="UPDATE tasks SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql,tuple(updates.values())+(task_id,))
        return self.db.fetch_one("SELECT * FROM tasks WHERE id=?",(task_id,))

    def operational_workboard(self, assigned_to=None):
        params=[]
        where=["t.status NOT IN ('Completed','Closed')"]
        if assigned_to:
            where.append("t.assigned_to=?")
            params.append(assigned_to)
        tasks=self.db.fetch_all(
            """SELECT t.*, p.name project_name, a.name activity_name
               FROM tasks t
               LEFT JOIN projects p ON p.id=t.project_id
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE %s
               ORDER BY
                 CASE t.priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2
                                  WHEN 'Normal' THEN 3 ELSE 4 END,
                 CASE WHEN t.due_date IS NULL OR t.due_date='' THEN 1 ELSE 0 END,
                 t.due_date, t.id""" % " AND ".join(where), tuple(params))
        projects=self.db.fetch_all(
            """SELECT p.id,p.name,p.status,p.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM projects p
               LEFT JOIN journal_lines jl ON jl.project_id=p.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE p.status NOT IN ('Completed','Closed')
               GROUP BY p.id
               ORDER BY p.name""")
        return {"tasks":[dict(x) for x in tasks],"projects":[dict(x) for x in projects]}

    def transition_project_task(self, task_id, new_status):
        self.db.execute("UPDATE tasks SET status=? WHERE id=?", (new_status, task_id))
        return self.db.fetch_one("SELECT * FROM tasks WHERE id=?", (task_id,))

    def task_by_id(self, task_id):
        return self.db.fetch_one(
            """SELECT t.*,p.name project_name,a.name activity_name
               FROM tasks t
               LEFT JOIN projects p ON p.id=t.project_id
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.id=?""",(task_id,))

    def operational_alerts(self, today_iso):
        tasks=self.db.fetch_all(
            """SELECT t.*,p.name project_name,a.name activity_name
               FROM tasks t
               LEFT JOIN projects p ON p.id=t.project_id
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.status NOT IN ('Completed','Closed')
                 AND (t.due_date IS NOT NULL AND t.due_date <> '')
               ORDER BY t.due_date,t.id""")
        projects=self.db.fetch_all(
            """SELECT p.id,p.name,p.status,p.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM projects p
               LEFT JOIN journal_lines jl ON jl.project_id=p.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE p.status NOT IN ('Completed','Closed')
               GROUP BY p.id""")
        return {"tasks":[dict(x) for x in tasks],"projects":[dict(x) for x in projects]}

    def personal_work_queue(self, assigned_to, today_iso, horizon_iso):
        return self.db.fetch_all(
            """SELECT t.*,p.name project_name,a.name activity_name
               FROM tasks t
               LEFT JOIN projects p ON p.id=t.project_id
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.assigned_to=?
                 AND t.status NOT IN ('Completed','Closed')
               ORDER BY
                 CASE WHEN t.due_date IS NULL OR t.due_date='' THEN 1 ELSE 0 END,
                 t.due_date,
                 CASE t.priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2
                                  WHEN 'Normal' THEN 3 ELSE 4 END,
                 t.id""",(assigned_to,))

    def quick_update_task(self, task_id, **fields):
        allowed={"status","due_date","priority","assigned_to"}
        updates={k:v for k,v in fields.items() if k in allowed}
        if not updates:
            return self.task_by_id(task_id)
        sql="UPDATE tasks SET "+", ".join(f"{k}=?" for k in updates)+" WHERE id=?"
        self.db.execute(sql, tuple(updates.values())+(task_id,))
        return self.task_by_id(task_id)

    def project_execution_view(self, project_id):
        project=self.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        activities=self.db.fetch_all(
            """SELECT a.id,a.name,a.status,a.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM activities a
               LEFT JOIN journal_lines jl ON jl.activity_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE a.project_id=?
               GROUP BY a.id
               ORDER BY a.activity_date,a.id""",(project_id,))
        tasks=self.db.fetch_all(
            """SELECT t.id,t.title,t.status,t.priority,t.assigned_to,t.due_date,
                      t.activity_id,a.name activity_name
               FROM tasks t
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.project_id=?
               ORDER BY t.activity_id,t.due_date,t.id""",(project_id,))
        budget_row=self.db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",(project_id,))
        budget=float(budget_row["budget_amount"]) if budget_row else float(project["budget"] or 0)
        actual_row=self.db.fetch_one(
            """SELECT COALESCE(SUM(CASE WHEN j.status='Posted' AND a.account_type='Expense'
                                       THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM journal_lines jl
               JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.project_id=?""",(project_id,))
        actual=float(actual_row["actual"] or 0)
        return {"project":dict(project),"budget":budget,"actual":round(actual,2),
                "variance":round(budget-actual,2),
                "utilization":round(actual/budget*100,2) if budget else 0.0,
                "activities":[dict(a) for a in activities],
                "tasks":[dict(t) for t in tasks]}

    def activity_execution_view(self, project_id, activity_id=None):
        if activity_id is None:
            return self.project_execution_view(project_id)
        activity=self.db.fetch_one(
            "SELECT * FROM activities WHERE id=? AND project_id=?",(activity_id,project_id))
        if not activity:
            raise ValueError("Activity not found in selected project.")
        tasks=self.db.fetch_all(
            """SELECT t.*,a.name activity_name
               FROM tasks t LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.project_id=? AND t.activity_id=?
               ORDER BY t.due_date,t.id""",(project_id,activity_id))
        return {"activity":dict(activity),"tasks":[dict(t) for t in tasks]}

    def project_progress_control(self, project_id):
        project=self.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        activities=self.db.fetch_all(
            """SELECT a.id,a.name,a.status,a.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM activities a
               LEFT JOIN journal_lines jl ON jl.activity_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE a.project_id=?
               GROUP BY a.id ORDER BY a.activity_date,a.id""",(project_id,))
        tasks=self.db.fetch_all(
            """SELECT t.*,a.name activity_name
               FROM tasks t LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.project_id=? ORDER BY t.activity_id,t.due_date,t.id""",(project_id,))
        budget_row=self.db.fetch_one(
            "SELECT budget_amount FROM project_budgets WHERE project_id=?",(project_id,))
        budget=float(budget_row["budget_amount"]) if budget_row else float(project["budget"] or 0)
        actual_row=self.db.fetch_one(
            """SELECT COALESCE(SUM(CASE WHEN j.status='Posted' AND a.account_type='Expense'
                                       THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM journal_lines jl JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id WHERE jl.project_id=?""",(project_id,))
        actual=float(actual_row["actual"] or 0)
        return {"project":dict(project),"budget":budget,"actual":actual,
                "activities":[dict(a) for a in activities],"tasks":[dict(t) for t in tasks]}

    def project_control_exceptions(self, project_id):
        project=self.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        activities=self.db.fetch_all(
            """SELECT a.id,a.name,a.budget,
                      COALESCE(SUM(CASE WHEN j.status='Posted' AND ac.account_type='Expense'
                                        THEN jl.debit-jl.credit ELSE 0 END),0) actual
               FROM activities a
               LEFT JOIN journal_lines jl ON jl.activity_id=a.id
               LEFT JOIN journals j ON j.id=jl.journal_id
               LEFT JOIN accounts ac ON ac.id=jl.account_id
               WHERE a.project_id=? GROUP BY a.id""",(project_id,))
        tasks=self.db.fetch_all(
            """SELECT t.*,a.name activity_name FROM tasks t
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.project_id=? AND t.status NOT IN ('Completed','Closed')
               ORDER BY t.due_date,t.id""",(project_id,))
        return {"project":dict(project),"activities":[dict(a) for a in activities],
                "tasks":[dict(t) for t in tasks]}

    def project_control_cockpit(self, project_id):
        project=self.db.fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
        if not project:
            raise ValueError("Project not found.")
        return {"project":dict(project)}

    def integrated_operations_dashboard(self):
        projects=self.db.fetch_all(
            "SELECT id,name,status,budget FROM projects WHERE status NOT IN ('Completed','Closed') ORDER BY name")
        task_summary=self.db.fetch_one(
            """SELECT
                 COUNT(*) open_count,
                 SUM(CASE WHEN status='Blocked' THEN 1 ELSE 0 END) blocked_count,
                 SUM(CASE WHEN due_date IS NOT NULL AND due_date<>'' AND due_date < date('now')
                          AND status NOT IN ('Completed','Closed') THEN 1 ELSE 0 END) overdue_count
               FROM tasks WHERE status NOT IN ('Completed','Closed')""")
        member_summary=self.db.fetch_one(
            """SELECT COUNT(*) total_members,
                      SUM(CASE WHEN status='Active' THEN 1 ELSE 0 END) active_members
               FROM members""")
        return {"projects":[dict(x) for x in projects],
                "task_summary":dict(task_summary) if task_summary else {},
                "member_summary":dict(member_summary) if member_summary else {}}

    def global_search(self, query, limit=50):
        q=f"%{str(query).strip()}%"
        if not str(query).strip():
            return []
        results=[]
        for table,label,fields in [
            ("projects","Projekt",("id","name","description")),
            ("activities","Aktivitet",("id","name","description")),
            ("tasks","Opgave",("id","title","description")),
            ("members","Medlem",("id","name","email"))
        ]:
            cols=", ".join(fields)
            rows=self.db.fetch_all(
                f"SELECT {cols} FROM {table} WHERE " +
                " OR ".join([f"{c} LIKE ?" for c in fields[1:]]) +
                " LIMIT ?", tuple([q]*(len(fields)-1)+[limit]))
            for r in rows:
                d=dict(r)
                title=d.get("name") or d.get("title") or ""
                results.append({"type":label,"id":d["id"],"title":title,
                                "subtitle":d.get("description") or d.get("email") or ""})
        return results[:limit]

    def global_search(self, query, limit=50):
        q=f"%{str(query).strip()}%"
        if not str(query).strip():
            return []
        results=[]
        specs=[
            ("projects","Projekt",["id","name","description"],["name","description"]),
            ("activities","Aktivitet",["id","name","description"],["name","description"]),
            ("tasks","Opgave",["id","title","description"],["title","description"]),
            ("members","Medlem",["id","full_name","email"],["full_name","email"])
        ]
        for table,label,fields,search_fields in specs:
            cols=", ".join(fields)
            rows=self.db.fetch_all(
                f"SELECT {cols} FROM {table} WHERE " +
                " OR ".join([f"{c} LIKE ?" for c in search_fields]) +
                " LIMIT ?", tuple([q]*len(search_fields)+[limit]))
            for r in rows:
                d=dict(r)
                results.append({"type":label,"id":d["id"],
                                "title":d.get("name") or d.get("title") or d.get("full_name") or "",
                                "subtitle":d.get("description") or d.get("email") or ""})
        return results[:limit]

    def global_search(self, query, limit=50):
        q=f"%{str(query).strip()}%"
        if not str(query).strip():
            return []
        results=[]
        specs=[
            ("projects","Projekt","id,name,description",["name","description"],
             lambda d:d.get("name","")),
            ("activities","Aktivitet","id,name,description",["name","description"],
             lambda d:d.get("name","")),
            ("tasks","Opgave","id,title,description",["title","description"],
             lambda d:d.get("title","")),
            ("members","Medlem","id,member_no,first_name,last_name,email",
             ["member_no","first_name","last_name","email"],
             lambda d:(d.get("first_name","")+" "+d.get("last_name","")).strip())
        ]
        for table,label,fields,search_fields,title_fn in specs:
            rows=self.db.fetch_all(
                f"SELECT {fields} FROM {table} WHERE " +
                " OR ".join([f"{c} LIKE ?" for c in search_fields]) +
                " LIMIT ?", tuple([q]*len(search_fields)+[limit]))
            for r in rows:
                d=dict(r)
                results.append({"type":label,"id":d["id"],"title":title_fn(d),
                                "subtitle":d.get("description") or d.get("email") or d.get("member_no") or ""})
        return results[:limit]

    def unified_record(self, record_type, record_id):
        record_type=str(record_type).strip().lower()
        specs={
            "project":("projects","id=?"),
            "activity":("activities","id=?"),
            "task":("tasks","id=?"),
            "member":("members","id=?")
        }
        if record_type not in specs:
            raise ValueError("Unknown record type.")
        table,where=specs[record_type]
        row=self.db.fetch_one(f"SELECT * FROM {table} WHERE {where}",(record_id,))
        if not row:
            raise ValueError("Record not found.")
        return dict(row)

    def personal_workspace(self, owner):
        owner=str(owner or "").strip()
        if not owner:
            return {"tasks":[]}
        tasks=self.db.fetch_all(
            """SELECT t.*, a.name activity_name, p.name project_name
               FROM tasks t
               LEFT JOIN activities a ON a.id=t.activity_id
               LEFT JOIN projects p ON p.id=t.project_id
               WHERE t.assigned_to=? AND t.status NOT IN ('Completed','Closed')
               ORDER BY CASE WHEN t.due_date IS NULL OR t.due_date='' THEN 1 ELSE 0 END,
                        t.due_date,t.priority DESC,t.id""",(owner,))
        return {"tasks":[dict(t) for t in tasks]}

    def today_work(self, owner, today):
        owner=str(owner or "").strip()
        if not owner: return {"tasks":[]}
        rows=self.db.fetch_all(
            """SELECT t.*, a.name activity_name, p.name project_name
               FROM tasks t
               LEFT JOIN activities a ON a.id=t.activity_id
               LEFT JOIN projects p ON p.id=t.project_id
               WHERE t.assigned_to=? AND t.status NOT IN ('Completed','Closed')
               ORDER BY
                 CASE WHEN t.due_date=? THEN 0
                      WHEN t.due_date IS NOT NULL AND t.due_date<>'' AND t.due_date<? THEN 1
                      ELSE 2 END,
                 CASE WHEN t.priority='High' THEN 0
                      WHEN t.priority='Medium' THEN 1 ELSE 2 END,
                 CASE WHEN t.status='Blocked' THEN 3 ELSE 0 END,
                 t.due_date,t.id""",(owner,today,today))
        return {"tasks":[dict(r) for r in rows]}

    def work_intake_inbox(self):
        rows=self.db.fetch_all(
            """SELECT t.*, p.name project_name, a.name activity_name
               FROM tasks t
               LEFT JOIN projects p ON p.id=t.project_id
               LEFT JOIN activities a ON a.id=t.activity_id
               WHERE t.status='Open'
                 AND (t.assigned_to IS NULL OR TRIM(t.assigned_to)='')
               ORDER BY
                 CASE WHEN t.priority='Critical' THEN 0
                      WHEN t.priority='High' THEN 1
                      WHEN t.priority='Normal' THEN 2 ELSE 3 END,
                 CASE WHEN t.due_date IS NULL OR t.due_date='' THEN 1 ELSE 0 END,
                 t.due_date,t.id""")
        return [dict(r) for r in rows]
