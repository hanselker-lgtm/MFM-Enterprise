import ast
from pathlib import Path


MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def _tree():
    return ast.parse(MAIN_WINDOW.read_text(encoding="utf-8"))


def _main_window_class():
    tree = _tree()
    return next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
    )


def test_mainwindow_core_methods_are_class_methods():
    cls = _main_window_class()
    methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    expected = {
        "__init__", "_login", "_build", "allowed", "denied",
        "clear", "card", "show_dashboard", "table", "show_projects",
        "show_project_finance", "new_project", "show_tasks", "new_task",
        "show_risks", "new_risk", "show_decisions", "new_decision",
        "show_accounting", "show_accounts", "new_account", "show_journals",
        "show_trial_balance", "refresh", "run", "show_financial_dashboard",
    }
    assert expected <= methods


def test_no_legacy_mfm_extension_functions_remain_top_level():
    tree = _tree()
    top_level_functions = {
        node.name for node in tree.body if isinstance(node, ast.FunctionDef)
    }
    assert top_level_functions == set()


def test_mainwindow_public_workspaces_are_real_methods():
    cls = _main_window_class()
    methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    expected = {
        "show_members", "show_membership_billing", "show_dunning", "show_member_admin",
        "show_activities", "show_project_financials", "show_project_control", "show_project_work",
        "show_operational_workboard", "show_operational_actions", "show_operational_alerts", "show_my_day",
        "show_daily_execution", "show_project_execution", "show_project_execution_actions",
        "show_project_progress_control", "show_project_control_actions", "show_project_control_cockpit",
        "show_integrated_operations_dashboard", "show_integrated_operations_actions", "show_workspace_integration",
        "show_global_search", "show_unified_record_view", "show_personal_workspace",
        "show_personal_work_actions", "show_today_view", "show_quick_capture", "show_work_intake_triage",
    }
    assert expected <= methods


def test_mainwindow_local_callbacks_remain_local():
    cls = _main_window_class()
    login = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "_login"
    )
    nested_names = {
        node.name for node in login.body if isinstance(node, ast.FunctionDef)
    }
    assert {"do_login", "on_close"} <= nested_names


def test_financial_dashboard_refresh_remains_a_local_callback():
    cls = _main_window_class()
    method = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "show_financial_dashboard"
    )
    nested_names = {
        node.name for node in method.body if isinstance(node, ast.FunctionDef)
    }
    assert "refresh" in nested_names


def test_mainwindow_command_registry_is_explicit_and_resolvable():
    cls = _main_window_class()
    registry = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "command_registry"
    )
    returns = [node for node in ast.walk(registry) if isinstance(node, ast.Return)]
    assert len(returns) == 1
    value = returns[0].value
    assert isinstance(value, (ast.Tuple, ast.List))
    commands = [(item.elts[0].value, item.elts[1].value) for item in value.elts]
    methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
    assert len(commands) == len(set(commands))
    assert all(method in methods for _, method in commands)
    assert all(label.strip() and method.startswith("show_") for label, method in commands)
