class ProjectService:
    def __init__(self, repo):
        self.repo = repo

    def create(self, name, description="", status="Planned", budget=0):
        name = str(name).strip()
        if not name:
            raise ValueError("Project name is required.")
        budget = float(budget or 0)
        if budget < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.create(name, str(description).strip(), status, budget)

    def list(self):
        return self.repo.list()

    def count(self):
        return self.repo.count()

    def set_budget(self, project_id, amount):
        amount = float(amount)
        if amount < 0:
            raise ValueError("Budget cannot be negative.")
        return self.repo.set_budget(project_id, amount)

    def budget(self, project_id):
        return self.repo.project_budget(project_id)

    def create_activity(self, project_id, name, description="", activity_date=None,
                        status="Planned", budget=0):
        if not self.repo.db.fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("Project not found.")
        name=str(name).strip()
        if not name: raise ValueError("Activity name is required.")
        budget=float(budget or 0)
        if budget < 0: raise ValueError("Activity budget cannot be negative.")
        return self.repo.create_activity(project_id,name,str(description).strip(),
                                          activity_date,status,budget)

    def activities(self, project_id):
        return self.repo.list_activities(project_id)

    def update_activity(self, activity_id, **fields):
        if "budget" in fields and float(fields["budget"]) < 0:
            raise ValueError("Activity budget cannot be negative.")
        return self.repo.update_activity(activity_id,**fields)

    def activity_summary(self, project_id):
        return dict(self.repo.project_activity_summary(project_id))

    def financial_tracking(self, project_id):
        return self.repo.project_financial_tracking(project_id)

    def expense_lines(self, project_id):
        return self.repo.project_expense_lines(project_id)

    def activity_financials(self, project_id):
        return self.repo.activity_actuals(project_id)

    def activity_financial_detail(self, project_id):
        rows=self.repo.activity_financial_detail(project_id)
        result=[]
        for r in rows:
            budget=float(r["budget"] or 0)
            actual=round(float(r["actual"] or 0),2)
            result.append({
                "id":r["id"],"name":r["name"],"status":r["status"],
                "budget":budget,"actual":actual,
                "variance":round(budget-actual,2),
                "utilization":round(actual/budget*100,2) if budget else 0.0
            })
        return result

    def project_control_dashboard(self, project_id):
        data=self.repo.project_control_dashboard(project_id)
        data["activities"]=[
            {
                **dict(a),
                "budget":float(a["budget"] or 0),
                "actual":round(float(a["actual"] or 0),2),
                "variance":round(float(a["budget"] or 0)-float(a["actual"] or 0),2),
                "utilization":round(float(a["actual"] or 0)/float(a["budget"])*100,2)
                    if float(a["budget"] or 0) else 0.0
            }
            for a in data["activities"]
        ]
        return data

    def project_tasks(self, project_id):
        return self.repo.project_tasks(project_id)

    def create_project_task(self, project_id, title, description="", activity_id=None,
                            assigned_to="", priority="Normal", due_date=None,
                            status="Open"):
        title=str(title).strip()
        if not title: raise ValueError("Task title is required.")
        if activity_id is not None:
            activity=self.repo.db.fetch_one("SELECT * FROM activities WHERE id=?", (activity_id,))
            if not activity or int(activity["project_id"]) != int(project_id):
                raise ValueError("Task activity must belong to the selected project.")
        if priority not in {"Low","Normal","High","Critical"}:
            raise ValueError("Invalid task priority.")
        return self.repo.create_project_task(project_id,title,str(description).strip(),
                                              activity_id,assigned_to,priority,due_date,status)

    def update_project_task(self, task_id, **fields):
        if "priority" in fields and fields["priority"] not in {"Low","Normal","High","Critical"}:
            raise ValueError("Invalid task priority.")
        return self.repo.update_project_task(task_id,**fields)

    def operational_workboard(self, assigned_to=None):
        data=self.repo.operational_workboard(assigned_to)
        tasks=data["tasks"]
        from datetime import date, timedelta
        today=date.today()
        overdue=[t for t in tasks if t.get("due_date") and t["due_date"] < today.isoformat()]
        critical=[t for t in tasks if t.get("priority")=="Critical"]
        high=[t for t in tasks if t.get("priority")=="High"]
        horizon=(today+timedelta(days=7)).isoformat()
        week_tasks=[t for t in tasks if t.get("due_date") and t["due_date"] <= horizon]
        for p in data["projects"]:
            budget=float(p["budget"] or 0)
            actual=float(p["actual"] or 0)
            p["budget"]=budget
            p["actual"]=round(actual,2)
            p["variance"]=round(budget-actual,2)
            p["utilization"]=round(actual/budget*100,2) if budget else 0.0
        data["metrics"]={"open_tasks":len(tasks),"critical_tasks":len(critical),
            "high_tasks":len(high),"overdue_tasks":len(overdue),
            "next_7_days":len(week_tasks),"active_projects":len(data["projects"])}
        return data
