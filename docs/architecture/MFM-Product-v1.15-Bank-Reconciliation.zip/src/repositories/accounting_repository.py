class AccountingRepository:
    def __init__(self, db):
        self.db = db

    def list_accounts(self, include_inactive=False):
        sql = "SELECT * FROM accounts"
        if not include_inactive:
            sql += " WHERE active=1"
        sql += " ORDER BY number"
        return self.db.fetch_all(sql)

    def create_account(self, number, name, account_type):
        return self.db.execute(
            "INSERT INTO accounts(number,name,account_type) VALUES(?,?,?)",
            (number, name, account_type),
        )

    def get_account(self, account_id):
        return self.db.fetch_one("SELECT * FROM accounts WHERE id=?", (account_id,))

    def create_fiscal_year(self, year):
        return self.db.execute("INSERT INTO fiscal_years(year) VALUES(?)", (year,))

    def get_fiscal_year(self, year):
        return self.db.fetch_one("SELECT * FROM fiscal_years WHERE year=?", (year,))

    def list_fiscal_years(self):
        return self.db.fetch_all("SELECT * FROM fiscal_years ORDER BY year DESC")

    def create_period(self, fiscal_year_id, period_no, start_date, end_date):
        return self.db.execute(
            """INSERT INTO fiscal_periods
               (fiscal_year_id,period_no,start_date,end_date)
               VALUES(?,?,?,?)""",
            (fiscal_year_id, period_no, start_date, end_date),
        )

    def list_periods(self, fiscal_year_id):
        return self.db.fetch_all(
            "SELECT * FROM fiscal_periods WHERE fiscal_year_id=? ORDER BY period_no",
            (fiscal_year_id,),
        )

    def get_period(self, period_id):
        return self.db.fetch_one("SELECT * FROM fiscal_periods WHERE id=?", (period_id,))

    def period_for_date(self, journal_date):
        return self.db.fetch_one(
            """SELECT fp.*, fy.year
               FROM fiscal_periods fp
               JOIN fiscal_years fy ON fy.id=fp.fiscal_year_id
               WHERE ? BETWEEN fp.start_date AND fp.end_date
               LIMIT 1""",
            (journal_date,),
        )

    def set_period_status(self, period_id, status):
        self.db.execute(
            "UPDATE fiscal_periods SET status=? WHERE id=?",
            (status, period_id)
        )

    def create_journal(self, journal_no, journal_date, description):
        return self.db.execute(
            "INSERT INTO journals(journal_no,journal_date,description) VALUES(?,?,?)",
            (journal_no, journal_date, description),
        )

    def add_line(self, journal_id, account_id, description, debit, credit, project_id=None):
        return self.db.execute(
            """INSERT INTO journal_lines
               (journal_id,account_id,description,debit,credit,project_id)
               VALUES(?,?,?,?,?,?)""",
            (journal_id, account_id, description, debit, credit, project_id),
        )

    def create_posted_journal(self, journal_no, journal_date, description, lines):
        statements = [
            ("INSERT INTO journals(journal_no,journal_date,description,status) VALUES(?,?,?,'Posted')",
             (journal_no, journal_date, description))
        ]
        # journal id is needed by the line inserts; use one transaction with a temp
        # sequence-free insert followed by SELECT of the unique journal number.
        with self.db.connect() as conn:
            try:
                cur = conn.execute(
                    "INSERT INTO journals(journal_no,journal_date,description,status) VALUES(?,?,?,'Posted')",
                    (journal_no, journal_date, description)
                )
                journal_id = cur.lastrowid
                for account_id, line_desc, debit, credit, project_id in lines:
                    conn.execute(
                        """INSERT INTO journal_lines
                           (journal_id,account_id,description,debit,credit,project_id)
                           VALUES(?,?,?,?,?,?)""",
                        (journal_id, account_id, line_desc, debit, credit, project_id)
                    )
                conn.commit()
                return journal_id
            except Exception:
                conn.rollback()
                raise

    def journal_by_number(self, journal_no):
        return self.db.fetch_one(
            "SELECT * FROM journals WHERE journal_no=? LIMIT 1",
            (journal_no,)
        )

    def get_journal(self, journal_id):
        journal = self.db.fetch_one("SELECT * FROM journals WHERE id=?", (journal_id,))
        if not journal:
            return None
        lines = self.get_journal_lines(journal_id)
        return {"journal": journal, "lines": lines}

    def get_journal_lines(self, journal_id):
        return self.db.fetch_all(
            """SELECT jl.*, a.number, a.name, a.account_type
               FROM journal_lines jl
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.journal_id=? ORDER BY jl.id""",
            (journal_id,),
        )

    def next_journal_number(self, journal_type="FIN"):
        row = self.db.fetch_one(
            "SELECT next_number FROM journal_sequences WHERE journal_type=?",
            (journal_type,),
        )
        if row is None:
            self.db.execute(
                "INSERT INTO journal_sequences(journal_type,next_number) VALUES(?,?)",
                (journal_type, 2)
            )
            return 1
        number = int(row["next_number"])
        self.db.execute(
            "UPDATE journal_sequences SET next_number=? WHERE journal_type=?",
            (number + 1, journal_type)
        )
        return number

    def set_journal_status(self, journal_id, status):
        self.db.execute("UPDATE journals SET status=? WHERE id=?", (status, journal_id))

    def list_journals(self):
        return self.db.fetch_all(
            "SELECT * FROM journals ORDER BY journal_date DESC, journal_no DESC"
        )

    def trial_balance(self, start_date=None, end_date=None):
        clauses = ["j.status='Posted'"]
        params = []
        if start_date:
            clauses.append("j.journal_date>=?")
            params.append(start_date)
        if end_date:
            clauses.append("j.journal_date<=?")
            params.append(end_date)
        posted = " AND ".join(clauses)
        return self.db.fetch_all(
            f"""SELECT a.id, a.number, a.name, a.account_type,
                       COALESCE(SUM(x.debit),0) debit,
                       COALESCE(SUM(x.credit),0) credit
                FROM accounts a
                LEFT JOIN (
                    SELECT jl.account_id, jl.debit, jl.credit
                    FROM journal_lines jl
                    JOIN journals j ON j.id=jl.journal_id
                    WHERE {posted}
                ) x ON x.account_id=a.id
                WHERE a.active=1
                GROUP BY a.id
                ORDER BY a.number""",
            tuple(params)
        )

    def account_movements(self, account_id, start_date=None, end_date=None):
        sql = """
            SELECT j.journal_no, j.journal_date, j.description AS journal_description,
                   jl.description, jl.debit, jl.credit, p.name AS project_name
            FROM journal_lines jl
            JOIN journals j ON j.id=jl.journal_id
            LEFT JOIN projects p ON p.id=jl.project_id
            WHERE jl.account_id=? AND j.status='Posted'
        """
        params = [account_id]
        if start_date:
            sql += " AND j.journal_date>=?"
            params.append(start_date)
        if end_date:
            sql += " AND j.journal_date<=?"
            params.append(end_date)
        sql += " ORDER BY j.journal_date, j.journal_no, jl.id"
        return self.db.fetch_all(sql, tuple(params))

    def general_ledger(self, start_date=None, end_date=None):
        sql = """
            SELECT j.journal_no, j.journal_date, j.description AS journal_description,
                   a.number, a.name, jl.description, jl.debit, jl.credit,
                   p.name AS project_name
            FROM journal_lines jl
            JOIN journals j ON j.id=jl.journal_id
            JOIN accounts a ON a.id=jl.account_id
            LEFT JOIN projects p ON p.id=jl.project_id
            WHERE j.status='Posted'
        """
        params = []
        if start_date:
            sql += " AND j.journal_date>=?"
            params.append(start_date)
        if end_date:
            sql += " AND j.journal_date<=?"
            params.append(end_date)
        sql += " ORDER BY j.journal_date, j.journal_no, jl.id"
        return self.db.fetch_all(sql, tuple(params))

    def project_financials(self, project_id):
        return self.project_actuals(project_id)

    def project_actuals(self, project_id):
        # Project actuals are expense-account movements only. A project journal
        # normally contains both the expense line and its funding/bank line;
        # counting both would incorrectly net the project cost to zero.
        return self.db.fetch_one(
            """SELECT COALESCE(SUM(jl.debit),0) debit,
                      COALESCE(SUM(jl.credit),0) credit
               FROM journal_lines jl
               JOIN journals j ON j.id=jl.journal_id
               JOIN accounts a ON a.id=jl.account_id
               WHERE jl.project_id=? AND j.status='Posted'
                 AND a.account_type='Expense'""",
            (project_id,)
        )


    def add_voucher_document(self, journal_id, file_name, stored_name,
                             mime_type, file_size, sha256, description, uploaded_at):
        return self.db.execute(
            """INSERT INTO voucher_documents
               (journal_id,file_name,stored_name,mime_type,file_size,sha256,description,uploaded_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (journal_id, file_name, stored_name, mime_type, file_size, sha256,
             description, uploaded_at)
        )

    def list_voucher_documents(self, journal_id):
        return self.db.fetch_all(
            """SELECT * FROM voucher_documents
               WHERE journal_id=? ORDER BY uploaded_at, id""",
            (journal_id,)
        )

    def get_voucher_document(self, document_id):
        return self.db.fetch_one(
            "SELECT * FROM voucher_documents WHERE id=?", (document_id,)
        )

    def delete_voucher_document(self, document_id):
        self.db.execute(
            "DELETE FROM voucher_documents WHERE id=?", (document_id,)
        )


    def add_audit_event(self, event_time, event_type, entity_type, entity_id,
                        description, actor=None, metadata=None):
        return self.db.execute(
            """INSERT INTO audit_events
               (event_time,event_type,entity_type,entity_id,description,actor,metadata)
               VALUES(?,?,?,?,?,?,?)""",
            (event_time, event_type, entity_type, entity_id, description,
             actor, metadata)
        )

    def list_audit_events(self, entity_type=None, entity_id=None,
                          start_date=None, end_date=None):
        sql = "SELECT * FROM audit_events WHERE 1=1"
        params = []
        if entity_type:
            sql += " AND entity_type=?"
            params.append(entity_type)
        if entity_id is not None:
            sql += " AND entity_id=?"
            params.append(entity_id)
        if start_date:
            sql += " AND event_time>=?"
            params.append(start_date)
        if end_date:
            sql += " AND event_time<=?"
            params.append(end_date)
        sql += " ORDER BY event_time DESC, id DESC"
        return self.db.fetch_all(sql, tuple(params))


    def list_bank_transactions(self, bank_account_id=None, status=None):
        sql = """SELECT * FROM bank_transactions WHERE 1=1"""
        params = []
        if bank_account_id is not None:
            sql += " AND bank_account_id=?"
            params.append(bank_account_id)
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY transaction_date DESC, id DESC"
        return self.db.fetch_all(sql, tuple(params))

    def create_bank_transaction(self, bank_account_id, transaction_date,
                                amount, description="", external_reference="",
                                status="Unmatched"):
        return self.db.execute(
            """INSERT INTO bank_transactions
               (bank_account_id,transaction_date,amount,description,
                external_reference,status)
               VALUES(?,?,?,?,?,?)""",
            (bank_account_id, transaction_date, amount, description,
             external_reference, status)
        )

    def update_bank_transaction_status(self, transaction_id, status, journal_id=None):
        if journal_id is None:
            return self.db.execute(
                "UPDATE bank_transactions SET status=? WHERE id=?",
                (status, transaction_id)
            )
        return self.db.execute(
            "UPDATE bank_transactions SET status=?, journal_id=? WHERE id=?",
            (status, journal_id, transaction_id)
        )

    def create_bank_match(self, bank_transaction_id, journal_id, matched_amount):
        return self.db.execute(
            """INSERT INTO bank_matches
               (bank_transaction_id,journal_id,matched_amount)
               VALUES(?,?,?)""",
            (bank_transaction_id, journal_id, matched_amount)
        )

    def get_bank_match(self, bank_transaction_id):
        return self.db.fetch_one(
            "SELECT * FROM bank_matches WHERE bank_transaction_id=?",
            (bank_transaction_id,)
        )

    def delete_bank_match(self, bank_transaction_id):
        return self.db.execute(
            "DELETE FROM bank_matches WHERE bank_transaction_id=?",
            (bank_transaction_id,)
        )
