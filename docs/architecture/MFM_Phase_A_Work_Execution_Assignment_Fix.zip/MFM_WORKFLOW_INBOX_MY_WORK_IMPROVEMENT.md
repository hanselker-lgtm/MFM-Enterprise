# MFM — Work Flow Improvement

## Concrete improvement

The Work Intake screen previously duplicated SQL in the GUI and selected all
Open tasks. That did not fully enforce the MFM Inbox rule at the GUI level.

The Inbox is defined as a filtered view of existing work:

- status = Open
- assigned_to is blank

The GUI now uses the existing `ProjectService.work_intake_inbox()` method.
This keeps the filtering rule in the service/repository layer and prevents the
GUI from maintaining a second, potentially inconsistent definition.

## User flow

Quick Capture
→ Inbox & Work Intake
→ Assignment
→ My Work
→ Today
→ Execute

Assigning an Inbox item removes it from the Inbox because the existing service
updates the task assignment.

## Scope

Changed:
- MainWindow Work Intake refresh logic
- Work Intake heading/help text

Not changed:
- database schema
- repository semantics
- business rules
- task model
- service API
- permissions

## Validation

- Python compileall: PASS
- Targeted GUI/navigation/work-intake tests: 28 passed, 41 deselected
