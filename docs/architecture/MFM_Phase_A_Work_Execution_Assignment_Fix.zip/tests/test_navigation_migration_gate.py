from pathlib import Path

MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def test_visible_navigation_migration_gate_remains_closed_until_full_regression():
    source = MAIN_WINDOW.read_text(encoding="utf-8")
    assert "command_registry" in source
    assert "build_product_navigation" not in source.split("def _build", 1)[1].split("def command_registry", 1)[0]
    assert "preview_product_navigation" not in source.split("def _build", 1)[1].split("def command_registry", 1)[0]


def test_product_areas_are_defined_before_visible_migration():
    source = MAIN_WINDOW.read_text(encoding="utf-8")
    expected = ["Home", "Work", "Projects", "Members", "Finance", "Reports", "Administration"]
    for area in expected:
        assert f'("{area}",' in source
