# MFM v1.49 — Product Completion — Step 225

## Boundary
Membership Invoice Referential Validation

## Finding
`MemberService.invoice_membership()` posted the accounting journal before the database validated the supplied membership/member relationship. An invalid membership ID or a membership belonging to another member could therefore cause a journal to be created before invoice persistence failed.

## Correction
The service now validates the member, membership existence, and membership-to-member relationship before creating the accounting journal.

## Architecture
No new engine or repository was introduced. The existing flow remains:

```text
MemberService
    ↓
existing MemberRepository read paths
    ↓
validation
    ↓
existing AccountingService journal path
    ↓
existing invoice persistence path
```

## Regression
Added regression coverage for:
- unknown membership
- membership belonging to another member
- no invoice created on rejection
- no accounting journal created on rejection

## Product code
CHANGED — real referential-validation defect fixed.

## Verification
Focused regression: PASS
Compileall: PASS
