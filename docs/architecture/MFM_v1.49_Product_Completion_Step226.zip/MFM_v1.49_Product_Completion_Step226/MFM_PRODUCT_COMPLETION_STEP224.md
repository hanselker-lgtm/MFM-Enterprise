# MFM v1.49 — Product Completion Step 224

## P1 — Regression Contract Alignment

Step 224 addresses two stale regression assumptions discovered during direct
inspection of the Step 223 baseline.

The product implementation was not changed.

### 1. Activity creation contract

`create_activity()` explicitly requires a newly created activity to start in
`Planned` status. The existing accounting-product regression attempted to
create an activity directly as `Active`.

The regression was corrected to follow the existing contract:

```text
create_activity(..., Planned)
        ↓
update_activity(..., Active)
```

### 2. Activity execution view contract

The current service boundary is:

```python
activity_execution_view(activity_id)
```

The older regression called it as if it were:

```python
activity_execution_view(project_id, activity_id)
```

That assumption did not match the current implementation and was replaced
with an invalid-activity regression against the actual service contract.

### Product code

NO PRODUCT CODE CHANGE.

No compatibility wrapper or alternate method signature was introduced merely
to satisfy stale tests.

### Verification

The affected regressions pass against the current implementation.

This step exists to restore agreement between the regression suite and the
actual established product contracts; it does not introduce a new product
feature or architecture.
