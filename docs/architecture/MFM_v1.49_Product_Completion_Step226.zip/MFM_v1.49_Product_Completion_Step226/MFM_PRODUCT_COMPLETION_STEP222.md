# MFM v1.49 — Product Completion — Step 222

## Boundary

**User Password Change Boundary**

Existing service boundary:

```python
UserService.change_password(user_id, new_password, confirmation)
```

## Actual flow

```text
UserService.change_password()
        ↓
validation
        ↓
PBKDF2-SHA256 password hash
        ↓
UserRepository.set_password()
        ↓
password + must_change_password reset
```

## Verified contract

- a new password is required
- confirmation must match
- minimum password length is 12 characters
- password is stored as a PBKDF2-SHA256 hash
- the previous password no longer authenticates
- the new password authenticates
- `must_change_password` is cleared after a successful change
- the existing UserRepository remains the authoritative persistence path

## Product code

**NO PRODUCT CODE CHANGE**

No new authentication engine, password store, or parallel user-management path was introduced.

## Regression

Focused Step 222 regression verifies the complete password-change contract, including first-run password-change state.

## Verification

```text
Focused regression: PASS
Compileall: PASS
```
