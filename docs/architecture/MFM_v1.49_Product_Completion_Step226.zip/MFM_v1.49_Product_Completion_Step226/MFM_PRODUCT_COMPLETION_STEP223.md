# MFM v1.49 — Product Completion Step 223

## Accounting Period Reopen Compatibility Boundary

### Boundary

Existing service boundary:

```python
AccountingService.reopen_period(period_id, actor=None)
```

### Finding

The active `reopen_period()` implementation handled only the newer
`accounting_periods` model and raised `Accounting period not found.` for IDs
belonging to the existing legacy `fiscal_periods` model.

This was inconsistent with the existing `close_period()` implementation,
which explicitly supports both models.

### Impact

A fiscal-year/month period created through the established legacy
`create_fiscal_year()` / `periods()` path could be closed successfully but
could not subsequently be reopened through the service boundary.

### Correction

The existing `reopen_period()` boundary was extended to mirror the established
compatibility behaviour of `close_period()`:

```text
accounting_periods
    -> reopen + accounting-period audit event

fiscal_periods
    -> reopen + fiscal-period audit event
```

No new service, repository, data model, or workflow was introduced.

### Regression

Added regression:

```text
test_legacy_fiscal_period_can_be_reopened_after_close
```

Verified:

- legacy fiscal period can be closed
- legacy fiscal period can be reopened
- status returns to `Open`
- `PERIOD_REOPENED` audit event is recorded

Focused result:

```text
1 passed
```

Related accounting-product regression:

```text
1 passed
```

Compile:

```text
python -m compileall -q src tests
PASS
```

### Product Code

```text
CHANGED — REAL COMPATIBILITY DEFECT FIXED
```

### Architectural decision

The existing dual period models remain unchanged. The fix preserves the
existing compatibility path rather than introducing a new abstraction.
