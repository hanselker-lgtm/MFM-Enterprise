import ast
from pathlib import Path

MAIN_WINDOW = Path(__file__).parents[1] / "src" / "gui" / "main_window.py"


def _main_window():
    tree = ast.parse(MAIN_WINDOW.read_text(encoding="utf-8"))
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MainWindow")


def test_top_search_adapter_exists_and_delegates_to_existing_global_search():
    cls = _main_window()
    method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "run_search")
    calls = [n for n in ast.walk(method) if isinstance(n, ast.Call)]
    assert any(
        isinstance(call.func, ast.Attribute)
        and call.func.attr == "show_global_search"
        and len(call.args) == 1
        for call in calls
    )


def test_global_search_accepts_initial_query_for_top_bar_reuse():
    cls = _main_window()
    method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "show_global_search")
    assert [arg.arg for arg in method.args.args][-1] == "initial_query"
    source = ast.unparse(method)
    assert "StringVar(value=str(initial_query or ''))" in source
