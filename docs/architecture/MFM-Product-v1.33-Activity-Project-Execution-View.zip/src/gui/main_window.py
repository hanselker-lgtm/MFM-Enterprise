import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import date

class MainWindow:
    def __init__(self, context):
        self.ctx = context
        self.root = tk.Tk()
        self.root.title("MFM — MaritimForeningsManager")
        self.root.geometry("1100x700")
        self.current_user = None
        self._login()

    def _login(self):
        win = tk.Toplevel(self.root)
        win.title("MFM Login")
        win.geometry("360x220")
        win.transient(self.root)
        win.grab_set()

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="MFM Login", font=("Segoe UI", 16, "bold")).pack(pady=(0,12))
        ttk.Label(frame, text="Username").pack(anchor="w")
        username = ttk.Entry(frame)
        username.pack(fill="x", pady=(0,8))
        ttk.Label(frame, text="Password").pack(anchor="w")
        password = ttk.Entry(frame, show="*")
        password.pack(fill="x")

        def do_login():
            user = self.ctx.users.authenticate(username.get(), password.get())
            if not user:
                messagebox.showerror("MFM Login", "Invalid username or password.")
                return
            self.current_user = user
            win.destroy()
            self._build()

        ttk.Button(frame, text="Login", command=do_login).pack(pady=14)
        win.protocol("WM_DELETE_WINDOW", self.root.destroy)
        username.focus_set()
        self.root.withdraw()

        def on_close():
            if win.winfo_exists():
                win.destroy()
            self.root.destroy()
        win.protocol("WM_DELETE_WINDOW", on_close)
        self.root.wait_window(win)
        if self.current_user:
            self.root.deiconify()

    def _build(self):
        top = ttk.Frame(self.root, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text="MFM — Management & Intelligence", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Button(top, text="Refresh", command=self.refresh).pack(side="right")
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(top, textvariable=self.search_var, width=35)
        search_entry.pack(side="right", padx=8)
        ttk.Button(top, text="Search", command=self.run_search).pack(side="right")
        search_entry.bind("<Return>", lambda event: self.run_search())

        nav = ttk.Frame(self.root, padding=(12,0))
        nav.pack(fill="x")
        for text, command in [
            ("Dashboard", self.show_dashboard),
            ("Projects", self.show_projects),
            ("Tasks", self.show_tasks),
            ("Risks", self.show_risks),
            ("Decisions", self.show_decisions),
            ("Accounting", self.show_accounting),
            ("Members", self.show_members),
            ("Membership Billing", self.show_membership_billing),
            ("Dunning", self.show_dunning),
            ("Member Administration", self.show_member_admin),
            ("Activities & Projects", self.show_activities),
            ("Project Financials", self.show_project_financials),
            ("Project Control", self.show_project_control),
            ("Project Work", self.show_project_work),
            ("Operational Workboard", self.show_operational_workboard),
            ("Operational Actions", self.show_operational_actions),
            ("Operational Alerts", self.show_operational_alerts),
            ("My Day", self.show_my_day),
            ("Daily Execution", self.show_daily_execution),
            ("Project Execution", self.show_project_execution),
            ("Bank", self.show_bank),
            ("Users", self.show_users),
            ("System", self.show_system),
            ("Export", self.show_export),
            ("Audit", self.show_audit),
            ("AI Assistant", self.show_ai),
            ("MFM Assistant", self.show_assistant),
            ("Bank Import & Matching", self.show_bank_import_matching),
            ("Year-End & Closing", self.show_year_end_closing),
            ("Financial Dashboard", self.show_financial_dashboard),
            ("Accounting Audit", self.show_accounting_audit),
            ("Voucher Documents", self.show_voucher_documents),
            ("Account Ledger", self.show_account_ledger),
            ("Journals & Vouchers", self.show_journals),
            ("Accounting Entry", self.show_accounting_entry),
            ("Accounting & Reports", self.show_accounting_reports),
            ("Forecast", self.show_forecast),
        ]:
            ttk.Button(nav, text=text, command=command).pack(side="left", padx=(0,6))

        self.body = ttk.Frame(self.root, padding=12)
        self.body.pack(fill="both", expand=True)
        self.show_dashboard()

def allowed(self, code):
    return self.ctx.permissions.can(self.current_user, code)

def denied(self):
    messagebox.showwarning("MFM Access", "You do not have permission for this function.")

    def clear(self):
        for child in self.body.winfo_children():
            child.destroy()

    def card(self, parent, title, value, row, col):
        f = ttk.LabelFrame(parent, text=title, padding=18)
        f.grid(row=row, column=col, sticky="nsew", padx=6, pady=6)
        ttk.Label(f, text=str(value), font=("Segoe UI", 22, "bold")).pack()
        return f

def show_dashboard(self):
    self.clear()
    ttk.Label(self.body, text="Management Dashboard", font=("Segoe UI", 18, "bold")).pack(anchor="w")

    snapshot = self.ctx.management.snapshot()
    grid = ttk.Frame(self.body)
    grid.pack(fill="x", pady=12)
    for c in range(4):
        grid.columnconfigure(c, weight=1)

    cards = [
        ("Projects", snapshot["projects"]),
        ("Open Tasks", snapshot["open_tasks"]),
        ("Open Risks", snapshot["open_risks"]),
        ("Pending Decisions", snapshot["pending_decisions"]),
        ("Members", snapshot["members"]),
        ("Open Invoices", snapshot["open_invoices"]),
        ("Unmatched Bank", snapshot["unmatched_bank"]),
        ("Result", f"{snapshot['result']:,.2f}"),
    ]
    for i, (title, value) in enumerate(cards):
        self.card(grid, title, value, i // 4, i % 4)

    ttk.Label(self.body, text="Attention Required", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(12, 6))
    attention = self.ctx.management.attention_items()
    tree = ttk.Treeview(self.body, columns=("priority","item"), show="headings", height=6)
    tree.heading("priority", text="Priority")
    tree.heading("item", text="Item")
    tree.column("priority", width=110)
    tree.column("item", width=700)
    for priority, item in attention:
        tree.insert("", "end", values=(priority, item))
    tree.pack(fill="x")

    ttk.Separator(self.body).pack(fill="x", pady=14)
    ttk.Label(
        self.body,
        text=f"Income {snapshot['income']:,.2f}  |  Expenses {snapshot['expenses']:,.2f}  |  Result {snapshot['result']:,.2f}",
        font=("Segoe UI", 11, "bold")
    ).pack(anchor="w")

    def table(self, columns, rows):
        tree = ttk.Treeview(self.body, columns=columns, show="headings")
        for c in columns:
            tree.heading(c, text=c.replace("_"," ").title())
            tree.column(c, width=180)
        for row in rows:
            tree.insert("", "end", values=[row[c] for c in columns])
        tree.pack(fill="both", expand=True, pady=10)
        return tree

    def show_projects(self):
        if not self.allowed("projects.view"):
            self.denied()
            return
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Projects", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="Project Finance", command=self.show_project_finance).pack(side="right", padx=(0,6))
        ttk.Button(head, text="New Project", command=self.new_project).pack(side="right")
        self.table(["id","name","status","budget"], self.ctx.projects.list())


def show_project_finance(self):
    self.clear()
    ttk.Label(self.body, text="Project Finance", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    projects = self.ctx.projects.list()
    if not projects:
        ttk.Label(self.body, text="Create a project first.").pack(anchor="w", pady=10)
        return
    project_names = {str(p["id"]): p["name"] for p in projects}
    selected = tk.StringVar(value=str(projects[0]["id"]))
    row = ttk.Frame(self.body); row.pack(fill="x", pady=10)
    ttk.Label(row, text="Project:").pack(side="left")
    combo = ttk.Combobox(row, textvariable=selected, values=list(project_names.keys()), state="readonly", width=10)
    combo.pack(side="left", padx=6)

    output = ttk.LabelFrame(self.body, text="Budget vs Actual", padding=12)
    output.pack(fill="x", pady=10)

    def refresh():
        for w in output.winfo_children(): w.destroy()
        pid = int(selected.get())
        result = self.ctx.accounting.project_budget_vs_actual(pid)
        ttk.Label(output, text=f"Budget: {result['budget']:,.2f}").pack(anchor="w")
        ttk.Label(output, text=f"Actual: {result['actual']:,.2f}").pack(anchor="w")
        ttk.Label(output, text=f"Variance: {result['variance']:,.2f}").pack(anchor="w")
        ttk.Label(output, text=f"Utilization: {result['utilization']:.1f}%").pack(anchor="w")

    ttk.Button(row, text="Refresh", command=refresh).pack(side="left")
    refresh()

    def new_project(self):
        if not self.allowed("projects.edit"):
            self.denied()
            return
        name = simpledialog.askstring("New Project", "Project name:")
        if not name: return
        try:
            self.ctx.projects.create(name)
            self.show_projects()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_tasks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Tasks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Task", command=self.new_task).pack(side="right")
        self.table(["id","title","status","due_date","owner"], self.ctx.tasks.list())

    def new_task(self):
        title = simpledialog.askstring("New Task", "Task title:")
        if not title: return
        try:
            self.ctx.tasks.create(title)
            self.show_tasks()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_risks(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Risks", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Risk", command=self.new_risk).pack(side="right")
        self.table(["id","title","severity","status","owner"], self.ctx.risks.list())

    def new_risk(self):
        title = simpledialog.askstring("New Risk", "Risk title:")
        if not title: return
        try:
            self.ctx.risks.create(title)
            self.show_risks()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))

    def show_decisions(self):
        self.clear()
        head = ttk.Frame(self.body); head.pack(fill="x")
        ttk.Label(head, text="Decisions", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(head, text="New Decision", command=self.new_decision).pack(side="right")
        self.table(["id","title","status","owner"], self.ctx.decisions.list())

    def new_decision(self):
        title = simpledialog.askstring("New Decision", "Decision title:")
        if not title: return
        try:
            self.ctx.decisions.create(title)
            self.show_decisions()
        except Exception as e:
            self.ctx.errors.handle(e, self.current_user, "GUI operation")
            messagebox.showerror("MFM", str(e))


def show_accounting(self):
    self.clear()
    ttk.Label(self.body, text="Accounting", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    buttons = ttk.Frame(self.body)
    buttons.pack(fill="x", pady=8)
    ttk.Button(buttons, text="Chart of Accounts", command=self.show_accounts).pack(side="left", padx=(0,6))
    ttk.Button(buttons, text="Journals", command=self.show_journals).pack(side="left", padx=(0,6))
    ttk.Button(buttons, text="Trial Balance", command=self.show_trial_balance).pack(side="left")
    ttk.Label(self.body, text="Accounting Core v0.1: balanced double-entry journals and trial balance.").pack(anchor="w", pady=10)

def show_accounts(self):
    self.clear()
    head = ttk.Frame(self.body); head.pack(fill="x")
    ttk.Label(head, text="Chart of Accounts", font=("Segoe UI", 16, "bold")).pack(side="left")
    ttk.Button(head, text="New Account", command=self.new_account).pack(side="right")
    self.table(["number","name","account_type"], self.ctx.accounting.accounts())

def new_account(self):
    number = simpledialog.askstring("New Account", "Account number:")
    if not number: return
    name = simpledialog.askstring("New Account", "Account name:")
    if not name: return
    account_type = simpledialog.askstring(
        "New Account", "Type (Asset, Liability, Income, Expense):",
        initialvalue="Expense")
    try:
        self.ctx.accounting.create_account(number, name, account_type)
        self.show_accounts()
    except Exception as e:
        messagebox.showerror("MFM Accounting", str(e))

def show_journals(self):
    self.clear()
    head = ttk.Frame(self.body); head.pack(fill="x")
    ttk.Label(head, text="Posted Journals", font=("Segoe UI", 16, "bold")).pack(side="left")
    ttk.Label(self.body, text="Journal entry creation UI is the next accounting increment.").pack(anchor="w", pady=8)
    self.table(["journal_no","journal_date","description","status"], self.ctx.accounting.journals())

def show_trial_balance(self):
    self.clear()
    ttk.Label(self.body, text="Trial Balance", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    self.table(["number","name","debit","credit"], self.ctx.accounting.trial_balance())

    def refresh(self):
        self.show_dashboard()

    def run(self):
        self.root.mainloop()


    def show_financial_dashboard(self):
        self.clear()
        ttk.Label(
            self.body, text="Financial Reporting & Management Dashboard",
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w")
        ttk.Label(
            self.body,
            text="Overblik over indtægter, omkostninger, resultat og balance."
        ).pack(anchor="w", pady=(2, 10))

        controls = ttk.Frame(self.body)
        controls.pack(fill="x", pady=6)

        ttk.Label(controls, text="Fra:").pack(side="left")
        start = ttk.Entry(controls, width=12)
        start.pack(side="left", padx=4)
        ttk.Label(controls, text="Til:").pack(side="left")
        end = ttk.Entry(controls, width=12)
        end.pack(side="left", padx=4)

        cards = ttk.Frame(self.body)
        cards.pack(fill="x", pady=10)

        values = {}
        for key, title in [
            ("revenue","Indtægter"),
            ("expenses","Omkostninger"),
            ("net_result","Årets resultat"),
            ("assets","Aktiver"),
            ("liabilities","Forpligtelser"),
            ("equity","Egenkapital")
        ]:
            frame = ttk.LabelFrame(cards, text=title)
            frame.pack(side="left", fill="x", expand=True, padx=3)
            label = ttk.Label(frame, text="0,00", font=("Segoe UI", 14, "bold"))
            label.pack(padx=8, pady=10)
            values[key] = label

        tree = ttk.Treeview(
            self.body,
            columns=("number","name","amount"),
            show="headings"
        )
        for col, title, width in [
            ("number","Konto",100),
            ("name","Navn",300),
            ("amount","Beløb",150)
        ]:
            tree.heading(col, text=title)
            tree.column(col, width=width)
        tree.pack(fill="both", expand=True, pady=8)

        def refresh():
            r = self.ctx.accounting.financial_dashboard(
                start.get().strip() or None,
                end.get().strip() or None
            )
            for k, label in values.items():
                label.config(text=f'{r[k]:,.2f}')
            for item in tree.get_children():
                tree.delete(item)
            for row in r["income_accounts"]:
                tree.insert("", "end", values=(
                    row["number"], row["name"], f'{row["amount"]:,.2f}'
                ))
            for row in r["expense_accounts"]:
                tree.insert("", "end", values=(
                    row["number"], row["name"], f'-{row["amount"]:,.2f}'
                ))

        ttk.Button(controls, text="Opdater", command=refresh).pack(side="left", padx=6)
        refresh()


def _mfm_member_clear(self):
    for child in self.body.winfo_children():
        child.destroy()

def _mfm_show_members(self):
    self._mfm_member_clear()
    self.ctx.members.refresh_invoice_statuses()

    ttk.Label(self.body, text="Members & Memberships",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,
              text="Medlemmer, medlemskaber, kontingenter, fakturaer og betalinger."
              ).pack(anchor="w",pady=(2,10))

    summary=self.ctx.members.summary()
    cards=ttk.Frame(self.body); cards.pack(fill="x",pady=6)
    for title,key in [
        ("Medlemmer","members"),("Aktive","active_members"),
        ("Aktive medlemskaber","active_memberships"),
        ("Åbne fakturaer","open_invoices"),
        ("Udestående","outstanding")
    ]:
        f=ttk.LabelFrame(cards,text=title)
        f.pack(side="left",fill="x",expand=True,padx=3)
        value=summary[key]
        txt=f"{float(value):,.2f}" if key=="outstanding" else str(value)
        ttk.Label(f,text=txt,font=("Segoe UI",13,"bold")).pack(padx=8,pady=8)

    toolbar=ttk.Frame(self.body); toolbar.pack(fill="x",pady=6)
    search=tk.StringVar()
    ttk.Label(toolbar,text="Søg:").pack(side="left")
    ttk.Entry(toolbar,textvariable=search,width=30).pack(side="left",padx=5)

    tree=ttk.Treeview(self.body,
        columns=("no","name","email","phone","status","joined"),
        show="headings")
    for c,t,w in [
        ("no","Medlemsnr.",100),("name","Navn",240),("email","E-mail",220),
        ("phone","Telefon",130),("status","Status",100),("joined","Indmeldt",110)
    ]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=6)

    selected_id={"value":None}

    def load():
        for x in tree.get_children(): tree.delete(x)
        rows=self.ctx.members.search(search.get()) if search.get().strip() else self.ctx.members.members()
        for r in rows:
            tree.insert("", "end", iid=str(r["id"]), values=(
                r["member_no"],f'{r["first_name"]} {r["last_name"]}',
                r["email"],r["phone"],r["status"],r["joined_date"] or ""
            ))

    def new_member():
        win=tk.Toplevel(self.root); win.title("Nyt medlem"); win.geometry("420x430")
        fields={}
        for label,key in [
            ("Medlemsnr.","member_no"),("Fornavn","first_name"),("Efternavn","last_name"),
            ("E-mail","email"),("Telefon","phone"),("Adresse","address"),
            ("Postnr.","postal_code"),("By","city"),("Indmeldelsesdato","joined_date")
        ]:
            ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
            e=ttk.Entry(win); e.pack(fill="x",padx=15); fields[key]=e
        fields["joined_date"].insert(0,date.today().isoformat())
        def save():
            try:
                self.ctx.members.create_member(
                    fields["member_no"].get(),fields["first_name"].get(),fields["last_name"].get(),
                    **{k:v.get() for k,v in fields.items() if k not in ("member_no","first_name","last_name")}
                )
                win.destroy(); load()
            except Exception as exc:
                messagebox.showerror("Medlem",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=14)

    def membership():
        sel=tree.selection()
        if not sel: return
        member_id=int(sel[0])
        types=self.ctx.members.membership_types()
        if not types:
            messagebox.showwarning("Medlemskab","Opret først en medlemskabstype.")
            return
        win=tk.Toplevel(self.root); win.title("Tilknyt medlemskab"); win.geometry("400x220")
        mapping={f'{x["name"]} — {float(x["annual_fee"]):,.2f}':x for x in types}
        var=tk.StringVar(value=list(mapping)[0])
        ttk.Label(win,text="Medlemskabstype").pack(anchor="w",padx=15,pady=8)
        ttk.Combobox(win,textvariable=var,values=list(mapping),state="readonly").pack(fill="x",padx=15)
        ttk.Label(win,text="Startdato").pack(anchor="w",padx=15,pady=(8,2))
        start=tk.Entry(win); start.pack(fill="x",padx=15); start.insert(0,date.today().isoformat())
        def save():
            try:
                self.ctx.members.add_membership(member_id,mapping[var.get()]["id"],start.get())
                win.destroy(); load()
            except Exception as exc: messagebox.showerror("Medlemskab",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=12)

    def invoice():
        sel=tree.selection()
        if not sel: return
        memberships=[m for m in self.ctx.members.memberships() if m["id"] and m["member_no"]==tree.item(sel[0])["values"][0]]
        if not memberships:
            messagebox.showwarning("Faktura","Medlemmet har intet aktivt medlemskab.")
            return
        m=memberships[0]
        self.ctx.members.invoice_membership(m["id"],m["id"] if False else
            next(x["id"] for x in self.ctx.members.repo.list_memberships() if x["member_no"]==m["member_no"] and x["membership_type"]==m["membership_type"]),
            float(m["annual_fee"]))
        load()

    def open_member():
        sel=tree.selection()
        if not sel: return
        member_id=int(sel[0])
        member=self.ctx.members.member(member_id)
        invoices=self.ctx.members.member_invoices(member_id)
        win=tk.Toplevel(self.root); win.title("Medlemsdetaljer"); win.geometry("850x500")
        ttk.Label(win,text=f'{member["member_no"]} — {member["first_name"]} {member["last_name"]}',
                  font=("Segoe UI",14,"bold")).pack(anchor="w",padx=12,pady=10)
        ttk.Label(win,text=f'{member["email"]} | {member["phone"]} | {member["address"]}, {member["postal_code"]} {member["city"]}').pack(anchor="w",padx=12)
        inv=ttk.Treeview(win,columns=("no","date","due","amount","paid","status"),show="headings")
        for c,t,w in [("no","Faktura",80),("date","Dato",100),("due","Forfald",100),("amount","Beløb",100),("paid","Betalt",100),("status","Status",130)]:
            inv.heading(c,text=t); inv.column(c,width=w)
        inv.pack(fill="both",expand=True,padx=12,pady=12)
        for r in invoices:
            status=self.ctx.members.invoice_status(r)
            inv.insert("", "end", values=(r["invoice_no"],r["invoice_date"],r["due_date"],
                f'{float(r["amount"]):,.2f}',f'{float(r["paid_amount"]):,.2f}',status))

    ttk.Button(toolbar,text="Nyt medlem",command=new_member).pack(side="left",padx=4)
    ttk.Button(toolbar,text="Tilknyt medlemskab",command=membership).pack(side="left",padx=4)
    ttk.Button(toolbar,text="Opret kontingentfaktura",command=invoice).pack(side="left",padx=4)
        ttk.Button(toolbar,text="Vis detaljer",command=open_member).pack(side="left",padx=4)
    ttk.Button(toolbar,text="Opdater",command=load).pack(side="left",padx=4)
    search.bind("<KeyRelease>",lambda e:load())
    tree.bind("<Double-1>",lambda e:open_member())
    load()

MainWindow._mfm_member_clear=_mfm_member_clear
MainWindow.show_members=_mfm_show_members


def _mfm_show_billing(self):
    self.clear()
    ttk.Label(self.body,text="Membership Billing & Payment Management",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Årlig masseopkrævning, betalingsstatus og restancer.").pack(anchor="w",pady=(2,10))

    controls=ttk.Frame(self.body); controls.pack(fill="x",pady=6)
    ttk.Label(controls,text="År:").pack(side="left")
    year=tk.StringVar(value=str(date.today().year))
    ttk.Entry(controls,textvariable=year,width=8).pack(side="left",padx=5)
    ttk.Label(controls,text="Fakturadato:").pack(side="left")
    invdate=tk.StringVar(value=date.today().isoformat())
    ttk.Entry(controls,textvariable=invdate,width=12).pack(side="left",padx=5)
    ttk.Label(controls,text="Forfald:").pack(side="left")
    due=tk.StringVar(value=date.today().isoformat())
    ttk.Entry(controls,textvariable=due,width=12).pack(side="left",padx=5)

    summary_frame=ttk.Frame(self.body); summary_frame.pack(fill="x",pady=6)
    summary_labels={}
    for key,title in [("invoices","Fakturaer"),("invoiced","Faktureret"),
                      ("paid_amount","Betalt"),("outstanding","Udestående")]:
        f=ttk.LabelFrame(summary_frame,text=title)
        f.pack(side="left",fill="x",expand=True,padx=3)
        lab=ttk.Label(f,text="0,00",font=("Segoe UI",13,"bold"))
        lab.pack(padx=8,pady=8); summary_labels[key]=lab

    tree=ttk.Treeview(self.body,
        columns=("member_no","name","type","amount","invoiced","invoice_no"),
        show="headings")
    for c,t,w in [("member_no","Medlemsnr.",100),("name","Navn",220),
                  ("type","Type",160),("amount","Beløb",110),
                  ("invoiced","Allerede faktureret",130),("invoice_no","Faktura",90)]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    preview_cache=[]
    def refresh():
        nonlocal preview_cache
        y=int(year.get())
        preview_cache=self.ctx.members.billing_preview(y,invdate.get(),due.get())
        for x in tree.get_children(): tree.delete(x)
        for r in preview_cache:
            tree.insert("", "end", values=(r["member_no"],r["name"],r["membership_type"],
                f'{r["amount"]:,.2f}',"Ja" if r["already_invoiced"] else "Nej",
                r["existing_invoice_no"] or ""))
        sm=self.ctx.members.payment_status_summary(y)
        for k,lab in summary_labels.items():
            lab.config(text=f'{sm[k]:,.2f}' if k!="invoices" else str(sm[k]))

    def bill():
        try:
            r=self.ctx.members.bill_memberships(int(year.get()),invdate.get(),due.get())
            refresh()
            messagebox.showinfo("Masseopkrævning",
                f'Oprettet: {r["created_count"]}\nSprunget over: {r["skipped_count"]}')
        except Exception as exc:
            messagebox.showerror("Masseopkrævning",str(exc))

    ttk.Button(controls,text="Preview",command=refresh).pack(side="left",padx=5)
    ttk.Button(controls,text="Opret alle kontingentfakturaer",command=bill).pack(side="left",padx=5)
    refresh()

MainWindow.show_membership_billing=_mfm_show_billing


def _mfm_show_dunning(self):
    self.clear()
    ttk.Label(self.body,text="Member Communication & Dunning",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Forfaldne kontingenter, påmindelser og rykkerhistorik."
              ).pack(anchor="w",pady=(2,10))
    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    ttk.Label(top,text="Pr. dato:").pack(side="left")
    asof=tk.StringVar(value=date.today().isoformat())
    ttk.Entry(top,textvariable=asof,width=12).pack(side="left",padx=5)

    tree=ttk.Treeview(self.body,
        columns=("invoice","member","due","days","amount","paid","outstanding"),
        show="headings")
    for c,t,w in [("invoice","Faktura",90),("member","Medlem",240),
                  ("due","Forfald",100),("days","Dage",70),
                  ("amount","Beløb",100),("paid","Betalt",100),
                  ("outstanding","Udestående",120)]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)
    cache={}

    def refresh():
        cache.clear()
        for x in tree.get_children(): tree.delete(x)
        rows=self.ctx.members.dunning_preview(asof.get())
        for idx,r in enumerate(rows):
            cache[str(idx)]=r
            tree.insert("", "end", iid=str(idx), values=(
                r["invoice_no"],r["name"],r["due_date"],r["days_overdue"],
                f'{r["amount"]:,.2f}',f'{r["paid_amount"]:,.2f}',
                f'{r["outstanding"]:,.2f}'
            ))

    def prepare(level):
        sel=tree.selection()
        if not sel: return
        row=cache[sel[0]]
        try:
            cid=self.ctx.members.record_dunning(row,level)
            messagebox.showinfo("Kommunikation",f"Kommunikation oprettet som kladde/log. ID: {cid}")
        except Exception as exc:
            messagebox.showerror("Kommunikation",str(exc))

    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    ttk.Button(top,text="Påmindelse",command=lambda:prepare(1)).pack(side="left",padx=5)
    ttk.Button(top,text="Rykker",command=lambda:prepare(2)).pack(side="left",padx=5)
    ttk.Button(top,text="Sidste påmindelse",command=lambda:prepare(3)).pack(side="left",padx=5)
    refresh()

MainWindow.show_dunning=_mfm_show_dunning


def _mfm_show_member_admin(self):
    self.clear()
    ttk.Label(self.body,text="Member & Association Administration",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Medlemsstatus, ind-/udmeldelse, kontaktdata og medlemskort."
              ).pack(anchor="w",pady=(2,10))

    overview=self.ctx.members.administration_overview()
    cards=ttk.Frame(self.body); cards.pack(fill="x",pady=5)
    for key,title in [("total","I alt"),("active","Aktive"),("inactive","Inaktive"),
                      ("suspended","Suspenderede"),("resigned","Udmeldte")]:
        f=ttk.LabelFrame(cards,text=title); f.pack(side="left",fill="x",expand=True,padx=3)
        ttk.Label(f,text=str(overview[key]),font=("Segoe UI",13,"bold")).pack(padx=8,pady=8)

    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    search=tk.StringVar()
    ttk.Label(top,text="Søg:").pack(side="left")
    ttk.Entry(top,textvariable=search,width=28).pack(side="left",padx=5)
    tree=ttk.Treeview(self.body,columns=("no","name","email","status","joined"),
                      show="headings")
    for c,t,w in [("no","Medlemsnr.",100),("name","Navn",220),
                  ("email","E-mail",220),("status","Status",110),("joined","Indmeldt",100)]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)
    cache={}

    def refresh():
        cache.clear()
        for x in tree.get_children(): tree.delete(x)
        rows=self.ctx.members.search(search.get()) if search.get().strip() else self.ctx.members.members()
        for r in rows:
            cache[str(r["id"])]=r
            tree.insert("", "end", iid=str(r["id"]),
                        values=(r["member_no"],f'{r["first_name"]} {r["last_name"]}',
                                r["email"],r["status"],r["joined_date"] or ""))

    def status_change(status):
        sel=tree.selection()
        if not sel: return
        try:
            self.ctx.members.change_member_status(int(sel[0]),status,
                reason=f"Status ændret via medlemsadministration til {status}.")
            refresh()
        except Exception as exc:
            messagebox.showerror("Medlemsstatus",str(exc))

    def show_card():
        sel=tree.selection()
        if not sel: return
        card=self.ctx.members.member_card(int(sel[0]))
        m=card["member"]
        lines=[
            f"Medlemsnr.: {m['member_no']}",
            f"Navn: {m['first_name']} {m['last_name']}",
            f"E-mail: {m['email']}",
            f"Telefon: {m['phone']}",
            f"Adresse: {m['address']}, {m['postal_code']} {m['city']}",
            f"Status: {m['status']}",
            "",
            f"Medlemskaber: {len(card['memberships'])}",
            f"Fakturaer: {len(card['invoices'])}",
            f"Administrationshændelser: {len(card['events'])}"
        ]
        messagebox.showinfo("Medlemskort","\n".join(lines))

    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=4)
    ttk.Button(top,text="Medlemskort",command=show_card).pack(side="left",padx=4)
    for status,label in [("Active","Aktiv"),("Inactive","Inaktiv"),
                         ("Suspended","Suspenderet"),("Resigned","Udmeldt")]:
        ttk.Button(top,text=label,command=lambda x=status:status_change(x)).pack(side="left",padx=2)
    search.bind("<Return>",lambda e:refresh())
    refresh()

MainWindow.show_member_admin=_mfm_show_member_admin


def _mfm_show_activities(self):
    self.clear()
    ttk.Label(self.body,text="Association Activities & Projects",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Projekter, aktiviteter, budgetter og fremdrift."
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    ttk.Label(top,text="Projekt:").pack(side="left")
    projects=self.ctx.projects.list()
    project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
    project_var=tk.StringVar(value=next(iter(project_map), ""))
    combo=ttk.Combobox(top,textvariable=project_var,values=list(project_map),
                       state="readonly",width=35)
    combo.pack(side="left",padx=5)

    stats=ttk.Frame(self.body); stats.pack(fill="x",pady=5)
    stat_labels={}
    for key,title in [("budget","Projektbudget"),("activity_budget","Aktivitetsbudget"),
                      ("activity_count","Aktiviteter")]:
        f=ttk.LabelFrame(stats,text=title); f.pack(side="left",fill="x",expand=True,padx=3)
        lab=ttk.Label(f,text="0,00",font=("Segoe UI",13,"bold"))
        lab.pack(padx=8,pady=8); stat_labels[key]=lab

    tree=ttk.Treeview(self.body,columns=("name","date","status","budget"),show="headings")
    for c,t,w in [("name","Aktivitet",260),("date","Dato",110),
                  ("status","Status",120),("budget","Budget",120)]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    def refresh():
        if not project_map: return
        pid=project_map.get(project_var.get())
        if not pid: return
        for x in tree.get_children(): tree.delete(x)
        rows=self.ctx.projects.activities(pid)
        for r in rows:
            tree.insert("", "end", iid=str(r["id"]),
                        values=(r["name"],r["activity_date"] or "",
                                r["status"],f'{float(r["budget"]):,.2f}'))
        proj=next((x for x in projects if x["id"]==pid),None)
        sm=self.ctx.projects.activity_summary(pid)
        stat_labels["budget"].config(text=f'{float(proj["budget"]):,.2f}' if proj else "0,00")
        stat_labels["activity_budget"].config(text=f'{float(sm["activity_budget"]):,.2f}')
        stat_labels["activity_count"].config(text=str(sm["activity_count"]))

    def new_activity():
        pid=project_map.get(project_var.get())
        if not pid: return
        win=tk.Toplevel(self.root); win.title("Ny aktivitet"); win.geometry("430x360")
        fields={}
        for label,key in [("Navn","name"),("Beskrivelse","description"),
                          ("Dato","activity_date"),("Budget","budget")]:
            ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
            e=ttk.Entry(win); e.pack(fill="x",padx=15); fields[key]=e
        fields["activity_date"].insert(0,date.today().isoformat())
        fields["budget"].insert(0,"0")
        def save():
            try:
                self.ctx.projects.create_activity(pid,fields["name"].get(),
                    fields["description"].get(),fields["activity_date"].get(),
                    "Planned",float(fields["budget"].get() or 0))
                win.destroy(); refresh()
            except Exception as exc: messagebox.showerror("Aktivitet",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=14)

    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    ttk.Button(top,text="Ny aktivitet",command=new_activity).pack(side="left",padx=5)
    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    refresh()

MainWindow.show_activities=_mfm_show_activities


def _mfm_show_project_financials(self):
    self.clear()
    ttk.Label(self.body,text="Project Financial Tracking",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Budget, faktisk projektforbrug og afvigelser."
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    ttk.Label(top,text="Projekt:").pack(side="left")
    projects=self.ctx.projects.list()
    project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
    var=tk.StringVar(value=next(iter(project_map),""))
    combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                       state="readonly",width=35)
    combo.pack(side="left",padx=5)

    cards=ttk.Frame(self.body); cards.pack(fill="x",pady=5)
    labels={}
    for key,title in [("budget","Budget"),("actual","Faktisk forbrug"),
                      ("variance","Rest / afvigelse"),("utilization","Forbrug %")]:
        f=ttk.LabelFrame(cards,text=title); f.pack(side="left",fill="x",expand=True,padx=3)
        lab=ttk.Label(f,text="0,00",font=("Segoe UI",13,"bold")); lab.pack(padx=8,pady=8)
        labels[key]=lab

    ttk.Label(self.body,text="Aktiviteter",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(10,2))
    act=ttk.Treeview(self.body,columns=("name","budget","actual","variance","status"),
                     show="headings",height=8)
    for c,t,w in [("name","Aktivitet",260),("budget","Budget",110),
                  ("actual","Forbrug",110),("variance","Rest",110),("status","Status",110)]:
        act.heading(c,text=t); act.column(c,width=w)
    act.pack(fill="both",expand=True,pady=5)

    ttk.Label(self.body,text="Projektposteringer",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
    lines=ttk.Treeview(self.body,columns=("date","journal","account","description","amount"),
                       show="headings",height=8)
    for c,t,w in [("date","Dato",100),("journal","Journal",80),("account","Konto",170),
                  ("description","Beskrivelse",280),("amount","Beløb",110)]:
        lines.heading(c,text=t); lines.column(c,width=w)
    lines.pack(fill="both",expand=True,pady=5)

    def refresh():
        pid=project_map.get(var.get())
        if not pid: return
        data=self.ctx.projects.financial_tracking(pid)
        labels["budget"].config(text=f'{data["budget"]:,.2f}')
        labels["actual"].config(text=f'{data["actual"]:,.2f}')
        labels["variance"].config(text=f'{data["variance"]:,.2f}')
        labels["utilization"].config(text=f'{data["utilization"]:.1f}%')
        for x in act.get_children(): act.delete(x)
        for r in self.ctx.projects.activity_financials(pid):
            act.insert("", "end", values=(r["name"],f'{float(r["budget"]):,.2f}',
                f'{float(r["actual"]):,.2f}',f'{float(r["variance"]):,.2f}',r["status"]))
        for x in lines.get_children(): lines.delete(x)
        for r in self.ctx.projects.expense_lines(pid):
            amount=float(r["debit"] or 0)-float(r["credit"] or 0)
            lines.insert("", "end", values=(r["journal_date"],r["journal_no"],
                f'{r["account_number"]} {r["account_name"]}',
                r["line_description"] or r["journal_description"],
                f'{amount:,.2f}'))

    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    refresh()

MainWindow.show_project_financials=_mfm_show_project_financials

def _mfm_show_project_control(self):
    self.clear()
    ttk.Label(self.body,text="Project Control & Budget Dashboard",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Samlet projektstyring: budget, forbrug, afvigelser og aktiviteter."
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    ttk.Label(top,text="Projekt:").pack(side="left")
    projects=self.ctx.projects.list()
    project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
    var=tk.StringVar(value=next(iter(project_map),""))
    combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                       state="readonly",width=38)
    combo.pack(side="left",padx=5)

    cards=ttk.Frame(self.body); cards.pack(fill="x",pady=5)
    labels={}
    for key,title in [("budget","Budget"),("actual","Forbrug"),
                      ("variance","Rest / afvigelse"),("utilization","Forbrug %"),
                      ("unallocated_actual","Ikke aktivitetsfordelt")]:
        f=ttk.LabelFrame(cards,text=title); f.pack(side="left",fill="x",expand=True,padx=2)
        lab=ttk.Label(f,text="0,00",font=("Segoe UI",12,"bold")); lab.pack(padx=6,pady=8)
        labels[key]=lab

    tree=ttk.Treeview(self.body,
        columns=("name","status","budget","actual","variance","utilization"),
        show="headings")
    for c,t,w in [("name","Aktivitet",240),("status","Status",100),
                  ("budget","Budget",105),("actual","Forbrug",105),
                  ("variance","Rest",105),("utilization","Forbrug %",100)]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=10)

    def refresh():
        pid=project_map.get(var.get())
        if not pid: return
        data=self.ctx.projects.project_control_dashboard(pid)
        for key in ("budget","actual","variance","unallocated_actual"):
            labels[key].config(text=f'{data[key]:,.2f}')
        labels["utilization"].config(text=f'{data["utilization"]:.1f}%')
        for x in tree.get_children(): tree.delete(x)
        for a in data["activities"]:
            tree.insert("", "end", values=(
                a["name"],a["status"],f'{a["budget"]:,.2f}',
                f'{a["actual"]:,.2f}',f'{a["variance"]:,.2f}',
                f'{a["utilization"]:.1f}%'))

    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    refresh()

MainWindow.show_project_control=_mfm_show_project_control

def _mfm_show_project_work(self):
    self.clear()
    ttk.Label(self.body,text="Project Work & Task Management",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Opgaver, ansvarlige, deadlines, prioritet og status."
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    ttk.Label(top,text="Projekt:").pack(side="left")
    projects=self.ctx.projects.list()
    project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
    var=tk.StringVar(value=next(iter(project_map),""))
    combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                       state="readonly",width=38); combo.pack(side="left",padx=5)

    tree=ttk.Treeview(self.body,columns=("title","activity","owner","priority","due","status"),
                      show="headings")
    for c,t,w in [("title","Opgave",260),("activity","Aktivitet",180),
                  ("owner","Ansvarlig",140),("priority","Prioritet",100),
                  ("due","Deadline",105),("status","Status",110)]:
        tree.heading(c,text=t); tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    def refresh():
        pid=project_map.get(var.get())
        if not pid:return
        for x in tree.get_children():tree.delete(x)
        for r in self.ctx.projects.project_tasks(pid):
            tree.insert("", "end", iid=str(r["id"]),
                values=(r["title"],r["activity_name"] or "",r["assigned_to"] or "",
                        r["priority"],r["due_date"] or "",r["status"]))

    def new_task():
        pid=project_map.get(var.get())
        if not pid:return
        win=tk.Toplevel(self.root); win.title("Ny opgave"); win.geometry("460x520")
        fields={}
        for label,key in [("Titel","title"),("Beskrivelse","description"),
                          ("Ansvarlig","assigned_to"),("Deadline","due_date")]:
            ttk.Label(win,text=label).pack(anchor="w",padx=15,pady=(8,2))
            e=ttk.Entry(win);e.pack(fill="x",padx=15);fields[key]=e
        ttk.Label(win,text="Prioritet").pack(anchor="w",padx=15,pady=(8,2))
        priority=tk.StringVar(value="Normal")
        ttk.Combobox(win,textvariable=priority,values=["Low","Normal","High","Critical"],
                     state="readonly").pack(fill="x",padx=15)
        ttk.Label(win,text="Aktivitet (valgfri ID)").pack(anchor="w",padx=15,pady=(8,2))
        activity=tk.StringVar(); ttk.Entry(win,textvariable=activity).pack(fill="x",padx=15)
        def save():
            try:
                aid=int(activity.get()) if activity.get().strip() else None
                self.ctx.projects.create_project_task(pid,fields["title"].get(),
                    fields["description"].get(),aid,fields["assigned_to"].get(),
                    priority.get(),fields["due_date"].get() or None,"Open")
                win.destroy();refresh()
            except Exception as exc:messagebox.showerror("Opgave",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=16)

    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    ttk.Button(top,text="Ny opgave",command=new_task).pack(side="left",padx=5)
    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    refresh()

MainWindow.show_project_work=_mfm_show_project_work

def _mfm_show_operational_workboard(self):
    self.clear()
    ttk.Label(self.body,text="Operational Workboard",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Det daglige overblik over opgaver, deadlines og aktive projekter."
              ).pack(anchor="w",pady=(2,10))

    cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
    labels={}
    for key,title in [("open_tasks","Åbne opgaver"),("critical_tasks","Kritiske"),
                      ("high_tasks","Høj prioritet"),("overdue_tasks","Forfaldne"),
                      ("next_7_days","Næste 7 dage"),("active_projects","Aktive projekter")]:
        f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
        lab=ttk.Label(f,text="0",font=("Segoe UI",14,"bold"));lab.pack(padx=6,pady=8)
        labels[key]=lab

    ttk.Label(self.body,text="Mine / åbne opgaver",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
    tasks=ttk.Treeview(self.body,columns=("title","project","activity","priority","due","status"),
                       show="headings",height=10)
    for c,t,w in [("title","Opgave",230),("project","Projekt",170),("activity","Aktivitet",150),
                  ("priority","Prioritet",90),("due","Deadline",100),("status","Status",100)]:
        tasks.heading(c,text=t);tasks.column(c,width=w)
    tasks.pack(fill="both",expand=True,pady=5)

    ttk.Label(self.body,text="Aktive projekter",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
    projects=ttk.Treeview(self.body,columns=("name","status","budget","actual","variance","util"),
                          show="headings",height=7)
    for c,t,w in [("name","Projekt",220),("status","Status",100),("budget","Budget",105),
                  ("actual","Forbrug",105),("variance","Rest",105),("util","Forbrug %",100)]:
        projects.heading(c,text=t);projects.column(c,width=w)
    projects.pack(fill="both",expand=True,pady=5)

    def refresh():
        data=self.ctx.projects.operational_workboard()
        for k,v in data["metrics"].items(): labels[k].config(text=str(v))
        for x in tasks.get_children():tasks.delete(x)
        for t in data["tasks"]:
            tasks.insert("", "end", values=(t["title"],t["project_name"] or "",
                t["activity_name"] or "",t["priority"],t["due_date"] or "",t["status"]))
        for x in projects.get_children():projects.delete(x)
        for p in data["projects"]:
            projects.insert("", "end", values=(p["name"],p["status"],
                f'{p["budget"]:,.2f}',f'{p["actual"]:,.2f}',
                f'{p["variance"]:,.2f}',f'{p["utilization"]:.1f}%'))
    ttk.Button(self.body,text="Opdater",command=refresh).pack(anchor="e",pady=5)
    refresh()

MainWindow.show_operational_workboard=_mfm_show_operational_workboard

def _mfm_show_operational_actions(self):
    self.clear()
    ttk.Label(self.body,text="Operational Actions & Workflow",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Arbejd direkte fra Workboard: åbn, start, blokér og afslut opgaver."
              ).pack(anchor="w",pady=(2,10))

    tree=ttk.Treeview(self.body,columns=("title","project","activity","priority","due","status"),
                      show="headings")
    for c,t,w in [("title","Opgave",240),("project","Projekt",170),
                  ("activity","Aktivitet",150),("priority","Prioritet",90),
                  ("due","Deadline",105),("status","Status",110)]:
        tree.heading(c,text=t);tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    action=ttk.Frame(self.body);action.pack(fill="x",pady=5)
    status=tk.StringVar(value="In Progress")
    ttk.Label(action,text="Ny status:").pack(side="left")
    ttk.Combobox(action,textvariable=status,
                 values=["Open","In Progress","Blocked","Completed","Closed"],
                 state="readonly",width=16).pack(side="left",padx=5)

    def refresh():
        for x in tree.get_children():tree.delete(x)
        data=self.ctx.projects.operational_workboard()
        for t in data["tasks"]:
            tree.insert("", "end", iid=str(t["id"]),
                values=(t["title"],t["project_name"] or "",t["activity_name"] or "",
                        t["priority"],t["due_date"] or "",t["status"]))
    def selected():
        sel=tree.selection()
        if not sel:
            messagebox.showinfo("Opgave","Vælg en opgave først.")
            return None
        return int(sel[0])
    def transition():
        tid=selected()
        if tid is None:return
        try:
            self.ctx.projects.transition_project_task(tid,status.get())
            refresh()
        except Exception as exc:messagebox.showerror("Workflow",str(exc))
    def complete():
        tid=selected()
        if tid is None:return
        try:
            self.ctx.projects.transition_project_task(tid,"Completed")
            refresh()
        except Exception as exc:messagebox.showerror("Workflow",str(exc))
    def open_task():
        tid=selected()
        if tid is None:return
        t=self.ctx.projects.task_detail(tid)
        messagebox.showinfo("Opgavedetaljer",
            f'Projekt: {t["project_name"] or ""}\n'
            f'Aktivitet: {t["activity_name"] or ""}\n'
            f'Opgave: {t["title"]}\n'
            f'Ansvarlig: {t["assigned_to"] or ""}\n'
            f'Prioritet: {t["priority"]}\n'
            f'Deadline: {t["due_date"] or ""}\n'
            f'Status: {t["status"]}\n\n{t["description"] or ""}')
    ttk.Button(action,text="Åbn detaljer",command=open_task).pack(side="left",padx=4)
    ttk.Button(action,text="Skift status",command=transition).pack(side="left",padx=4)
    ttk.Button(action,text="Færdig",command=complete).pack(side="left",padx=4)
    ttk.Button(action,text="Opdater",command=refresh).pack(side="left",padx=4)
    refresh()

MainWindow.show_operational_actions=_mfm_show_operational_actions

def _mfm_show_operational_alerts(self):
    self.clear()
    ttk.Label(self.body,text="Notifications, Deadlines & Follow-up",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Viser kun forhold, der kræver opmærksomhed."
              ).pack(anchor="w",pady=(2,10))

    summary=ttk.Frame(self.body);summary.pack(fill="x",pady=5)
    critical=ttk.LabelFrame(summary,text="Kritiske");critical.pack(side="left",fill="x",expand=True,padx=3)
    high=ttk.LabelFrame(summary,text="Høj prioritet");high.pack(side="left",fill="x",expand=True,padx=3)
    total=ttk.LabelFrame(summary,text="I alt");total.pack(side="left",fill="x",expand=True,padx=3)
    labs=[ttk.Label(critical,text="0",font=("Segoe UI",14,"bold")),
          ttk.Label(high,text="0",font=("Segoe UI",14,"bold")),
          ttk.Label(total,text="0",font=("Segoe UI",14,"bold"))]
    for l,f in zip(labs,[critical,high,total]):l.pack(pady=8)

    tree=ttk.Treeview(self.body,columns=("severity","title","project","due","message"),
                      show="headings")
    for c,t,w in [("severity","Niveau",90),("title","Hændelse",220),
                  ("project","Projekt",180),("due","Deadline",105),("message","Detalje",300)]:
        tree.heading(c,text=t);tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    def refresh():
        data=self.ctx.projects.operational_alerts()
        labs[0].config(text=str(data["counts"]["critical"]))
        labs[1].config(text=str(data["counts"]["high"]))
        labs[2].config(text=str(data["counts"]["total"]))
        for x in tree.get_children():tree.delete(x)
        for i,a in enumerate(data["alerts"]):
            tree.insert("", "end", iid=str(i),
                        values=(a["severity"],a["title"],a.get("project",""),
                                a.get("due_date",""),a.get("message","")))
    ttk.Button(self.body,text="Opdater",command=refresh).pack(anchor="e",pady=5)
    refresh()

MainWindow.show_operational_alerts=_mfm_show_operational_alerts

def _mfm_show_my_day(self):
    self.clear()
    ttk.Label(self.body,text="Personal Work Queue & My Day",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Dit personlige arbejdsbord: hvad skal jeg gøre nu og den næste uge?"
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
    ttk.Label(top,text="Ansvarlig:").pack(side="left")
    people=sorted({(x.get("assigned_to") or "").strip() for x in self.ctx.projects.operational_workboard()["tasks"]
                   if (x.get("assigned_to") or "").strip()})
    person=tk.StringVar(value=people[0] if people else "")
    combo=ttk.Combobox(top,textvariable=person,values=people,width=28)
    combo.pack(side="left",padx=5)

    cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
    labels={}
    for key,title in [("overdue","Forfaldne"),("today","I dag"),
                      ("next_7_days","Næste 7 dage"),("critical","Kritiske"),("blocked","Blokerede")]:
        f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
        l=ttk.Label(f,text="0",font=("Segoe UI",13,"bold"));l.pack(pady=8);labels[key]=l

    tree=ttk.Treeview(self.body,columns=("title","project","activity","priority","due","status"),
                      show="headings")
    for c,t,w in [("title","Opgave",240),("project","Projekt",170),("activity","Aktivitet",150),
                  ("priority","Prioritet",90),("due","Deadline",105),("status","Status",105)]:
        tree.heading(c,text=t);tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    def refresh():
        if not person.get().strip(): return
        data=self.ctx.projects.my_day(person.get().strip())
        for k in labels:labels[k].config(text=str(data["metrics"][k]))
        for x in tree.get_children():tree.delete(x)
        for t in data["tasks"]:
            tree.insert("", "end", iid=str(t["id"]),
                        values=(t["title"],t["project_name"] or "",t["activity_name"] or "",
                                t["priority"],t["due_date"] or "",t["status"]))
    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    refresh()

MainWindow.show_my_day=_mfm_show_my_day

def _mfm_show_daily_execution(self):
    self.clear()
    ttk.Label(self.body,text="Quick Actions & Daily Execution",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Udfør de vigtigste handlinger direkte fra din arbejdsdag."
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body); top.pack(fill="x",pady=6)
    ttk.Label(top,text="Ansvarlig:").pack(side="left")
    people=sorted({(x.get("assigned_to") or "").strip()
                   for x in self.ctx.projects.operational_workboard()["tasks"]
                   if (x.get("assigned_to") or "").strip()})
    person=tk.StringVar(value=people[0] if people else "")
    combo=ttk.Combobox(top,textvariable=person,values=people,width=28)
    combo.pack(side="left",padx=5)

    tree=ttk.Treeview(self.body,columns=("title","project","priority","due","status"),
                      show="headings")
    for c,t,w in [("title","Opgave",260),("project","Projekt",190),
                  ("priority","Prioritet",95),("due","Deadline",105),("status","Status",115)]:
        tree.heading(c,text=t);tree.column(c,width=w)
    tree.pack(fill="both",expand=True,pady=8)

    action=ttk.Frame(self.body); action.pack(fill="x",pady=5)
    def selected():
        sel=tree.selection()
        if not sel:
            messagebox.showinfo("Daglig udførelse","Vælg en opgave først.")
            return None
        return int(sel[0])
    def run_action(name,value=None):
        tid=selected()
        if tid is None:return
        try:
            self.ctx.projects.quick_action(tid,name,value)
            refresh()
        except Exception as exc:
            messagebox.showerror("Quick Action",str(exc))
    ttk.Button(action,text="▶ Start",command=lambda:run_action("start")).pack(side="left",padx=3)
    ttk.Button(action,text="■ Bloker",command=lambda:run_action("block")).pack(side="left",padx=3)
    ttk.Button(action,text="✓ Færdig",command=lambda:run_action("complete")).pack(side="left",padx=3)
    ttk.Button(action,text="↶ Åbn igen",command=lambda:run_action("reopen")).pack(side="left",padx=3)

    def edit():
        tid=selected()
        if tid is None:return
        win=tk.Toplevel(self.root);win.title("Hurtig redigering");win.geometry("400x300")
        ttk.Label(win,text="Deadline (YYYY-MM-DD)").pack(anchor="w",padx=15,pady=(12,2))
        due=tk.StringVar();ttk.Entry(win,textvariable=due).pack(fill="x",padx=15)
        ttk.Label(win,text="Prioritet").pack(anchor="w",padx=15,pady=(10,2))
        pr=tk.StringVar(value="Normal")
        ttk.Combobox(win,textvariable=pr,values=["Low","Normal","High","Critical"],
                     state="readonly").pack(fill="x",padx=15)
        ttk.Label(win,text="Ansvarlig").pack(anchor="w",padx=15,pady=(10,2))
        owner=tk.StringVar(value=person.get());ttk.Entry(win,textvariable=owner).pack(fill="x",padx=15)
        def save():
            try:
                if due.get().strip():run_action("deadline",due.get().strip())
                run_action("priority",pr.get())
                run_action("assign",owner.get())
                win.destroy();refresh()
            except Exception as exc:messagebox.showerror("Redigering",str(exc))
        ttk.Button(win,text="Gem",command=save).pack(pady=15)
    ttk.Button(action,text="Redigér",command=edit).pack(side="left",padx=8)
    ttk.Button(action,text="Opdater",command=lambda:refresh()).pack(side="left",padx=3)

    def refresh():
        if not person.get().strip():return
        data=self.ctx.projects.my_day(person.get().strip())
        for x in tree.get_children():tree.delete(x)
        for t in data["tasks"]:
            tree.insert("", "end",iid=str(t["id"]),
                        values=(t["title"],t["project_name"] or "",t["priority"],
                                t["due_date"] or "",t["status"]))
    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    refresh()

MainWindow.show_daily_execution=_mfm_show_daily_execution

def _mfm_show_project_execution(self):
    self.clear()
    ttk.Label(self.body,text="Activity & Project Execution",
              font=("Segoe UI",18,"bold")).pack(anchor="w")
    ttk.Label(self.body,text="Projektfremdrift, aktiviteter, opgaver og økonomi i ét samlet billede."
              ).pack(anchor="w",pady=(2,10))

    top=ttk.Frame(self.body);top.pack(fill="x",pady=6)
    ttk.Label(top,text="Projekt:").pack(side="left")
    projects=self.ctx.projects.list()
    project_map={f'{x["id"]} — {x["name"]}':x["id"] for x in projects}
    var=tk.StringVar(value=next(iter(project_map),""))
    combo=ttk.Combobox(top,textvariable=var,values=list(project_map),
                       state="readonly",width=38);combo.pack(side="left",padx=5)

    cards=ttk.Frame(self.body);cards.pack(fill="x",pady=5)
    labels={}
    for key,title in [("task_progress","Opgavefremdrift"),("budget","Budget"),
                      ("actual","Forbrug"),("variance","Rest"),("utilization","Forbrug %")]:
        f=ttk.LabelFrame(cards,text=title);f.pack(side="left",fill="x",expand=True,padx=2)
        l=ttk.Label(f,text="0",font=("Segoe UI",12,"bold"));l.pack(pady=8);labels[key]=l

    ttk.Label(self.body,text="Aktiviteter",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
    acts=ttk.Treeview(self.body,columns=("name","status","progress","budget","actual","variance"),
                      show="headings",height=7)
    for c,t,w in [("name","Aktivitet",220),("status","Status",100),("progress","Fremdrift",95),
                  ("budget","Budget",105),("actual","Forbrug",105),("variance","Rest",105)]:
        acts.heading(c,text=t);acts.column(c,width=w)
    acts.pack(fill="x",pady=4)

    ttk.Label(self.body,text="Opgaver",font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(8,2))
    tasks=ttk.Treeview(self.body,columns=("title","activity","owner","priority","due","status"),
                       show="headings",height=9)
    for c,t,w in [("title","Opgave",240),("activity","Aktivitet",160),("owner","Ansvarlig",130),
                  ("priority","Prioritet",90),("due","Deadline",105),("status","Status",110)]:
        tasks.heading(c,text=t);tasks.column(c,width=w)
    tasks.pack(fill="both",expand=True,pady=4)

    def refresh():
        pid=project_map.get(var.get())
        if not pid:return
        d=self.ctx.projects.project_execution_view(pid)
        labels["task_progress"].config(text=f'{d["task_progress"]:.1f}%')
        labels["budget"].config(text=f'{d["budget"]:,.2f}')
        labels["actual"].config(text=f'{d["actual"]:,.2f}')
        labels["variance"].config(text=f'{d["variance"]:,.2f}')
        labels["utilization"].config(text=f'{d["utilization"]:.1f}%')
        for x in acts.get_children():acts.delete(x)
        for a in d["activities"]:
            acts.insert("", "end",values=(a["name"],a["status"],f'{a["progress"]:.1f}%',
                f'{a["budget"]:,.2f}',f'{a["actual"]:,.2f}',f'{a["variance"]:,.2f}'))
        for x in tasks.get_children():tasks.delete(x)
        for t in d["tasks"]:
            tasks.insert("", "end",values=(t["title"],t["activity_name"] or "",
                t["assigned_to"] or "",t["priority"],t["due_date"] or "",t["status"]))
    combo.bind("<<ComboboxSelected>>",lambda e:refresh())
    ttk.Button(top,text="Opdater",command=refresh).pack(side="left",padx=5)
    refresh()

MainWindow.show_project_execution=_mfm_show_project_execution
